""""
Input-output Module
===================

The following module provides the possibility to work with ``RAT`` files, widely
used by DLR-HR institute and some others.

:author: Andreas Reigber <andreas.reigber@dlr.de>
:author: Anton Heister <anton.heister@dlr.de>

"""

from __future__ import absolute_import
from __future__ import print_function
from functools import reduce
import ctypes
import os
from scipy import misc
import numpy as np
import warnings
import mmap
import h5py


red = "\033[91m"
endc = "\033[0m"

def write_pixmap(filename, image_array, palette=True):
    """Save a ``numpy`` 2D array as jpg/png/etc.

    Parameters
    ----------
    filename : str
        Output filename.
    image : ndarray, MxN or MxNx3 or MxNx4
        Array containing image values. If the shape is ``MxN``, the array
        represents a grey-level image. Shape ``MxNx3`` stores the red, green
        and blue bands along the last dimension. An alpha layer may be
        included, specified as the last colour band of an ``MxNx4`` array.
    """
    from .visualisation import myPalette

    if palette is True and myPalette is not False:
        p = myPalette
        misc.imsave(filename, p[image_array])
    else:
        misc.imsave(filename, image_array)


write_png = write_pixmap
write_jpg = write_pixmap


def rarr(filename, **kwargs):
    """
    Reads STE-HDF5 file, returns it as a np ndarray variable
    """
    file = Hdf(filename)
    array = file.read(**kwargs)
    return array


def sarr(filename, array, **kwargs):
    """
    Writes a numpy ndarray into a STE-HDF5 file.
    """
    file = Hdf(filename)
    file.write(array, **kwargs)


class Hdf():
    """
    Class to read/write single numpy arrays to HDF5  files in simple manner. Should work mostly like rrat/srat
    when using the helper routines rarr / sarr.
    """
    file = None
    def __init__(self, filename):
        if not filename.endswith(".hd5"):
            filename += ".hd5"
        self.filename = filename
        self.file = h5py.File(self.filename, 'a')
        self.data = None

    def read(self, **kwargs):
        # if 'block' in kwargs:
        #     block = kwargs['block']
        #     self.data = self.file['data']
        #     shp = self.data.shape
        #     if len(shp) == 1:    # 1D data -> use only 1st block parameter
        #         return self.data[block[0]:block[0]+block[2]]
        #     elif len(shp) == 2:  # 2D data -> easy
        #         return self.data[block[0]:block[0]+block[2], block[1]:block[1]+block[3]]
        #     else:                # >2D data -> check for pixel or band interleave
        #         p1 = reduce(mul, shp[-2:], 1)
        #         p2 = reduce(mul, shp[:-2], 1)
        #         p3 = reduce(mul, shp[0:2], 1)
        #         p4 = reduce(mul, shp[2:], 1)
        #         foo = [p1, p2, p3, p4]
        #         idx = foo.index(min(foo))
        #         if idx == 0 or idx == 3:  # pixel interleave
        #             return self.data[block[0]:block[0]+block[2], block[1]:block[1]+block[3], ...]
        #         else:                     # band interleave
        #             return self.data[..., block[0]:block[0]+block[2], block[1]:block[1]+block[3]]
        # else:
        data = []
        for ds in self.file:
            data.append(self.file[ds][...])
        if len(data) == 1:
            return data[0]
        elif len(data) == 0:
            return None
        else:
            return data

    def write(self, array, **kwargs):
        # if 'block' in kwargs:
        #     print("ERROR: block write not yet implemented")
        # else:
        for ds in self.file:
            del self.file[ds]
        if not isinstance(array, list):
            array = [array]
        for k, arr in enumerate(array):
            self.data = self.file.create_dataset("D"+str(k+1), data=arr)

    def expose(self):
        return self.file['data']

    def __del__(self):
        if self.file is not None:
            self.file.close()


def rrat(filename, **kwargs):
    """Read an entire RAT file, return it as a numpy array."""
    rat_file = RatFile(filename)
    return rat_file.read(**kwargs)


def srat(filename, array, **kwargs):
    """Write a numpy ndarray into a RAT file."""
    rat_file = RatFile(filename)
    rat_file.write(array, **kwargs)


class RatHeaderRat(ctypes.Structure):
    """
    A base class to store RAT header's attributes.

    The class is a child of ``ctypes.Structure``. This is made to write and read
    RAT headers correctly and easily preserving the size of each field in bytes.

    :param magiclong: used for RAT version control
    :type magiclong: int
    :param version: RAT version (currently 1.0 and 2.0 versions are available)
    :type version: float
    :param ndim: number of array's dimension
    :type ndim: int
    :param nchannel: number of channels
    :type nchannel: int
    :param shape: the shape of the data array
    :type shape: list
    :param var: specifies data type according to IDL's convention. More
      information here <http://www.exelisvis.com/docs/IDL_Data_Types.html>
    :type var: int
    :param sub: to be implemented
    :type sub: int
    :param rattype: to be implemented
    :type rattype: int

    .. note:: Due to some degree of redundancy in RatHeader  (there are 3
      connected attributes: ``shape``, ``ndim``, ``nchannel``), the priority in
      determining the value of ``ndim`` and ``nchannel`` parameters is given to
      ``shape`` parameter. That means that ``ndim`` is calculated as
      ``len(shape)`` and ``nchannel`` can be given as ``**kwargs``, if not given
      then it is equal either to ``shape[-1]`` if ``ndim > 2`` or to ``0`` if
      ``ndim < 2``.
    """
    _pack_ = 1
    _fields_ = [("magiclong", ctypes.c_int),
                ("version", ctypes.c_float),
                ("ndim", ctypes.c_int),
                ("nchannel", ctypes.c_int),
                ("shape", ctypes.c_int * 8),
                ("var", ctypes.c_int),
                ("sub", ctypes.c_int * 2),
                ("rattype", ctypes.c_int),
                ("reserved", ctypes.c_int * 9)]

    def __init__(self, **kwargs):
        """Create an object of RatHeaderRat class.

        Create RatHeaaderRat instance. Due to redundancy of ``RAT`` header
        (there are 3 connected attributes: ``shape``, ``ndim``, ``nchannel``).
        Until the latter 2 are not specified explicitly, their value is
        calculated based on ``shaped``.

        To specify the data type of a ``RAT`` file one may use either ``dtype``
        keyword with numpy data type or a string as a value, or a ``var``
        keyword according to IDL's regulations.

        **Keywords**:
          :param shape: a shape of a ``RAT`` file.
          :type shape: list
          :param ndim: number of dimensions, if not given, then parsed from
            ``shape``
          :type ndim: int
          :param nchannel: number of channels, if not given, then parsed from
            ``shape``.
          :type nchannel: int
          :param var: a data type according to IDL's regulation
          :type var: int
          :param dtype: a data type of a ``RAT`` file.
          :type dtype: numpy.dtype or a string
          :param dtype: a data type of a ``RAT`` file.
          :type dtype: numpy.dtype or a string
          :param sub: ...
          :param sub: list
          :param rattype: type of a ``RAT`` file
          :type rattype: int

        """
        self.magiclong = 844382546
        self.version = 2.0
        # checking kwargs
        if 'shape' in kwargs:
            # reverse the shape so it corresponds to RAT convention
            self.shape = (ctypes.c_int * 8)(*kwargs['shape'][::-1])
            if 'ndim' in kwargs:
                self.ndim = ctypes.c_int(kwargs['ndim'])
            else:
                self.ndim = ctypes.c_int(len(kwargs['shape']))

            if 'nchannel' in kwargs:
                self.nchannel = ctypes.c_int(kwargs['nchannel'])
            else:
                if len(kwargs['shape']) <= 2:
                    self.nchannel = ctypes.c_int(0)
                else:
                    self.nchannel = ctypes.c_int(kwargs['shape'][-1])
        if 'var' in kwargs:
            self.var = ctypes.c_int(kwargs['var'])
        if 'rattype' in kwargs:
            self.rattype = ctypes.c_int(kwargs['rattype'])
        if 'sub' in kwargs:
            self.sub = (ctypes.c_int * 2)(*kwargs['sub'])
        else:
            self.sub = (ctypes.c_int * 2)(1, 1)
        if 'dtype' in kwargs:
            if type(kwargs['dtype']) == type:
                data_type = np.dtype(kwargs['dtype']).name
            elif type(kwargs['dtype'] == str):
                data_type = kwargs['dtype']
            self.var = get_var(data_type)

class RatHeaderInfo(ctypes.Structure):
    """Contains a 100 character line for RatFile description.
    """
    _pack_ = 1
    _fields_ = [("info", ctypes.c_char * 100)]


class RatHeaderGeo(ctypes.Structure):
    """Contains positioning information.

    :param projection:
    :type projection:
    :param ps_east:
    :type ps_east:
    :param ps_north:
    :type ps_north:
    :param min_east:
    :type min_east:
    :param min_north:
    :type min_north:
    :param zone:
    :type zone:
    :param hemisphere:
    :type hemisphere:
    :param long0scl:
    :type long0scl:
    :param max_axis_ell:
    :type max_axis_ell:
    :param min_axis_ell:
    :type min_axis_ell:
    :param dshift_tx:
    :type dshift_tx:
    :param dshift_ty:
    :type dshift_ty:
    :param dshift_tz:
    :type dshift_tz:
    :param dshift_rx:
    :type dshift_rx:
    :param dshift_ry:
    :type dshift_ry:
    :param dshift_rz:
    :type dshift_rz:
    :param dshift_scl:
    :type dshift_scl:
    :param dshift_info:
    :type dshift_info:
    """
    _pack_ = 1
    _fields_ = [("projection", ctypes.c_short),
                ("ps_east", ctypes.c_double),
                ("ps_north", ctypes.c_double),
                ("min_east", ctypes.c_double),
                ("min_north", ctypes.c_double),
                ("zone", ctypes.c_short),
                ("hemisphere", ctypes.c_short),
                ("long0scl", ctypes.c_double),
                ("max_axis_ell", ctypes.c_double),
                ("min_axis_ell", ctypes.c_double),
                ("dshift_tx", ctypes.c_double),
                ("dshift_ty", ctypes.c_double),
                ("dshift_tz", ctypes.c_double),
                ("dshift_rx", ctypes.c_double),
                ("dshift_ry", ctypes.c_double),
                ("dshift_rz", ctypes.c_double),
                ("dshift_scl", ctypes.c_double),
                ("dshift_info", ctypes.c_char * 64),
                ("reserved", ctypes.c_byte * 18)]


class RatHeaderEmpty(ctypes.Structure):
    _pack_ = 1
    _fields_ = [("reserved", ctypes.c_int * 25)]


class RatHeader(ctypes.Structure):
    """Contains RatHeaderRat, RatHeaderInfo and RatHeaderGeo.

        Create RatHeaaderRat instance. Due to redundancy of ``RAT`` header
        (there are 3 connected attributes: ``shape``, ``ndim``, ``nchannel``).
        Until the latter 2 are not specified explicitly, their value is
        calculated based on ``shaped``.

        To specify the data type of a ``RAT`` file one may use either ``dtype``
        keyword with numpy data type or a string as a value, or a ``var``
        keyword according to IDL's regulations.

        **Keywords**:
          :param shape: a shape of a ``RAT`` file.
          :type shape: list
          :param ndim: number of dimensions, if not given, then parsed from
            ``shape``
          :type ndim: int
          :param nchannel: number of channels, if not given, then parsed from
            ``shape``.
          :type nchannel: int
          :param var: a data type according to IDL's regulation
          :type var: int
          :param dtype: a data type of a ``RAT`` file.
          :type dtype: numpy.dtype or a string
          :param sub: ...
          :param sub: list
          :param rattype: type of a ``RAT`` file
          :type rattype: int

        """
    _pack_ = 1
    _fields_ = [("Rat", RatHeaderRat),
                ("Info", RatHeaderInfo),
                ("Geo", RatHeaderGeo),
                ("Stat", RatHeaderEmpty),
                ("Reserved1", RatHeaderEmpty),
                ("Reserved2", RatHeaderEmpty),
                ("Reserved3", RatHeaderEmpty),
                ("Reserved4", RatHeaderEmpty),
                ("Reserved5", RatHeaderEmpty)]

    def __init__(self, **kwargs):
        self.Rat = RatHeaderRat(**kwargs)


class RatFile():
    """    Class for manipulating RAT formatted files."""

    def __init__(self, filename):
        """Initialize a RAT file.

        If the file exists reads the file's header, if not then initializes
        the empty ``RatFile`` **instance** with a given filename.

        :param filename: either a RAT filename (with \*.rat extension) if the
          file is in current working directory or an absolute path of the file.
        :type filename: string
        :return: RatFile instance

        .. note:: If the file doesn't exist the function creates a new
          ``RatFile`` instance with an empty header, not an empty file.
        """
        self.filename = filename
        self.Header = RatHeader()
        # the shape of numpy array
        self.shape = ()
        if os.path.exists(self.filename):
            self.version, self.xdrflag = self.get_version()
            self.read_header()
            self.shape = self._get_shape()
            self.dtype = self._get_dtype()
            self.exists = True
        else:
            self.exists = False

    def create(self, shape=None, header=None, **kwargs):
        """Create an empty ``RAT`` file and write a RAT header into it.

        Create an empty ``rat`` file with given parameters and write a RAT
        header. Either ``RatHeader`` instance or ``shape`` list should be
        given as an argument. If both are given, then the value of ``shape``
        overrides the ``RatHeaderRat.shape`` value. It is necessary to specify
        a ``dtype`` keyword if the proper datatype wasn't specified in
        header's ``RatHeaderRat.var`` attribute).

        :param shape: the shape of the data to store in \*.rat file
        :type shape: list
        :param header: a rat header
        :type header: RatHeaderRat
        :keyword dtype: data type
        :type dtype: type or string

        :return: None

        :raises: IOError

        .. note::

          1) The ``dtype`` keyword maybe given either as a string
             (i.e. 'int16') or as a numpy ``type`` instance (i.e. ``np.int16``).

          2) The function creates an empty binary file which is a sparse file
             for Linux and Windows, OS X however doesn't support sparse files
             so it will be just an empty file there.

        """
        # raise an error if neither header nor shape is given as an arg
        if (header is None) and (shape is None):
            print(red + 'Please, specify either shape or header!' + endc)
            raise IOError

        if header is not None:
            self.Header = header
            self.shape = self._get_shape()

        if shape is not None:
            self.Header.Rat.shape = (ctypes.c_int * 8)(*shape[::-1])
            self.shape = tuple(shape)

        if 'dtype' in kwargs:
            if type(kwargs['dtype']) == type:
                data_type = np.dtype(kwargs['dtype']).name
            elif type(kwargs['dtype'] == str):
                data_type = kwargs['dtype']
            self.Header.Rat.var = get_var(data_type)

        self.dtype = self._get_dtype()

        if 'rattype' in kwargs:
            self.Header.Rat.rattype = ctypes.c_int(kwargs['rattype'])

        # calculate the needed size of an empty file
        n_bytes = reduce(lambda x, y: x * y, self.shape) * self.dtype.itemsize

        # write the Header and truncate the file
        with open(self.filename, 'wb') as lun:
            lun.write(self.Header)
            lun.truncate(n_bytes)
            self.exists = True
        return


    def write(self, arr=[], **kwargs):
        """Write either a whole data array or a block of data into a rat file.

        The following usages are available:

        Write a whole data array either with or without the ``header`` keyword.
        In latter case the parameters of the array (shape and dtype), are parsed
        into an empy ``header`` instance and written to the file. In this case
        it's also possible to explicitly specify ``rattype`` keyword.

        When specifing the ``header`` keyword it is also possible to specify
        ``shape``, ``dtype`` and ``rattype`` keywords so the values of these
        parameters contained in ``header`` will be overwritten.

        When using a ``block`` keyword it is supposed that the header was
        already written (the entire shape of the ``RAT`` file should be known
        prior block writting).

        To write only a ``header`` one should use ``rat.write(header=header)``
        command, where ``rat`` is a ``RatFile`` instance and ``header`` is a
        ``RatHeader`` instance.

        Using a ``block`` keyword for 2D arrays the offset in both axes is
        possible (i.e. if the shape specified in header is [100,200], then a
        block can be equal to [20,50, 130, 200]). In other cases only an offset
        along the first axis is supported. The data type of the ``arr`` should
        correspond to the one given in previously written ``header``, otherwise
        an error will be raised.

        :param arr: array to be stored in rat file
        :type arr: numpy.ndarray

        **Keywords**:
          :param block: a position, where to write an array; has the following
            form ``[start_1, stop_1, ..., ..., start_N, stop_N]``, where ``N``
            is a number of array's dimensions.
          :type block: list
          :param header: RAT header
          :type header: RatHeaderRat
          :param shape: shape to overwrite the shape of the header
          :type shape: list
          :param dtype: data type to be written into header
          :param rattype: numpy.dtype or a string
          :param rattype: specifies RAT file type
          :type rattype: int


        :raises: IOError

        """
        # block writing
        if 'block' in kwargs:
            # check if datatype of arr and of 'var' are the same
            self._check_dtypes(arr)

            block = kwargs['block']
            # check if the block var meets the requirements
            self._check_block(block, arr=arr)

            if 'header' in kwargs:
                print(red + 'The header should have been written prior to block '
                            'writting!' + endc)
                raise IOError

            # for 2D arrays an offset for both axes is allowed
            if arr.ndim == 2:
                # create zero-filled numpy array of self.shape
                # and fill it with arr.data corresponding to block array values
                temp = np.zeros(
                    [arr.shape[0], self.shape[1]], dtype=arr.dtype)
                temp[:, block[2]:block[3]] = arr
                arr = temp
                offset = 1000 + self.shape[1] * block[0] * arr.itemsize

            else:
                offset = 1000 + np.ravel_multi_index(
                    block[::2], self.shape) * arr.itemsize

            with open(self.filename, 'r+') as lun:
                # The header should be written prior block writting
                lun.seek(offset)
                arr.tofile(lun)
                self.exists = True
            return

        # no block writing
        else:
            if 'header' in kwargs:
                self.Header = kwargs['header']
                # modify existing header if needed
                if 'shape' in kwargs:
                    self.Header.Rat.shape = (
                        ctypes.c_int * 8)(*kwargs['shape'][::-1])
                    self.shape = tuple(kwargs['shape'])
                if 'dtype' in kwargs:
                    if type(kwargs['dtype']) == type:
                        data_type = np.dtype(kwargs['dtype']).name
                    elif type(kwargs['dtype'] == str):
                        data_type = kwargs['dtype']
                    self.Header.Rat.var = get_var(data_type)
                if 'rattype' in kwargs:
                    self.Header.Rat.rattype = kwargs['rattype']
                # check if datatypes of array and header are equal
                if arr != []:
                    self._check_dtypes(arr)

            elif arr != []:
                # parse array parameters to the Header
                self.Header = RatHeader(
                    shape=arr.shape,
                    var=np.ctypeslib.array(get_var(arr.dtype)))
                if 'rattype' in kwargs:
                    self.Header.Rat.rattype = kwargs['rattype']

            else:
                print(red + "Specify a header, an array or both!" + endc)
                raise IOError

            self.dtype = self._get_dtype()
            self.shape = self._get_shape()

            n_bytes_total = (
            1000 + reduce(lambda x, y: x * y, self.shape) * self.dtype.itemsize)

            with open(self.filename, 'wb') as lun:
                lun.write(self.Header)
                if arr != []:
                    arr.tofile(lun)
                self.exists = True
                if lun.tell() > n_bytes_total:
                    warnings.warn("The size of the RAT file exceed! The array "
                                  "is written outside the header's dimensions!")
            return
    # --------------------------------------------------------------------------
    def read(self, **kwargs):
        """Read the data from ``RAT`` file as a numpy array.

        Works both with ``RAT`` 1.0 and 2.0 files, allows to read the data in
        blocks along all the axes.

        **Keywords**:
          :param block: the block of data to read;
            ``block=[start_1, stop_1, ..., ..., start_N, stop_N]``, where ``N``
            is a number of axes.

        :return: numpy.ndarray

        :raises: IOError if the file doesn't exist, if ``RAT`` version is not
          recognized and when ``block`` doesn't correspond to the shape of
          ``RAT`` header.
        """
        if self.exists == False:
            print(red + "ERROR: The file is not found" + endc)
            raise IOError
        if 'block' in kwargs:
            block = kwargs['block']
            # check if the block var meets the requirements
            self._check_block(block)
        else:
            block = np.zeros(2 * len(self.shape), dtype=np.int)
            block[1::2] = self.shape

        ind = tuple(map(
            lambda x, y: slice(x, y, None), block[::2], block[1::2]))

        if self.version == 2.0:
            offset = 1000
        elif self.version == 1.0:
            offset = int(104 + 4 * self.Header.Rat.ndim + 4 * self.xdrflag)
        else:
            print(red + "ERROR: RAT version not supported" + endc)
            raise IOError

        with open(self.filename, 'rb') as lun:
            mm = mmap.mmap(
                lun.fileno(), length=0, access=mmap.ACCESS_READ)

            arr = (np.ndarray.__new__(np.ndarray, self.shape, dtype=self.dtype,
                                      buffer=mm, offset=offset)[ind])
            if self.xdrflag == 1:
                arr = arr.byteswap()

        return arr


    def append(self, arr):
        """Append the ``RAT`` file with a given array along the first axis.

        :param arr: the array to write
        :type arr: numpy.ndarray

        :raises: warning if the dimensions specified in file's header are exceed
        """
        # self.read_header()
        # check if datatype of arr and of 'var' are the same
        self._check_dtypes(arr)

        # check if the array's and header's shape correspond to each other
        if len(self.shape) > 1 and (self.shape[1::] != arr.shape):
            print(red + "The shape specified in the header and the shape of "
                        "the array don't correspond to each other!" + endc)
            raise IOError

        n_bytes_total = 1000 + reduce(lambda x, y: x * y, self.shape) * arr.itemsize

        with open(self.filename, 'ab') as lun:
            arr.tofile(lun)
            if lun.tell() > n_bytes_total:
                warnings.warn("The size of the RAT file exceed! The array is "
                              "written outside the header's dimensions!")
        return


    # --------------------------------------------------------------------------
    def read_header(self):
        # reading the version
        self.version = self.get_version()[0]
        """Read ``RAT`` header; supports both ``RAT`` 1.0 and 2.0 versions."""
        if self.version == 2.0:
            with open(self.filename, 'rb') as lun:
                lun.readinto(self.Header)

        elif self.version == 1.0:
            warnings.warn('Old RAT v1.0 format!')
            if self.xdrflag == 1:
                data_type = '>i4'
                offset = 4 * 4
            else:
                data_type = '<i4'
                offset = 3 * 4

            with open(self.filename, 'rb') as lun:
                ndim = np.fromfile(file=lun, dtype=data_type, count=1)
                shape = np.fromfile(file=lun, dtype=data_type, count=ndim)
                var = np.fromfile(file=lun, dtype=data_type, count=1)
                rattype = np.fromfile(file=lun, dtype=data_type, count=1)
                lun.seek(offset, 1)
                info = np.fromfile(file=lun, dtype="B", count=80).tostring().rstrip()

            # initialize the header
            self.Header = RatHeader(shape=shape, ndim=ndim, var=var,
                                    rattype=rattype)
            self.Header.Info.info = info

        else:
            print(red + "ERROR: RAT version not supported" + endc)
            raise IOError

        self.dtype = self._get_dtype()

    #--------------------------------------------------------------------------

    def help(self):
        """Print basic imformation about ``RAT`` file.

        Print ``shape``, ``data type`` and ``info`` from file's header.
        If the file doesn't exist, then print ``empy file``.
        """
        print()
        print("FILE  : ", os.path.abspath(self.filename))
        if self.exists == True:
            print("SHAPE : ", self.shape)
            print("TYPE  : ", self._get_dtype())
            print("INFO  : ", self.Header.Info.info)
        else:
            print("--- empty file ---")

    #--------------------------------------------------------------------------

    def get_version(self):
        """Get the version of ``RAT`` file: 1.0 or 2.0."""
        Header = RatHeader()
        magiclong = Header.Rat.magiclong
        magicreal = 0

        with open(self.filename, 'rb') as lun:
            magicreal = np.fromfile(file=lun, dtype="i4", count=1)
        if magicreal != magiclong:  # Check if maybe we have a RAT V1 File...
            with open(self.filename, 'rb') as lun:
                ndim = np.fromfile(file=lun, dtype="<i4", count=1)
            xdrflag = 0
            if ndim < 0 or ndim > 9:
                ndim = ndim.byteswap()
                xdrflag = 1
            if ndim < 0 or ndim > 9:
                print(red + "ERROR: format not recognised!" + endc)
                return False, False
            version = 1.0
        else:  #-------------- Yeah, RAT 2.0 found
            with open(self.filename, 'rb') as lun:
                lun.seek(4)
                version = np.fromfile(file=lun, dtype="float32", count=1)[0]
            xdrflag = 0

        return version, xdrflag

    def _check_block(self, block, **kwargs):
        stop_more_than_shape = reduce(lambda x, y: x or y, (
            map(lambda x, y: (x > y), block[1::2], self.shape)))
        if stop_more_than_shape:
            print(red + 'Value of block exceeds '
                        'the array shape!' + endc)
            raise IOError

        block_is_negative = any(
            ((i < 0) or ((type(i) != int) and (type(i) != np.int32))) for i in block)
        if block_is_negative:
            print(red + 'The items in block should be nonnegative integers!')
            raise IOError

        if 'arr' in kwargs:
            if len(block) // 2 != kwargs['arr'].ndim:
                print(red + 'The dimensions of block do not correspond to the '
                            'dimensions of array!' + endc)
                raise IOError

            block_not_shape = reduce(lambda x, y: x or y,
                                     map(lambda x, y, z: (x - y) != z,
                                         block[1::2], block[::2],
                                         kwargs['arr'].shape))
            if block_not_shape:
                print(red + 'Lenght of block components does not correspond to'
                            ' the shape of the array!' + endc)
                raise IOError


    def _check_dtypes(self, arr):
        """Check if dtypes of given array and the one in header are the equal"""
        if self.Header.Rat.var != get_var(arr.dtype).value:
            print(red + "The data type of the array to be written and "
                        "the one specified in file's header"
                         "don't correspond to each other!" + endc)
            raise IOError

    def _get_dtype(self):
        """Get data type give ```Header.Rat.var``."""
        try:
            return np.dtype(dtype_dict[self.Header.Rat.var])
        except KeyError:
            print(red + "The data type is either not specified or "
                        "not supported!" + endc)
            raise IOError

    def _get_shape(self):
        """Get numpy array shape from ``Header.Rat.shape`` that is IDL style"""
        shape = np.ctypeslib.as_array(self.Header.Rat.shape)
        shape = shape[shape != 0]
        return tuple(shape[::-1])


def get_var(dtype):
    """Get ``RatHeaderRat.var`` value given ``dtype``."""
    var = [key for (key, value) in dtype_dict.items() if
           value == dtype]
    if var == []:
        print(red + 'The data type is not supported!' + endc)
        raise IOError
    else:
        return ctypes.c_int(var[0])

# data type dictionary to net RAT's and np's data formats
dtype_dict = {1: 'uint8',
              2: 'int16',
              3: 'int32',
              4: 'float32',
              5: 'float64',
              6: 'complex64',
              9: 'complex128',
              12: 'uint16',
              13: 'uint32',
              14: 'int64',
              15: 'uint64'}
