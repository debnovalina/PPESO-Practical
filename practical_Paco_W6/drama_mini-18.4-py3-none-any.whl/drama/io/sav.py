from __future__ import absolute_import, division, print_function
from scipy.io.idl import readsav


def read_sav(filename):
    """ Function to read IDL sav files.
        
        :param filename: File name, with the complete path.
        :type filename: string
        
        :returns: dictionary with the IDL variables (keys and values).
    """
    
    struct = readsav(filename)
    
    return struct
