"""
==============================
I/O Package (:mod:`trampa.io`)
==============================

.. currentmodule:: trampa.io

Configuration files
===================

.. autosummary::
   :toctree: generated/

   ConfigFile
   
netCDF Files
============

.. autosummary::
   :toctree: generated/

   NETCDFHandler
   
Instrument Errors files
=======================

.. autosummary::
   :toctree: generated/

   InstrumentErrorsFilez

Read sav files
==============

.. autosummary::
   :toctree: generated/

   read_sav

rat files
=========

.. autosummary::
   :toctree: generated/

   RatFile
   srat
   rrat
   
"""

from .cfg import ConfigFile
from .netcdf import NETCDFHandler
from .errors import InstrumentErrorsFile
from .sav import read_sav
from .rat import RatFile, srat, rrat

