import time
from netCDF4 import Dataset
from ..io import NETCDFHandler


class InstrumentErrorsFile(NETCDFHandler):
    """ Class to read/write Instrument Errors files produced by
        drama.performance.sar.InstrumentErrors class

        :param file_name: File name
        :param mode: Access mode (w = write, r = read, r+ = read + append)
        :param pattern_dim: Pattern dimensions
        :param slowtime_dim: Slow-time error dimensions
        :param format: netCDF format

    """

    def __init__(self, file_name, mode, pattern_dim=None, slowtime_dim=None, format='NETCDF4'):

        self.__file__ = Dataset(file_name, mode, format)

        # If writing, define file
        if mode == 'w':
            # Set file attributes
            self.__file__.description = 'TRAMPA Library Instrument Errors File'
            self.__file__.history = 'Created ' + time.ctime(time.time())
            self.__file__.source = 'TRAMPA Library'

            # Dimensions
            if (not pattern_dim) or (not slowtime_dim):
                raise ValueError('Data dimensions are needed when creating new file!')

            self.__file__.createDimension('ch_dim', pattern_dim[0])
            self.__file__.createDimension('patt_dim', pattern_dim[1])
            self.__file__.createDimension('az_dim', slowtime_dim[1])
            self.__file__.createDimension('rg_dim', slowtime_dim[2])

            ## Variables
            # Pattern
            self.__file__.createVariable('sin_az', 'f8', ('patt_dim'))
            self.__file__.createVariable('bp_tx_err_tot_r', 'f8', ('patt_dim'))
            self.__file__.createVariable('bp_tx_err_tot_i', 'f8', ('patt_dim'))
            self.__file__.createVariable('bp_rx_err_tot_r', 'f8', ('ch_dim', 'patt_dim'))
            self.__file__.createVariable('bp_rx_err_tot_i', 'f8', ('ch_dim', 'patt_dim'))
            # Slow-time error
            self.__file__.createVariable('rand_sigma_beta_tx', 'f8', ('az_dim', 'rg_dim'))
            self.__file__.createVariable('rand_sigma_beta_rx', 'f8', ('ch_dim', 'az_dim', 'rg_dim'))
            self.__file__.createVariable('rand_sigma_phase_tx', 'f8', ('az_dim', 'rg_dim'))
            self.__file__.createVariable('rand_sigma_phase_rx', 'f8', ('ch_dim', 'az_dim', 'rg_dim'))
