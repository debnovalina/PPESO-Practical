from __future__ import absolute_import, division, print_function
import numpy as np
import lxml.etree as ET
from collections import namedtuple
from dateutil import parser
from tkinter import filedialog as tkFileDialog
from tkinter import Tk

Takes = namedtuple('dataTakes', ['takeId', 'takeImaging', 'takeMode',
                                 'takeBeamId', 'takeLooking', 'takeStart',
                                 'takeStop', 'takeTargetHoA', 'takeMinHoA',
                                 'takeMaxHoA', 'takePriority', 'takeCostumer',
                                 'takePurpose', 'takeAdditional'])

TAP_lookup = namedtuple('TAP_lookup', ['t0', 'delta_t', 'LUT'])


def TAP_lookup_table(TAP_takes, t_start=None, t_end=None,  delta_t=1):
    """ A function to create a lookup table pointing to a TAP Takes
    """
    # Check start and stop times, force them to be within boundaries
    bad_times = False
    if t_start is None:
        t_start = TAP_takes.takeStart[0]
    elif t_start < TAP_takes.takeStart[0]:
        print("Adjusting t_start to first acquisition in TAP")
        t_start = TAP_takes.takeStart[0]
    elif t_start > TAP_takes.takeStart[-1]:
        bad_times = True
    if t_end is None:
        t_end = TAP_takes.takeStop[-1]
    elif t_end > TAP_takes.takeStop[-1]:
        t_end = TAP_takes.takeStop[-1]
    elif t_end <= t_start:
        bad_times = True
    if bad_times:
        raise ValueError("Invalid times")
    #t_start = np.datetime64(t_start, dtype='M8[s]')
    #t_end = np.datetime64(t_end, dtype='M8[s]')
    t_interval_s = (t_end - t_start).astype('m8[s]').astype(int)
    #rel_takeStart = (np.array(TAP_takes.takeStart, dtype='M8[s]')
    #                 - t_start).astype('m8[s]').astype(int)
    rel_takeStart = (TAP_takes.takeStart - t_start).astype('m8[s]').astype(int)
    rel_takeStart = rel_takeStart / delta_t
    #rel_takeStop = (np.array(TAP_takes.takeStop, dtype='M8[s]')
    #                - t_start).astype('m8[s]').astype(int)
    rel_takeStop = (TAP_takes.takeStop - t_start).astype('m8[s]').astype(int)
    rel_takeStop = rel_takeStop / delta_t
    ntimes = int(np.round(t_interval_s / delta_t))
    good_takes = np.where((rel_takeStart >= 0) & (rel_takeStop <= ntimes))
    lookup = np.empty(ntimes, dtype=int)
    lookup[:] = -1
    # return (lookup, rel_takeStart, rel_takeStop)
    for take_ind in good_takes[0]:
        lookup[rel_takeStart[take_ind]:rel_takeStop[take_ind]+1] = take_ind
    return TAP_lookup(t_start, delta_t, lookup)


def read_TAP(filename=None, app=None):

    """ Function to read the information provided by TAP (XML file)
        and returns such information as a tuple.

        :param fileName: Name of the file. Default=None.
        :type fileName: string
        :param app: Desired application. Defualt=Forest.
        :type app: string

        :returns: two tuple with the general information about the axqusition
                  swaths and the specific information about the data takes for
                  a certain period of time.

    """

    # Open parameter file to derive user inputs
    if (filename is None):
        roott = Tk()
        roott.withdraw()
        roott.overrideredirect(True)
        roott.geometry('0x0+0+0')
        roott.deiconify()
        roott.lift()
        roott.focus_force()
        filename = tkFileDialog.askopenfilename(parent=roott)
        roott.destroy()

    tree = ET.parse(filename)
    root = tree.getroot()

    # -------------------------------------------------------------------------
    # tapTakes is root[2:]
    #
    # tapTakes: data takes for a certain period of time. The information
    # provided is the take id, take imaging mode (stripmap, spotlight, ...),
    # take configuration (bistatic, monstatic,...), take beam (swath) id,
    # take looking configuration (right- or leftlooking), take start time,
    # take stop time, take target HoA (Height of Ambiguity), take minimum HoA
    # and take maximum HoA.
    #
    # The information for each take is extracted in 10 lists which are
    # collected together in a named tuple
    # -------------------------------------------------------------------------

    tapTakes = root[2:]

    take_additional = []
#    for field in tapTakes:
#        for subfield in field:
#            if subfield.tag == 'orderParams':
#                for subsubfield in subfield:
#                    if subsubfield.tag == 'additionalOrderInformation':
#                        for subsubsubfield in subsubfield:
#                            if subsubsubfield.tag == 'value':
#                                take_additional.append(subsubsubfield.text)
    for field in tapTakes:
        for subfield in field:
            if subfield.tag == 'beamId':
                take_additional.append(subfield.text)


#    appTakesPos = []
#    if app == 'Forest':
#        for iii in range(len(tapTakes)):
#            if ((take_additional[iii] == 'Forest_Boreal_mode_B4_bist_asc_LARGE_orbitShifted') or
#                (take_additional[iii] == 'Forest_Temperate_mode_B4_bist_asc_LARGE_orbitShifted') or
#                (take_additional[iii] == 'Forest_Tropical_mode_B4_bist_asc_LARGE_orbitShifted')):
#                appTakesPos.append(iii)
#    elif app == 'Deformation':
#        for iii in range(len(tapTakes)):
#            if ((take_additional[iii] == 'Large-Scale_Deformation_A1_mono_175km_desc_LARGE') or
#                (take_additional[iii] == 'Large-Scale_Deformation_B1_mono_100km_asc_LARGE')):
#                appTakesPos.append(iii)
#    else:
#        print('ERROR! Application not implemented yet!')

    appTakesPos = []
    if app == 'Forest':
        for iii in range(len(tapTakes)):
            if (take_additional[iii] == 'mode_B4_bist'):
                appTakesPos.append(iii)
    elif app == 'Deformation':
        for iii in range(len(tapTakes)):
            if ((take_additional[iii] == 'mode_A1_mono_175km') or
                (take_additional[iii] == 'mode_B1_mono_100km')):
                appTakesPos.append(iii)
    elif app == 'Global':
        for iii in range(len(tapTakes)):
            if (take_additional[iii] == 'mode_B4_bist'):
                appTakesPos.append(iii)
    else:
        print('ERROR! Application not implemented yet!')


    tapTakesNew = []
    for jjj in range(len(appTakesPos)):
        tapTakesNew.append(tapTakes[appTakesPos[jjj]])



    take_id = []
    take_imaging = []
    take_mode = []
    take_beamid = []
    take_looking = []
    take_start = []
    take_stop = []
    take_HoA_target =[]
    take_HoA_min =[]
    take_HoA_max = []
    take_priority = []
    take_costumer = []
    take_purpose = []
    take_additional = []
    for field in tapTakesNew:
        take_id.append(field.attrib['tapTapeIdx'])
        for subfield in field:
            if subfield.tag == 'imagingMode':
                take_imaging.append(subfield.text)
            if subfield.tag == 'interferometricMode':
                take_mode.append(subfield.text)
            if subfield.tag == 'beamId':
                take_beamid.append(subfield.text)
            if subfield.tag == 'looking':
                take_looking.append(subfield.text)
            if subfield.tag == 'startUTC_TTG':
                take_start.append(subfield.text)
            if subfield.tag == 'StopUTC_TTG':
                take_stop.append(subfield.text)
            if subfield.tag == 'HoA':
                for subsubfield in subfield:
                    if subsubfield.tag == 'HoA_target':
                        take_HoA_target.append(np.float(subsubfield.text))
                    if subsubfield.tag == 'HoA_min':
                        take_HoA_min.append(np.float(subsubfield.text))
                    if subsubfield.tag == 'HoA_max':
                        take_HoA_max.append(np.float(subsubfield.text))
            if subfield.tag == 'orderParams':
                for subsubfield in subfield:
                    if subsubfield.tag == 'acquisitionPriority':
                        take_priority.append(subsubfield.text)
                    if subsubfield.tag == 'customerGroup':
                        take_costumer.append(subsubfield.text)
                    if subsubfield.tag == 'appliedTo':
                        take_purpose.append(subsubfield.text)
                    if subsubfield.tag == 'additionalOrderInformation':
                        for subsubsubfield in subsubfield:
                            if subsubsubfield.tag == 'value':
                                take_additional.append(subsubsubfield.text)

    # Convert the list with data times as strings to datatime format
    for iii in range(len(take_start)):
        take_start[iii] = np.datetime64(parser.parse(take_start[iii], fuzzy=True),
                                        dtype='M8[s]')
        take_stop[iii] = np.datetime64(parser.parse(take_stop[iii], fuzzy=True),
                                       dtype='M8[s]')
        #take_start[iii] = parser.parse(take_start[iii], fuzzy=True)
        #take_stop[iii] = parser.parse(take_stop[iii], fuzzy=True)

    takesInformation = Takes(take_id, take_imaging, take_mode, take_beamid,
                             take_looking, take_start, take_stop,
                             np.asarray(take_HoA_target), np.asarray(take_HoA_min),
                             np.asarray(take_HoA_max), take_priority,
                             take_costumer, take_purpose, take_additional)

    # -------------------------------------------------------------------------
    # inputAssumptions is root[1]
    #
    # inputAssmuption: general information about acquisition swaths, as swath
    # id, data rate, look angle at near range and look angle at far range.
    #
    # The information is extracted in 4 lists which are collected together in a
    # named tuple
    # -------------------------------------------------------------------------
    inAssump = root[1]

    swath_id = []
    data_rate = []
    look_ang_near = []
    look_ang_far = []

    acqMode = takesInformation.takeBeamId[0]

    for field in inAssump[1:]:
        if (field.attrib['beamId'] == acqMode):
            swath_id.append(field.attrib['beamId'])
            for subfield in field:
                if subfield.tag == 'dataRate':
                    data_rate.append(np.float(subfield.text))
                if subfield.tag == 'LookAngle_Near':
                    look_ang_near.append(np.float(subfield.text))
                if subfield.tag == 'LookAngle_Far':
                    look_ang_far.append(np.float(subfield.text))

    Swaths = namedtuple('swathInfo',['swathId', 'dataRate', 'lookNear',
                                         'lookFar'])
    swathsInformation = Swaths(swath_id, np.asarray(data_rate),
                               np.asarray(look_ang_near),
                               np.asarray(look_ang_far))

    return swathsInformation, takesInformation
