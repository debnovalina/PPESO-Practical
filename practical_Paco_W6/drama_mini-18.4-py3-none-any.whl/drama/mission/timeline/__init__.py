# -*- coding: utf-8 -*-
"""
=========================================================
Mission Timeline Package (:mod:`drama.mission.timeline`)
=========================================================

.. currentmodule:: drama.mission.timeline

TimeLine
========

.. autosummary::
    :toctree: generated/

    latlon_timeline
    timeline_expand
    timeline_compress
    LatLonTimeline
    FormationTimeline

"""

from .acquisitions import latlon_timeline, timeline_expand, \
                          timeline_compress, LatLonTimeline
from .formation import FormationTimeline
