from __future__ import absolute_import, division, print_function
import numpy as np
from collections import namedtuple
import drama.coverage as cov
from drama.mission.timeline import read_TAP as TAP
from drama.geo.sar.geometry import look_to_inc, inc_to_look
import drama.utils as misc
from drama.io.cli import ProgressBar


PointTimeline = namedtuple('PointTimeline',
                           ['theta_i', 'northing', 'orbtime', 'orbnum',
                            'theta_l', 'slant_range'])


PointTimelineTAP = namedtuple('PointTimelineTAP',
                              ['theta_i', 'theta_l', 'northing',
                               'beamID', 'mode', 'orbnum', 'acqtime',
                               'theta_i_b', 'theta_l_b', 'northing_b'])


def timeline_compress(track, lat_ind_array, lon_ind_array, Horb,
                      track_B = None):
    """ Compresses calculated timeline in order to turn vectors full on NAN
        values into lists.

        :author: Paco Lopez-Dekker

        :param track: a Named tuple of the type SingleTrack
        :param lat_ind_array: array of latitude indices
        :param lon_ind_array: Norb x ... array of longitude indices
    """

    # Dimensions of input, first dimension is orbit number
    dim_in = lon_ind_array.shape
    # Prepare output
    res = np.empty(dim_in[1:], dtype=np.object)
    if track_B:
        res_B = np.empty(dim_in[1:], dtype=np.object)
    if (len(dim_in) == 2):
        # Transpose the data
        lon_ind_t = lon_ind_array.transpose()
        # Loop over one dimension
        for ind1 in range(dim_in[1]):
            # Look for regular values
            gd = np.where(~np.isnan(lon_ind_t[ind1]))
            lat_ind = lat_ind_array[ind1].astype(int)
            lon_inds = lon_ind_t[ind1, gd].astype(int)
            theta_i = track.inc_angle[lat_ind, lon_inds.flatten()]
            northing = track.northing[lat_ind, lon_inds.flatten()]
            orbtime = track.time[lat_ind, lon_inds.flatten()]
            slant_range = track.slant_range[lat_ind, lon_inds.flatten()]
            theta_l = np.degrees(inc_to_look(theta_i, Horb))

            res[ind1] = PointTimeline(theta_i, northing, orbtime, gd[0],
                                      theta_l, slant_range)

            if track_B:
                theta_i_B = track_B.inc_angle[lat_ind, lon_inds.flatten()]
                northing_B = track_B.northing[lat_ind, lon_inds.flatten()]
                orbtime_B = track_B.time[lat_ind, lon_inds.flatten()]
                theta_l_B = np.degrees(inc_to_look(theta_i_B, Horb))
                slant_range_B = track_B.slant_range[lat_ind,
                                                    lon_inds.flatten()]
                res_B[ind1] = PointTimeline(theta_i_B, northing_B, orbtime_B,
                                            gd[0], theta_l_B, slant_range_B)

    elif (len(dim_in) == 3):
        # Transpose the data
        lon_ind_t = lon_ind_array.transpose(1, 2, 0)
        # Loop over two dimension
        for ind1 in range(dim_in[1]):
            for ind2 in range(dim_in[2]):
                # Look for regular values
                gd = np.where(~np.isnan(lon_ind_t[ind1, ind2]))
                lat_ind = lat_ind_array[ind1, ind2].astype(int)
                lon_inds = lon_ind_t[ind1, ind2, gd].astype(int)
                theta_i = track.inc_angle[lat_ind, lon_inds.flatten()]
                northing = track.northing[lat_ind, lon_inds.flatten()]
                orbtime = track.time[lat_ind, lon_inds.flatten()]
                theta_l = np.degrees(inc_to_look(theta_i, Horb))
                slant_range = track.slant_range[lat_ind, lon_inds.flatten()]
                res[ind1, ind2] = PointTimeline(theta_i, northing, orbtime,
                                                gd[0], theta_l, slant_range)
                if track_B:
                    theta_i_B = track_B.inc_angle[lat_ind, lon_inds.flatten()]
                    northing_B = track_B.northing[lat_ind, lon_inds.flatten()]
                    orbtime_B = track_B.time[lat_ind, lon_inds.flatten()]
                    theta_l_B = np.degrees(inc_to_look(theta_i_B, Horb))
                    slant_range_B = track_B.slant_range[lat_ind,
                                                        lon_inds.flatten()]
                    res_B[ind1, ind2] = PointTimeline(theta_i_B, northing_B,
                                                      orbtime_B, gd[0],
                                                      theta_l_B, slant_range_B)
    else:
        raise ValueError("Too many dimensions in input parameter")
    # Return value
    if track_B:
        return (res, res_B)
    else:
        return res


def timeline_expand(acqs, Torb, Norb, Ncycles, time_offset,
                    TAP_LUT, TAP_acqs, TAP_swaths):
    """ This function expands an acquisition timeline to several cycles according to
        a TAP

        :param acqs: a PointTimeline named tuple
        :param Torb: orbit time, in seconds
        :param Norb: number of revolutions per repeat cycle
        :param Ncycles: number of repeat cycles in TAP
        :param time_offset: a global time offset between the TAP and the orbit
                            time
        :param TAP_LUT: Lookup table to TAP
        :param TAP_acqs: the actual TAP
        :param TAP_swaths: swaths defined in TAP
        :param Horb: orbital height
    """
    orbtime = acqs.orbtime.reshape([1, acqs.orbtime.size])
    orbnum = acqs.orbnum.reshape([1, acqs.orbtime.size])

    # repetition for the number of cycles
    dorbnum = Norb * np.arange(Ncycles).reshape([Ncycles, 1])
    # unwrapped time
    uwtime = ((orbnum + dorbnum) * Torb + orbtime).flatten()
    uworbnum = (orbnum + dorbnum).flatten()

    theta_i = np.repeat(acqs.theta_i.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()
    theta_l = np.repeat(acqs.theta_l.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()

    northing = np.repeat(acqs.northing.reshape([1, acqs.orbtime.size]),
                         Ncycles, axis=0).flatten()

    t_in = np.round((uwtime + time_offset) / TAP_LUT.delta_t).astype(int)
    # limiting the time of the acquisition to maximum value in the TAP
    val_ind = np.where((t_in >= 0) & (t_in < TAP_LUT.LUT.size))
    theta_i = theta_i[val_ind]
    theta_l = theta_l[val_ind]
    northing = northing[val_ind]
    uworbnum = uworbnum[val_ind]
    in_acq = TAP_LUT.LUT[t_in[val_ind]]
    # Reduce
    act_acq = np.where(in_acq != -1)
    theta_i = theta_i[act_acq]
    theta_l = theta_l[act_acq]
    uworbnum = uworbnum[act_acq]
    northing = northing[act_acq]
    beamID = np.array([TAP_acqs.takeBeamId]).flatten()[in_acq[act_acq]]
    mode = np.array([TAP_acqs.takeMode]).flatten()[in_acq[act_acq]]
    t_in = t_in[act_acq]

    # Check angles
    # This is taken as it was, bit it does not consider the swath for the
    # actual mode so it probably is wrong
    in_swath = np.where((theta_l > TAP_swaths.lookNear[0]) &
                        (theta_l < TAP_swaths.lookFar[0]))
    theta_i = theta_i[in_swath]
    theta_l = theta_l[in_swath]
    uworbnum = uworbnum[in_swath]
    northing = northing[in_swath]
    beamID = beamID[in_swath]
    mode = mode[in_swath]
    t_in = t_in[in_swath]
    return PointTimelineTAP(theta_i, theta_l, northing, beamID, mode, uworbnum,
                            t_in, None, None, None)


def timeline_expand_orbtml(acqs, Torb, Norb, orb_tmln, swathes,
                           swathtype='inc_range', acqs_bist=None):
    """ This function expands an acquisition timeline to several cycles
        in accordance to a OrbTimeline object


        :param acqs: a PointTimeline named tuple
        :param Torb: orbit time, in seconds
        :param Norb: number of revolutions per repeat cycle
        :param orb_tmln
        :param swathes: n_modes x 2 array defining the swathes according to
                        swathtype (radians or meter)
        :param swatgtype: one out of 'inc_range' (default) or 'echo_window'
    """
    orbtime = acqs.orbtime.reshape([1, acqs.orbtime.size])
    orbnum = acqs.orbnum.reshape([1, acqs.orbtime.size])
    Ncycles = orb_tmln.mode.shape[0]
    # repetition for the number of cycles
    cyc = np.arange(Ncycles, dtype=np.int).reshape([Ncycles, 1])
    cyc = np.repeat(cyc, acqs.orbtime.size, axis=1).flatten()
    # orb = np.arange(Norb, dtype=np.int).reshape([1, Norb, 1])
    delta_t = orb_tmln.timevec[1] - orb_tmln.timevec[0]

    theta_i = np.repeat(acqs.theta_i.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()
    theta_l = np.repeat(acqs.theta_l.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()
    northing = np.repeat(acqs.northing.reshape([1, acqs.orbtime.size]),
                         Ncycles, axis=0).flatten()
    orbnum = np.repeat(acqs.orbnum.reshape([1, acqs.orbtime.size]),
                       Ncycles, axis=0).flatten().astype(np.int)
    orbtime = np.repeat(acqs.orbtime.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()
    orbtind = np.floor(acqs.orbtime / delta_t).astype(np.int)
    orbtind = np.repeat(orbtind.reshape([1, acqs.orbtime.size]),
                        Ncycles, axis=0).flatten()
    thismode = orb_tmln.mode[cyc, orbnum, orbtind]
    acquire = orb_tmln.inMask[cyc, orbnum, orbtind]
    swthnear = swathes[thismode - 1, 0]
    swthfar = swathes[thismode - 1, 1]
    if swathtype == 'echo_window':
        slant_range = np.repeat(acqs.slant_range.reshape([1,
                                                          acqs.orbtime.size]),
                                Ncycles, axis=0).flatten()
        inswath = np.logical_and(slant_range > swthnear, slant_range < swthfar)
    else:

        inswath = np.logical_and(theta_i > swthnear, theta_i < swthfar)
    t_in = (cyc * Norb + orbnum) * Torb + orbtime
    goodones = np.where(np.logical_and(acquire, inswath))
    if acqs_bist is not None:
        # Add bistatic acquisition
        theta_i_b = np.repeat(acqs_bist.theta_i.
                              reshape([1, acqs.orbtime.size]),
                              Ncycles, axis=0).flatten()
        theta_l_b = np.repeat(acqs_bist.theta_l.
                              reshape([1, acqs.orbtime.size]),
                              Ncycles, axis=0).flatten()
        northing_b = np.repeat(acqs_bist.northing.
                               reshape([1, acqs.orbtime.size]),
                               Ncycles, axis=0).flatten()
        return PointTimelineTAP(theta_i[goodones],
                                theta_l[goodones],
                                northing[goodones],
                                None,
                                thismode[goodones],
                                (cyc * Norb + orbnum)[goodones],
                                t_in[goodones],
                                theta_i_b[goodones],
                                theta_l_b[goodones],
                                northing_b[goodones])
    else:
        return PointTimelineTAP(theta_i[goodones],
                                theta_l[goodones],
                                northing[goodones],
                                None,
                                thismode[goodones],
                                (cyc * Norb + orbnum)[goodones],
                                t_in[goodones],
                                None, None, None)


def latlon_timeline(swathInterpData, swathInterpData_Bist=None,
                    lat_Coord=0, lon_Coord=-50,
                    inc_angle_range=None,
                    as_struct_array=False):

    """ Checks if a given point lies or not in a given swath

        :author: Paco Lopez-Dekker, Mariantonietta Zonno

        :param swathInterpData: information from "swath_interpol" funtion.
        :type swathInterpData: tuple
        :param lat_Coord: input latitude coordinate [deg].
        :type lat_Coord: float
        :param lon_Coord: input longitude coordinate [deg].
        :type lon_Coord: float
        :param inc_angle_range: range of incident angles [deg].
        :type inc_angle: 2-elements list
        :param as_struct_array: do we want to store timeline as structured
        array?
        :type as_struct_array: Boolean
        :returns: named tuple with the indexes to the reference swath.

    """

    Norb = int(swathInterpData.norb)
    dlat = swathInterpData.dlat
    dlon = swathInterpData.dlon
    Torb = swathInterpData.Torb    # Torb in hours
    delta_lon = Torb * 360. / 24.

    # Incident angles range
    if (inc_angle_range is None):
        inc_angle_range = [np.nanmin(swathInterpData.Ascending.inc_angle),
                           np.nanmax(swathInterpData.Ascending.inc_angle)]
        inc_angle_range[0] = np.rad2deg(inc_angle_range[0]) + 0.1
        inc_angle_range[1] = np.rad2deg(inc_angle_range[1]) - 0.1

    # check if coordiantes are an array, and force them to be one
    if isinstance(lat_Coord, np.ndarray):
        lat = lat_Coord
    else:
        if np.size(lat_Coord):
            lat = np.array([lat_Coord]).flatten()
        else:
            lat = np.array(lat_Coord)
    if isinstance(lon_Coord, np.ndarray):
        lon = lon_Coord
    else:
        if np.size(lon_Coord):
            lon = np.array([lon_Coord]).flatten()
        else:
            lon = np.array(lon_Coord)
    # ascending
    mask_asc = np.logical_and((swathInterpData.Ascending.inc_angle >
                               np.deg2rad(inc_angle_range[0])),
                              (swathInterpData.Ascending.inc_angle <
                               np.deg2rad(inc_angle_range[1])))

    lat_asc = swathInterpData.Ascending.lat
    lon_asc = swathInterpData.Ascending.lon

    # Unwrap the longitudes
    lon_asc = np.where(lon_asc > 0, lon_asc, lon_asc + 360)
    # finding the indices, the output is an array
    ind_lat_asc = np.around((lat - lat_asc[0])/dlat).astype(int)
    # Dimensions of output lon
    dim_lon_asc = (Norb,) + lon.shape
    ind_lon_asc = np.zeros(dim_lon_asc)
    # Set all to Nan
    ind_lon_asc[:] = np.nan
    # for showing some progress
    bar = ProgressBar("Processing", Norb * 2)
    for i_orbit in range(Norb):
        lon_rotated = lon + delta_lon * i_orbit
        lon_rotated = np.where(lon_rotated < 0, lon_rotated + 360, lon_rotated)
        lon_rotated = np.mod(lon_rotated, 360)
        tmp = lon_rotated - lon_asc[0]
        tmp = np.where(tmp < 0, tmp + 360, tmp)
        this_ind = np.around(tmp/dlon).astype(int)
        val_ind = np.where((this_ind >= 0) & (this_ind < lon_asc.size) &
                           (ind_lat_asc >= 0) & (ind_lat_asc < lat_asc.size))
        if val_ind[0].size > 0:
            val_cond_2 = mask_asc[ind_lat_asc[val_ind], this_ind[val_ind]]
            val_ind_ = (np.array([i_orbit]*val_ind[0].size),) + val_ind
            ind_lon_asc[val_ind_] = np.where(val_cond_2,
                                             this_ind[val_ind], np.nan)
        bar.update(i_orbit)
    # descending
    mask_desc = np.logical_and((swathInterpData.Descending.inc_angle >
                                np.deg2rad(inc_angle_range[0])),
                               (swathInterpData.Descending.inc_angle <
                                np.deg2rad(inc_angle_range[1])))
    lat_desc = swathInterpData.Descending.lat
    lon_desc = swathInterpData.Descending.lon
    # Unwrap the longitudes
    lon_desc = np.where(lon_desc > 0, lon_desc, lon_desc + 360)
    # finding the indices
    ind_lat_desc = np.around((lat - lat_desc[0])/dlat).astype(int)
    ind_lon_desc = np.zeros(dim_lon_asc)
    ind_lon_desc[:] = np.nan

    for i_orbit in range(Norb):
        lon_rotated = lon + delta_lon * i_orbit
        lon_rotated = np.where(lon_rotated < 0, lon_rotated + 360, lon_rotated)
        lon_rotated = np.mod(lon_rotated, 360)
        tmp = lon_rotated - lon_desc[0]
        tmp = np.where(tmp < 0, tmp + 360, tmp)
        this_ind = np.around(tmp/dlon).astype(int)
        # this_ind = np.around((lon_rotated - lon_desc[0])/dlon).astype(int)

        val_ind = np.where((this_ind > 0) & (this_ind < lon_desc.size) &
                           (ind_lat_desc >= 0) & (ind_lat_desc < lat_desc.size))
        if val_ind[0].size > 0:
            val_cond_2 = mask_desc[ind_lat_desc[val_ind], this_ind[val_ind]]
            val_ind_ = (np.array([i_orbit]*val_ind[0].size),) + val_ind
            ind_lon_desc[val_ind_] = np.where(val_cond_2,
                                              this_ind[val_ind], np.nan)
        bar.update(i_orbit + Norb)
    # Prepare output
    if swathInterpData_Bist:
        asc_acqs = timeline_compress(swathInterpData.Ascending,
                                     ind_lat_asc, ind_lon_asc,
                                     swathInterpData.Horb,
                                     swathInterpData_Bist.Ascending)
        desc_acqs = timeline_compress(swathInterpData.Descending,
                                      ind_lat_desc, ind_lon_desc,
                                      swathInterpData.Horb,
                                      swathInterpData_Bist.Descending)
        asc_acqs_Mono = asc_acqs[0]
        asc_acqs_Bist = asc_acqs[1]
        desc_acqs_Mono = desc_acqs[0]
        desc_acqs_Bist = desc_acqs[1]
        return (asc_acqs_Mono, asc_acqs_Bist, desc_acqs_Mono, desc_acqs_Bist)
    else:
        asc_acqs = timeline_compress(swathInterpData.Ascending,
                                     ind_lat_asc, ind_lon_asc,
                                     swathInterpData.Horb)
        desc_acqs = timeline_compress(swathInterpData.Descending,
                                      ind_lat_desc, ind_lon_desc,
                                      swathInterpData.Horb)
        return (asc_acqs, desc_acqs)


class LatLonTimeline:
    """A class for a acquisition timeline
    """
    TAP_loaded = False

    def __init__(self, par_file=None, lats=0, lons=0, dlat=0.5, dlon=0.5,
                 inc_angle_range=None,  ext_orbit=False, form=None,
                 look_dir='right', squint=0,
                 track_grid=None, track_grid_prim=None):

        """ Initializes instance of LatLonTimeline

            :author: Paco Lopez-Dekker, Mariantonietta Zonno

            :param par_file: parameter file
            :param lats: input latitude coordinate [deg].
            :type lats: float
            :param lons: input longitude coordinate [deg].
            :type lons: float
            :param inc_angle_range: range of incident angles [deg].
            :type inc_angle_range: 2-elements list
            :param ext_orbit: if an external orbit is provided
            :type ext_orbit: bool
            :param form: formation class instance
            :type form: object
            :ext_orbit: external orbit file used by one_orbit if passed as
                        input

            :returns: named tuple with the indexes to the reference swath.

        """

        self.par_file = misc.get_parFile(parfile=par_file)
        self.lats = lats
        self.lons = lons
        self.inc_angle_range = inc_angle_range
        inc_angle_range_ = (np.abs(np.array(inc_angle_range)) +
                            np.array([-1, 1]))
        self.has_primary = False
        if form is not None:
            self.track = form.track
            if track_grid is None:
                print("Interpolating track")
                self.track_grid = cov.swath_interpol(self.track, dlat=dlat,
                                                     dlon=dlon)
            else:
                self.track_grid = track_grid
            if hasattr(form, "track_prim"):
                self.has_primary = True
                self.track_prim = form.track_prim
                if track_grid_prim is None:
                    print("Interpolating primary track")
                    self.track_prim_grid = cov.swath_interpol(self.track_prim,
                                                              dlat=dlat,
                                                              dlon=dlon)
                else:
                    self.track_prim_grid = track_grid_prim
                all_acqs = latlon_timeline(self.track_prim_grid,
                                           self.track_grid,
                                           self.lats, self.lons,
                                           self.inc_angle_range)
                self.asc_acqs = all_acqs[0]
                self.asc_acqs2 = all_acqs[1]
                self.desc_acqs = all_acqs[2]
                self.desc_acqs2 = all_acqs[3]
            else:
                (self.asc_acqs,
                 self.asc_acqs) = latlon_timeline(self.track_grid,
                                                  None,
                                                  self.lats, self.lons,
                                                  self.inc_angle_range)
        else:
            self.track = cov.single_swath(ext_source=ext_orbit,
                                          parFile=self.par_file,
                                          look=look_dir,
                                          inc_angle=inc_angle_range_,
                                          squint=squint)
            if track_grid is None:
                print("Interpolating track")
                self.track_grid = cov.swath_interpol(self.track, dlat=dlat,
                                                     dlon=dlon)
            else:
                self.track_grid = track_grid

            (self.asc_acqs,
             self.desc_acqs) = latlon_timeline(self.track_grid,
                                               None,
                                               self.lats,
                                               self.lons,
                                               self.inc_angle_range)

    def load_TAP(self, filename=None, application=None, t_start=None,
                 t_end=None, delta_t=1):
        """ Reads TAP file and creates a lookup table to it

            :author: Paco Lopez-Dekker

            :param filename: TAP file. A dialog is opened when no file is given
            :param application: Desired application
            :param t_start: start time in datetime format for LUT. It defaults
            to the start of the TAP file
            :param t_stop: stop time, in datetime format for LUT.
            :param delta_t: the time step considered for creating the LUT
        """
        self.TAP_loaded = True
        self.TAP_swaths, self.TAP_acqs = TAP.read_TAP(filename, application)
        self.TAP_LUT = TAP.TAP_lookup_table(self.TAP_acqs)

    def cycle(self, pt_ind):
        """ Returns acquisition timeline for a given point

            :author: Paco Lopez-Dekker

            :param pt_ind: 1 or 2 element index to desired point
        """
        cond = (type(pt_ind) is tuple) or (type(pt_ind) is list)
        pt_ind_ = tuple(pt_ind) if cond else (pt_ind,)
        if len(pt_ind_) != (len(self.asc_acqs.shape)):
            raise ValueError("Wrong indices")
        a_acqs = self.asc_acqs[pt_ind_]
        d_acqs = self.desc_acqs[pt_ind_]
        # Read ascending angles
        a_inc = self.track_grid.Ascending.inc_angle[a_acqs.lat_ind,
                                                    a_acqs.lon_inds.flatten()]
        d_inc = self.track_grid.Descending.inc_angle[d_acqs.lat_ind,
                                                     d_acqs.lon_inds.flatten()]
        return (a_inc, d_inc)

    def TAP_merge(self):

        """Function to check if the a possible acquisition is included in the TAP

        """

        Norb = self.track_grid.norb
        Torb = self.track_grid.Torb*3600   # sec
        cycletime = Torb*Norb
        #T0 = np.datetime64(self.track_grid.T0, dtype='M8[s]')
        T0 = self.track_grid.T0
        T0_TAP = self.TAP_LUT.t0
        timedif = (T0-T0_TAP).astype('m8[s]').astype(int)
        TAP_max = len(self.TAP_LUT.LUT)
        numcycles = np.ceil(TAP_max/cycletime).astype(int)
        ncycle = np.arange(0, numcycles*cycletime, cycletime)
        dim_in = np.size(np.shape(self.asc_acqs))

        asc_TAP_tl = np.empty(self.asc_acqs.size, dtype=np.object)
        dsc_TAP_tl = np.empty(self.desc_acqs.size, dtype=np.object)

        bar = ProgressBar("Merging with the TAP", self.asc_acqs.size)
        # FIX-ME: this does not consider SESAME/PICOSAR like acquisitions
        # with a primary and a secondary formation
        for i in range(self.asc_acqs.size):
            asc_TAP_tl[i] = timeline_expand(self.asc_acqs.flatten()[i],
                                            Torb,
                                            self.track.norb,
                                            numcycles,
                                            timedif,
                                            self.TAP_LUT,
                                            self.TAP_acqs,
                                            self.TAP_swaths)
            dsc_TAP_tl[i] = timeline_expand(self.desc_acqs.flatten()[i],
                                            Torb,
                                            self.track.norb,
                                            numcycles,
                                            timedif,
                                            self.TAP_LUT,
                                            self.TAP_acqs,
                                            self.TAP_swaths)
            bar.update(i)
        self.asc_TAP_timeline = asc_TAP_tl.reshape(self.asc_acqs.shape)
        self.desc_TAP_timeline = dsc_TAP_tl.reshape(self.desc_acqs.shape)

    def OrbTimeline_merge(self, orb_tmln, swathes, swathtype='inc_range'):
        """ Merges given OrbTimeline object and expands acquisition timeline
            accordingly

            :param orb_tmln: OrbTimeline object as defined in
                             drama/coverage/activation
            :param swathes: n_modes x 2 array defining the swathes according to
                            swathtype (radians or meter)
            :param swatgtype: one out of 'inc_range' (default) or 'echo_window'
        """
        Norb = self.track_grid.norb
        Torb = self.track_grid.Torb*3600   # sec
        cycletime = Torb * Norb
        # T0 = np.datetime64(self.track_grid.T0, dtype='M8[s]')
        T0 = self.track_grid.T0
        numcycles = len(orb_tmln.cyclevec)
        ncycle = np.arange(0, numcycles * cycletime, cycletime)
        dim_in = np.size(np.shape(self.asc_acqs))

        asc_tl = np.empty(self.asc_acqs.size, dtype=np.object)
        dsc_tl = np.empty(self.desc_acqs.size, dtype=np.object)

        bar = ProgressBar("Merging with the TAP", self.asc_acqs.size)
        if self.has_primary:
            for i in range(self.asc_acqs.size):
                asc_tl[i] = timeline_expand_orbtml(self.asc_acqs.flatten()[i],
                                                   Torb,
                                                   self.track.norb,
                                                   orb_tmln,
                                                   swathes,
                                                   swathtype,
                                                   self.asc_acqs2.flatten()[i])
                dsc_tl[i] = timeline_expand_orbtml(self.desc_acqs.flatten()[i],
                                                   Torb,
                                                   self.track.norb,
                                                   orb_tmln,
                                                   swathes,
                                                   swathtype,
                                                   self.desc_acqs2.flatten()[i])
                bar.update(i)
        else:
            for i in range(self.asc_acqs.size):
                asc_tl[i] = timeline_expand_orbtml(self.asc_acqs.flatten()[i],
                                                   Torb,
                                                   self.track.norb,
                                                   orb_tmln,
                                                   swathes,
                                                   swathtype,
                                                   None)
                dsc_tl[i] = timeline_expand_orbtml(self.desc_acqs.flatten()[i],
                                                   Torb,
                                                   self.track.norb,
                                                   orb_tmln,
                                                   swathes,
                                                   swathtype,
                                                   None)
                bar.update(i)
        self.asc_TAP_timeline = asc_tl.reshape(self.asc_acqs.shape)
        self.desc_TAP_timeline = dsc_tl.reshape(self.desc_acqs.shape)

    def check_angles(self, theta_i, beam):
        # the check with the if will be necessary when in one tap
        # there will be more than one acquisition modes
        # if beam == self.TAP_swaths.swathId[0]:
        inc1 = look_to_inc(np.deg2rad(self.TAP_swaths.lookNear),
                           self.track.Horb)
        inc2 = look_to_inc(np.deg2rad(self.TAP_swaths.lookFar),
                           self.track.Horb)
        I = np.where(np.logical_and(theta_i >= inc1, theta_i <= inc2))
        return I