"""
=======================================
Mission Package (:mod:`trampa.mission`)
=======================================

.. currentmodule:: trampa.mission

TimeLine
========

.. autosummary::
    :toctree: generated/


Subpackages
===========
.. toctree::
   :maxdepth: 1

   trampa.mission.timeline

"""
