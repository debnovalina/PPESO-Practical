from __future__ import absolute_import, division, print_function
import numpy as np
from collections import namedtuple
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.basemap import Basemap, maskoceans
import os
from mpl_toolkits import axes_grid1
from drama.mission.timeline import acquisitions as tml

def latency_analysis(lat_min, lat_max, lat_res, lon_min, lon_max, lon_res,
                     inc_angle_range, look_dir='right', parFile=None):

    """ Calculates latencies w.r.t. coverages over a full repeat cycle
        at a chosen grid of latitudes and longitudes. Usually you want to
        go for fine resolution in longitude, about 2 swathes wide, and a
        coarse resolution in latitude.

        :author: Thomas Boerner

        :param lat_min: minimum of desired latitude grid [deg].
        :type lat_min: float
        :param lat_max: maximum of desired latitude grid [deg].
        :type lat_max: float
        :param lat_res: resolution of desired latitude grid [deg].
        :type lat_min: float
        :param lon_min: minimum of desired longitude grid [deg].
        :type lon_min: float
        :param lon_max: maximum of desired longitude grid [deg].
        :type lon_max: float
        :param lon_res: resolution of desired longitude grid [deg].
        :type lon_min: float
        :param inc_angle_range: near and far range incidence angle [deg].
        :type inc_angle_range: two-elements array
        :param look_dir: look direction of radar, i.e. 'left' or 'right'.
        :type look_dir: string
        :param parFile: complete path to parameter file.
        :type parFile: string

        :returns: named tuple containing latency analysis results.

    """

    # define lat/lon grid w.r.t. user inputs
    lat_arr = np.arange(lat_min, lat_max + lat_res, lat_res)
    lon_arr = np.arange(lon_min, lon_max + lon_res, lon_res)
    lon = lon_arr.reshape([1,lon_arr.size]) + np.zeros([lat_arr.size,
                                                        lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size,1]) + np.zeros(lon_arr.shape)

    # get timeline for each point
    timeline = tml.LatLonTimeline(par_file=parFile, lats=lat, lons=lon,
                                 inc_angle_range=inc_angle_range,
                                 look_dir=look_dir)

    # retrieve timelines for each latitude and put them into arrays
    Torb         = timeline.track.Torb
    norb         = timeline.track.norb
    rep_cyc      = timeline.track.repeat_cycle * 24.
    asc_tl       = timeline.asc_acqs
    desc_tl      = timeline.desc_acqs
    cnt_asc      = np.zeros(lat_arr.size)
    cnt_desc     = np.zeros(lat_arr.size)
    cnt_comb     = np.zeros(lat_arr.size)
    tl_diff_asc  = np.zeros(0)
    tl_diff_desc = np.zeros(0)
    tl_diff_comb = np.zeros(0)
    tl_ev_asc    = np.zeros((lat_arr.size,lon_arr.size))
    tl_ev_desc   = np.zeros((lat_arr.size,lon_arr.size))
    tl_ev_comb   = np.zeros((lat_arr.size,lon_arr.size))
    max_asc      = np.zeros((lat_arr.size,lon_arr.size))
    max_desc     = np.zeros((lat_arr.size,lon_arr.size))
    max_comb     = np.zeros((lat_arr.size,lon_arr.size))

    for i in range(lat_arr.size):
        for j in range(lon_arr.size):
            orbtime_asc  = asc_tl[i][j].orbtime
            if (orbtime_asc.size != 0):
                orbtime_asc    = np.append(orbtime_asc, orbtime_asc[0])
                orbnum_asc     = asc_tl[i][j].orbnum
                orbnum_asc     = np.append(orbnum_asc, orbnum_asc[0] + norb)
                cnt_asc[i]     = cnt_asc[i-1] + orbtime_asc.size
                orbtime_asc    = orbtime_asc/3600. + Torb*orbnum_asc
                diff_asc       = orbtime_asc[1:] - orbtime_asc[0:-1]
                max_asc[i,j]   = np.max(diff_asc)
                tl_diff_asc    = np.append(tl_diff_asc, diff_asc)
                tl_ev_asc[i,j] = (1./(2.*rep_cyc))*np.sum((diff_asc**2))

            orbtime_desc = desc_tl[i][j].orbtime
            if (orbtime_desc.size != 0):
                orbtime_desc    = np.append(orbtime_desc, orbtime_desc[0])
                orbnum_desc     = desc_tl[i][j].orbnum
                orbnum_desc     = np.append(orbnum_desc, orbnum_desc[0] + norb)
                cnt_desc[i]     = cnt_desc[i-1] + orbtime_desc.size
                orbtime_desc    = orbtime_desc/3600. + Torb*orbnum_desc
                diff_desc       = orbtime_desc[1:] - orbtime_desc[0:-1]
                max_desc[i,j]   = np.max(diff_desc)
                tl_diff_desc    = np.append(tl_diff_desc, diff_desc)
                tl_ev_desc[i,j] = (1./(2.*rep_cyc))*np.sum((diff_desc**2))

            if ((orbtime_asc.size != 0) or (orbtime_desc.size != 0)):
                if (orbtime_asc.size == 0):
                    # orbtime_comb    = orbtime_desc
                    # orbnum_comb     = orbnum_desc
                    # diff_comb       = diff_desc
                    max_comb[i,j]   = max_desc[i,j]
                    tl_diff_comb    = tl_diff_desc
                    tl_ev_comb[i,j] = tl_ev_desc[i,j]
                    cnt_comb[i]     = cnt_desc[i]
                if (orbtime_desc.size == 0):
                    # orbtime_comb    = orbtime_asc
                    # orbnum_comb     = orbnum_asc
                    # diff_comb       = diff_asc
                    max_comb[i,j]   = max_asc[i,j]
                    tl_diff_comb    = tl_diff_asc
                    tl_ev_comb[i,j] = tl_ev_asc[i,j]
                    cnt_comb[i]     = cnt_asc[i]
                else:
                    orbtime_comb    = np.append(orbtime_asc, orbtime_desc)
                    # orbnum_comb     = np.append(orbnum_asc, orbnum_desc)
                    osort           = orbtime_comb.argsort()
                    orbtime_comb    = orbtime_comb[osort]
                    # orbnum_comb     = orbnum_comb[osort]
                    cnt_comb[i]     = cnt_comb[i-1] + orbtime_comb.size
                    diff_comb       = orbtime_comb[1:] - orbtime_comb[0:-1]
                    max_comb[i,j]   = np.max(diff_comb)
                    tl_diff_comb    = np.append(tl_diff_comb, diff_comb)
                    tl_ev_comb[i,j] = (1./(2.*rep_cyc))*np.sum((diff_comb**2))


    latencies = namedtuple('latencies',
                           ['cnt_asc', 'cnt_desc', 'cnt_comb',
                            'tl_diff_asc', 'tl_diff_desc', 'tl_diff_comb',
                            'tl_ev_asc', 'tl_ev_desc', 'tl_ev_comb',
                            'max_asc', 'max_desc', 'max_comb',
                            'lat_arr', 'lon_arr', 'lat_min', 'lat_max',
                            'lon_min', 'lon_max', 'lat', 'lon'])

    latencies = latencies(cnt_asc, cnt_desc, cnt_comb, tl_diff_asc,
                          tl_diff_desc, tl_diff_comb, tl_ev_asc, tl_ev_desc,
                          tl_ev_comb, max_asc, max_desc,
                          max_comb, lat_arr, lon_arr, lat_min, lat_max,
                          lon_min, lon_max, lat, lon)

    return latencies


def plot_latency(ltc, max_cb_ev=None, max_cb_mx=None, discrete=True,
                 savepath=None, continents=True,
                 projection='cyl', grid_spacing=20):

    """ Creates some plots from latency analysis results.

        :author: Thomas Boerner

        :param ltc: latency analysis results.
        :type ltc: tuple
        :param max_cb: maximum value to be shown in the plot (and color bar).
        :type max_cb: int
        :param discrete: flag to trigger discrete color bar (rather than a
                         continuous cb, which is better for yearly results)
                         [True/False].
        :type discrete: boolean
        :param savepath: path to directory where plot shall be saved.
        :type savepath: string
        :param continents: flag to trigger plotting of coastlines
        :type continents: boolean

        :returns: nothing, only plots.

    """

    mpl.rcParams.update({'font.size': 10})

    if (savepath is not None):
        if not os.path.exists(savepath):
            os.makedirs(savepath)

    if (max_cb_ev is None):
        max_cb_ev = np.max(np.concatenate([ltc.tl_ev_asc,
                                           ltc.tl_ev_desc]))/24. + 1
    else:
        max_cb_ev = max_cb_ev + 1

    if (max_cb_mx is None):
        max_cb_mx = np.max(np.concatenate([ltc.max_asc,
                                           ltc.max_desc]))/24. + 1
    else:
        max_cb_mx = max_cb_mx + 1

    labels_ev = np.arange(0, int(max_cb_ev) + 1, 1)
    loc_ev = labels_ev + .5
    labels_t_ev = list(map(str,labels_ev.tolist()))
    labels_t_ev[-2] = '>= ' + labels_t_ev[-2]

    cmap_ev = plt.get_cmap('jet', max_cb_ev)
    cmaplist_ev = [cmap_ev(i) for i in range(cmap_ev.N)]
    cmaplist_ev[0] = (0,0,0,0)
    cmap_ev = cmap_ev.from_list('Custom cmap', cmaplist_ev, cmap_ev.N)

    labels_mx = np.arange(0, int(max_cb_mx) + 1, 1)
    loc_mx = labels_mx + .5
    labels_t_mx = list(map(str,labels_mx.tolist()))
    labels_t_mx[-2] = '>= ' + labels_t_mx[-2]

    cmap_mx = plt.get_cmap('jet', max_cb_mx)
    cmaplist_mx = [cmap_mx(i) for i in range(cmap_mx.N)]
    cmaplist_mx[0] = (0,0,0,0)
    cmap_mx = cmap_mx.from_list('Custom cmap', cmaplist_mx, cmap_mx.N)

    # ascending
    fig1 = plt.figure()
    ax1 = fig1.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im1 = plt.pcolormesh(xs, ys, ltc.tl_ev_asc/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        xs, ys = m(ltc.lon, ltc.lat)

        im1 = plt.pcolormesh(xs, ys, ltc.tl_ev_asc/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)


    ax1.set_title('Ascending Expected Latencies [days]')

    cb1 = m.colorbar(im1,"right", size="5%", pad='2%')

    if discrete:
        cb1.set_ticks(loc_ev)
        cb1.set_ticklabels(labels_t_ev)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'ltc_ev_' + projection + '_asc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()

    fig11 = plt.figure()
    ax11 = fig11.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im11 = plt.pcolormesh(xs, ys, ltc.max_asc/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        xs, ys = m(ltc.lon, ltc.lat)

        im11 = plt.pcolormesh(xs, ys, ltc.max_asc/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)


    ax11.set_title('Ascending Maximum Latencies [days]')

    cb11 = m.colorbar(im11,"right", size="5%", pad='2%')

    if discrete:
        cb11.set_ticks(loc_mx)
        cb11.set_ticklabels(labels_t_mx)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'max_' + projection + '_asc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()

    # descending
    fig2 = plt.figure()
    ax2 = fig2.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im2 = plt.pcolormesh(xs, ys, ltc.tl_ev_desc/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        im2 = plt.pcolormesh(xs, ys, ltc.tl_ev_desc/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)

    ax2.set_title('Descending Expected Latencies [days]')

    cb2 = m.colorbar(im2,"right", size="5%", pad='2%')

    if discrete:
        cb2.set_ticks(loc_ev)
        cb2.set_ticklabels(labels_t_ev)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'ltc_ev_' + projection + '_desc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()

    fig22 = plt.figure()
    ax22 = fig22.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im22 = plt.pcolormesh(xs, ys, ltc.max_desc/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        im22 = plt.pcolormesh(xs, ys, ltc.max_desc/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)

    ax22.set_title('Descending Maximum Latencies [days]')

    cb22 = m.colorbar(im22,"right", size="5%", pad='2%')

    if discrete:
        cb22.set_ticks(loc_mx)
        cb22.set_ticklabels(labels_t_mx)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'max_' + projection + '_desc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()

    # combined/interleaved
    fig3 = plt.figure()
    ax3 = fig3.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im3 = plt.pcolormesh(xs, ys, ltc.tl_ev_comb/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        im3 = plt.pcolormesh(xs, ys, ltc.tl_ev_comb/24., cmap=cmap_ev, vmin=0,
                             vmax=max_cb_ev)

    ax3.set_title('Asc. + Desc. Expected Latencies [days]')

    cb3 = m.colorbar(im3,"right", size="5%", pad='2%')

    if discrete:
        cb3.set_ticks(loc_ev)
        cb3.set_ticklabels(labels_t_ev)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'ltc_ev_' + projection + '_comb.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()

    fig33 = plt.figure()
    ax33 = fig33.add_axes([0.1, 0.1, 0.8, 0.8])

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = ltc.lat_min if projection == 'npstere' else ltc.lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=0, resolution='l')
        m.drawcoastlines()
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        xs, ys = m(ltc.lon, ltc.lat)

        im33 = plt.pcolormesh(xs, ys, ltc.max_comb/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)

    else:
        m = Basemap(llcrnrlon=ltc.lon_min, llcrnrlat=ltc.lat_min,
                    urcrnrlon=ltc.lon_max, urcrnrlat=ltc.lat_max,
                    projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmapboundary()
        m.drawcoastlines()

        im33 = plt.pcolormesh(xs, ys, ltc.max_comb/24., cmap=cmap_mx, vmin=0,
                              vmax=max_cb_mx)

    ax33.set_title('Asc. + Desc. Maximum Latencies [days]')

    cb33 = m.colorbar(im33,"right", size="5%", pad='2%')

    if discrete:
        cb33.set_ticks(loc_mx)
        cb33.set_ticklabels(labels_t_mx)

    if (savepath is not None):
        figpath = os.path.join(savepath, 'max_' + projection + '_comb.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        plt.close()


    plt.show()

    return

