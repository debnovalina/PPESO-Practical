# -*- coding: utf-8 -*-
"""
=========================================================
Mission Timeline Package (:mod:`drama.mission.timeline`)
=========================================================

.. currentmodule:: drama.mission.coverage

TimeLine
========

.. autosummary::
    :toctree: generated/

    latency_analysis
    plot_latency

"""

from .coverage import latency_analysis, plot_latency