
import struct

class Struct():
    """ Base class to create structures in a C-like way
        This class is useful when writing binary files with a fixed structure 
        is needed
        
        .. warning::
           **DO NOT** USE THIS CLASS IF YOU NEED 'STRUCT' LIKE OBJECT IN PYTHON!
           PYTHON HAS BETTER WAYS TO DO THAT!
           
        .. note::
            Should see if this code can be ported to RECARRAYS...!
        
        Example::
        
            class StructName(Struct):
                _fields_ = [('var_name_1', 'type', default_value),
                                           ...
                            ('var_name_2', 'type', default_value)]
        
        Allowed types:
            * All types supported by :mod:`struct` (ex. c, i, d, h...)
            * All those types as arrays (ex. 10c, 8i, 19d, 2h...) where 
              number indicates array length
            * Other ``Struct`` members: 'C' 
            
        :raises: ValueError if fields are not defined
    """
    def __init__(self):
        
        if self._fields_ is None:
            raise ValueError('Structure fields not defined')
        
        for var_name, _, def_value in self._fields_:
                vars(self)[var_name] = def_value 
                
    def packed(self):
        """ Returns the structure as a binary sequence of bytes, 
            useful to write the structure into a file
            
            :returns: Structure as a binary sequence of bytes
        """
        
        output = []
        for var_name, type, _ in self._fields_:
            # Check whether type is array, other structure or scalar value
            if len(type) > 1:
                output.append(struct.pack(type, *vars(self)[var_name]))
            else:
                if type == 'C':
                    output.append(vars(self)[var_name].packed())
                else:
                    output.append(struct.pack(type, vars(self)[var_name]))
                    
        return ''.join(output)