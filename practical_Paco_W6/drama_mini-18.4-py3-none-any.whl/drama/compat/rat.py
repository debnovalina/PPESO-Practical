
import struct
import numpy as np
from . import Struct


np2idl = {np.dtype(np.int8) : (1, 'b'),
          np.dtype(np.int16) : (2, 'h'),
          np.dtype(np.int32) : (3, 'i'),
          np.dtype(np.int64) : (14, 'q'),
          np.dtype(np.uint16) : (12, 'H'),
          np.dtype(np.uint32) : (13, 'I'),
          np.dtype(np.uint64) : (15, 'Q'),
          np.dtype(np.float) : (5, 'd'),
          np.dtype(np.float32) : (4, 'f'),
          np.dtype(np.float64) : (5, 'd'),
          np.dtype(np.complex) : (9, 'd'),
          np.dtype(np.complex64) : (6, 'f'),
          np.dtype(np.complex128) : (9, 'd'),
          np.dtype(np.string_) : (7, 's')}

       
class Rat(Struct):
    _fields_ = [('magic_long', 'i', 844382546),
                ('version', 'f', 2.0),
                ('n_dim', 'i', 0),
                ('n_channel', 'i', 0),
                ('dim', '8i', [0] * 8),
                ('var', 'i', 0),
                ('sub', '2i', [1] * 2),
                ('rat_type', 'i', 0),
                ('reserved', '9i', [0] * 9)]


class DatumShift(Struct):
    _fields_ = [('tx', 'd', 0.0),
                ('ty', 'd', 0.0),
                ('tz', 'd', 0.0),
                ('rx', 'd', 0.0),
                ('ry', 'd', 0.0),
                ('rz', 'd', 0.0),
                ('scl', 'd', 0.0),
                ('info', '64b', bytearray(64))]
    
    
class Geo(Struct):
    _fields_ = [('projection', 'h', 0),
                ('ps_east', 'd', 0.0),
                ('ps_north', 'd', 0.0),
                ('min_east', 'd', 0.0),
                ('min_north', 'd', 0.0),
                ('zone', 'h', 0),
                ('hemisphere', 'h', 0),
                ('long0scl', 'd', 0.9996),
                ('max_axis_ell', 'd', 6378137.0),
                ('min_axis_ell', 'd', 6356752.31425),
                ('datum_shift', 'C', DatumShift()),
                ('reserved', '18b', bytearray(18))]
    
    
class RatHeader(Struct):
    _fields_ = [('rat', 'C', Rat()),
                ('info', '100b', bytearray(100)),
                ('geo', 'C', Geo()),
                ('stat', '25i', [0] * 25),
                ('reserved_1', '25i', [0] * 25),
                ('reserved_2', '25i', [0] * 25),
                ('reserved_3', '25i', [0] * 25),
                ('reserved_4', '25i', [0] * 25),
                ('reserved_5', '25i', [0] * 25)]


class RatFile():
    """ Class to handle RAT files. 
        This class lets you to write *any* NumPy array into file with RAT format.
        
        :param file_name: File path
        :param mode: File access mode, 'w' (write) or 'r' (read)
        :param overwrite: If true, will overwrite existing file
        
        :raises ValueError: if indicated mode is not supported
        :raises IOError: if indicated file cannot be read/written
            
        .. note::
           This file format should only be used if you need to interact with
           IDL code. If you are only using Python, maybe :mod:`pickle` is a
           better solution
        
        .. note::
           Only write support implemented
    """
    def __init__(self, file_name, mode, overwrite = True):

        if mode != 'w':
            raise ValueError('Access mode not supported')
        
        if overwrite == True:
            mode += '+'
        
        self.file = open(file_name, mode)
        self.header = RatHeader()
        
    def write(self, data):
        """ Writes data into the RAT file 
            
            :param data: NumPy data array
            
            :raises ValueError: If data is not a NumPy array or containing data type is not supported by IDL
        """
        
        if type(data) != np.ndarray:
            raise TypeError('Only NumPy arrays are supported')
        
        try:
            data_type = np2idl[data.dtype]
        except KeyError:
            raise TypeError('Data type not supported')
        
        self.header.rat.var = data_type[0]
        self.header.rat.n_dim = len(data.shape)
        # TODO: Should check if it is really correct for all cases
        self.header.rat.dim[0:len(data.shape)] = data.shape[::-1]
        
        self.header.rat.n_channel = 1
        
        self.header.info[0] = ' '
        
        self.file.write(self.header.packed())
        
        # Complex type must be written [Re,Im]
        # TODO: Should be improved
        if (data_type[0] == 9) or (data_type[0] == 6):
            self.file.write(struct.pack('%d%s' % (data.size * 2, data_type[1]), *np.array([[c.real, c.imag] for c in data.flatten()]).flatten()))  
        else:
            self.file.write(struct.pack('%d%s' % (data.size, data_type[1]), *data.flatten()))
        
    def close(self):
        """ Closes RAT file """
        self.file.close()