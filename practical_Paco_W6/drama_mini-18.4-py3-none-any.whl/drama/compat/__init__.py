"""
============================================
Compatibility Package (:mod:`trampa.compat`)
============================================

.. currentmodule:: trampa.compat

This module contains utilities to keep compatibility
with other interfaces (e.g. IDL)

IDL RAT files
=============

.. autosummary::
   :toctree: generated/

   RatFile
   
C-Like Struct
=============

.. autosummary::
   :toctree: generated/

   Struct
   
"""

from .struct import Struct
from .rat import RatFile