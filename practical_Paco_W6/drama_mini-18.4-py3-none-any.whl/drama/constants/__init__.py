"""
===========================================
Constants Package (:mod:`trampa.constants`)
===========================================

.. currentmodule:: trampa.constants
  
Constants
=========

.. autosummary::
    :toctree: generated/


"""

from .constants import *
