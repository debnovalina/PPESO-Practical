import numpy as np

import os
from collections import namedtuple
import scipy.interpolate as interpol
from .misc import get_parFile

def read_wbmod(filename=None):

    """ Reader for ionospheric wbmod data files (plain tabulated ASCII files 
        in *.dat or compressed *.dat.gz ). Format description as follows: 
        
        Filenames: 
        wb_biomass_YYYY-MM-DDs-LLcXXkY-T.dat.gz
        where:
            - YYYY-MM-DD is the date in year-month-day format
            - LL is the look angle in degrees (positive for left-looking on 
              the ascending node)
            - XX is the confidence interval for the Ck parameter supplied by 
              WBMOD (for details, see Green & Quegan, 2008 , 2009; Rino, 1979)
            - Y is the planetary Kp index (1, 3 or 7)
            - T is the sunrise/set type identifier (r for sunrise, s for 
              sunset).
        
        File contents: 
        - Col. 1: Longitude of ground incidence point (degrees)
        - Col. 2: Latitude of ground incidence point (degrees)
        - Col. 3: Longitude of ionospheric penetration point (IPP) (degrees)
        - Col. 4: Latitude of IPP (degrees)
        - Col. 5: Longitude of satellite (degrees), between -180°and 180° with 
                  positive values Eastward of the prime meridian 
        - Col. 6: Latitude of satellite (degrees) between -80°and 80° with 
                  positive values North of the equator, negative values to the 
                  South
        - Col. 7: S4 scintillation index
        - Col. 8: Phase PDS strength parameter
        - Col. 9: Phase PDS slope parameter
        - Col. 10: In situ irregularity slope parameter
        - Col. 11: Logarithm of the ionospheric strength parameter, log10(CkL)
        - Col. 12: Along-field anisotropy parameter, a
        - Col. 13: Across-field anisotropy parameter, b
        - Col. 14: Magnetic declination at IPP (degrees)
        - Col. 15: Magnetic dip angle at IPP (degrees)
        - Col. 16: Magnetic meridian angle at IPP (degrees)
        - Col. 17: The angle between irregularity sheets and L-shells (degrees)
        - Col. 18: Angle between radar boresight and nadir (degrees) at 
                   ionosphere 

        :author: Thomas Boerner
        
        :param filename: name of the wbmod data file
        :type filename: string

        :returns: wbmod data array

    """

    # let user pick file if not provided via keyword
    filename = get_parFile(filename)
    
    # make use of numpy.genfromtxt , *.gz files are automatically decompressed
    data = np.genfromtxt(filename,dtype=None)
    
    # extract information from filename
    fname   = os.path.split(filename)[1]
    fname   = fname.split('wb_biomass_')[1]
    fname   = fname.split('.dat')[0]
    
    suntype = fname.split('-')[-1]
    
    date    = fname.split('s')[0].split('-')
    date    = [int(i) for i in date]
    
    fname   = fname.split('s')[1].split('c')
    
    look_a  = float(fname[0])
    
    fname   = fname[1].split('-')[0].split('k')
    
    Ck_conf = float(fname[0])
    
    Kp      = int(fname[1])
    
    # put everything into a named tuple
    wbmod_data = namedtuple('wbmod_data',
                            ['date', 'look_a', 'Ck_conf', 'Kp', 'suntype', 
                             'data'])
    wbmod_data = wbmod_data(date, look_a, Ck_conf, Kp, suntype, data)
    
    return wbmod_data
    
    
def interp_wbmod(filename=None):

    """ Interpolates wbmod data to a regular lat/lon grid of ground 
        incidence point coordinates. Result is stored to a binary file. 
        
        :author: Thomas Boerner
        
        :param filename: name of the wbmod data file
        :type filename: string

        :returns: nothing, but data is stored to binary file
        
    """
    
    # let user pick file if not provided via keyword
    if filename is None:
        Tk().withdraw()
        filename = tkFileDialog.askopenfilename(title='Select file')
    
    # retrieve data from original wbmod data file
    wbmod_data = read_wbmod(filename=filename)
    
    # create regular lat/lon grid with a spacing of 1 degree
    lat = np.linspace(-90, +90, 181)       # regularly spaced lat vector
    lon = np.linspace(-180, +180, 361)     # regularly spaced lon vector
    lon_i, lat_i = np.meshgrid(lon, lat)
    
    # input ground incidence lat/lon
    lat_gr = wbmod_data.data[:,1]
    lon_gr = wbmod_data.data[:,0]
    
    # interpolate input data
    CkL = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,10],
                            (lon_i, lat_i), method='linear')
    S4_scint = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,6],
                                 (lon_i, lat_i), method='linear')
    a = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,11],
                          (lon_i, lat_i), method='linear')
    b = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,12],
                          (lon_i, lat_i), method='linear')
    mag_decl = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,13],
                                 (lon_i, lat_i), method='linear')
    mag_dip = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,14],
                                (lon_i, lat_i), method='linear')
    ang_irregsh = interpol.griddata((lon_gr, lat_gr), wbmod_data.data[:,16],
                                    (lon_i, lat_i), method='linear')
    
    # write results to file
    file_out = filename.split('dat')[0] + 'npz'
    np.savez(file_out, CkL=CkL, S4_scint=S4_scint, a=a, b=b, 
             mag_decl=mag_decl, mag_dip=mag_dip, ang_irregsh=ang_irregsh, 
             lat=lat, lon=lon)
    
    return 

    
def load_wbmod(filename=None):

    """ Loads interpolated (regularly gridded) wbmod data from .npz files 
        stored using the interp_wbmod function and writes them into a named 
        tuple. 
        
        :author: Thomas Boerner
        
        :param filename: name of the interpolated wbmod .npz data file
        :type filename: string

        :returns: named tuple containing interpolated wbmod data
        
    """
    
    # let user pick file if not provided via keyword
    if filename is None:
        Tk().withdraw()
        filename = tkFileDialog.askopenfilename(title='Select file')
    
    # retrieve data from interpolated .npz wbmod data file
    wb = np.load(filename)
    
    # sort file contents into a named tuple
    wbmod_int = namedtuple('wbmod_int',
                            ['CkL', 'S4_scint', 'a', 'b', 'mag_decl', 
                             'mag_dip', 'ang_irregsh', 'lat', 'lon'])
    wbmod_int = wbmod_int(wb['CkL'], wb['S4_scint'], wb['a'], wb['b'], 
                          wb['mag_decl'], wb['mag_dip'], wb['ang_irregsh'], 
                          wb['lat'], wb['lon'])
    
    return wbmod_int
    
    
def retrieve_wbmod(path, date=[1998,3,16], look_a=25, Ck_conf=50, 
                   Kp=1, suntype='r'):

    """ Retrieves interpolated wbmod data from a given set of file parameters. 
        
        :author: Thomas Boerner
        
        :param path: path to the wbmod database
        :type path: string
        :param date: date array [year,month,day]
        :type date: 1-dim array
        :param look_a: look angle in degrees, either 25° or -25°
        :type look_a: number
        :param Ck_conf: confidence interval of Ck, either 50 or 90
        :type Ck_conf: number
        :param Kp: planetary Kp index, either 1, 3 or 7
        :type Kp: number
        :param suntype: sunrise/set type identifier, either 'r' or 's'
        :type suntype: string

        :returns: named tuple containing interpolated wbmod data
        
    """
    
    # convert parameters into file string
    year = np.str(date[0])
    if date[1] < 10: 
        month = '0' + np.str(date[1])
    else: 
        month = np.str(date[1])
    if date[2] < 10: 
        day = '0' + np.str(date[2])
    else: 
        day = np.str(date[2])
    
    filename = (path + 'wb_biomass_' + year + '-' + month + '-' + day + 's' + 
                np.str(look_a) + 'c' + np.str(Ck_conf) + 'k' + np.str(Kp) + 
                '-' + suntype + '.npz')
    
    # call the reader
    wbmod_int = load_wbmod(filename=filename)
    
    return wbmod_int
    
    
    