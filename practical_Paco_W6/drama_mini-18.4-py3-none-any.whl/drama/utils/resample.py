from __future__ import absolute_import, division, print_function
import numpy as np


def lincongrid1d(data, new_shp):
    ind = np.arange(new_shp) * data.size / new_shp
    ind_f = np.floor(ind).astype(int)
    delta = ind - ind_f
    data_ = data.flatten()
    inds = np.where(ind_f < (data.size - 1))
    res = np.zeros(new_shp, dtype=data.dtype)
    res[inds] = (data_[ind_f[inds]] * (1 - delta[inds]) +
                 delta[inds] * data_[ind_f[inds]+1])
    inds = np.where(ind_f >= (data.size - 1))
    res[inds] = (data_[ind_f[inds]] +
                 ((data_[ind_f[inds]] - data_[ind_f[inds]-1]) *
                  delta[inds]))
    return res


def lincongrid2d(data, new_shp):
    if (len(data.shape) != len(new_shp)) or (len(new_shp) != 2):
        raise NameError("Incompatible dimensions to lincongrid2d")

    # Handle case where first dimension is one
    if data.shape[0] == 1:
        d1 = lincongrid1d(data, new_shp[1]).reshape(1, new_shp[1])
        # We do not expand trivial dimensions
        return d1
    if data.shape[1] == 1:
        d1 = lincongrid1d(data, new_shp[0]).reshape(new_shp[0], 1)

    # Interpolate first over the first dimension
    ind = np.arange(new_shp[0]) * data.shape[0] / new_shp[0]
    ind_f = np.floor(ind).astype(int)
    delta = ind - ind_f
    inds = np.where(ind_f < (data.shape[0] - 1))[0]
    d1 = np.zeros((new_shp[0], data.shape[1]), dtype=data.dtype)
    delta_ = delta[inds].reshape((inds.size, 1))
    d1[inds, :] = (data[ind_f[inds], :] * (1 - delta_) +
                   delta_ * data[ind_f[inds]+1, :])
    inds = np.where(ind_f >= (data.shape[0] - 1))[0]
    delta_ = delta[inds].reshape((inds.size, 1))
    d1[inds, :] = (data[ind_f[inds], :] +
                   ((data[ind_f[inds], :] - data[ind_f[inds]-1, :]) *
                    delta_))
    # Interpolate first over the first dimension
    ind = np.arange(new_shp[1]) * data.shape[1] / new_shp[1]
    ind_f = np.floor(ind).astype(int)
    delta = ind - ind_f
    inds = np.where(ind_f < (data.shape[1] - 1))[0]
    d2 = np.zeros((new_shp[0], new_shp[1]), dtype=data.dtype)
    delta_ = delta[inds].reshape((1, inds.size))
    d2[:, inds] = (d1[:, ind_f[inds]] * (1 - delta_) +
                   delta_ * d1[:, ind_f[inds]+1])
    inds = np.where(ind_f >= (data.shape[1] - 1))[0]
    delta_ = delta[inds].reshape(1, (inds.size))
    d2[:, inds] = (d1[:, ind_f[inds]] +
                   ((d1[:, ind_f[inds]] - d1[:, ind_f[inds]-1]) *
                    delta_))
    return d2


def lincongrid(data, new_shp):
    """ Resizes 1 or 2 dimensionsal array to new shape
        performing a bilineal interpolation

        :param data: input np.array
        :param data: output shape (same dimensions as input)

        :out: resized array
    """
    if len(data.shape) == 1:
        return lincongrid1d(data, new_shp)
    elif len(data.shape) == 2:
        return lincongrid2d(data, new_shp)
    else:
        print("Unsuported number of dimensions")
        raise NameError("lincongrid failed")


def linresample(data, samples_, axis=0, extrapolate=False):
    """ Resamples data to new samples
        :param data: ndarray
        :param samples: new samples (1D vector)
        :param axis: axis to be resampled
        :param extrapolate: extend if required repeating first or last sample
    """
    smp = np.array(samples_)  # Just to make sure
    if not extrapolate:
        if (smp.min() < 0) or (smp.max() > (data.shape[axis] - 1)):
            print("Output samples out of bound")
            raise NameError("linresample failed")
    else:
        smp = np.where(smp > 0, smp, 0)
        smp = np.where(smp <= data.shape[axis] - 1, smp, data.shape[axis] - 1)
    ind_f = np.floor(smp).astype(int)
    delta = smp - ind_f
    # Now a hack to account for the case that the last sample is the last input
    # index
    ind_c = np.where(delta > 0, ind_f + 1, ind_f)
    delta_nshp = np.ones(len(data.shape), dtype=np.int32)
    delta_nshp[axis] = delta.size
    delta = delta.reshape(delta_nshp.tolist())
    if axis == 0:
        out = data[ind_f] * (1-delta) + data[ind_c] * delta
    elif axis == 1:
        out = data[:, ind_f] * (1-delta) + data[:, ind_c] * delta
    elif axis == 2:
        out = data[:, :, ind_f] * (1-delta) + data[:, :, ind_c] * delta
    else:
        print("Only resampling up third axis is supported")
        raise NameError("linresample failed")
    return out


def interp_rat(rat, samples):
    """ Read and interpolate samples from rat

        :param rat: rat object
        :param samples: a tuple with the new axes. The tuple should have the
                        same number of elements as we have dimensions
    """
    if len(rat.shape) != len(samples):
        print("Invalid axes")
        raise NameError("interp_rat failed")
    rat_block = ()
    for dim in range(len(samples)):
        t_block = (int(np.floor(samples[dim].min()).astype(int)),
                   int(np.ceil(samples[dim].max()).astype(int) + 1))
        rat_block = rat_block + t_block
    data = rat.read(block=rat_block)
    for dim in range(len(samples)):
        data = linresample(data,
                           samples[dim] - np.floor(samples[dim].min()),
                           axis=dim)

    return data