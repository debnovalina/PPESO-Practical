import numpy
import gdal
from gdal import *
import sys
import numpy as np
from drama.utils.misc import db2lin, db
from .misc import get_parFile
import matplotlib.pyplot as plt

def get_info_and_data(filename=None):

    """ General function to read the .tif file containing the backscattering map

        :param filename: Name of the .tif file containing the backscattering map
        :type filename: string

        :returns: backscattering map and correlated information

    """

    filename=r'/home/zonn_ma/Data/L band backscattering/meanHH_compress.tif'
    filename = get_parFile(filename)

    dataset = gdal.Open(filename, gdalconst.GA_ReadOnly)
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray(0, 0, dataset.RasterXSize, dataset.RasterYSize)
    geotransform = dataset.GetGeoTransform()
    lon0 = geotransform[0]
    lat0 = geotransform[3]
    dlon = geotransform[1]
    dlat = geotransform[5]
    lats = numpy.array([lat0 , lat0 + dlat*dataset.RasterYSize])
    lons = numpy.array([lon0, lon0 + dlon*dataset.RasterXSize])
    info = lats, lons, dataset.RasterXSize, dataset.RasterYSize, dlon, dlat

    return info, data


def load_sigma0(**kwargs):

    """ Function to get the sigma0 value for a given point with coordinates
        lat and lon

        :param lat: starting latitude point of the area of interest; if not
                    passed all the lat extension will be considered
        :type lat: float
        :param lon: starting longitude point of the area of interest; if not
                    passed all the lat extension will be considered
        :type lon: float
        :param lat_ext: extension of the area in lat; if not
                        passed all the lat extension will be considered
        :type lat_ext: float
        :param lon_ext: extension of the area in long; if not
                        passed all the lat extension will be considered
        :type lon_ext: float
        :param file_backscatt: Name of the .tif file containing the gamma_nought
        :type file_backscatt: string
        :param file_inc: Name of the .tif file containing the local incidence
                         angle
        :type file_inc: string

        :returns: sigma_nought for the point at coordinate [lat, lon]
    """

    if 'file_backscatt' not in kwargs:
        Tk().withdraw()
        file_backscatt_ = tkFileDialog.askopenfilename(title='Select backscattering map file')
    else:
        file_backscatt_ = kwargs['file_backscatt']
    if 'file_inc' not in kwargs:
        Tk().withdraw()
        file_inc_ = tkFileDialog.askopenfilename(title='Select incid_angle map file')
    else:
        file_inc_ = kwargs['file_inc']

    # load the gamma nouth
    dataset = gdal.Open(file_backscatt_, gdalconst.GA_ReadOnly)
    geotransform = dataset.GetGeoTransform()
    band = dataset.GetRasterBand(1)
    lon0 = geotransform[0]
    lat0 = geotransform[3]
    dlon = geotransform[1]
    dlat = geotransform[5]
    lats = numpy.array([lat0 , lat0 + dlat*dataset.RasterYSize])
    lons = numpy.array([lon0, lon0 + dlon*dataset.RasterXSize])
    lats = np.arange(lats[0], lats[1], dlat)
    lons = np.arange(lons[0], lons[1], dlon)

    # check if a specific point coordinate has been given or if the entire map
    # has to be loaded
    if 'lat' not in kwargs:
        lon_start = 0
        lat_start = 0
        lon_ext = dataset.RasterXSize
        lat_ext = dataset.RasterYSize
    else:
        lat = kwargs['lat']
        lon = kwargs['lon']
        #check the validity latlon in the tiff
        if min(lats) > lat or max(lats) < lat or min(lons) > lon or max(lons) < lon:
            print('error lat or lon are out of the image')
            sys.exit(0)
        lat_start = int(abs(np.around((lat - lats[0])/abs(dlat))))
        lon_start = int(np.around((lon - lons[0])/dlon))

        if 'lat_ext' in kwargs:
            # number of pixels I want to consider in the selected area
           lat_ext = int(abs(np.round(kwargs['lat_ext']/dlat)))
        else:
            lat_ext = 1 # just a single point
        #check the validity
        if lat_ext+lat_start > dataset.RasterYSize:
            print('Error: lat extension out of the image')
            sys.exit(0)

        if 'lon_ext' in kwargs:
           # number of pixels I want to consider in the selected area
           lon_ext = int((np.round(kwargs['lon_ext']/dlon)))
        else:
           lon_ext = 1 # number of pixels I want to consider in the selected area
        #check the validity latlon in the tiff
        if lon_ext+lon_start > dataset.RasterXSize:
            print('Error: lon extension out of the image')
            sys.exit(0)

    #read the data of the area of interest
    gamma_nought = np.array(band.ReadAsArray(lon_start, lat_start, lon_ext,
                                             lat_ext))
#    plt.figure()
#    plt.imshow(gamma_nought)
#    plt.colorbar()
    # transform the pixel value of gamma_nought in dB value
    dB_gamma_nought = map_decoding(gamma_nought)
#    plt.figure()
#    plt.imshow(dB_gamma_nought)
#    plt.colorbar()
    # transform the gamma_nought in sigma_nougth [dB]
    loc_inc_ang, sigma_0 = gamma_nought_to_sigma_nought(lon_start, lat_start,
                                                        lon_ext, lat_ext,
                                                        dB_gamma_nought,
                                                        file_inc_)
#    plt.figure()
#    plt.imshow(loc_inc_ang)
#    plt.colorbar()
#    plt.figure()
#    plt.imshow(sigma_0)
#    plt.colorbar()
    return sigma_0, dlat, dlon


def map_decoding(Value, ValueMax=255, ValueMin=0, dBMax=10, dBMin=-25):

    """ Function to convert a value from pixel values to unit values (dB)

        :param Value: Value to be converted
        :type Value: int
        :param ValueMax: maximum pixel value of the map
        :type ValueMax: int
        :param ValueMin: minimum pixel value of the map
        :type ValueMin: int
        :param dBMax: maximum value of the map in dB
        :type dBMax: float
        :param dBMin: minimum value of the map in dB
        :type dBMax: float

        :returns: value converted in unit values (dB)
    """

    # convert the range of the data in the real range [dB]
    ValueRange = (ValueMax - ValueMin)
    dBRange = (dBMax - dBMin)
    delta = dBRange/ValueRange
    map_decoded = (Value * delta) + dBMin

    return map_decoded


def gamma_nought_to_sigma_nought(lon_start, lat_start, lon_ext, lat_ext,
                                 dB_gamma_nought, filename_inc):

    """ Function to convert gamma_nought to sigma_nought

        :param lon_start: sample for the longitudes in the map from which to
                          start to read the incidence angle
        :type lon_start: int
        :param lat_start: sample for the latitudes in the map from which to
                          start to read the incidence angle
        :type lat_start: int
        :param lon_ext: extension of the area of interest [number of pixels]
        :type lon_ext: int
        :param lat_ext: extension of the area of interest  [number of pixels]
        :type lat_ext: float
        :param dB_gamma_nought: gamma_nought value in dB
        :type dB_gamma_nought: float

        :returns: sigma_nought (dB)
    """

    # read the local incidence angle
    dataset = gdal.Open(filename_inc, gdalconst.GA_ReadOnly)
    geotransform = dataset.GetGeoTransform()
    band = dataset.GetRasterBand(1)
    lon0 = geotransform[0]
    lat0 = geotransform[3]
    dlon = geotransform[1]
    dlat = geotransform[5]
    lats = numpy.array([lat0 , lat0 + dlat*dataset.RasterYSize])
    lons = numpy.array([lon0, lon0 + dlon*dataset.RasterXSize])
    lats = np.arange(lats[0], lats[1], dlat)
    lons = np.arange(lons[0], lons[1], dlon)
    loc_inc_ang = np.array(band.ReadAsArray(lon_start, lat_start, lon_ext,
                                            lat_ext))/5.
    # compute the sigma_0
    sigma_0 = db(db2lin(dB_gamma_nought)*np.cos(np.radians(loc_inc_ang)))

    return loc_inc_ang, sigma_0


def load_Cband_sigma0(GBM, lat, lon, inc_angle, case='avg'):

    """ Function to read the backscattering from the map as function of lat,
        lon and incidence angle

        :param GBM: backscattering map
        :type GBM: 2d array
        :param lat: latitude
        :type lat: float
        :param lon: longitude
        :type lon: float
        :param inc_angle: incidence angle
        :type inc_angle: float
        :param case: flag to read the average, worst or best value
        :type case: string
        :returns: coherence and kz
    """
    # Check for the correct positions on the interc and slope maps
    lat_arr = np.round(np.arange(-90., 90.0, 0.1), 1)
    lon_arr = np.round(np.arange(-180., 180., 0.1), 1)
    i = (np.where(lat_arr == lat)[0])
    j = (np.where(lon_arr == lon)[0])

    if case == 'avg':
        sigma0 = GBM[i, j, 0] + np.degrees(inc_angle)*GBM[i, j, 2]
    elif case == 'best':
        sigma0 = GBM[i, j, 0] + np.degrees(inc_angle)*GBM[i, j, 2]
        sigma0_std = np.sqrt(np.abs(GBM[i, j, 1] +
                                    (np.degrees(inc_angle)**2)*GBM[i, j, 3] +
                                    2.*np.degrees(inc_angle)*GBM[i, j, 4] -
                                    2.*np.degrees(inc_angle)*GBM[i, j, 0]*GBM[i, j, 2]))
        sigma0 = sigma0 + sigma0_std
    elif case == 'worst':
        sigma0 = GBM[i, j, 0] + np.degrees(inc_angle)*GBM[i, j, 2]
        sigma0_std = np.sqrt(np.abs(GBM[i, j, 1] +
                                    (np.degrees(inc_angle)**2)*GBM[i, j, 3] +
                                    2.*np.degrees(inc_angle)*GBM[i, j, 4] -
                                    2.*np.degrees(inc_angle)*GBM[i, j, 0]*GBM[i, j,2]))
        sigma0 = sigma0 - sigma0_std

    return sigma0




