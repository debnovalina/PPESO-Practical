import numpy as np
from drama import constants as const

def rot_z(vector, angle, inverse_transform=False):
    """ Rotates vector by angle around z-axis

        :param vector: 3 dimensional vector
        :param angle: angle [deg]
        :param inverse_Transform: Perform inverse rotation around z-axis

        :returns: rotated vector coordinates
    """
    if vector.shape[0] != 3:
        vector = vector.T
    if vector.ndim == 1:
        vector = vector.reshape((3, 1))
    angle_rad = np.deg2rad(angle)
    if inverse_transform:
        angle_rad == - angle_rad

    xp = (np.cos(angle_rad) * vector[0] + np.sin(angle_rad) * vector[1])
    yp = (- np.sin(angle_rad) * vector[0] + np.cos(angle_rad) * vector[1])
    zp = vector[2]
    return np.array([xp, yp, zp])


def rot_z_prime(vector, angle, inverse_transform=False):
    """ Derivative of rot_z matrix w.r.t time (Need to be further multiplied
        by the argument's derivative of the angle)

        :param vector: 3 dimensional vector
        :param angle: angle [deg]
        :param inverse_Transform: Perform inverse rotation around z-axis

        :returns: rotated vector coordinates
    """
    if vector.shape[0] != 3:
        vector = vector.T
    if vector.ndim == 1:
        vector = vector.reshape((3, 1))
    angle_rad = np.deg2rad(angle)
    if inverse_transform:
        angle_rad == - angle_rad

    xp = (-np.sin(angle_rad) * vector[0] + np.cos(angle_rad) * vector[1])
    yp = (-np.cos(angle_rad) * vector[0] - np.sin(angle_rad) * vector[1])
    zp = np.zeros_like(xp)
    return np.array([xp, yp, zp])


def rot_x(vector, angle, inverse_transform=False):
    """ Rotates vector by angle around x-axis

        :param vector: 3 dimensional vector
        :param angle: angle [deg]
        :param inverse_Transform: Perform inverse rotation around x-axis

        :returns: rotated vector coordinates
    """
    if vector.shape[0] != 3:
        vector = vector.T
    if vector.ndim == 1:
        vector = vector.reshape((3, 1))
    angle_rad = np.deg2rad(angle)
    if inverse_transform:
        angle_rad == - angle_rad

    xp = vector[0]
    yp = (np.cos(angle_rad) * vector[1] + np.sin(angle_rad) * vector[2])
    zp = (-np.sin(angle_rad) * vector[1] + np.cos(angle_rad) * vector[2])
    return np.array([xp, yp, zp])


def coord_transform(coord_vec, reci, veci, time_vec=None, stop='end'):
    """ Transform coordinates from space relative (r,t,n) system to local
        tangent one

        :date: 02.03.2015

        :author: Jalal Matar

        :param coord_vec: coordinates to be transformed [3xN]
        :param reci: coordinate system center in ECI frame [3xN]
        :param veci: coordinate system velocity in ECI frame [3xN]
        :param time_vec: time instant of point in orbit [3xN]
        :param stop: case 'end'  -> output local tangent coords
                     case 'eci'  -> output eci coords
                     case 'ecef' -> output ecef coords

        :return: coordinates in local tangent frame
    """
    ome_earth = const.omega_earth
    recf = np.zeros(reci.shape, dtype='float')
    vecf = np.zeros(veci.shape, dtype='float')
    coord_ECI = np.zeros(coord_vec.shape, dtype='float')
    coord_ECEF = np.zeros(coord_vec.shape, dtype='float')
    coord_lt = np.zeros(coord_vec.shape, dtype='float')

    if time_vec is None:
        time_vec = np.ones(coord_vec.shape[1], dtype=float)

    for k in range(0, reci.shape[1]):

        # position in ECEF
        recf[:, k] = rot_z(reci[:, k], np.rad2deg(ome_earth*time_vec[k]))

        # velocity in ECEF
        vecf[:, k] = (rot_z(veci[:, k], np.rad2deg(ome_earth*time_vec[k])) +
                      (ome_earth *
                       rot_z_prime(reci[:, k],
                                   np.rad2deg(ome_earth*time_vec[k]))))

        # space relative to ECI transformation matrix
        t1 = reci[:, k]/np.sqrt(reci[:, k].dot(reci[:, k]))
        t2 = veci[:, k]/np.sqrt(veci[:, k].dot(veci[:, k]))
        t3 = np.cross(t1, t2)

        T_mat = np.concatenate(([t1], [t2], [t3])).T

        coord_ECI[:, k] = np.dot(T_mat, coord_vec[:, k])
        coord_ECEF[:, k] = rot_z(coord_ECI[:, k],
                                 np.rad2deg(ome_earth*time_vec[k]))

        # ECEF to space relative transformation matrix
        e1 = recf[:, k]/np.sqrt(recf[:, k].dot(recf[:, k]))
        e2 = vecf[:, k]/np.sqrt(vecf[:, k].dot(vecf[:, k]))
        e3 = np.cross(e1, e2)

        E = np.concatenate(([e1], [e2], [e3]))

        coord_lt[:, k] = np.dot(E, coord_ECEF[:, k])

    if stop == 'end':
        return coord_lt
    elif stop == 'eci':
        return coord_ECI
    elif stop == 'ecef':
        return coord_ECEF
    else:
        return 0
