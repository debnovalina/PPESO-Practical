from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
import numpy as np

def plotting_maps():
    """ Function for plotting "any" parameter in a lat - lon map 
    """
    #lats =
    #lons = 
    #lons, lats = np.meshgrid(lons, lats)
    #parameter =     
    
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=-180,
                urcrnrlon=180, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    # draw a boundary around the map, fill the background.
    # this background will end up being the ocean color, since
    # the continents will be drawn on top.
    #m.drawmapboundary(fill_color='aqua')
    # fill continents, set lake color same as ocean color.
    m.fillcontinents(color='gray',lake_color='aqua')
    # overplot the "parameter" values
    #im_parameter = m.pcolormesh(lons, lats, parameter, shading='flat',
    #                         cmap=plt.cm.jet, latlon=True) 
    # draw parallels and meridians.
    m.drawparallels(np.arange(-90.,91.,30.))
    m.drawmeridians(np.arange(-180.,180.,60.))
    m.drawmapboundary(fill_color='aqua')
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    # add colorbar
    cb = m.colorbar(deform_im,"right", size="5%", pad="2%")
    plt.show()
