
"""
===============================================
General Utilities Package (:mod:`drama.utils`)
===============================================

.. currentmodule:: drama.utils


General utilities
=================

.. autosummary::
   :toctree: generated/

   db
   db2lin
   optimize_fftsize
   factorize
   nearest_power_2
   smooth
   Empty
   historic
   prime
   checkcommondivisors
   get_parFile
   save_object
   load_object
   writepar
   find_con_idx

Plotting utilities
==================

.. autosummary::
   :toctree: generated/

   image
   plotting_maps

Plotting colormaps
==================

.. autosummary::
   :toctree: generated/

   sea_cmap
   sealight_cmap
   bwr_cmap

Matrix Manipulation
===================

.. autosummary::
   :toctree: generated/

   rot_z
   rot_z_prime

System
======

.. autosummary::
   :toctree: generated/

   load_mod_perf

"""

from .misc import Empty, get_parFile, db, db2lin, smooth, nearest_power_2, \
                  factorize, optimize_fftsize, balance_elements, \
                  historic, prime, checkcommondivisors, save_object, \
                  load_object, writepar, find_con_idx
from .plot import image, sea_cmap, sealight_cmap, bwr_cmap, add_colorbar
# from .maps_plot import plotting_maps
from .wbmod import read_wbmod, interp_wbmod, load_wbmod, retrieve_wbmod
from .resample import lincongrid1d, lincongrid2d, lincongrid, \
                      linresample, interp_rat
