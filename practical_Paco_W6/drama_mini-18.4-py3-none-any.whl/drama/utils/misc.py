from collections import namedtuple
import numpy as np
from scipy import signal

import pickle
import multiprocessing

class Empty():
    """ An empty class """
    pass


def get_parFile(parfile=None):
    """Mini gui to get filename
    """
    def _test(out_q):
        out_q.put('hola')

    if (parfile is None):
        #output_queue = multiprocessing.Queue()
        #p = multiprocessing.Process(target=_get_parFile, args=(output_queue,))
        #p.start()
        #parfile = output_queue.get()
        #p.join()
        parfile = _get_parFile(1)
    return parfile


def _get_parFile(out_q):
    from tkinter import filedialog as tkfiledialog
    from tkinter import Tk
    root = Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.geometry('0x0+0+0')
    root.deiconify()
    root.lift()
    root.focus_force()
    parfile = tkfiledialog.askopenfilename(parent=root)
    root.destroy()
    # out_q.put(parfile)
    return parfile


def save_object(obj, filename):
    """ Saves an object in a file (better use .pkl format)
    """
    with open(filename, 'wb') as output:
        pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)


def load_object(filename):
    """ Loads an object from a file.pkl
    """
    with open(filename, 'rb') as f:
        obj = pickle.load(f)
    return obj


def save_tuple(obj, filename):
    """ saves a one level tuple containg arrays, lists and single elements
        Note: no nested tuples can be included
    """
    # name of the tuple
    tname = type(obj).__name__

    # tuple fields
    fields1 = obj._fields
    # field types
    types_all = np.empty(len(fields1), dtype=type)
    type_var = []  # corresponding field name
    listall = ['np.savez(filename', 'tname=' + '"' + tname + '"']
    for i in range(len(fields1)):
        listall.append(fields1[i] + ' = obj.' + fields1[i])
        types_all[i] = type(obj[i])
        type_var.append(fields1[i])
    types = sorted(zip(type_var, types_all))
    listall.append('types = types)')
    eval(",".join(listall))


def load_tuple(filename):
    """ load tuple from file saved using save_tuple"""
    arrays = np.load(filename)
    fields = arrays.files

    # name of the tuple
    tname = str(arrays['tname'])
    fields.remove('tname')
    # fields types
    types = arrays['types']
    fields.remove('types')

    # rearange types according to fields order
    t_name = [i[0] for i in types]
    t_type = [i[1] for i in types]
    pos = [fields.index(i) for i in t_name]
#    t_name = [x for (y,x) in sorted(zip(pos,t_name))]
    t_type = [x for (y, x) in sorted(zip(pos, t_type))]

    # Create new tuple
    Data = namedtuple(tname, fields)

    # create an empty tuple
    emptyD = "Data("
    for i in range(len(fields)):
        if t_type[i] is int:
            var = 'int(arrays["' + fields[i] + '"]),'
        elif t_type[i] is float:
            var = 'float(arrays["' + fields[i] + '"]),'
        elif t_type[i] is str:
            var = 'str(arrays["' + fields[i] + '"]),'
        elif t_type[i] is list:
            var = 'arrays["' + fields[i] + '"].tolist(),'
        else:
            var = 'arrays["' + fields[i] + '"],'
        emptyD = emptyD + var
    emptyD = emptyD[:-1] + ")"
    data = eval(emptyD)
    return data


#def gentype(element, intuple=False):
#    """ similar to type function, except that it works on tuples
#
#    :param element: element to be type tested
#    :param intuple: if True and element is a tuple, then check type of tuple
#                    fields
#    :return: type as an array or single (depending on intuple)
#    """
#    # check type of elements inside the tuple
#    if isinstance(element, tuple) and intuple:
#        dtype = np.empty(len(element), dtype=type)
#        for i in range(len(element)):
#            if isinstance(element[i], tuple):
#                dtype[i] = tuple
#            else:
#                dtype[i] = type(element[i])
#    elif intuple:  # return array output
#        if isinstance(element, tuple):
#            dtype = np.array([tuple], dtype=type)
#        else:
#            dtype = np.array([type(element)], dtype=type)
#    else:  # return single output
#        if isinstance(element, tuple):
#            dtype = tuple
#        else:
#            dtype = type(element)
#    return dtype


def db(data, clip=False, clip_value=-20, norm=False):
    """ Converts data to dB scale

        :param data: Input data
        :param clip: Limit dB range
        :param clip_value: Clipping value
        :param norm: Normalize data w.r.t. maximum

        :returns: dB data
    """

    if clip:
        lin_value = np.power(10., clip_value/10.)
        c_data = np.where(data < lin_value, lin_value, data)
    else:
        c_data = data

    db_val = 10*np.log10(np.abs(c_data))

    return db_val - np.max(db_val) if norm else db_val


def db2lin(data, amplitude=False):
    """ Converts data from dB to linear

        :param data: Input data
        :param amplitude: Input is amplitude :math:`20\log{x}` or power :math:`10\log{x}`
        :type amplitude: bool

        :returns: Linear data
    """

    if amplitude:
        return 10.0**(data/20.0)
    else:
        return 10.0**(data/10.0)


def nearest_power_2(value):
    """ Calculates the nearest 2^n value for given input
        Method from http://graphics.stanford.edu/~seander/bithacks.html

        :param value: Input value/s (scalar or array, max. 32-bit integer!)

        :returns: Nearest 2^n
    """

    v = np.array(value).astype(int)
    v -= 1
    v |= v >> 1
    v |= v >> 2
    v |= v >> 4
    v |= v >> 8
    v |= v >> 16
    v += 1

    return v

def nearest_power2(values):
    return (2**np.ceil(np.log2(values))).astype(int)


def optimize_fftsize(values, max_prime=2):
    """ Returns 'good' dimensions for FFT algorithm

        :param value: Input value/s
        :param max_prime: Maximum prime allowed (FFT is optimal for 2)

        :returns: Nearest 'good' value/s
    """
    # Force array type (if scalar was given)
    if np.isscalar(values):
        values = np.array([values], dtype=np.int)

    if max_prime == 2:
        good_values = nearest_power2(values)
        return good_values if len(good_values) > 1 else good_values[0]

    good_values = np.array([], dtype=np.int)
    for value in values:
        best_value = value
        while (np.max(factorize(best_value)) > max_prime):
            best_value += 1
        good_values = np.append(good_values, best_value)

    return good_values if len(good_values) > 1 else good_values[0]


def factorize(n):
    """ Prime factorize a number

        :param n: Number

        :returns: Array with prime factors
    """
    result = np.array([])
    for i in np.append(2, np.arange(3, n + 1, 2)):
        s = 0
        while np.mod(n, i) == 0:
            n /= i
            s += 1
        result = np.append(result, [i]*s)
        if n == 1:
            return result


def balance_elements(N, size):
    """ Divide N elements in size chunks
        Useful to balance arrays of size N not multiple
        of the number of processes

        :param N: Number of elements
        :param size: Number of divisions

        :returns: (counts, displ) vectors
    """
    # Counts
    count = np.round(N/size)
    counts = count*np.ones(size, dtype=np.int)
    diff = N - count*size
    counts[:diff] += 1

    # Displacements
    displ = np.concatenate(([0], np.cumsum(counts)[:-1]))

    return counts, displ

def smooth1d(data, window_len=11, window='flat', axis=0):
    if window == 'flat':
        shp = np.array(data.shape).astype(np.int)
        # shp[axis] += int(window_len)
        out = np.zeros(shp, dtype=data.dtype)
        wlh1 = int(window_len / 2)
        wlh2 = window_len - wlh1
        wl = int(window_len)
        normf = np.zeros(shp[axis])

        for ind in range(window_len):
            #print(ind)
            i1 = int(ind - wlh1)
            i2 = i1 + shp[axis]
            if i1 <= 0:
                o1 = -i1
                i1 = 0
                o2 = shp[axis]
            else:
                i2 = shp[axis]
                o1 = 0
                o2 = shp[axis] - i1
            #print((i1, i2, o1, o2))

            normf[o1:o2] += 1
            if data.ndim == 1 or axis == 0:
                out[o1:o2] += data[i1:i2]
            elif axis == 1:
                out[:, o1:o2] += data[:, i1:i2]
            elif axis == 2:
                out[:, :,  o1:o2] += data[:, :, i1:i2]
        shpn = np.ones_like(shp)
        shpn[axis] = shp[axis]
        out /= normf.reshape(shpn)
        #print(normf)
        return out
    else:
        raise ValueError('1d Smoothing with non flat window not yet supported')


def smooth(data, window_len=11, window='flat', axis=None, force_fft=False):
    """ Smooth the data using a window with requested size.
    
        This method is based on the convolution of a scaled window with the signal.
        Works with 1-D and 2-D arrays.

        :param data: Input data
        :param window_len: Dimension of the smoothing window; should be an odd integer
        :param window: Type of window from 'flat', 'hanning', 'hamming', 'bartlett', 'blackman'.
                       Flat window will produce a moving average smoothing.
        :param axis: if set, then it smoothes only over that axis
        :param force_fft: force use of fftconvolve to overide use of direct implementation for flat windows

        :returns: the smoothed signal
    """

    if data.ndim > 2:
        raise ValueError('Arrays with ndim > 2 not supported')

    if (window_len < 3 and window != 'flat') or window_len < 2:
        return data

    if not window in ['flat', 'hanning', 'hamming', 'bartlett', 'blackman']:
        raise ValueError('Window type not supported')

    if window == 'flat' and ((axis is not None) or (data.ndim == 1)):
        if axis is None:
            axis_ = 0
        else:
            axis_ = axis
        return smooth1d(data, window_len, axis=axis_)

    # Calculate Kernel
    if window == 'flat':
        w = np.ones(window_len)
    else:
        w = eval('np.' + window + '(window_len)')

    # Smooth
    if data.ndim > 1:
        if axis is None:
            w = np.sqrt(np.outer(w, w))
        elif axis == 0:
            w = w.reshape((w.size, 1))
        else:
            w = w.reshape((1, w.size))

    y = signal.fftconvolve(data, w/w.sum(), mode='same')

    return y


def prime(i, primes):
    """
    :author: Lennart
    """
    for prime in primes:
        if not (i == prime or i % prime):
            return False
    primes.add(i)
    return i


def historic(n):
    """ Lists the first n prime numbers

    :author:  Lennart

    :returns: set of n prime numbers
    """
    primes = set([2])
    i, p = 2, 0
    while True:
        if prime(i, primes):
            p += 1
            if p == n:
                return primes
        i += 1


def checkcommondivisors(a, b):
    """ Checks the common devisors between 2 variables a and b
    """

    pr = historic(min([a, b]))
    pr = list(pr)
    for i in range(0, len(pr)):
        if ((a % pr[i]) == 0 and (b % pr[i]) == 0):
            return 1
    return 0


def asc_desc(v_arr):
    """ Function that gives the indices for ascending and descending node
        according to a velocity vector.

       :param v_arr:  Velocity vector.
       :type v_arr: 2-D float array

       returns: named tuple containing ascending and descending indices.

    """
    # separate data into ascending and descending nodes
    desc_loc = np.where(v_arr[:, 2] < 0)
    order_desc = np.array_split(desc_loc[0],
                                np.where(np.diff(desc_loc[0]) != 1)[0] + 1)
    # create descending indices
    desc_idx = np.zeros((len(order_desc), 2), dtype=np.int32)
    for i in range(0, len(order_desc)):
        desc_idx[i, 0] = order_desc[i][0]
        desc_idx[i, 1] = order_desc[i][-1]

    asc_loc = np.where(v_arr[:, 2] > 0)
    order_asc = np.array_split(asc_loc[0],
                               np.where(np.diff(asc_loc[0]) != 1)[0] + 1)
    # create ascending indices
    asc_idx = np.zeros((len(order_asc), 2), dtype=np.int32)
    for i in range(0, len(order_asc)):
        asc_idx[i, 0] = order_asc[i][0]
        asc_idx[i, 1] = order_asc[i][-1]

    Arr_indices = namedtuple('Arr_indices', ['asc_idx', 'desc_idx'])
    arr_indices = Arr_indices(asc_idx, desc_idx)
    return arr_indices


def find_con_idx(arr1):
    "Find indices of continuous segments"

    idx_arr = np.array(([[0, 0]]))
    j = 0
    while (j < arr1.shape[0]):
        st_idx = arr1[j]
        i = j
        while (i < arr1.shape[0] - 1) and (arr1[i+1] - arr1[i] == 1):
            i = i+1
        j = j + i
        end_idx = arr1[i]
        idx_arr = np.append(idx_arr, [[st_idx, end_idx]], axis=0)
        j = j + 1

    return idx_arr[1:, :]


def writepar(fileName, dDays, nRevs, i, e, omega, asc_node, starttime,
             timeduration, timestep, near_look, far_look, gr_res):
    """ Create a parameter file"""
    try:
        file = open(fileName, 'w+')   # Trying to create a new file or open one
        file.truncate()
    except:
        print('Something went wrong!')

    # Start writing Procedure
    file.write("# Repeat Mission Parameters")
    file.write("\n\n")
    file.write("[orbit]")
    file.write("\n\n")
    file.write("# desired days per cycle [d]")
    file.write("\n")
    file.write("days_cycle = " + str(dDays))
    file.write("\n\n")
    file.write("# number of orbits for repeat")
    file.write("\n")
    file.write("orbits_nbr = " + str(nRevs))
    file.write("\n\n")
    file.write("# inclination")
    file.write("\n")
    file.write("inc =  " + str(i))
    file.write("\n\n")
    file.write("# eccentricity")
    file.write("\n")
    file.write("ecc = " + str(e))
    file.write("\n\n")
    file.write("omega_p = " + str(omega))
    file.write("\n\n")
    file.write("# right ascension of ascending node [deg]")
    file.write("\n")
    file.write("asc_node = " + str(asc_node))
    file.write("\n\n")
    file.write("# fraction of an orbit period")
    file.write("\n")
    file.write("starttime = " + str(starttime))
    file.write("\n\n")
    file.write("# orbit calculation time [d]")
    file.write("\n")
    file.write("timeduration = " + str(timeduration))
    file.write("\n\n")
    file.write("# Time step [s]")
    file.write("\n")
    file.write("timestep = " + str(timestep))
    file.write("\n\n")
    file.write("[sar]")
    file.write("\n\n")
    file.write("# 1st near range angle (RL --> negative angle) [deg]")
    file.write("\n")
    file.write("near_1 = " + str(near_look))
    file.write("\n\n")
    file.write("# 1st far range angle [deg]")
    file.write("\n")
    file.write("far_1 = " + str(far_look))
    file.write("\n\n")
    file.write("# ground range resolution [m]")
    file.write("\n")
    file.write("gr_res = " + str(gr_res))
    file.write("\n")

    file.close()