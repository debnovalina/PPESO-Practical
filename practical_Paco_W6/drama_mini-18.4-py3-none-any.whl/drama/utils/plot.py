
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors
from mpl_toolkits import axes_grid1

# Sea NRCS color map
cdict_sea = {'red':  ((0.0, 0.0, 0.0),
                      (0.25, 0.0, 0.0),
                      (0.75, 0.0, 0.0),
                      (1.0, 1.0, 1.0)),

             'green': ((0.0, 0.0, 0.0),
                       (0.25, 0.0, 0.0),
                       (0.75, 0.5, 0.5),
                       (1.0, 1.0, 1.0)),

             'blue':  ((0.0, 0.0, 0.0),
                       (0.25, 0.5, 0.5),
                       (0.75, 1.0, 1.0),
                       (1.0, 1.0, 1.0))
             }

sea_cmap = matplotlib.colors.LinearSegmentedColormap('sea_cmap', cdict_sea)

# Sea light NRCS color map
cdict_sealight = {'red':  ((0.0, 0.0, 0.0),
                           (0.25, 0.0, 0.0),
                           (0.75, 0.0, 0.0),
                           (1.0, 1.0, 1.0)),

                  'green': ((0.0, 0.0, 0.0),
                            (0.25, 0.0, 0.0),
                            (0.75, 0.0, 0.0),
                            (1.0, 1.0, 1.0)),

                  'blue':  ((0.0, 0.0, 0.0),
                            (0.25, 0.0, 0.0),
                            (0.75, 0.5, 0.5),
                            (1.0, 1.0, 1.0))
                  }

sealight_cmap = matplotlib.colors.LinearSegmentedColormap('sealight_cmap', cdict_sealight)

# Blue-White-Red color map
cdict_bwr = {'red':  ((0.0, 1.0, 1.0),
                      (0.5, 1.0, 1.0),
                      (1.0, 0.0, 0.0)),

             'green': ((0.0, 0.0, 0.0),
                       (0.5, 1.0, 1.0),
                       (1.0, 0.0, 0.0)),

             'blue':  ((0.0, 0.0, 0.0),
                       (0.5, 1.0, 1.0),
                       (1.0, 1.0, 1.0))
             }

bwr_cmap = matplotlib.colors.LinearSegmentedColormap('bwr_cmap', cdict_bwr)


def add_colorbar(im, aspect=20, pad_fraction=0.5, **kwargs):
    """Add a vertical color bar to an image plot."""
    divider = axes_grid1.make_axes_locatable(im.axes)
    width = axes_grid1.axes_size.AxesY(im.axes, aspect=1/aspect)
    pad = axes_grid1.axes_size.Fraction(pad_fraction, width)
    current_ax = plt.gca()
    cax = divider.append_axes("right", size=width, pad=pad)
    plt.sca(current_ax)
    return im.axes.figure.colorbar(im, cax=cax, **kwargs)


def image(data, min=None, max=None,
          xlabel=None, ylabel=None, title=None, cmap=sea_cmap,
          origin='lower', aspect=1, extent=None,
          cbar=True, cbar_xlabel=None, cbar_ylabel=None,
          save=False, save_path='',
          usetex=False, block=True, dpi=150):

    """ Plot a 2-D array as an image

        :param data: Input 2-D array
        :param min: Minimum value to plot
        :param max: Maximum value to plot
        :param xlabel: Plot x-axis label
        :param ylabel: Plot y-axis label
        :param title: Plot title
        :param origin: Plot origin ('lower', 'upper')
        :param aspect: Aspect ratio
        :param extent: Plot axis limitation ([XMIN,XMAX,YMIN,YMAX])
        :param cbar: Show colorbar
        :param cbar_xlabel: Colorbar x-axis label
        :param cbar_ylabel: Colorbar y-axis label
        :param save: Save plot instead of showing
        :param save_path: Plot file name
        :param usetex: Use TeX to render text
        :param dpi: dots per inch

     .. note::
        This module defines (and uses by default) ``sea_cmap``, which is a blueish colormap.
        Note that :mod:`matplotlib` has many pre-defined colormaps.

    """
    # TeX
    if usetex:
        plt.rc('text', usetex=usetex)
        plt.rc('font', family='serif')

    if min is None:
        min = np.min(data)
    if max is None:
        max = np.max(data)

    plt.figure()
    plt.imshow(data, vmin=min, vmax=max, cmap=cmap, origin=origin, aspect=aspect, extent=extent)

    # X/Y Labels and titles
    if xlabel:
        plt.xlabel(xlabel)
    if ylabel:
        plt.ylabel(ylabel)
    if title:
        plt.title(title)

    # Colorbar
    if cbar:
        colorbar = plt.colorbar()
        if cbar_xlabel:
            colorbar.ax.set_xlabel(cbar_xlabel)
        if cbar_ylabel:
            colorbar.ax.set_ylabel(cbar_ylabel)

    # Show/save
    if save:
        plt.savefig(save_path, bbox_inches='tight', dpi=dpi)
        plt.close()
    else:
        plt.show(block=block)

