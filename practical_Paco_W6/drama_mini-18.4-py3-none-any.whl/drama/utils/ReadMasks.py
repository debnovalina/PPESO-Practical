# -*- coding: utf-8 -*-
"""
Created on Mon May  2 11:54:22 2016

@author: zonn_ma
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from scipy.ndimage.interpolation import zoom
import pickle
import os
import mpl_toolkits.basemap as bsmp
from drama.utils.resample import linresample


# TODO: we have now hard coded file names, going with non hard coded
# directories. This doesn't really make sense. Maybe the files should go
# to some kind of configuration file, or something.
def load_Cryo_boundary_mask(MaskPath, **kwargs):
    # Choose one of the two following
    CryoMask_boundaries = 'Sesame_CryoMask_v01_20160426_SS.tif'  # 1 km resol
#    CryoMask_boundaries = 'Sesame_CryoMask_v02_20160426_SS.tif' # 250 m resol
    im = Image.open(os.path.join(MaskPath, CryoMask_boundaries))
    CryoMask = np.array(im)
    mask_lats = np.linspace(-90, 90, CryoMask.shape[0])
    mask_lons = np.linspace(-180, 180, CryoMask.shape[1])
    return (mask_lats, mask_lons, np.flipud(CryoMask))


def load_Permafrost_mask(MaskPath, **kwargs):
    submask = kwargs.pop("submask", None)
    if submask == 'high':
        Mask_filename = 'permaice_h_icecontent_Diss.tif'
        im = Image.open(os.path.join(MaskPath, Mask_filename))
        Mask = np.array(im)[:, :, 3]
    elif submask == 'medium':
        Mask_filename = 'permaice_m_icecontent_Diss.tif'
        im = Image.open(os.path.join(MaskPath, Mask_filename))
        Mask = np.array(im)[:, :, 3]
    else:
        Mask_filename = 'permaice_h_icecontent_Diss.tif'
        im = Image.open(os.path.join(MaskPath, Mask_filename))
        Mask1 = np.array(im)[:, :, 3]
        Mask_filename = 'permaice_m_icecontent_Diss.tif'
        im = Image.open(os.path.join(MaskPath, Mask_filename))
        Mask2 = np.array(im)[:, :, 3]
        Mask = np.logical_or(Mask1, Mask2)

    mask_lats = np.linspace(-90, 90, Mask.shape[0])
    mask_lons = np.linspace(-180, 180, Mask.shape[1])
    return (mask_lats, mask_lons, np.flipud(Mask))


def load_Cryo_mask(MaskPath, **kwargs):
    CryoMask = np.load(os.path.join(MaskPath,
                                    'Sesame_CryoMask_v01_20160426_SS.npy'))
    mask_lats = np.linspace(-90, 90, CryoMask.shape[0])
    mask_lons = np.linspace(-180, 180, CryoMask.shape[1])
    return (mask_lats, mask_lons, np.flipud(CryoMask))


def load_Mountain_mask(MaskPath, **kwargs):
    submask = kwargs.pop("submask", None)
    MountainMask_filename = 'Sesame_MountainMask_v01_20160425_SS.tif'
    im = Image.open(os.path.join(MaskPath, MountainMask_filename))
    MountainMask = np.flipud(np.array(im))
    mask_lats = np.linspace(-90, 90, MountainMask.shape[0])
    mask_lons = np.linspace(-180, 180, MountainMask.shape[1])
    return (mask_lats, mask_lons, MountainMask)


def load_Forest_mask(MaskPath, **kwargs):
    submask = kwargs.pop("submask", None)
    h_min = kwargs.pop("h_min", 0)
    filename = os.path.join(MaskPath, 'forest_height_0_5deg.p')
    forest_h = (pickle.load(open(filename, 'rb')))
    mask_lats = np.linspace(-90, 90, forest_h.shape[0])
    mask_lons = np.linspace(-180, 180, forest_h.shape[1])
    if submask.lower() == "boreal":
        print("Boreal forests taken as all forests North of 45N")
        bor_lat_inds = np.where(mask_lats >= 45)
        first_ind = bor_lat_inds[0][0]
        forest_h[0:first_ind, :] = 0
    forest_h = np.where(forest_h > h_min, forest_h, 0)
    return (mask_lats, mask_lons, forest_h)


def read_Cryo_boundary_mask(lat_min, lat_max, lon_min, lon_max, lat_arr,
                            lon_arr, MaskPath):
    (mask_lats, mask_lons, CryoMask_b) = load_Cryo_boundary_mask(MaskPath)
    # define for the map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(mask_lats >= lat_min,
                                               mask_lats <= lat_max)))
    lon_ind = np.array(np.where(np.logical_and(mask_lons >= lon_min,
                                               mask_lons <= lon_max)))
    CryoMask_b = CryoMask_b[lat_ind.flatten()[0]:lat_ind.flatten()[-1]+1,
                            lon_ind.flatten()[0]:lon_ind.flatten()[-1]+1]
    # interpolation on the same lat lon grid
    CryoMask_b_new = zoom(CryoMask_b, (lat_arr.size/CryoMask_b.shape[0],
                          lon_arr.size/CryoMask_b.shape[1]), order=1)
    return CryoMask_b_new


def read_Cryo_mask(lat_min, lat_max, lon_min, lon_max, lat_arr, lon_arr,
                   MaskPath):
    (mask_lats, mask_lons, CryoMask) = load_Cryo_mask(MaskPath)
    # define for the map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(mask_lats >= lat_min,
                                               mask_lats <= lat_max)))
    lon_ind = np.array(np.where(np.logical_and(mask_lons >= lon_min,
                                               mask_lons <= lon_max)))
    CryoMask = CryoMask[lat_ind.flatten()[0]:lat_ind.flatten()[-1]+1,
                        lon_ind.flatten()[0]:lon_ind.flatten()[-1]+1]
    # interpolation on the same lat lon grid
    CryoMask_new = zoom(CryoMask, (lat_arr.size/CryoMask.shape[0],
                        lon_arr.size/CryoMask.shape[1]), order=1)
    return CryoMask_new


def read_Mountain_mask(lat_min, lat_max, lon_min, lon_max, lat_arr, lon_arr,
                       MaskPath):
    #    MountainMask_filename= inData.path.MountMask_filename_npy

    MountainMask_filename = 'Sesame_MountainMask_v01_20160425_SS.tif'
    im = Image.open(MaskPath+MountainMask_filename)
    MountainMask = np.array(im)
    mask_lats = np.linspace(-90, 90, MountainMask.shape[0])
    mask_lons = np.linspace(-180, 180, MountainMask.shape[1])
    # define for the forest map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(mask_lats >= lat_min,
                                               mask_lats <= lat_max)))
    lon_ind = np.array(np.where(np.logical_and(mask_lons >= lon_min,
                                               mask_lons <= lon_max)))
    MountainMask = MountainMask[lat_ind.flatten()[0]:lat_ind.flatten()[-1]+1,
                                lon_ind.flatten()[0]:lon_ind.flatten()[-1]+1]
    # interpolation on the lat lon grid
    MountainMask_new = zoom(MountainMask, (lat_arr.size/MountainMask.shape[0],
                            lon_arr.size/MountainMask.shape[1]), order=1)

    return MountainMask_new


def read_Forest_mask(lat_min, lat_max, lon_min, lon_max, lat_arr, lon_arr,
                     MaskPath):

    forest_h = (pickle.load(open(MaskPath, 'rb')))

    mask_lats = np.linspace(-90, 90, forest_h.shape[0])
    mask_lons = np.linspace(-180, 180, forest_h.shape[1])
    # define for the forest map the same area of the region of interest
    # define for the forest map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(mask_lats >= lat_min,
                                               mask_lats <= lat_max)))
    lon_ind = np.array(np.where(np.logical_and(mask_lons >= lon_min,
                                               mask_lons <= lon_max)))

    forest_height = forest_h[lat_ind.flatten()[0]:lat_ind.flatten()[-1]+1,
                             lon_ind.flatten()[0]:lon_ind.flatten()[-1]+1]

    # interpolation on the finer lat lon grid
    forest_h_new = zoom(forest_height, (lat_arr.size/forest_height.shape[0],
                        lon_arr.size/forest_height.shape[1]), order=1)

    return forest_h_new


def load_Land_mask(*dummy, lakes=True, resolution='l', grid=5):
    """ Reads land mask from basemap
    """
    (lsmask_lons,
     lsmask_lats,
     lsmask) = bsmp._readlsmask(lakes=lakes, resolution='l', grid=5)
    return (lsmask_lats, lsmask_lons, lsmask)


def read_mask(lats, lons,
              MaskPath=None, what='land', binary=True,
              submask=None, h_min=5):
    """ Loads a mask

        :param lats: ndarray of monotonically increasing latitudes between
                     -90 and 90 degrees.
        :param lons: ndarray of monotonically increasing longitudes between
                     -180 and 180 degrees
    """
    readers = {'forest': load_Forest_mask,
               'mountain': load_Mountain_mask,
               'cryo': load_Cryo_mask,
               'cryo_boundary': load_Cryo_boundary_mask,
               'land': load_Land_mask,
               'permafrost': load_Permafrost_mask,
               'boreal': load_Forest_mask}
    if submask is None:
        if what.lower() == 'boreal':
            submask = 'boreal'
    try:
        (latin, lonin, mask) = readers[what.lower()](MaskPath,
                                                     submask=submask,
                                                     h_min=h_min)
    except:
        try:
            # Try without passing a parameter...
            (latin, lonin, mask) = readers[what.lower()](MaskPath)
        except:
            mesg = ("Could not read mask for %s" % what)
            raise ValueError(mesg)

    dlat = latin[1] - latin[0]
    dlon = lonin[1] - lonin[0]
    latind = (lats - latin[0]) / dlat
    lonind = (lons - lonin[0]) / dlon
    latind = np.where(latind <= (latin.size - 1), latind, latin.size - 1)
    lonind = np.where(lonind <= (lonin.size - 1), lonind, lonin.size - 1)
    latind = np.where(latind > 0, latind, 0)
    lonind = np.where(lonind > 0, lonind, 0)
    mask_out = linresample(linresample(mask * 1, latind, axis=0),
                           lonind, axis=1)
    if binary:
        mask_out = np.where(mask_out == 0, 0, 1).astype('bool')
    return mask_out
