# -*- coding: utf-8 -*-
"""
Created on Mon May  9 14:18:22 2016

@author: lope_fr
"""

import numpy as np
import copy
import mpl_toolkits.basemap as bsmp
import matplotlib.pyplot as plt
from drama import utils as utls
from drama.utils.coord_trans import rot_z
from drama.utils.resample import linresample
import drama.coverage as cov
import drama.geo.sar as sargeo
from drama.orbits import single_orbit as so
from drama.io.cli import ProgressBar
from drama.utils.ReadMasks import read_mask
from collections import namedtuple


RoIinview_ = namedtuple("inRoI", ['inRoI', 'inRoIpct', 'timevec',
                                  'T0'])

LatMaskinview_ = namedtuple("inLatMask", ['inMask', 'timevec',
                                          'T0', 'cyclevec'])

GSinview = namedtuple("GSinView", ['contact', 'of_zenith', 'timevec',
                                   'T0', 'contact_length'])


class RoIinview(RoIinview_):
    """ This is a class that extends the named tuple
    """
    def and_mask(self, mask):
        if isinstance(mask, RoIinview):
            mask_ = mask.inRoI
        else:
            mask_ = mask
        self.inRoI[:, :] = np.logical_and(self.inRoI, mask_)

    def or_mask(self, mask):
        if isinstance(mask, RoIinview):
            mask_ = mask.inRoI
        else:
            mask_ = mask
        self.inRoI[:, :] = np.logical_or(self.inRoI, mask_)


class OrbTimeline(LatMaskinview_):
    """ This is a class that extends the named tuple
    """
    def and_mask(self, mask):
        if isinstance(mask, RoIinview):
            mask_ = mask.inRoI
        else:
            mask_ = mask
        ndim = mask_.ndim
        if ndim == 3:
            self.inMask[:, :, :] = np.logical_and(self.inMask, mask_)
        elif ndim == 1:
            self.inMask[:, :, :] = np.logical_and(self.inMask,
                                                  mask_.reshape((1, 1,
                                                                 mask_.size)))
        elif ndim == 2:
            self.inMask[:, :, :] = np.logical_and(self.inMask,
                                                  mask_.reshape((1,) +
                                                                mask_.shape))

    def mask_to_mode(self, mode):
        """ Generated mode activation profile merging
            the acquisition mask with the provided mode selection

            :param mode: mode is a Ncyc x Norb x Ntimes array, where
                         Norb and Ntimes may be degenerated (i.e.
                         mode.shape == (Ncyc, 1, 1)). This is all handled by
                         nunmpy dimension casting. Ncyc may coincide with
                         the cycles in LastMaskinview, or it may be longer,
                         in which it is assumed to start at cycle 0. In this
                         case the routine uses self.cyclevec to select the
                         relavent part.
        """
        if mode.ndim == 1:
            mode_ = mode.reshape((mode.size, 1, 1)).astype(np.int8)
        else:
            mode_ = mode.astype(np.int8)
        if mode_.shape[0] == self.inMask.shape[0]:
            # Easiest case
            self.mode = (self.inMask * mode_)
        else:
            self.mode = (self.inMask *
                         mode_[self.cyclevec[0]:self.cyclevec[-1] + 1, :, :])


def CompositeOrbTimeline(tmlns, mode):
    """ Takes a tuple of OrbTimeline objects, and merges them according to
        a mode selection

        :param tmlns: tuple of timelines
        :param mode: mode is a Ncyc x Norb x Ntimes array, where
                         Norb and Ntimes may be degenerated (i.e.
                         mode.shape == (Ncyc, 1, 1)). This is all handled by
                         nunmpy dimension casting. Ncyc may coincide with
                         the cycles in LastMaskinview, or it may be longer,
                         in which it is assumed to start at cycle 0. In this
                         case the routine uses self.cyclevec to select the
                         relavent part.
    """
    if mode.ndim == 1:
        mode_ = mode.reshape((mode.size, 1, 1)).astype(np.int8)
    else:
        mode_ = mode.astype(np.int8)
    inMask = np.logical_and(tmlns[0].inMask, mode_ == 1)
    for md in range(1, len(tmlns)):
        inMask = np.logical_or(inMask,
                               np.logical_and(tmlns[md].inMask,
                                              mode_ == md + 1))
    merged_tmln = copy.deepcopy(tmlns[0])
    merged_tmln.inMask[:, :, :] = inMask
    merged_tmln.mask_to_mode(mode)
    return merged_tmln


def GlobalCompositeOrbTimeline(tmlns, mode, tmlns1= None, tmlns2=None, ):
    """ Takes a tuple of OrbTimeline objects, and merges them according to
        a mode selection

        :param tmlns: tuple of timelines
        :param mode: mode is a Ncyc x Norb x Ntimes array, where
                         Norb and Ntimes may be degenerated (i.e.
                         mode.shape == (Ncyc, 1, 1)). This is all handled by
                         nunmpy dimension casting. Ncyc may coincide with
                         the cycles in LastMaskinview, or it may be longer,
                         in which it is assumed to start at cycle 0. In this
                         case the routine uses self.cyclevec to select the
                         relavent part.
    """
    if mode.ndim == 1:
        mode_ = mode.reshape((mode.size, 1, 1)).astype(np.int8)
    else:
        mode_ = mode.astype(np.int8)
    inMask = np.logical_and(tmlns[0].inMask, mode_ == 1)
    if tmlns1:
        inMask1 = np.logical_and(tmlns1[0].inMask, mode_ == 1)
        inMask2 = np.logical_and(tmlns2[0].inMask, mode_ == 1)
    inMask_Global = np.logical_or(inMask,np.logical_or(inMask1, inMask2))

    merged_tmln = copy.deepcopy(tmlns[0])
    merged_tmln.inMask[:, :, :] = inMask_Global
    merged_tmln.mask_to_mode(mode)

    return merged_tmln


def GS_in_view(parfile, lat, lon, elev_min=10,
               orb_type='sunsync', ext_source=False):
    """ Determines when a ground station is in view
    """
    Single_orbData = so.one_orbit(orb_type, 'right',
                                  ext_source=ext_source, parFile=parfile)
    Norb = int(Single_orbData.norb)
    Torb = Single_orbData.Torb
    print(Torb)
    # This is only for a sunsynchronous orbit!
    dlonorb = 360 / 24 * Torb
    r_ecef = Single_orbData.r_ecef
    # v_ecef = Single_orbData.v_ecef
    GSxyz = sargeo.ecef_to_geodetic([lat, lon, 0], inverse=True)
    zenith_v = GSxyz / np.linalg.norm(GSxyz)
    npts = r_ecef.shape[0]
    zenith_ang = np.zeros((Norb, npts))
    for i_orb in range(Norb):
        # Rotate orbit
        r_ecef_r = rot_z(r_ecef, dlonorb * i_orb).transpose()
        GS2sat = r_ecef_r - GSxyz.reshape((1, 3))
        G22sat_v = GS2sat / np.linalg.norm(GS2sat, axis=1).reshape((npts, 1))
        zenith_ang[i_orb] = np.arccos(np.sum(G22sat_v *
                                             zenith_v.reshape((1, 3)), axis=1))

    zenith_ang = np.degrees(zenith_ang)
    contact_mask = zenith_ang < (90 - elev_min)
    dt = Single_orbData.timevec[1] - Single_orbData.timevec[0]
    contact_length = np.sum(contact_mask, axis=1)
    return GSinview(contact_mask, zenith_ang, Single_orbData.timevec,
                    Single_orbData.T0, contact_length)


def contact_plot(parfile, contact_masks,
                 orb_type='sunsync', ext_source=False,
                 colors=('red', 'olive', 'purple', 'teal', 'firebrick'),
                 fontsize=12, gridsize=(30, 60), projection='cyl',
                 lat_0=0,lon_0=0, figsize=(6, 3)):
    """ Plots orbits on a map with a ground station mask overlay (contacts)
    """
    Single_orbData = so.one_orbit(orb_type, 'right',
                                  ext_source=ext_source, parFile=parfile)
    Norb = int(Single_orbData.norb)
    Torb = Single_orbData.Torb
    print(Torb)
    # This is only for a sunsynchronous orbit!
    dlonorb = 360 / 24 * Torb
    r_ecef = Single_orbData.r_ecef
    npts = r_ecef.shape[0]
    plt.figure(figsize=figsize)
    # prepare map plot
    if (projection is 'cyl'):
        m = bsmp.Basemap(llcrnrlon=-180, llcrnrlat=-90, urcrnrlon=+180,
                         urcrnrlat=+90, projection=projection)
    else:
        m = bsmp.Basemap(projection=projection,lat_0=lat_0,lon_0=lon_0,
                         resolution='l')
    m.drawparallels(np.arange(-90,90,gridsize[0]), labels=[1,0,0,1],
                    fontsize=fontsize)
    m.drawmeridians(np.arange(-180,180,gridsize[1]), labels=[1,0,0,1],
                    fontsize=fontsize)
    m.drawmapboundary()
    m.drawcoastlines()
    if type(contact_masks) is tuple:
        contact_maskss = contact_masks
    else:
        contact_maskss = (contact_masks,)
    nmask = len(contact_maskss)

    for i_orb in range(Norb):
        # Rotate orbit
        r_ecef_r = rot_z(r_ecef, dlonorb * i_orb).transpose()
        latlon = sargeo.ecef_to_geodetic(r_ecef_r, inverse=False)
        # take care of longitudinal jumps
        lon_jump = np.where(np.abs(latlon[:, 1][1:]-latlon[:, 1][:-1]) > 300)
        latlon[:, 1][lon_jump] = np.nan
        latlon[:, 0][lon_jump] = np.nan
        # create map plot
        x, y = m(latlon[:, 1], latlon[:, 0])
        im1 = m.plot(x, y, 'b-', linewidth=0.1)
        for i_m in range(nmask):
            latlon_ = np.copy(latlon)
            latlon_[np.invert(contact_maskss[i_m][i_orb, :]), 0:2] = np.nan
            x, y = m(latlon_[:, 1], latlon_[:, 0])
            im2 = m.plot(x, y, linewidth=1.0,
                         color=colors[i_m % len(colors)])


def RoI_in_view(parfile=None, inc_range=[25, 35],
                orb_type='sunsync', look='right', ext_source=False,
                echo_window=None,
                mask_path=None,
                mask_name='land', neg_mask_name=None,
                inRoIpct_threshold=5):

    """ Determines when a ROI is in view by a particular mode.
        Currently this function only takes into account the global land mass
        as ROI. Future enhancements might also be able to use arbitrary ROI
        masks.

        :author: Paco, re-using code from Thomas Börner

        :param parfile: parameter file with orbit parameters
        :param inc: near and far range incidence angle [deg].
        :type inc: two-elements array
        :param echo_window: near and far slant range of echo window or string
                           defining strategy. By default the echo window is
                           ignored and implicitly defined by the range of
                           incident angles. If passed explictly, then it
                           is used every where. If echo_window is set to
                           'ref_equator' then the echo window position is
                           calculated at the equator for the given range of
                           incident angles, and used everywhere else
        :param mask_path: where to look for the masks (this should change in
                          the future)
        :param mask_name: (land, cryo, cryo_boundary, forest, or mountain)
        :param neg_mask_name: where not to acquire. This can be useful, for
                              example, to determine things acquired in addition
                              to previously acquired things
        :param inRoIpct_threshold: percentage of swath occupied by RoI to
                                   consider it included (i.e. trigger an
                                   acquisitions)

        :returns: named tuple defined as
                  namedtuple("inRoI", ['inRoI', 'inRoIpct', 'timevec',
                                       'T0'])

    """
    parfile = utls.misc.get_parFile(parfile=parfile)
    orbit = cov.single_swath(look='right', parFile=parfile,
                             inc_angle=[inc_range[0] - 5, inc_range[1] + 5],
                             ext_source=ext_source)
    if not isinstance(echo_window, type(None)):
        use_echo_window = True
        if echo_window == 'ref_equator':
            sr_range = sargeo.inc_to_sr(np.array(np.radians(inc_range)),
                                        orbit.Horb)
            print("Echo window slr (%f, %f)" % (sr_range[0], sr_range[1]))
        else:
            sr_range = np.array(echo_window)
    else:
        use_echo_window = False

    timevec = orbit.timevec
    lat = orbit.swathData.lat
    lon = orbit.swathData.lon
    Norb = int(orbit.norb)
    Torb = orbit.Torb

    delta_lon = Torb*360./24.
    ntimes = np.size(timevec)

    # Define swath mask
    if use_echo_window:
        swath_mask = np.logical_and(orbit.swathData.R > sr_range[0],
                                    orbit.swathData.R < sr_range[1])
    else:
        swath_mask = np.logical_and((np.degrees(orbit.swathData.incident) >
                                     inc_range[0]),
                                    (np.degrees(orbit.swathData.incident) <
                                     inc_range[1]))

    swath_size = np.sum(swath_mask, axis=1)
    # result arrays
    inRoI = np.zeros((Norb, ntimes), dtype='bool')
    inRoIpct = np.zeros((Norb, ntimes), dtype='float32')
    # Load in the mask of interest
    lats_mask = np.linspace(-90, 90, 1800)
    lons_mask = np.linspace(-180, 180, 3600)
    if type(mask_name) is tuple:
        for i_m in range(len(mask_name)):
            if i_m == 0:
                RoI = read_mask(lats_mask, lons_mask,
                                mask_path, mask_name[i_m])
            else:
                RoI_ = read_mask(lats_mask, lons_mask,
                                 mask_path, mask_name[i_m])
                RoI = np.logical_or(RoI, RoI_)
    else:
        RoI = read_mask(lats_mask, lons_mask, mask_path, mask_name)
    if neg_mask_name is not None:
        if type(neg_mask_name) is tuple:
            nRoI = np.zeros_like(RoI, dtype='bool')
            for i_m in range(len(neg_mask_name)):
                print("Eliminating %s" % neg_mask_name[i_m])
                nRoI_ = read_mask(lats_mask, lons_mask,
                                  mask_path, neg_mask_name[i_m])
                nRoI = np.logical_or(nRoI, nRoI_)
        else:
            print("Eliminating %s" % neg_mask_name)
            nRoI = read_mask(lats_mask, lons_mask, mask_path, neg_mask_name)
        # Substract masks
        RoI = np.logical_and(RoI, np.logical_not(nRoI))
    # for showing some progress
    bar = ProgressBar("Processing", Norb)

    # loop through orbits and apply earth rotation shift
    lati = lat.flatten()
    for i_orbit in range(int(Norb)):
        lon_sh = np.mod(lon + 180 - delta_lon * i_orbit, 360) - 180
        loni = lon_sh.flatten()
        lsmasko = bsmp.interp(RoI, lons_mask, lats_mask, loni, lati,
                              masked=True, order=0)
        # valid points when
        # - they are in the RoI mask
        # - and they are in the swath

        mask_ = lsmasko != 0
        # masked_swath = np.ma.masked_array(swath, mask=mask_)
        RoI_mask = np.reshape(mask_, lat.shape)
        mask = np.logical_and(RoI_mask, swath_mask)
        inRoIpct[i_orbit] = (np.sum(mask, axis=1) / swath_size * 100)
        inRoI[i_orbit] = inRoIpct[i_orbit] > inRoIpct_threshold

        bar.update(i_orbit)

    # calculate results
    duty_cycle = np.sum(inRoI) / (ntimes*Norb)
    RoI_seen = np.sum(inRoIpct) / (ntimes*Norb) / duty_cycle
    print()
    print("Duty cycle: %4.2f%%" % (duty_cycle*100.))
    print("RoI seen when active: %4.2f%%: " % RoI_seen)

    return RoIinview(inRoI, inRoIpct, timevec, orbit.T0)


def DailyLatMask(parfile, mask_asc, mask_dsc, cycles, inc_ref=35,
                 orb_type='sunsync', look='right', ext_source=False,
                 echo_window=None, mask_sampling='daily'):

    """ Generates possible activation applying a latitude dependent mask.

        :author: Paco, re-using code from Thomas Börner

        :param parfile: parameter file with orbit parameters
        :param mask_asc: a 2-D ndarray boolean mask where the first dimension
                         spans latitudes betwen -90 and 90 degree, and the
                         second is a time index.
        :param mask_dsc: a 2-D ndarray boolean mask where the first dimension
                         spans latitudes betwen -90 and 90 degree, and the
                         second is a time index.
        :param cycles: repeat cycle interval tuple (first, last), or just one
        :param inc_ref: reference incidence angle [deg].
        :param echo_window: near and far slant range of echo window or string
                           defining strategy. By default the echo window is
                           ignored and implicitly defined by the range of
                           incident angles. If passed explictly, then it
                           is used every where. If echo_window is set to
                           'ref_equator' then the echo window position is
                           calculated at the equator for the given range of
                           incident angles, and used everywhere else
        :param mask_sampling: May be 'daily', 'orbit' or 'repeat_cycle'
    """
    parfile = utls.misc.get_parFile(parfile=parfile)
    inc_range = [inc_ref - 1, inc_ref + 1]
    orbit = cov.single_swath(look='right', parFile=parfile,
                             inc_angle=[inc_range[0] - 5, inc_range[1] + 5],
                             ext_source=ext_source)
    if not isinstance(echo_window, type(None)):
        use_echo_window = True
        if echo_window == 'ref_equator':
            sr_range = sargeo.inc_to_sr(np.array(np.radians(inc_range)),
                                        orbit.Horb)
            print("Echo window slr (%f, %f)" % (sr_range[0], sr_range[1]))
        else:
            sr_range = np.array(echo_window)
    else:
        use_echo_window = False

    timevec = orbit.timevec
    lat = orbit.swathData.lat
    Norb = int(orbit.norb)
    Torb = orbit.Torb
    if mask_sampling == 'daily':
        dt_mask = 24 * 3600  # seconds
    elif mask_sampling == 'orbit':
        dt_mask = Torb * 3600
    elif mask_sampling == 'repeat_cycle':
        dt_mask = orbit.repeat_cycle * 24 * 3600
    else:
        print("Invalid mask sampling, defaulting to repeat cycle")
        dt_mask = orbit.repeat_cycle * 24 * 3600

    ntimes = np.size(timevec)

    # Define swath mask
    if use_echo_window:
        swath_mask = np.logical_and(orbit.swathData.R > sr_range[0],
                                    orbit.swathData.R < sr_range[1])
    else:
        swath_mask = np.logical_and((np.degrees(orbit.swathData.incident) >
                                     inc_range[0]),
                                    (np.degrees(orbit.swathData.incident) <
                                     inc_range[1]))

#    lat2maskind = lat / (181 / mask_asc.shape[0])
#    mask_asc_i = utls.resample.linresample(mask_asc, lat2maskind, axis=0)
#    mask_dsc_i = utls.resample.linresample(mask_dsc, lat2maskind, axis=0)
    if type(cycles) is tuple:
        cyclev = range(cycles[0], cycles[1] + 1)
    else:
        cyclev = range(cycles, cycles + 1)
    mask_out = np.zeros((len(cyclev), Norb, ntimes), dtype='bool')
    for cycle in cyclev:
        orbit_time = (cycle * orbit.repeat_cycle * 24 * 3600 +
                      np.arange(Norb) * Torb * 3600)
        orbitmaskind = orbit_time / dt_mask
        mask_asc_orb = linresample(mask_asc, orbitmaskind, axis=1)
        mask_dsc_orb = linresample(mask_dsc, orbitmaskind, axis=1)
        malat = np.ma.array(lat, mask=swath_mask)
        lat_ref = np.mean(malat, axis=1)
        lat_ind = (lat_ref + 90) / (181 / mask_asc.shape[0])

        ai0 = int(orbit.asc_idx[0])
        ai1 = int(orbit.asc_idx[1])
        di0 = int(orbit.desc_idx[0])
        di1 = int(orbit.desc_idx[1])
        c = cycle - cyclev[0]
        mask_out[c, :, ai0:ai1] = (linresample(mask_asc_orb,
                                               lat_ind[ai0:ai1],
                                               axis=0) > 0).T
        mask_out[c, :, di0:di1] = (linresample(mask_dsc_orb,
                                               lat_ind[di0:di1],
                                               axis=0) > 0).T

    return OrbTimeline(mask_out, timevec, orbit.T0, cyclev)
