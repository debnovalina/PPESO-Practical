from __future__ import absolute_import, division, print_function
import numpy as np
from collections import namedtuple
from drama import constants as const
from drama.io import cfg as cfg
from drama.geo.sar import geometry as geometry
from drama.orbits import single_orbit as so

Swath = namedtuple('Swath', ['lat', 'lon', 'incident', 'Northing',
                             'GP_mask', 'LoS_satcoord', 'R', 'xyz'])

def line_of_sight_b(la_deg1, r_ecef1, r_ecef2, v_ecef1, v_ecef2):
    """ Calculates the intersection between line of sight (near and far range)
        with the ellipsoid and then retrieves the geometric parameters
        (incidence angle and northing) for both the satellites for a bistatic
        configuration

        :author: Thomas Boerner, Paco Lopez-Dekker, Mariantonietta Zonno

        :param la_deg1: vector of look angles (deg) for satellite 1.
        :type la_deg1: float 1-D vector
        :param r_ecef1: satellite 1 position in ECF reference frame.
        :type r_ecef1: float 2-D array
        :param r_ecef2: satellite 2 position in ECF reference frame.
        :type r_ecef2: float 2-D array
        :param v_ecef1: satellite 1 velocity in ECF reference frame.
        :type v_ecef1: float 2-D array

        :returns: named tuple containing latitudes and longitudes for near and
                  far range and versors required for computing LoS .

    """
    # A bit of initialization
    Np = r_ecef1.shape[0]
    Nla = la_deg1.size
    la1 = np.radians(la_deg1)
    r_x = const.r_equatorial()   # earth equatorial radius [m]
    r_y = const.r_equatorial()   # earth equatorial radius [m]
    r_z = const.r_polar()   # earth radius at pole [m]

    # Calculate velocity and positions versor for both the satellites
    v_ecf_ver1 = v_ecef1/np.linalg.norm(v_ecef1, axis=1).reshape((Np, 1))
    r_ecf_ver1 = r_ecef1/np.linalg.norm(r_ecef1, axis=1).reshape((Np, 1))
    v_ecf_ver2 = v_ecef2/np.linalg.norm(v_ecef2, axis=1).reshape((Np, 1))
    r_ecf_ver2 = r_ecef2/np.linalg.norm(r_ecef2, axis=1).reshape((Np, 1))
    # Build cross product of versors
    n_ver1 = np.cross(v_ecf_ver1, r_ecf_ver1)    # cross product of versors
    n_ver2 = np.cross(v_ecf_ver2, r_ecf_ver2)
    # Calculate near and far range line of sight versors for both the
    # satellites
    LoS1 = geometry.create_LoS(r_ecef1, v_ecef1, la1, squint_a=0)
#    LoS1 = (-np.cos(la1.reshape(1, Nla, 1))*r_ecf_ver1.reshape(Np, 1, 3) +
#            np.sin(la1.reshape(1, Nla, 1))*n_ver1.reshape(Np, 1, 3))

    # Calculate near and far range intersection points of line of sight
    # with ellipsoid
    icp = geometry.pt_get_intersection_ellipsoid(r_ecef1, LoS1)
    R1 = np.linalg.norm(icp - r_ecef1.reshape((Np, 1, 3)), axis=2)
    # vector from the second satellite towards the points on the ellipsoid
    LoS2 = icp - r_ecef2.reshape((Np, 1, 3))
    R2 = np.linalg.norm(LoS2, axis=2)
    LoS2 = (LoS2/R2.reshape((Np, Nla, 1)))
    # LoS in satellite coordinates
    LoS1_satcord = np.zeros(LoS1.shape)
    LoS1_satcord[:, :, 0] = np.sum(LoS1 * v_ecf_ver1.reshape((Np, 1, 3)),
                                   axis=2)
    LoS1_satcord[:, :, 1] = np.sum(LoS1 * r_ecf_ver1.reshape((Np, 1, 3)),
                                   axis=2)
    LoS1_satcord[:, :, 2] = np.sum(LoS1 * n_ver1.reshape((Np, 1, 3)),
                                   axis=2)
    LoS2_satcord = np.zeros(LoS2.shape)
    LoS2_satcord[:, :, 0] = np.sum(LoS2 * v_ecf_ver2.reshape((Np, 1, 3)),
                                   axis=2)
    LoS2_satcord[:, :, 1] = np.sum(LoS2 * r_ecf_ver2.reshape((Np, 1, 3)),
                                   axis=2)
    LoS2_satcord[:, :, 2] = np.sum(LoS2 * n_ver2.reshape((Np, 1, 3)),
                                   axis=2)
    # Vector normal to the surface
    surf_n = icp/(np.array([r_x**2, r_y**2, r_z**2]).reshape(1, 1, 3))
    surf_n = (surf_n /
              np.linalg.norm(surf_n, axis=2).reshape((Np, Nla, 1)))

    LoS_local_z1 = -1 * np.sum(surf_n * LoS1, axis=-1)
    LoS_local_z2 = -1 * np.sum(surf_n * LoS2, axis=-1)

    inc_angle1 = np.arccos(LoS_local_z1)
    inc_angle2 = np.arccos(LoS_local_z2)

    z_u = np.array([0, 0, 1])
    local_N_v = (z_u.reshape((1, 1, 3)) -
                 np.sum(surf_n*z_u.reshape((1, 1, 3)), 2).reshape((Np, Nla, 1))
                 * surf_n)
    local_N_v = (local_N_v /
                 np.linalg.norm(local_N_v, axis=2).reshape((Np, Nla, 1)))
    local_E_v = np.cross(local_N_v, surf_n)

    #  satellite 1
    LoS_local_xy1 = -LoS1 - LoS_local_z1.reshape(Np, Nla, 1) * surf_n
    LoS_local_xy_N1 = np.sum(LoS_local_xy1 * local_N_v, axis=-1)
    LoS_local_xy_E1 = np.sum(LoS_local_xy1 * local_E_v, axis=-1)
    LoS_local_N1 = np.arctan2(LoS_local_xy_E1, LoS_local_xy_N1)
    #  satellite 2
    LoS_local_xy2 = -LoS2 - LoS_local_z2.reshape(Np, Nla, 1) * surf_n
    LoS_local_xy_N2 = np.sum(LoS_local_xy2 * local_N_v, axis=-1)
    LoS_local_xy_E2 = np.sum(LoS_local_xy2 * local_E_v, axis=-1)
    LoS_local_N2 = np.arctan2(LoS_local_xy_E2, LoS_local_xy_N2)

    # Convert intercept point to lat lon
    lat = np.degrees(np.arctan(icp[:, :, 2]/(np.sqrt(icp[:, :, 0]**2. +
                                                     icp[:, :, 1]**2.))))
    lon = np.degrees(np.arctan2(icp[:, :, 1], icp[:, :, 0]))

    # check for points in the swath that are on the other side of the pole
    goodPoints1 = np.where(np.sum(r_ecef1[:, :2].reshape(Np, 1, 2) *
                           icp[:, :, :2], axis=2) > 0)
    goodPoints2 = np.where(np.sum(r_ecef2[:, :2].reshape(Np, 1, 2) *
                           icp[:, :, :2], axis=2) > 0)

    GP_mask1 = np.zeros((Np, Nla)) + np.nan # or zeros? not sure what interpol does with them.
    GP_mask2 = np.zeros((Np, Nla)) + np.nan
    GP_mask1[goodPoints1] = 1
    GP_mask2[goodPoints2] = 1
    if Np*Nla - np.sum(GP_mask1) > 0.0:
        print('There are points on the other side of the pole(s) for satellite 1')
    if Np*Nla - np.sum(GP_mask2) > 0.0:
        print('There are points on the other side of the pole(s) for satellite 2')


    swath1 = Swath(lat, lon, inc_angle1, LoS_local_N1, GP_mask1,
                   LoS1_satcord, R1, icp)
    swath2 = Swath(lat, lon, inc_angle2, LoS_local_N2, GP_mask2,
                   LoS2_satcord, R2, icp)

    return (swath1, swath2)


def single_swath_b(f, orb_type='sunsync', look='left', ext_source=False,
                   parFile=None, inc_angle=None):
    """ Calculates many geometrical variables for one orbit at a user defined
        grid including swathData.

        :author: Jalal Matar, Mariantonietta Zonno
        :param look: satellites formation [class instance]
        :param look: left or right
        :param orb_type: sunsync or repeat
        :param look: left or right
        :param orb_type: sunsync or repeat
        :param ext_source: if True, use external data source
        :param -: All orbit parameters should be in parFile


        :returns: named tuple containing geometrical outputs and SwathData.

    """
    # Satellite
    inData1 = cfg.ConfigFile(parFile)
    # Retrieve data for a single orbit for the first satellite
    Single_orbData = so.one_orbit(orb_type, look, ext_source, parFile)
    Horb1 = Single_orbData.Horb
    r_ecef1 = Single_orbData.r_ecef
    v_ecef1 = Single_orbData.v_ecef

    baseline = f.baseline3d()
    dr_t_asc = baseline[1].dr_t
    dr_t_desc = baseline[0].dr_t
    print("single_swath_b: assuming constant along-track separation")
    v_orb_m = np.mean(np.linalg.norm(v_ecef1, axis=1))
    orb_delay = -1 * np.mean(dr_t_asc) / v_orb_m
    print("Orbit delay: %f" % orb_delay)
    del_orbData = so.one_orbit(orb_type, look, ext_source, parFile,
                               companion_delay=orb_delay,
                               aei=Single_orbData.aei)
    r_ecef2 = del_orbData.r_ecef
    v_ecef2 = del_orbData.v_ecef

    if inc_angle is None:
        la_near1 = np.rad2deg(geometry.inc_to_look(np.deg2rad(inData1.sar.near_1),
                                                   Horb1))
        la_far1 = np.rad2deg(geometry.inc_to_look(np.deg2rad(inData1.sar.far_1),
                                                  Horb1))
    else:
        la_near1 = np.rad2deg(geometry.inc_to_look(np.deg2rad(inc_angle[0]),
                                                   Horb1))
        la_far1 = np.rad2deg(geometry.inc_to_look(np.deg2rad(inc_angle[1]),
                                                  Horb1))

    # get incident angles from look angles
    inc_near1 = geometry.look_to_inc(np.deg2rad(np.abs(la_near1)), Horb1)
    inc_far1 = geometry.look_to_inc(np.deg2rad(np.abs(la_far1)), Horb1)

    gr_res1 = inData1.sar.gr_res

    # get ground range from incident angles
    groundR_near1 = geometry.inc_to_gr(inc_near1, Horb1)
    groundR_far1 = geometry.inc_to_gr(inc_far1, Horb1)

    # number of cells along swath width
    n_cells1 = int(np.absolute(groundR_far1 - groundR_near1)/gr_res1)

    # look angle vector [deg]
    la_vector1 = np.linspace(la_near1, la_far1, n_cells1)

    # Get lat, lon, incident & Northing information for both satellite when
    # look at the same points on the ground
    swath1, swath2 = line_of_sight_b(la_vector1, r_ecef1, r_ecef2,
                                     v_ecef1, v_ecef2)

    OrbTrack = namedtuple('OrbTrack', Single_orbData._fields+('swathData',))
    swathD = namedtuple('swathD', ['swathData'])
    swd = swathD(swath1)
    Sat1Info = OrbTrack(*(Single_orbData + swd))
    swd = swathD(swath2)
    Sat2Info = OrbTrack(*(del_orbData + swd))

    return Sat1Info, Sat2Info
