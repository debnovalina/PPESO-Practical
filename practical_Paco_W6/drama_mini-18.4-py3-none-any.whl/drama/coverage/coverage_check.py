from __future__ import absolute_import, division, print_function
from mpl_toolkits.basemap import Basemap
import numpy as np
from drama.orbits import repeat_design as rd
from drama.coverage import swath_calc as tl
from drama.coverage import swath_coverage as sc
from drama import constants as const
from drama.utils import misc as mi
import matplotlib.pyplot as plt


def check_cov(req_orbs=None, inclination_win=None, orb_spec=None, look='right',
              parNum=1, incident_vec=[20, 45]):
    """ check coverage of certain repeat orbits

        :param req_orbs: a numpy array containing required repeat days
        :param inclination_win: array containing all orbital inclinations to
                                be checked
        :param orb_spec: array containing specific orbit in the form
                         np.array(([[dDays1, nRevs1], [dDays2, nRevs2], ..]))
        :param incident_vec: range of radar beam incident angles
    """
    if orb_spec is None:

        if req_orbs is None:
            # range of wanted orbital repeat cycles
            min_cycle = 1
            max_cycle = 6
            req_orbs = np.array(range(min_cycle, max_cycle + 1))
        else:
            min_cycle = np.min(req_orbs)
            max_cycle = np.max(req_orbs)
    else:
        all_arr = orb_spec

    if inclination_win is None:
        # Orbital Inclinations to be checked
        inclination_win = np.array(range(60, 135, 2), dtype=float)

    # ################### Initialization Parameters ######################## #

    # Parameter file name
    direct = '/home/mata_ja/pythonCodes/drama/drama/coverage/paramsMEO/'
    name = 'par_all' + str(parNum) + '.par'
    fileName = direct + name

    # Array to fill with orbits that fullfill global coverage
    # global_cov = np.array(([0], [0], [0]))  # ([dDays], [nRevs], [inclination])

    lon_width = 360  # longitudinal coverage range
    dlat = 0.05
    dlon = 0.05
    # Create coverage check window
    # min_lonwin = 0
    # max_lonwin = lon_width
    min_lat = -85
    max_lat = +85

    # Orbit related
    orb_type = 'repeat'
    ext_source = False
    ecc = 0.  # eccentriciy
    omega = 120.
    starttime = 3.
    timeduration = 12
    timestep = 1.
    asc_node = 359.
    gr_res = 25000.

    # ###################################################################### #

    # ###### list all repeat orbits between min and max cylcle values ###### #
    if orb_spec is None:
        # range of wanted orbital repeat cycles
        min_cycle = 1
        max_cycle = 5
        all_orbs = rd.all_repeat_orbs(80, 0, min_cycle=min_cycle,
                                      max_cycle=max_cycle, doPlot=0)
        # Note that: the existence of repeat orbits is not bound to inclination

        # Arrange repeat orbits in ascending order as [Nd, Np, h_orb]
        all_arr = np.array([0, 0, 0], dtype=float)
        st_idx = 0
        for idx in req_orbs:

            temp1 = all_orbs[all_orbs[:, 0] == idx, :]
            # carefull height depends on inclination
            temp1[:, 2] = (temp1[:, 2] - const.r_earth).astype(int)/1000.
            temp1 = np.flipud(temp1)

            all_arr = np.vstack((all_arr, temp1))
            # all_arr[st_idx:(st_idx + temp1.shape[0]), :] = temp1
            st_idx = st_idx + temp1.shape[0]
        all_arr = all_arr[1:, :]
    # all_arr = np.array(([[2, 27]]))
    # print(all_arr)
    # all_arr contains all needed orbits
    # ###################################################################### #
    # for showing some progress

    per_cov = np.zeros((all_arr.shape[0]*inclination_win.shape[0], 4))
    # Format: per_cov = ([[cov-percentage, dDays, nRevs, incl],...])
    ctr = 1
    for orb_num in range(0, all_arr.shape[0]):
        for incl in inclination_win:
#            print("orbit: " + str(ctr) + " / " +
#                  str(all_arr.shape[0]*inclination_win.shape[0]))
            # Retrieve input parameters from file
            dDays = int(all_arr[orb_num, 0])
            nRevs = int(all_arr[orb_num, 1])

            # Calculate accurate semi-major axis according to inclination
            a = rd.repeat_EROr(incl, float(dDays)/nRevs, ecc)[1][0]

            # Calculate look angles
            [near_look, far_look] =  np.rad2deg(np.arcsin(np.sin(np.deg2rad(incident_vec))*const.r_earth/(a)))

            # write parameter file
            mi.writepar(fileName, dDays, nRevs, incl, ecc, omega, asc_node,
                        starttime, timeduration, timestep, near_look, far_look,
                        gr_res)

            # Get Single swath data
            One_Orb = tl.single_swath(orb_type, look, ext_source, fileName)

            swathInterpData = tl.swath_interpol(One_Orb, dlat=dlat, dlon=dlon,
                                                maxlat_value=75.,
                                                flag_plot=False)

            cov = sc.coverage_analysis(swathInterpData, lon_width=lon_width,
                                       silent=True)

            cov_total = cov.cov_asc_tot + cov.cov_desc_tot

#            # Create latitude window
            lat_st = min(np.min(cov.lat_desc), np.min(cov.lat_asc))
            lat_en = max(np.max(cov.lat_desc), np.max(cov.lat_asc))
            ratio_lat = cov_total.shape[0]/np.abs(lat_en - lat_st)

            # Create weight matrix
            # Cosine of latitudes
            WM = np.arange(min_lat, max_lat+dlat, dlat).reshape((max_lat-min_lat+dlat)/dlat, 1)
            WM = np.cos(np.deg2rad(WM))

            if lat_st <= min_lat and lat_en >= max_lat:
                cov_lat_st = np.int((min_lat - lat_st)*ratio_lat)
                cov_lat_en = (cov_total.shape[0] -
                              np.int((lat_en - max_lat)*ratio_lat) - 1)
                if (cov_lat_en - cov_lat_st + 1) != WM.shape[0]:
                    cov_lat_st = cov_lat_st + 1
            elif lat_st > min_lat and lat_en < max_lat:
                cov_lat_st = 0
                cov_lat_en = cov_total.shape[0] - 1
            elif lat_st <= min_lat and lat_en < max_lat:
                cov_lat_st = np.int((min_lat - lat_st)*ratio_lat) + 1
                cov_lat_en = cov_total.shape[0] - 1
            else:
                cov_lat_st = 0
                cov_lat_en = (cov_total.shape[0] -
                              np.int((lat_en - max_lat)*ratio_lat) - 1)

            # Total coverage window
            cov_win = cov_total[cov_lat_st:cov_lat_en+1, :]

            # Find total coverage window bounds ( for % coverage pupose)
            cov_all = np.zeros([(max_lat-min_lat)/dlat + 1, cov_win.shape[1]])

            if lat_st <= min_lat and lat_en >= max_lat:
                cov_all = cov_win
            elif lat_st > min_lat and lat_en < max_lat:
                bound1 = np.int((lat_st - min_lat)*ratio_lat)
                bound2 = np.int((lat_en - min_lat)*ratio_lat)
                cov_all[bound1:bound2, :] = cov_win
            elif lat_st <= min_lat and lat_en < max_lat:
                bound1 = 0
                bound2 = np.int((lat_en - min_lat)*ratio_lat)
                cov_all[bound1:bound2, :] = cov_win
            else:
                bound1 = np.int((lat_st - min_lat+1)*ratio_lat) - 1
                bound2 = cov_all.shape[0]
                if (bound2 - bound1) != cov_win.shape[0]:
                    bound1 = bound2 - cov_win.shape[0]
                cov_all[bound1:bound2, :] = cov_win


            # Weighted Coverage
            cov_norm = cov_all
            cov_norm[cov_norm > 0] = 1
            WC = cov_norm*WM
            # percentage coverage
            per_cov[ctr-1, :] = [np.sum(WC)/np.size(WC)*100, dDays, nRevs, incl]
            ctr = ctr+1

            # Check if window is totally covered
#            if not np.any(cov_win == 0):
#                global_cov = np.concatenate((global_cov, ([dDays], [nRevs],
#                                                          [incl])), 1)
##            partial_cov_plot(cov_win, cov.lon_cov_asc[0], cov.lon_cov_asc[-1],
##                             min_lat, max_lat, lat_st, lat_en)
##            bar.update(ctr)
#    global_cov = global_cov[:, 1:]
#
#    cover = namedtuple('COVER', ['incident', 'global_cov', 'per_cov'])
#    out = cover(incident_vec, global_cov, per_cov)

    return per_cov


def partial_cov_plot(covData, lonmin, lonmax, latmin, latmax, lat_st, lat_en):
        # window Output
    x0 = lonmin
    x1 = lonmax
    y0 = max(latmin, lat_st)
    y1 = min(latmax, lat_en)
    max_cb = np.max(covData) + 1

    cmap = plt.get_cmap('jet', max_cb)
    cmaplist = [cmap(j) for j in range(cmap.N)]
    cmaplist[0] = (0, 0, 0, 0)
    cmap = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    fig3 = plt.figure()
    ax3 = fig3.add_axes([0.1, 0.1, 0.8, 0.8])
    m = Basemap(llcrnrlon=x0, llcrnrlat=latmin, urcrnrlon=x1,
                urcrnrlat=latmax, projection='cyl')
    m.drawparallels(np.arange((int(latmin/10.)-1)*10,
                              (int(latmax/10.)+1)*10, 10),
                    labels=[1, 0, 0, 1], fontsize=12)
    m.drawmeridians(np.arange(-180, 180, 10), labels=[1, 0, 0, 1], fontsize=12)
    ax3.set_title('window Coverage')
    plt.imshow(covData, extent=(x0, x1, y0, y1),
               vmin=0, vmax=max_cb, cmap=cmap)
    plt.colorbar()
