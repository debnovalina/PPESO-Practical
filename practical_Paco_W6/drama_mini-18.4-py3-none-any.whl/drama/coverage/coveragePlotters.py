import numpy as np
import os
from copy import copy
from drama.orbits import repeat_design as rd
from drama.orbits import calc_orbit as cco
from drama.orbits import sunsync_orbit as sso
from drama.orbits import read_XMLorbit
from drama import constants as const
from drama.io import cfg
from drama.coverage import swath_calc as tl
from drama.coverage import swath_coverage as sc
from drama.utils import misc as misc
from drama.utils.coord_trans import (rot_z, rot_z_prime)
from drama.geo.sar import geometry as geo
from matplotlib.widgets import Slider
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap


def test_look():
    """ Find the range of valid look angles for corresponding orbital heights
    """

    r_earth = const.r_earth
    look_angle1 = np.arange(-90, 90.1, 0.5, dtype=float)
    look_angle = np.reshape(look_angle1, (len(look_angle1), 1))

    # Horb1 = np.arange(16500.0e03, 16520.0e03, 1.0e03, dtype=float)
    Horb1 = np.arange(500.0e03, 37000.0e03, 1000.0e03, dtype=float)
    Horb = np.reshape(Horb1, (1, len(Horb1)))

    sin_look = np.sin(np.deg2rad(look_angle))
    output_mat = sin_look + (1./r_earth)*np.dot(sin_look, Horb)

    # Setting the validity mask
    valid_mat = copy(output_mat)
    valid_mat[valid_mat > 1] = -10
    valid_mat[valid_mat < -1] = -10
    valid_mat[valid_mat > -10] = -9
    valid_mat = valid_mat + 10

    # Plotting
    plt.figure()
    ax1 = plt.subplot(111)
    xx, yy = np.meshgrid(Horb1, look_angle1)
    plt.pcolormesh(xx, yy, valid_mat)
    # plt.imshow(valid_mat.copy(), origin='lower')
    ticks = ax1.get_xticks()/1000.
    ticks = map(int, ticks)
    ax1.set_xticklabels(ticks)
    plt.colorbar()
    plt.title('Valid Regions (red)')
    plt.grid(True)
    # plt.axis('auto')
    plt.xlim(min(Horb1), max(Horb1))
    plt.xlabel('Orbital Height [km]')
    plt.ylabel('Look angle [deg]')
    plt.show()

    # incidence to look formula
    # np.rad2deg(np.arcsin(np.sin(np.deg2rad(15))*
    #             const.r_earth/(a))

    return output_mat, valid_mat


def plot_RGT(dDays, nRevs, i=89.4, e=0.0, omega=90.0, asc_node=359.145,
             timeduration=7., starttime=3., timestep=2., orb_type='repeat'):
    """ Plots the ground track of an RGT orbit

    :author: Jalal Matar

    :date: 26.1.2015

    :param dDay: Number of days for a repeat cycle
    :param nRevs: Number of revolutions per Rday
    :param i: inclination [deg] (not required for sunsync)
    :param e: eccentricity (not required for sunsync)
    :param omega: argument of perigee
    :param asc_node: right ascension of the ascending node [deg]
    :param timeduration: duration of orbit [days]
    :param timestep: step size of sampling
    :param starttime: time (starting at perigee)
    :param orb_type: repeat or sunsync

    """

    if orb_type == 'sunsync':
        # Generate parameters for sunsync orbit
        (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs, acc=1)
        data = cco.calc_orb_gen(e, a, i, omega, asc_node, timeduration,
                                timestep, starttime, noinfo=1, omega_per_dot=0)

    elif orb_type == 'repeat':
        # Generate parameters for repeat orbit
        all_repeats = rd.all_repeat_orbs(i, e, dDays, dDays,
                                         doPlot=0)
        repeat = all_repeats[all_repeats[:, 0] == dDays, :]
        repeat_nRd = repeat[repeat[:, 1] == nRevs, :]
        a = repeat_nRd[0, 2]

        data = cco.calc_orb_gen(e, a, i, omega, asc_node, timeduration,
                                timestep, starttime, noinfo=1, omega_per_dot=0)

    lon_arr = data.lon_arr
    lat_arr = data.lat_arr

    plt.figure()
    plt.title(str(dDays) + "/" + str(nRevs) + " RGT,    a" + "$\\approx$" +
              str(int(a/1000.)) + " km,   i= " + str(i) + " deg,   e= " +
              str(e))
    m = Basemap(projection='cyl', resolution='l', area_thresh=None)
    m.drawmapboundary()
    m.fillcontinents(color='#dadada', lake_color='white')
    m.drawparallels(np.arange(-90, 90, 30), color='gray')
    m.drawmeridians(np.arange(-180, 180, 30), color='gray')
    m.scatter(lon_arr, lat_arr, alpha=0.3, color='blue', zorder=3, marker='.')

    return


def plot_cov_RGT(orb_type='repeat', look='right', spherical=False,
                 ground_track=False, ext_source=False, parFile=None,
                 plotAll=False, plot_days=None, plot_revs=None):
    """Plots the coverage map for a RGT orbit on a Spherical Earth

    :author: Jalal Matar

    :date: 03.02.2015

    :param look: left, right or both
    :param spherical: set to True if you wish to have a Sperical Earth plot
    :param orb_type: sunsync or repeat
    :param ground_track: enables plotting ground track on top of coverage
    :param ext_source: if True, use external data source
    :param -: All orbit parameters should be in parFile.
    :param plotAll: if True, plot ascending, descending and combined
                    separately
    :param plot_days: plots certain number of days
    :param plot_revs: plots certain number of revs

    """

    parFile = misc.get_parFile(parFile)
    inData = cfg.ConfigFile(parFile)

    # define constants
    T_sidereal = 86164.09053  # [sec]

    # Retrieve input parameters from file
    dDays = inData.orbit.days_cycle
    nRevs = inData.orbit.orbits_nbr

    if (not ext_source):
        omega = inData.orbit.omega_p
        timestep = inData.orbit.timestep  # [s]
        starttime = inData.orbit.starttime
        timeduration = inData.orbit.timeduration
        asc_node = inData.orbit.asc_node

        # Prepare Ground track data
        if orb_type == 'sunsync':
            # Generate parameters for sunsync orbit
            Tday = 86400.  # [sec]
            Torb = 24.*dDays/nRevs  # orbita period [hrs]
            (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs, acc=1.)

        elif orb_type == 'repeat':
            # Aquire repeat specific orbit params
            i = inData.orbit.inc
            e = inData.orbit.ecc
            Tao = float(dDays)/nRevs
            Tday = T_sidereal
            Torb = (T_sidereal/3600.)*Tao  # orbital period [hrs]

            # Generate parameters for repeat orbit
            all_repeats = rd.all_repeat_orbs(i, e, dDays, dDays,
                                             doPlot=0)
            repeat = all_repeats[all_repeats[:, 0] == dDays, :]
            repeat_nRd = repeat[repeat[:, 1] == nRevs, :]
            a = repeat_nRd[0, 2]  # semi major axis[m]

        data = cco.calc_orb_gen(e, a, i, omega, asc_node, timeduration,
                                timestep, starttime, noinfo=1, omega_per_dot=0)
        lon_arr = data.lon_arr
        lat_arr = data.lat_arr

    else:  # external data source
        # Read data from XML file
        xmlFilePath = os.path.dirname(parFile)
        xmlFile = os.path.join(xmlFilePath, inData.orbit.xmlFileName)
        [oHInfo, stateVecInfo] = read_XMLorbit(xmlFile)

        # Retrieve output variables
        Torb = 24.*dDays/nRevs  # orbital period [hrs]
        Tday = 86400.  # [sec]
        (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs, acc=1.)

        # Create time vector [timevec]
        timevec = np.array(stateVecInfo.timeGPS)

        # Create poition vector [recf]
        Xpos = np.array(stateVecInfo.posX)
        Ypos = np.array(stateVecInfo.posY)
        Zpos = np.array(stateVecInfo.posZ)
        recf = np.vstack((Xpos, Ypos, Zpos)).T

        # Create velocity vector [vecf]
        Xvel = np.array(stateVecInfo.velX)
        Yvel = np.array(stateVecInfo.velY)
        Zvel = np.array(stateVecInfo.velZ)
        v = np.vstack((Xvel, Yvel, Zvel)).T

        # check if velocity is complementary or ecef
        if oHInfo.accuracy == 'REFC':
            vcomp = v
            omega_earth = const.omega_earth
            vecf = np.zeros(v.shape)
            reci = np.zeros(recf.shape)
            for k in range(0, vcomp.shape[0]):
                argR = np.rad2deg(omega_earth*timevec[k])
                reci[k, :] = rot_z(recf[k, :], argR, inverse_transform=True)
                vecf[k, :] = (vcomp[k, :] +
                              omega_earth*rot_z_prime(reci[k, :], argR))
        elif oHInfo.accuracy == 'REFE':
            vecf = v

        # separate data into ascending and descending nodes
        v_indices = misc.asc_desc(vecf)
        asc_idx = v_indices.asc_idx
        desc_idx = v_indices.desc_idx

        diff = desc_idx[0, 1] - desc_idx[0, 0]
        for idx in range(1, len(desc_idx)):
            diff2 = desc_idx[idx, 1] - desc_idx[idx, 0]
            if diff2 == diff:
                desc_idx2 = desc_idx[idx-1, :]
                asc_idx2 = asc_idx[asc_idx[:, 0] == (desc_idx2[1] + 1), :]
                asc_idx2 = asc_idx2[0, :]
                break
            diff = diff2

        # select data of one_orbit
        r_ecf_new = recf[desc_idx2[0]:asc_idx2[1], :]

        # declination (gamma)
        lat_arr = np.arctan((r_ecf_new[:, 2]) /
                            (np.sqrt(((r_ecf_new[:, 0])**2.0) +
                                     ((r_ecf_new[:, 1])**2.0))))

        # right ascension (alpha)
        lon_arr = np.arctan2(r_ecf_new[:, 1], r_ecf_new[:, 0])

    # Prepare Swath data
    if look == 'left' or look == 'right':
        One_Orb = tl.single_swath(orb_type, look, ext_source, parFile)
        swathData = One_Orb.swathData
        Torb = One_Orb.Torb
    elif look == 'both':
        One_Orb_L = tl.single_swath(orb_type, 'left', ext_source, parFile)
        One_Orb_R = tl.single_swath(orb_type, 'right', ext_source, parFile)
        swathDataL = One_Orb_L.swathData
        swathDataR = One_Orb_R.swathData
        Torb = One_Orb_L.Torb

    # Basemap plotter
    def plot_Basemap(proj, lon0=0, lat0=0, sect='combined'):
        """ Plots Basemap

        :param lon0: longitude center of map [-180, 180]
        :param lat: latitude center of map
        :param proj: type of projection
        """
        plt.title(str(dDays) + "/" + str(nRevs) + " RGT (" + sect +
                  "),    a" + "$\\approx$" + str(int(a/1000.)) +
                  " km,  i= " + str(i) + " deg,   e= " + str(e), fontsize=14)
        if spherical:
            m = Basemap(projection=proj, lon_0=lon0, lat_0=lat0,
                        resolution='l', area_thresh=None, ax=ax1)
            m.drawmeridians(np.arange(-180, 180, 10), color='gray')
            m.drawparallels(np.arange(-90, 90, 10), color='gray')
        else:
            m = Basemap(projection=proj, resolution='l', area_thresh=None,
                        lat_0=0, lon_0=0, llcrnrlon=-180, urcrnrlon=180)
            m.drawmeridians(np.arange(-180, 180, 10), labels=[1, 0, 0, 1],
                            fontsize=12)
            m.drawparallels(np.arange(-90, 90, 10),  labels=[1, 0, 0, 1],
                            fontsize=12)

        m.drawmapboundary()
        m.drawcoastlines()
        m.fillcontinents(color='#808080', lake_color='white')
#        m.fillcontinents(color='coral', lake_color='aqua')
#        m.bluemarble()
        delta_lon1 = Torb*360./(Tday/3600.)

        if plot_revs is None:
            if plot_days is None:
                neighbours = nRevs
            else:
                neighbours = np.ceil(plot_days*24./Torb).astype(int)
        else:
            neighbours = plot_revs

        if look == 'left' or look == 'right':
            p_color = '#87CEFA'
            if look == 'right':
                p_color = 'green'

            if sect == 'combined':
                sw_lon = swathData.lon
                sw_lat = swathData.lat
            elif sect == 'ascending':
                asc_idx = np.atleast_2d(One_Orb.asc_idx)
                asc_idx = asc_idx[np.where(np.diff(asc_idx) != 0)[0][0], :]
                sw_lon = swathData.lon[asc_idx[0]:asc_idx[1] + 1, :]
                sw_lat = swathData.lat[asc_idx[0]:asc_idx[1] + 1, :]
            elif sect == 'descending':
                desc_idx = np.atleast_2d(One_Orb.desc_idx)
                desc_idx = desc_idx[np.where(np.diff(desc_idx) != 0)[0][0], :]
                sw_lon = swathData.lon[desc_idx[0]:desc_idx[1] + 1, :]
                sw_lat = swathData.lat[desc_idx[0]:desc_idx[1] + 1, :]

            sw_lon = np.where(sw_lon > 0, sw_lon, sw_lon + 360)

            # Plot neighbouring swath
            for jj in range(neighbours):
                # for jj in range(1):
                delta_lon = jj * delta_lon1
                sw_lon_rot = np.mod(sw_lon - delta_lon, 360)
                sw_lon_rot = np.where(sw_lon_rot > 0, sw_lon_rot,
                                      sw_lon_rot + 360)
                sw_lon_rot[np.where(sw_lon_rot > (lon0 + 180))] -= 360

                if spherical:
                    x1, y1 = m(sw_lon_rot, sw_lat)
                else:
                    x1 = sw_lon_rot
                    y1 = sw_lat
                m.scatter(x1, y1, alpha=0.05, color=p_color,
                          zorder=3, marker='.')
        elif look == 'both':
            # Plot neighbouring swath
            for jj in range(neighbours):
                delta_lon = jj * delta_lon1
                sw_lonL = swathDataL.lon - delta_lon
                sw_lonR = swathDataR.lon - delta_lon
                sw_lonL = np.mod(sw_lonL, 360)
                sw_lonL = np.where(sw_lonL > 0, sw_lonL, sw_lonL + 360)
                sw_lonL[np.where(sw_lonL > lon0 + 180)[0]] -= 360

                if spherical:
                    x1, y1 = m(sw_lonL, swathDataL.lat)
                else:
                    x1 = sw_lonL
                    y1 = swathDataL.lat
                m.scatter(x1, y1, alpha=0.05, color='blue',
                          zorder=3, marker='.')

                sw_lonR = np.mod(sw_lonR, 360)
                sw_lonR = np.where(sw_lonR > 0, sw_lonR, sw_lonR + 360)
                sw_lonR[np.where(sw_lonR > lon0 + 180)[0]] -= 360

                if spherical:
                    x2, y2 = m(sw_lonR, swathDataR.lat)
                else:
                    x2 = sw_lonR
                    y2 = swathDataR.lat
                m.scatter(x2, y2, alpha=0.6, color='green',
                          zorder=3, marker='.')

        # Plot ground track on top
        if ground_track:
            geo_arr = geo.ecef_to_geodetic(One_Orb.r_ecef)
            lat_all = geo_arr[:, 0]
            lon_all = geo_arr[:, 1]
            for jj in range(1, neighbours):
                lat_all = np.append(lat_all, geo_arr[:, 0])
                lon_rot = np.mod(geo_arr[:, 1] - jj*delta_lon1, 360)
                lon_rot = np.where(lon_rot > 0, lon_rot, lon_rot + 360)
                lon_rot[np.where(lon_rot > lon0 + 180)[0]] -= 360

                lon_all = np.append(lon_all, lon_rot)
            if spherical:
                x, y = m(lon_all, lat_all)
            else:
                x = lon_all
                y = lat_all
            m.scatter(x, y, alpha=0.3, color='red', zorder=3, marker='.')
        plt.show()

    # Slider function call (For spherical only)
    def on_change(val):
        lonshift = slider1.val
        latshift = slider2.val
        plt.sca(ax1)
        plt.cla()
        ax1.set_xticks([])
        ax1.set_yticks([])
        plot_Basemap('ortho', lonshift, latshift)
        return

    if spherical:
        # Plot Basemap
        plt.figure()
        gs = gridspec.GridSpec(12, 12)
        ax1 = plt.subplot(gs[:10, :])
        ax1.set_xticks([])
        ax1.set_yticks([])
        lon_in = 15
        lat_in = 35
        plot_Basemap('ortho', lon_in, lat_in)

        # Create Sliders
        slider_ax = plt.subplot(gs[10, :])
        slider1 = Slider(slider_ax, "Lon Center", -180, 180,
                         valinit=lon_in, color='#AAAAAA')
        slider1.on_changed(on_change)
        slider_ay = plt.subplot(gs[11, :])
        slider2 = Slider(slider_ay, "Lat Center", -90, 90, valinit=lat_in,
                         color='#AAAAAA')
        slider2.on_changed(on_change)

    else:
        # Plot Basemap
        plt.figure()
        plot_Basemap(proj='cyl')
        if plotAll:
            plt.figure()
            plot_Basemap(proj='cyl', sect='ascending')
            plt.figure()
            plot_Basemap(proj='cyl', sect='descending')
    return One_Orb


def exact_plot(lon_range=[-180, 180], lat_range=[-90, 90], orb_type='repeat',
               look='right', plotAll=True, plot_days=None, plot_revs=None,
               parFile=None, ext_source=False,):
    """ Plots Coverage on a grid with accurate number of repeats and
        calculates the percentage of coverage

        :author: Jalal Matar

        :param lon_range: longitudinal coverage range
        :param lat_range: latitude coverage range
        :param orb_type: sunsync or repeat
        :param look: left or right
        :param plotAll: if True plots additional separate asc/desc plots
        :param -: All orbit parameters should be in parFile.

        :returns: coverage percentage

    """
    parFile = misc.get_parFile(parFile)

    # define constants
    dlat = 0.1
    dlon = 0.1
    [min_lat, max_lat] = lat_range
    lon_width = lon_range[1] - lon_range[0]

    # Get Single swath data
    One_Orb = tl.single_swath(orb_type, look, parFile=parFile,
                              ext_source=ext_source)

    swathInterpData = tl.swath_interpol(One_Orb, dlat=dlat, dlon=dlon,
                                        maxlat_value=90., flag_plot=False)
    cov = sc.coverage_analysis(swathInterpData, lon_width=lon_width,
                               days=plot_days, revs=plot_revs)

    cov_total = cov.cov_asc_tot + cov.cov_desc_tot

    if plotAll:
        sc.coverage_plot(cov)

    # Create latitude window
    lat_st = min(np.min(cov.lat_desc), np.min(cov.lat_asc))  # lat data start
    lat_en = max(np.max(cov.lat_desc), np.max(cov.lat_asc))  # lat data end
    ratio_lat = cov_total.shape[0]/np.abs(lat_en - lat_st)  # approx. 1/dlat

    # Create weight matrix
    # Cosine of latitudes
    WM = np.arange(min_lat, max_lat+dlat,
                   dlat).reshape(round((max_lat-min_lat+dlat)/dlat), 1)
    WM = np.cos(np.deg2rad(WM))

    # Find coverage window bounds
    if lat_st <= min_lat and lat_en >= max_lat:
                cov_lat_st = np.int((min_lat - lat_st)*ratio_lat)
                cov_lat_en = (cov_total.shape[0] -
                              np.int((lat_en - max_lat)*ratio_lat) - 1)
                if (cov_lat_en - cov_lat_st + 1) != WM.shape[0]:
                    cov_lat_st = cov_lat_st + 1
    elif lat_st > min_lat and lat_en < max_lat:
        cov_lat_st = 0
        cov_lat_en = cov_total.shape[0] - 1
    elif lat_st <= min_lat and lat_en < max_lat:
        cov_lat_st = np.int((min_lat - lat_st)*ratio_lat) + 1
        cov_lat_en = cov_total.shape[0] - 1
    else:
        cov_lat_st = 0
        cov_lat_en = (cov_total.shape[0] -
                      np.int((lat_en - max_lat)*ratio_lat) - 1)

    # Total coverage window
    cov_win = cov_total[cov_lat_st:cov_lat_en+1, :]
    cov_win = np.roll(cov_win, int(180/dlon))
#    x0 = -180
#    x1 = 180
#
#    y0 = max(min_lat, lat_st)
#    y1 = min(max_lat, lat_en)
#    max_cb = int(np.max(cov.cov_asc_tot + cov.cov_desc_tot)) + 2
#    labels = np.arange(0, int(max_cb) + 1, 1)
#    loc = labels + .5
#    labels_t = list(map(str, labels.tolist()))
#    labels_t[-2] = '>= ' + labels_t[-2]
#
#    cmap = plt.get_cmap('jet', max_cb)
#    cmaplist = [cmap(j) for j in range(cmap.N)]
#    cmaplist[0] = (0, 0, 0, 0)
#    cmap = cmap.from_list('Custom cmap', cmaplist, cmap.N)
#
#    fig3 = plt.figure()
#    ax3 = fig3.add_axes([0.1, 0.1, 0.8, 0.8])
#
#    m = Basemap(llcrnrlon=-180, llcrnrlat=-90, urcrnrlon=180,
#                urcrnrlat=90, projection='cyl')
#    m.drawmeridians(np.arange(-180, 180, 10), labels=[1, 0, 0, 1],
#                    fontsize=12)
#    m.drawcoastlines()
#    m.drawparallels(np.arange((int(min_lat/10.)-1)*10,
#                              (int(max_lat/10.)+1)*10, 10),
#                    labels=[1, 0, 0, 1], fontsize=12)
#    ax3.set_title('window Coverage', fontsize=16)
#    plt.imshow(cov_win, extent=(x0, x1, y0, y1),
#               vmin=0, vmax=max_cb, cmap=cmap, origin='lower')
#    cb = plt.colorbar()
#    cb.set_ticks(loc)
#    cb.set_ticklabels(labels_t)
#    plt.draw()

    # Find total coverage window bounds ( for % coverage pupose)
    cov_all = np.zeros([(max_lat-min_lat)/dlat + 1, cov_win.shape[1]])

    if lat_st <= min_lat and lat_en >= max_lat:
        cov_all = cov_win
    elif lat_st > min_lat and lat_en < max_lat:
        bound1 = np.int((lat_st - min_lat)*ratio_lat)
        bound2 = np.int((lat_en - min_lat)*ratio_lat)
        cov_all[bound1:bound2, :] = cov_win
    elif lat_st <= min_lat and lat_en < max_lat:
        bound1 = 0
        bound2 = np.int((lat_en - min_lat)*ratio_lat)
        cov_all[bound1:bound2, :] = cov_win
    else:
        bound1 = np.int((lat_st - min_lat+1)*ratio_lat) - 1  # same
        bound2 = cov_all.shape[0]
        if (bound2 - bound1) != cov_win.shape[0]:
            bound1 = bound2 - cov_win.shape[0]
        cov_all[bound1:bound2, :] = cov_win

    # Weighted Coverage
    cov_norm = cov_all
    cov_norm[cov_norm > 0] = 1
    WC = cov_norm*WM
    per_cov = np.sum(WC)/np.size(WC)*100  # percentage coverage

    return per_cov
