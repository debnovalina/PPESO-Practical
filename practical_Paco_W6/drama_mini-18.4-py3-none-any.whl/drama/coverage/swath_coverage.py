from __future__ import absolute_import, division, print_function
import numpy as np
from collections import namedtuple
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.basemap import Basemap, maskoceans, addcyclic, shiftgrid
import math
import os
import sys
import drama.geo.sar as sargeo
from drama.io.cli import ProgressBar
from mpl_toolkits import axes_grid1


def add_colorbar(im, aspect=20, pad_fraction=0.5, **kwargs):
    """Add a vertical color bar to an image plot."""
    divider = axes_grid1.make_axes_locatable(im.axes)
    width = axes_grid1.axes_size.AxesY(im.axes, aspect=1/aspect)
    pad = axes_grid1.axes_size.Fraction(pad_fraction, width)
    current_ax = plt.gca()
    cax = divider.append_axes("right", size=width, pad=pad)
    plt.sca(current_ax)
    return im.axes.figure.colorbar(im, cax=cax, **kwargs)


def coverage_analysis(swathInterpData, inc_angle_range=None,
                      lon_width=None, days=None, revs=None, blinds=False,
                      PRF=None, duty_cycle=None, silent=False,
                      res_lat=None, res_lon=None,
                      echo_window=None):

    """ Calculates coverage maps (arrays) seperately for ascending and
        descending orbit sections for a given time interval (days) and a
        longitudinal width (deg). In addition you can trigger blind ranges,
        which requires PRF and duty_cycle to be set.

        :author: Thomas Boerner

        :param swathInterpData: interpolated swath data.
        :type swathInterpData: tuple
        :param inc_angle_range: near and far range incidence angle [deg].
        :type inc_angle_range: two-elements array
        :param lon_width: longitudinal width for which the coverage is
                          computed [deg].
        :type lon_width: float
        :param days: time interval for which the coverage is computed [d].
        :type days: int
        :param blinds: flag to trigger blind ranges [True/False].
        :type blinds: boolean
        :param PRF: PRF for processing blind ranges [Hz].
        :type PRF: float
        :param duty_cycle: duty cycle for processing blind ranges.
        :type duty_cycle: float
        :param res_lat: angular resolution in latitude [deg].
        :type res_lat: float
        :param res_lon: angular resolution in longitude [deg].
        :type res_lon: float
        :param srg_window: near and far slant range of echo window or string
                           defining strategy. By default the echo window is
                           ignored and implicitly defined by the range of
                           incident angles. If passed explictly, then it
                           is used every where. If echo_window is set to
                           'ref_equator' then the echo window position is
                           calculated at the equator for the given range of
                           incident angles, and used everywhere else

        :returns: named tuple containing coverage maps and according lat/lon
                  coordinates, used by plot/hist functions to visualise
                  results.

    """

    timevec = swathInterpData.timevec
    Norb = swathInterpData.norb
    dlat = swathInterpData.dlat
    dlon = swathInterpData.dlon

    #Torb = (timevec[-1]-timevec[0])/60./60.    #Torb in hours
    Torb = swathInterpData.Torb
    delta_lon = Torb*360./24.

    if (revs != None):
        Norb = revs
    else:
        if (days != None):
            Norb = np.ceil(days*24./Torb).astype(int)

    # Incident angles range
    if (inc_angle_range is None):
        inc_angle_range = [np.nanmin(swathInterpData.Ascending.inc_angle),
                           np.nanmax(swathInterpData.Ascending.inc_angle)]
        inc_angle_range[0] = np.rad2deg(inc_angle_range[0]) + 1
        inc_angle_range[1] = np.rad2deg(inc_angle_range[1]) - 1
    incr_angle_range = np.radians(inc_angle_range)
    # are there blind ranges?
    if not isinstance(echo_window, type(None)):
        use_echo_window = True
        if echo_window == 'ref_equator':
            sr_range = sargeo.inc_to_sr(np.array(np.radians(inc_angle_range)),
                                        swathInterpData.Horb)
            print("Echo window slr (%f, %f)" % (sr_range[0], sr_range[1]))
        else:
            sr_range = np.array(echo_window)
    else:
        use_echo_window = False
    if blinds:
        br = sargeo.blind_ranges(inc_angle_range, swathInterpData.Horb,
                                 PRF, duty_cycle)
    else:
        br = None

    # set new resolution for ascending
    if not (res_lat is None):
        dim_lata = np.shape(swathInterpData.Ascending.lat)[0]
        idx_lat = np.round(np.arange(0, dim_lata, res_lat/dlat)).astype(int)
        dim_lata = np.shape(idx_lat)[0]
    else:
        dim_lata = np.shape(swathInterpData.Ascending.lat)[0]
        idx_lat = np.arange(dim_lata).astype(int)

    if not (res_lon is None):
        dim_lona = np.shape(swathInterpData.Ascending.lon)[0]
        idx_lon = np.round(np.arange(0, dim_lona, res_lon/dlon)).astype(int)
        dim_lona = np.shape(idx_lon)[0]
    else:
        dim_lona = np.shape(swathInterpData.Ascending.lon)[0]
        idx_lon = np.arange(dim_lona).astype(int)
    if use_echo_window:
        sr = swathInterpData.Ascending.slant_range[idx_lat, :]
        sr = sr[:, idx_lon]
        mask_asc = np.logical_and((sr > sr_range[0]),
                                  (sr < sr_range[1]))
        # Consider here blind ranges
        if not (br is None):
            for i_br in range(br.inc_s.shape[0]):
                mask_br = np.logical_and((sr > br.slant_range_s[i_br]),
                                         (sr < br.slant_range_e[i_br]))
                mask_br = np.logical_not(mask_br)
                mask_asc = mask_asc * mask_br
    else:
        inc_angle = swathInterpData.Ascending.inc_angle[idx_lat, :]
        inc_angle = inc_angle[:, idx_lon]
        # mask for ascending swath
        mask_asc = np.logical_and((inc_angle > incr_angle_range[0]),
                                  (inc_angle < incr_angle_range[1]))
        # Consider here blind ranges
        if not (br is None):
            for i_br in range(br.inc_s.shape[0]):
                mask_br = np.logical_and((inc_angle > np.deg2rad(br.inc_s[i_br])),
                                         (inc_angle < np.deg2rad(br.inc_e[i_br])))
                mask_br = np.logical_not(mask_br)
                mask_asc = mask_asc * mask_br

    lat_asc = swathInterpData.Ascending.lat[idx_lat]
    lon_asc = swathInterpData.Ascending.lon[idx_lon]

    # Unwrap the longitudes
    lon_asc = np.where(lon_asc > 0, lon_asc, lon_asc + 360)

    #set new resolution for descending
    if (res_lat != None):
        dim_latd = np.shape(swathInterpData.Descending.lat)[0]
        idx_lat  = np.round(np.arange(0,dim_latd,res_lat/dlat)).astype(int)
        dim_latd = np.shape(idx_lat)[0]
    else:
        dim_latd = np.shape(swathInterpData.Descending.lat)[0]
        idx_lat  = np.arange(dim_latd).astype(int)

    if (res_lon != None):
        dim_lond = np.shape(swathInterpData.Descending.lon)[0]
        idx_lon  = np.round(np.arange(0,dim_lond,res_lon/dlon)).astype(int)
        dim_lond = np.shape(idx_lon)[0]
    else:
        dim_lond = np.shape(swathInterpData.Descending.lon)[0]
        idx_lon  = np.arange(dim_lond).astype(int)

    if use_echo_window:
        sr = swathInterpData.Descending.slant_range[idx_lat, :]
        sr = sr[:, idx_lon]
        mask_desc = np.logical_and((sr > sr_range[0]),
                                   (sr < sr_range[1]))
        # Consider here blind ranges
        if not (br is None):
            for i_br in range(br.inc_s.shape[0]):
                mask_br = np.logical_and((sr > br.slant_range_s[i_br]),
                                         (sr < br.slant_range_e[i_br]))
                mask_br = np.logical_not(mask_br)
                mask_desc = mask_desc * mask_br
    else:
        inc_angle = swathInterpData.Descending.inc_angle[idx_lat, :]
        inc_angle = inc_angle[:, idx_lon]
        # mask for descending swath
        mask_desc = np.logical_and((inc_angle > incr_angle_range[0]),
                                   (inc_angle < incr_angle_range[1]))
        # Consider here blind ranges
        if not (br is None):
            for i_br in range(br.inc_s.shape[0]):
                mask_br = np.logical_and((inc_angle > np.deg2rad(br.inc_s[i_br])),
                                         (inc_angle < np.deg2rad(br.inc_e[i_br])))
                mask_br = np.logical_not(mask_br)
                mask_desc = mask_desc * mask_br

    lat_desc = swathInterpData.Descending.lat[idx_lat]
    lon_desc = swathInterpData.Descending.lon[idx_lon]

    # Unwrap the longitudes
    lon_desc = np.where(lon_desc > 0, lon_desc, lon_desc + 360)

    # Compute coverage
    if (res_lat is not None):
        dlat = res_lat
    if (res_lon is not None):
        dlon = res_lon

    if (lon_width is None):
        lon_width = 90.

    ncov_lon = int(lon_width/dlon)

    # fix trial
    mask_asc_full = np.zeros((dim_lata, int(360/dlon)), dtype='int16')
    mask_asc_full[:, (lon_asc/dlon).astype(int)] = mask_asc
    mask_desc_full = np.zeros((dim_latd, int(360/dlon)), dtype='int16')
    mask_desc_full[:, (lon_desc/dlon).astype(int)] = mask_desc

    cov_asc = np.zeros((dim_lata, ncov_lon, Norb), dtype='int16')
    cov_desc = np.zeros((dim_latd, ncov_lon, Norb), dtype='int16')

    lon_cov_asc = np.arange(0, ncov_lon, 1, dtype='float32')*dlon
    lon_cov_desc = np.arange(0, ncov_lon, 1, dtype='float32')*dlon
#    lon_cov_desc = lon_cov_asc + (lon_cov_asc[-1] + lon_desc[0] - lon_asc[-1])

    if not silent:
        # for showing some progress
        bar = ProgressBar("Processing", Norb)

    for i_orbit in range(int(Norb)):
        lon_cov_asc_rot = np.mod(lon_cov_asc + delta_lon*i_orbit, 360)
        lon_cov_asc_rot_idx = np.mod((np.rint(lon_cov_asc_rot /
                                      dlon)).astype(int),
                                     360/dlon).astype(int)
        lon_cov_desc_rot = np.mod(lon_cov_desc + delta_lon*i_orbit, 360)
        lon_cov_desc_rot_idx = np.mod((np.rint(lon_cov_desc_rot /
                                      dlon)).astype(int),
                                      360/dlon).astype(int)

        cov_asc[:, :, i_orbit] = mask_asc_full[:, lon_cov_asc_rot_idx]
        cov_desc[:, :, i_orbit] = mask_desc_full[:, lon_cov_desc_rot_idx]

        if not silent:
            bar.update(i_orbit)
    if not silent:
        print()

    cov_asc_tot = np.sum(cov_asc, axis=2)
    cov_desc_tot = np.sum(cov_desc, axis=2)

    Masks = namedtuple('Masks', ['mask_asc', 'mask_desc', 'lat_asc', 'lon_asc',
                                 'lat_desc', 'lon_desc',
                                 'delta_lon', 'cov_asc_tot', 'cov_desc_tot',
                                 'lon_cov_asc', 'lon_cov_desc', 'repeat_cycle',
                                 'dlon'])

    result = Masks(mask_asc, mask_desc, lat_asc, lon_asc, lat_desc, lon_desc,
                   delta_lon, cov_asc_tot, cov_desc_tot, lon_cov_asc,
                   lon_cov_desc, swathInterpData.repeat_cycle, dlon)

    return result


def coverage_add(cov1, cov2):
    Masks = namedtuple('Masks', ['mask_asc', 'mask_desc', 'lat_asc', 'lon_asc',
                                 'lat_desc', 'lon_desc',
                                 'delta_lon', 'cov_asc_tot', 'cov_desc_tot',
                                 'lon_cov_asc', 'lon_cov_desc', 'repeat_cycle'])

    result = Masks(np.logical_and(cov1.mask_asc, cov2.mask_asc),
                   np.logical_and(cov1.mask_desc, cov1.mask_desc),
                   cov1.lat_asc, cov1.lon_asc, cov1.lat_desc, cov1.lon_desc,
                   cov1.delta_lon,
                   cov1.cov_asc_tot + cov2.cov_asc_tot,
                   cov1.cov_desc_tot + cov2.cov_desc_tot,
                   cov1.lon_cov_asc, cov1.lon_cov_desc,
                   cov1.repeat_cycle + cov2.repeat_cycle)
    return result


def coverage_plot(cov, max_cb=None, lat_min=-90, lat_max=90, discrete=True,
                  cov_multiplier=1, savepath=None, continents=True,
                  lon_cent=0, lon_ext=None, projection='cyl',
                  grid_spacing=20, cmapb='jet'):

    """ Plots coverage analysis results (ascending/descending/combined).

        :author: Thomas Boerner

        :param cov: coverage data.
        :type cov: tuple
        :param max_cb: maximum value to be shown in the plot (and color bar).
        :type max_cb: int
        :param lat_min: minimum latitude to be plotted on the map [deg].
        :type lat_min: float
        :param lat_max: maximum latitude to be plotted on the map [deg].
        :type lat_max: float
        :param discrete: flag to trigger discrete color bar (rather than a
                         continuous cb, which is better for yearly results)
                         [True/False].
        :type discrete: boolean
        :param cov_multiplier: scaling factor for results different from one
                               repeat cycle.
        :type cov_multiplier: float
        :param savepath: path to directory where plot shall be saved.
        :type savepath: string
        :param continents: flag to trigger plotting of coastlines
        :type continents: boolean
        :param lon_cent: longitude around which to center the plot [deg]
        :type lon_cent: float
        :param lon_ext: longitudinal extent of the plot [deg]
        :type lon_ext: float
        :param cmapb: Base color map

        :returns: nothing, only plots.

    """
    #General plot settings
    if projection == 'npstere' or projection == 'spstere':
        doeps = False
    else:
        doeps = False
    mpl.rcParams.update({'font.size': 10})
    if (savepath != None):
        if not os.path.exists(savepath):
            os.makedirs(savepath)

    if (max_cb == None):
        max_cb = np.max(cov.cov_asc_tot + cov.cov_desc_tot) + 1
        max_cb = max_cb * cov_multiplier

    max_cb = max_cb + 1
    labels = np.arange(1, int(max_cb/cov_multiplier) + 1, 1)
    labels = labels * cov_multiplier
    loc = labels + .5
    #labels_t = np.array(map(str, labels), dtype='|S10')
    labels_t = list(map(str,labels.tolist()))
    labels_t[-2] = '>= ' + labels_t[-2]

    cmap = plt.get_cmap(cmapb, int((max_cb-1)/cov_multiplier))
    try:
        cmaplist = [cmap(i) for i in range(cmap.N)]
        #cmaplist[0] = (0,0,0,0)
        cmap = cmap.from_list('Custom cmap', cmaplist, cmap.N)
    except:
        print("Manipulating color table not working for %s" % cmapb)
        cmap = cmapb
    # ascending
    fig1 = plt.figure()
    ax1 = fig1.add_axes([0.1, 0.1, 0.8, 0.8])
    x0 = cov.lon_cov_asc[0]
    x1 = cov.lon_cov_asc[-1]
#    xext = x1 - x0
#    x0 = lon_cent - xext/2.
#    x1 = lon_cent + xext/2.

    if (lon_ext is None):
        lon_min = -(180 - lon_cent)
        lon_max =  (180 + lon_cent)
    else:
        lon_min = lon_cent - lon_ext/2
        lon_max = lon_cent + lon_ext/2


    #prepare data plot grid with correct map longitudes [-180°;+180°]
    lon_nowrap_idx = np.where(cov.lon_cov_asc <= 180.)[0]
    lon_wrap_idx   = np.where(cov.lon_cov_asc > 180.)[0]

    lon_nowrap = cov.lon_cov_asc[lon_nowrap_idx]
    lon_wrap   = cov.lon_cov_asc[lon_wrap_idx] - 360.

    lon_nowrap_2d, lat_nowrap_2d = np.meshgrid(lon_nowrap, cov.lat_asc)
    lon_wrap_2d, lat_wrap_2d     = np.meshgrid(lon_wrap, cov.lat_asc)
    imdata_nw = (cov.cov_asc_tot[:, lon_nowrap_idx] * cov_multiplier)
    imdata_nw = np.ma.masked_values(imdata_nw, 0)
    imdata_w = (cov.cov_asc_tot[:, lon_wrap_idx] *  cov_multiplier)
    imdata_w = np.ma.masked_values(imdata_w, 0)

    if projection == 'npstere' or projection == 'spstere':
        boundinglat = lat_min if projection == 'npstere' else lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat, lon_0=lon_cent, resolution='l')
        m.drawcoastlines()
        #m.fillcontinents(color='coral',lake_color='aqua')
        # draw parallels and meridians.
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')
        xs_nowrap, ys_nowrap = m(lon_nowrap_2d, lat_nowrap_2d)
        xs_wrap, ys_wrap = m(lon_wrap_2d, lat_wrap_2d)
        imdata = (cov.cov_asc_tot[:,lon_nowrap_idx] * cov_multiplier)
        imdata = np.ma.masked_values(imdata, 0)
        im1 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                             imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im1 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)

    else:
        m = Basemap(llcrnrlon=lon_min, llcrnrlat=lat_min, urcrnrlon=lon_max,
                    urcrnrlat=lat_max, projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        if (continents == True):
            m.drawmapboundary()
            m.drawcoastlines()
#
        xs_nowrap, ys_nowrap = m(lon_nowrap_2d, lat_nowrap_2d)
        xs_wrap, ys_wrap = m(lon_wrap_2d, lat_wrap_2d)
        imdata = (cov.cov_asc_tot[:,lon_nowrap_idx] * cov_multiplier)
        imdata = np.ma.masked_values(imdata, 0)
        im1 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                            imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im1 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)


    ax1.set_title('Ascending Coverage')
    #cb1 = plt.colorbar(im1, fraction=0.046, pad=0.04)
    cb1 = m.colorbar(im1,"right", size="5%", pad='2%')
    #cb1 = add_colorbar(im1)
    if discrete:
        cb1.set_ticks(loc)
        cb1.set_ticklabels(labels_t)

    if (savepath != None):
            if doeps:
                figpath = os.path.join(savepath, 'covmap_' + projection + '_asc.eps')
                plt.savefig(figpath, bbox_inches='tight', dpi=200)
            figpath = os.path.join(savepath, 'covmap_' + projection + '_asc.png')
            plt.savefig(figpath, bbox_inches='tight', dpi=200)
            plt.close()

    # descending
    fig2 = plt.figure()
    ax2 = fig2.add_axes([0.1,0.1,0.8,0.8])
    imdata_nw = (cov.cov_desc_tot[:, lon_nowrap_idx] * cov_multiplier)
    imdata_nw = np.ma.masked_values(imdata_nw, 0)
    imdata_w = (cov.cov_desc_tot[:, lon_wrap_idx] *  cov_multiplier)
    imdata_w = np.ma.masked_values(imdata_w, 0)
    if projection == 'npstere' or projection == 'spstere':
        boundinglat = lat_min if projection == 'npstere' else lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat,lon_0=lon_cent,resolution='l')
        m.drawcoastlines()
        #m.fillcontinents(color='coral',lake_color='aqua')
        # draw parallels and meridians.
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        im2 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                             imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im2 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)

    else:
        m = Basemap(llcrnrlon=lon_min, llcrnrlat=lat_min, urcrnrlon=lon_max,
                    urcrnrlat=lat_max, projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        if (continents == True):
            m.drawmapboundary()
            m.drawcoastlines()

        im2 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                             imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im2 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)


    cb2 = m.colorbar(im2,"right", size="5%", pad='2%')
    ax2.set_title('Descending Coverage')

    if discrete:
        cb2.set_ticks(loc)
        cb2.set_ticklabels(labels_t)

    if (savepath != None):
            if doeps:
                figpath = os.path.join(savepath, 'covmap_' + projection + '_desc.eps')
                plt.savefig(figpath, bbox_inches='tight', dpi=200)
            figpath = os.path.join(savepath, 'covmap_' + projection + '_desc.png')
            plt.savefig(figpath, bbox_inches='tight', dpi=200)
            plt.close()

    # combined
    imdata_nw = ((cov.cov_asc_tot[:, lon_nowrap_idx] +
                  cov.cov_desc_tot[:, lon_nowrap_idx]) * cov_multiplier)
    imdata_nw = np.ma.masked_values(imdata_nw, 0)
    imdata_w = ((cov.cov_asc_tot[:, lon_wrap_idx] +
                 cov.cov_desc_tot[:, lon_wrap_idx]) *  cov_multiplier)
    imdata_w = np.ma.masked_values(imdata_w, 0)
    fig3 = plt.figure()
    ax3 = fig3.add_axes([0.1,0.1,0.8,0.8])
    if projection == 'npstere' or projection == 'spstere':
        boundinglat = lat_min if projection == 'npstere' else lat_max
        m = Basemap(projection=projection,
                    boundinglat=boundinglat,lon_0=lon_cent,resolution='l')
        m.drawcoastlines()
        #m.fillcontinents(color='coral',lake_color='aqua')
        # draw parallels and meridians.
        m.drawparallels(np.arange(-80.,81.,grid_spacing))
        m.drawmeridians(np.arange(-180.,181.,grid_spacing))
        m.drawmapboundary(fill_color='aqua')

        im3 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                             imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im3 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)

    else:
        m = Basemap(llcrnrlon=lon_min, llcrnrlat=lat_min, urcrnrlon=lon_max,
                    urcrnrlat=lat_max, projection='cyl')
        m.drawparallels(np.arange(-90,90,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        m.drawmeridians(np.arange(-180,180,grid_spacing),labels=[1,0,0,1],
                        fontsize=10)
        if (continents == True):
            m.drawmapboundary()
            m.drawcoastlines()

        im3 = plt.pcolormesh(xs_nowrap, ys_nowrap,
                             imdata_nw, cmap=cmap, vmin=1, vmax=max_cb)
        if (np.shape(lon_wrap_idx)[0] != 0):
            im3 = plt.pcolormesh(xs_wrap, ys_wrap,
                                 imdata_w, cmap=cmap, vmin=1,
                                 vmax=max_cb)


    ax3.set_title('Asc/Dsc Combined Coverage')
    cb3 = m.colorbar(im3,"right", size="5%", pad='2%')
    if discrete:
        cb3.set_ticks(loc)
        cb3.set_ticklabels(labels_t)
    if (savepath != None):
            if doeps:
                figpath = os.path.join(savepath, 'covmap_' + projection + '_comb.eps')
                plt.savefig(figpath, bbox_inches='tight', dpi=200)
            figpath = os.path.join(savepath, 'covmap_' + projection + '_comb.png')
            plt.savefig(figpath, bbox_inches='tight', dpi=200)
            plt.close()

    plt.show()

    return


def coverage_hist(cov, max_cb=None, cov_multiplier=1, lat_hist=0,
                  savepath=None, Normed=True):

    """ Plots histograms of coverage analysis results (ascending/descending/
        combined) at a given latitude.

        :author: Thomas Boerner

        :param cov: coverage data.
        :type swathInterpData: tuple
        :param max_cb: maximum value to be considered for the histogram.
        :type max_cb: int
        :param lat_hist: latitude at which the histogram is calculated [deg].
        :type lat_hist: float
        :param normed: flag to trigger normalized histograms [True/False].
        :type normed: boolean
        :param cov_multiplier: scaling factor for results different from one
                               repeat cycle.
        :type cov_multiplier: float
        :param savepath: path to directory where plot shall be saved.
        :type savepath: string

        :returns: nothing, only plots.

    """
    #General plot settings
    mpl.rcParams.update({'font.size': 12})
    if (savepath != None):
        if not os.path.exists(savepath):
            os.makedirs(savepath)

    if (max_cb == None):
        max_cb = np.max(cov.cov_asc_tot + cov.cov_desc_tot) + 1
        max_cb = max_cb * cov_multiplier

    max_cb = max_cb + 1
    labels = np.arange(0, int(max_cb) + 1, 1)
    loc = labels + .5
    #labels_t = np.array(map(str, labels), dtype='|S10')
    labels_t = list(map(str,labels.tolist()))
    labels_t[-2] = '>= ' + labels_t[-2]

    cmap = plt.get_cmap('jet', max_cb)
    cmaplist = [cmap(i) for i in range(cmap.N)]
    cmaplist[0] = (0,0,0,0)
    cmap = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    #compute index of requested latitude
    idx_lat_hist = np.argmin(np.abs(cov.lat_asc - lat_hist))

    #plot histograms
    fig4 = plt.figure()
    plt.title('Ascending Coverage Histogram @ ' + np.str(lat_hist) +
              ' deg lat')
    plt.xlabel('coverages per year')
    plt.ylabel('Frequency')
    plt.hist(cov.cov_asc_tot[idx_lat_hist,:]*cov_multiplier, bins=labels,
             normed=Normed)
    if (savepath != None):
        figpath = os.path.join(savepath, 'hist_asc.eps')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        figpath = os.path.join(savepath, 'hist_asc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)

    fig5 = plt.figure()
    plt.title('Descending Coverage Histogram @ ' + np.str(lat_hist) +
              ' deg lat')
    plt.xlabel('coverages per year')
    plt.ylabel('Frequency')
    plt.hist(cov.cov_desc_tot[idx_lat_hist,:]*cov_multiplier, bins=labels,
             normed=Normed)
    if (savepath != None):
        figpath = os.path.join(savepath, 'hist_desc.eps')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        figpath = os.path.join(savepath, 'hist_desc.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
    fig6 = plt.figure()
    plt.title('Asc/Dsc Combined Coverage Histogram @ ' + np.str(lat_hist) +
              ' deg lat')
    plt.xlabel('coverages per year')
    plt.ylabel('Frequency')
    plt.hist((cov.cov_asc_tot + cov.cov_desc_tot)[idx_lat_hist, :]
              *cov_multiplier, bins=labels, normed=Normed)
    if (savepath != None):
        figpath = os.path.join(savepath, 'hist_comb.eps')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)
        figpath = os.path.join(savepath, 'hist_comb.png')
        plt.savefig(figpath, bbox_inches='tight', dpi=200)

    plt.show()

    out = plt.hist(cov.cov_asc_tot[idx_lat_hist,:]*cov_multiplier, bins=labels)

    return out


def duty_cycle(orbit, inc_angle_range=None):

    """ Estimates the duty cycle based on ROIs.
        Currently this function only takes into account the global land mass
        as ROI. Future enhancements might also be able to use arbitrary ROI
        masks.

        :author: Thomas Boerner

        :param orbit: orbit data.
        :type orbit: tuple
        :param inc_angle_range: near and far range incidence angle [deg].
        :type inc_angle_range: two-elements array

        :returns: named tuple containing duty cycle and amount of land in acq.

    """

    timevec = orbit.timevec
    lat = orbit.swathData.lat
    lon = orbit.swathData.lon
    Norb = orbit.norb
    Torb = orbit.Torb

    delta_lon = Torb*360./24.
    ntimes = np.size(timevec)

    if (inc_angle_range != None):
        inc = orbit.swathData.incident
        iar = np.deg2rad(inc_angle_range)
        idx = np.where((inc[0,:] > iar[0]) & (inc[0,:] < iar[1]))
        idx = [np.min(idx),np.max(idx)]
        lat = lat[:,idx[0]:idx[1]]
        lon = lon[:,idx[0]:idx[1]]

    swath = np.zeros(np.size(lat,axis=0)*np.size(lat,axis=1), dtype='int16')+1

    # result arrays
    land_yn = np.zeros(ntimes*Norb, dtype='int16')
    land_pc = np.zeros(ntimes*Norb, dtype='float32')

    # for showing some progress
    bar = ProgressBar("Processing", Norb)

    # loop through orbits and apply earth rotation shift
    for i_orbit in range(Norb):

        lon_sh = np.mod(lon - delta_lon*i_orbit, 360) - 180
        lati = np.reshape(lat,np.size(lat,axis=0)*np.size(lat,axis=1))
        loni = np.reshape(lon_sh,np.size(lat,axis=0)*np.size(lat,axis=1))

        masked_swath = maskoceans(loni, lati, swath, inlands=False,
                                  resolution='f', grid=1.25)

        mask = np.reshape(masked_swath.mask,
                          [np.size(lat,axis=0),np.size(lat,axis=1)])
        mask = np.invert(mask)

        for i_time in range(ntimes):
            t_idx = i_orbit*ntimes + i_time
            land_pc[t_idx] = np.mean(mask[i_time,:])
            land_yn[t_idx] = np.int(np.ceil(land_pc[t_idx]))

        bar.update(i_orbit)

    print()

    # calculate results
    duty_cycle = np.sum(land_yn)/(ntimes*Norb)
    land_seen = np.sum(land_pc)/np.sum(land_yn)

    print("Duty cycle [%]: ", duty_cycle*100.)
    print("Land seen when active [%]: ", land_seen*100.)

    duty = namedtuple('duty', ['duty_cycle', 'land_seen'])
    result = duty(duty_cycle, land_seen)

    return result









