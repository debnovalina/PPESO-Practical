
"""
=================================================
Mission Coverage Package (:mod:`drama.coverage`)
=================================================

.. currentmodule:: drama.coverage

Coverage tools
==============

.. autosummary::
   :toctree: generated/

   line_of_sight
   coverage_test
   swath_interpol
   single_swath
   duty_cycle
   coverage_analysis
   coverage_add
   coverage_plot
   coverage_hist
   plot_RGT
   test_look
   plot_cov_RGT
   check_cov
   partial_cov_plot
   single_swath_b
   line_of_sight_bist

Coverage maps and performance
=============================

.. autosummary::
   :toctree: generated/

Coverage interfaces
===================

.. autosummary::
   :toctree: generated/

"""

from .swath_calc import single_swath, coverage_test, swath_interpol, \
                        line_of_sight, orbit_geoc
from .swath_coverage import duty_cycle, coverage_analysis,\
                            coverage_add, coverage_plot, coverage_hist
from .coveragePlotters import plot_RGT, plot_cov_RGT, test_look
from .coverage_check import check_cov, partial_cov_plot
from .system_perf import load_mod_perf
from .bist_tools import single_swath_b, line_of_sight_b
