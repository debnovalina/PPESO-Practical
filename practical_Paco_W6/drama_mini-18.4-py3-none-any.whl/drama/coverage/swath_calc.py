from __future__ import absolute_import, division, print_function
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
from collections import namedtuple
from drama import constants as const
from drama.io import cfg as cfg
from drama.geo.sar import geometry as geom
import scipy.interpolate as interpol
from drama.utils import misc as misc
from drama.orbits import single_orbit as so
import os
# from drama.geo.sar.geometry import g

SwathInterpData = namedtuple('SwathInterpData',
                             ['Ascending', 'Descending',
                              'timevec', 'norb', 'dlat', 'dlon',
                              'Torb', 'Horb', 'repeat_cycle', 'T0'])


#class SwathInterpData(SwathInterpData_):
#    def save(self, dirname, nameroot):
#        fname_asc = os.path.join(dirname, (nameroot))


SingleTrack = namedtuple('SingleTrack',
                         ['lat', 'lon', 'inc_angle', 'northing', 'slant_range',
                          'mask',
                          'time','velocity_x', 'velocity_y', 'velocity_z'])


Swath = namedtuple('Swath', ['lat', 'lon', 'incident', 'Northing',
                             'GP_mask', 'R', 'xyz'])


def line_of_sight(la_deg, r_ecf, v_ecf, squint=0):
    """ Calculates the intersection between line of sight (near and far range)
        with the ellipsoid.

        :author: Thomas Boerner, Paco Lopez-Dekker

        :param la_deg: vector of look angles (deg).
        :type la_deg: float 1-D vector
        :param r_ecf: satellite position in ECF reference frame.
        :type r_ecf: float 2-D array
        :param v_ecf: satellite velocity in ECF reference frame.
        :type v_ecf: float 2-D array

        :returns: named tuple containing latitudes and longitudes for near and
                  far range and versors required for computing LoS.

    """
    # A bit of initialization
    Np = r_ecf.shape[0]
    Nla = la_deg.size
    la = np.radians(la_deg)
    r_x = const.r_equatorial()  # earth equatorial radius [m]
    r_y = const.r_equatorial()   # earth equatorial radius [m]
    r_z = const.r_polar()   # earth radius at pole [m]

    # Calculate velocity and positions versor
    v_ecf_ver = v_ecf/np.linalg.norm(v_ecf, axis=1).reshape((Np, 1))
    r_ecf_ver = r_ecf/np.linalg.norm(r_ecf, axis=1).reshape((Np, 1))

    # Build cross product of versors
    n_ver = np.cross(v_ecf_ver, r_ecf_ver)    # cross product of versors

    # Calculate near and far range line of sight versors
    LoS = geom.create_LoS(r_ecf, v_ecf, la, squint_a=squint)
#    LoS = (-np.cos(la.reshape(1, Nla, 1)) * r_ecf_ver.reshape(Np, 1, 3) +
#           np.sin(la.reshape(1, Nla, 1)) * n_ver.reshape(Np, 1, 3))

    # Calculate near and far range intersection points of line of sight
    # with ellipsoid
    icp = geom.pt_get_intersection_ellipsoid(r_ecf, LoS)
    R = np.linalg.norm(icp - r_ecf.reshape((Np,1,3)), axis=2)
    # Vector normal to the surface
    surf_n = icp/(np.array([r_x**2, r_y**2, r_z**2]).reshape(1, 1, 3))
    surf_n = (surf_n /
              np.linalg.norm(surf_n, axis=2).reshape((Np, Nla, 1)))

    # icp_ver = icp / np.linalg.norm(icp, axis=2).reshape((Np, Nla, 1))
    LoS_local_z = -1 * np.sum(surf_n * LoS, axis=-1)
    z_u = np.array([0, 0, 1])
    local_N_v = (z_u.reshape((1, 1, 3)) -
                 surf_n *
                 np.sum(surf_n*z_u.reshape((1, 1, 3)), 2).reshape((Np, Nla, 1)))
    local_N_v = (local_N_v /
                 np.linalg.norm(local_N_v, axis=2).reshape((Np, Nla, 1)))
    local_E_v = np.cross(local_N_v, surf_n)
    inc_angle = np.arccos(LoS_local_z)
    LoS_local_xy = -LoS - LoS_local_z.reshape(Np, Nla, 1) * surf_n
    LoS_local_xy_N = np.sum(LoS_local_xy * local_N_v, axis=-1)
    LoS_local_xy_E = np.sum(LoS_local_xy * local_E_v, axis=-1)
    LoS_local_N = np.arctan2(LoS_local_xy_E, LoS_local_xy_N)

    # Convert intercept point to lat lon
    lat = np.degrees(np.arctan(icp[:, :, 2]/(np.sqrt(icp[:, :, 0]**2. +
                                                     icp[:, :, 1]**2.))))
    lon = np.degrees(np.arctan2(icp[:, :, 1], icp[:, :, 0]))

    # check for points in the swath that are on the other side of the pole
    goodPoints = np.where(np.sum(r_ecf[:,:2].reshape(Np, 1, 2)*
                         icp[:,:,:2], axis=2) > 0)

    GP_mask = np.zeros((Np, Nla)) + np.nan #or zeros? not sure what interpol does with them.
    GP_mask[goodPoints] = 1
    if Np*Nla - np.sum(GP_mask) > 0.0:
        print('There are points on the other side of the pole(s)')

    # the code below might be needed, so I'll keep it, but inactive:
    # ;;PLD check for points that are on the other side of the pole
    # ;;This is a hack, since it does not handle the case where both interection points are behind the poles (fix is not difficult)
    # ;;I am returning the positions in the vector where I have issues
    # wh_conf_north = where((total(intercept_point_near[0:1,*]*intercept_point_far[0:1,*],1) le 0) and (intercept_point_far[2,*] gt 0),num_conflicts)
    # wh_conf_south = where((total(intercept_point_near[0:1,*]*intercept_point_far[0:1,*],1) le 0) and (intercept_point_far[2,*] lt 0),num_conflicts)

#    Swath = namedtuple('Swath', ['lat', 'lon', 'incident', 'Northing',
#                                 'GP_mask'])
    swath = Swath(lat, lon, inc_angle, LoS_local_N, GP_mask, R, icp)

    return swath


def single_swath(orb_type='sunsync', look='left', ext_source=False,
                 parFile=None, inc_angle=None, squint=0):
    """ Calculates many geometrical variables for one orbit at a user defined
        grid including swathData.

        :author: Jalal Matar

        :param look: left or right
        :param orb_type: sunsync or repeat
        :param ext_source: if True, use external data source
        :param -: All orbit parameters should be in parFile.

        :returns: named tuple containing geometrical outputs and SwathData.

    """
    parFile = misc.get_parFile(parFile)
    inData = cfg.ConfigFile(parFile)

    # Retrieve data for a single orbit
    Single_orbData = so.one_orbit(orb_type, look, ext_source, parFile)
    Horb = Single_orbData.Horb
    r_ecef = Single_orbData.r_ecef
    v_ecef = Single_orbData.v_ecef

    # create look angle vector
    if inc_angle is None:
        la_near = np.rad2deg(geom.inc_to_look(np.deg2rad(inData.sar.near_1),
                                              Horb))
        la_far = np.rad2deg(geom.inc_to_look(np.deg2rad(inData.sar.far_1),
                                             Horb))
    else:
        la_near = np.rad2deg(geom.inc_to_look(np.deg2rad(inc_angle[0]), Horb))
        la_far = np.rad2deg(geom.inc_to_look(np.deg2rad(inc_angle[1]), Horb))
    gr_res = inData.sar.gr_res

    if (look == 'right'):
        la_near = abs(la_near)
        la_far = abs(la_far)
    elif (look == 'left'):
        la_near = -abs(la_near)
        la_far = -abs(la_far)

    # get incident angles from look angles
    inc_near = geom.look_to_inc(np.deg2rad(np.abs(la_near)), Horb)
    inc_far = geom.look_to_inc(np.deg2rad(np.abs(la_far)), Horb)

    # get ground range from incident angles
    groundR_near = geom.inc_to_gr(inc_near, Horb)
    groundR_far = geom.inc_to_gr(inc_far, Horb)
#    print(groundR_far-groundR_near)

    # number of cells along swath width
    n_cells = int(np.absolute(groundR_far - groundR_near)/gr_res)

    # look angle vector [deg]
    la_vector = np.linspace(la_near, la_far, n_cells)

    # Get lat, lon, incident & Northing information
    swathData = line_of_sight(la_vector, r_ecef, v_ecef, squint)

    # Add SwathData to the tuple containing one_orbit parameters
    OrbTrack = namedtuple('OrbTrack', Single_orbData._fields+('swathData', ))
    swathD = namedtuple('swathD', ['swathData'])
    swd = swathD(swathData)
    result = OrbTrack(*(Single_orbData + swd))

    return result

def coverage_test():
    """Just a test function for this module
    """
    N = 100
    pos = np.zeros((N, 3), dtype="float")
    pos[:, 0] = 7e6
    pos[:, 2] = np.arange(N)*7e3
    vel = np.zeros((N, 3))
    vel[:, 2] = 7e3
    vel[:, 1] = 0.5e3
    la = np.arange(10) + 25
    swath = line_of_sight(-la, pos, vel)
    return swath


def swath_interpol(orbit, dlat=0.5, dlon=0.5, maxlat_value=90.,
                   flag_plot=False):
    """ Interpolates some geometrical variables characterizing one orbit
        onto a regular grid.

        :author: Mariantonietta Zonno, Maria Sanjuan-Ferrer

        :param orbit: information from "one_orbit" function.
        :type out: tuple
        :param dlat: latitude step for interpolation [deg].
        :type dlat: float
        :param dlon: longitude step for interpolation [deg].
        :type dlon: float
        :param maxlat_value: maximum (minimum) condiered latitude [deg].
        :type maxlat_value: float

        :returns: tuple containing the latitude and longitude values for the
                  reference grid, the interpolated incidence angle, northing,
                  and a mask of the mapped and not-mapped points for both
                  ascending and descending, and also the time vector for the
                  complete orbit and the number of orbits per repeat cycle.
                  In addition, the time vector is also interpolated to the lat
                  lon grid
    """

    desc_idx = orbit.desc_idx
    asc_idx = orbit.asc_idx
    GP_mask = orbit.swathData.GP_mask
    inc_angle_min = np.min(orbit.swathData.incident)
    inc_angle_max = np.max(orbit.swathData.incident)

    # Ascending
    lat1 = (orbit.swathData.lat*GP_mask)[asc_idx[0]:asc_idx[1] + 1, :]
    lon1 = (orbit.swathData.lon*GP_mask)[asc_idx[0]:asc_idx[1] + 1, :]
    time1 = orbit.timevec[asc_idx[0]:asc_idx[1] + 1]
    v_ecef1 = orbit.v_ecef[asc_idx[0]:asc_idx[1] + 1, :]

    # repeat it
    time1 = np.repeat(time1, lat1.shape[1]).reshape(lat1.shape)

    v_ecef1_x = np.repeat(v_ecef1[:, 0], lat1.shape[1]).reshape(lat1.shape)
    v_ecef1_y = np.repeat(v_ecef1[:, 1], lat1.shape[1]).reshape(lat1.shape)
    v_ecef1_z = np.repeat(v_ecef1[:, 2], lat1.shape[1]).reshape(lat1.shape)

    inc_angle1 = (orbit.swathData.incident*GP_mask)[asc_idx[0]:asc_idx[1]+1, :]
    northing1 = (orbit.swathData.Northing*GP_mask)[asc_idx[0]:asc_idx[1]+1, :]
    slant1 = (orbit.swathData.R*GP_mask)[asc_idx[0]:asc_idx[1]+1, :]

    # set edges of incidence array to zero (prevent interpolation issues)
    inc_angle1[0, :] = 0
    inc_angle1[-1, :] = 0
    inc_angle1[:, 0] = 0
    inc_angle1[:, -1] = 0
    slant1[0, :] = 0
    slant1[-1, :] = 0
    slant1[:, 0] = 0
    slant1[:, -1] = 0
    indx1 = np.where((lat1 > -maxlat_value) & (lat1 < maxlat_value))
    # caveat: this spoils the zero edges if maxlat_value is < 90° !
    lat1_ = lat1[indx1]
    lon1_ = lon1[indx1]
    inc_angle1_ = inc_angle1[indx1]
    northing1_ = northing1[indx1]
    slant1_ = slant1[indx1]
    time1_ = time1[indx1]
    v_ecef1_x_ = v_ecef1_x[indx1]
    v_ecef1_y_ = v_ecef1_y[indx1]
    v_ecef1_z_ = v_ecef1_z[indx1]

    # unwrap longitudes to avoid wrapping issues
    lon1_ = np.degrees(np.unwrap(np.radians(lon1_)))

    lat_min = np.min(orbit.swathData.lat)
    lat_max = np.max(orbit.swathData.lat)
    lon_min = np.min(lon1_)
    lon_max = np.max(lon1_)

    # reshaping for the interpolation
    lat = np.reshape(lat1_, np.prod(np.size(lat1_)))
    lon = np.reshape(lon1_, np.prod(np.size(lon1_)))
    inc_angle = np.reshape(inc_angle1_, np.prod(np.size(inc_angle1_)))
    northing = np.reshape(northing1_, np.prod(np.size(northing1_)))
    slant = np.reshape(slant1_, np.prod(np.size(northing1_)))
    # Regular grid construction
    Nlat = np.int(np.abs(lat_max-lat_min)/dlat)+1
    Nlon = np.int(np.abs(lon_max-lon_min)/dlon)+1
    lat_i = np.linspace(lat_min, lat_max, Nlat)  # regularly spaced lat vector
    lon_i = np.linspace(lon_min, lon_max, Nlon)  # regularly spaced lon vector
    lon_i_asc, lat_i_asc = np.meshgrid(lon_i, lat_i)

    # Interpolation
    inc_angle_i_asc = interpol.griddata((lon, lat), inc_angle,
                                        (lon_i_asc, lat_i_asc),
                                        method='linear',
                                        fill_value=999)
    northing_i_asc = interpol.griddata((lon, lat), northing,
                                       (lon_i_asc, lat_i_asc),
                                       method='linear')
    slant_i_asc = interpol.griddata((lon, lat), slant,
                                    (lon_i_asc, lat_i_asc),
                                    method='linear')
    time_i_asc = interpol.griddata((lon, lat), time1_.flatten(),
                                   (lon_i_asc, lat_i_asc),
                                   method='linear',
                                   fill_value=-999)
    velocity_i_asc_x = interpol.griddata((lon, lat), v_ecef1_x_.flatten(),
                                         (lon_i_asc, lat_i_asc),
                                         method='linear',
                                         fill_value=-999)
    velocity_i_asc_y = interpol.griddata((lon, lat), v_ecef1_y_.flatten(),
                                         (lon_i_asc, lat_i_asc),
                                         method='linear',
                                         fill_value=-999)
    velocity_i_asc_z = interpol.griddata((lon, lat), v_ecef1_z_.flatten(),
                                         (lon_i_asc, lat_i_asc),
                                         method='linear',
                                         fill_value=-999)


    mask_asc = np.logical_and((inc_angle_i_asc > inc_angle_min),
                              (inc_angle_i_asc < inc_angle_max))


    if flag_plot:

        plt.figure()
        v = [0.0, np.size(lat), -180.0, 180.0]
        plt.axis(v)
        plt.plot(lat, label='latitude', color='red')
        plt.plot(lon, label='longitude', color='blue')
        plt.title('Vector of latitudes (red) and longitudes (blue)')
        plt.grid(True)
        plt.show()

        plt.figure()
        plt.imshow(np.rad2deg(inc_angle_i_asc), vmin=inc_angle_min,
                   vmax=inc_angle_max, cmap=plt.cm.jet, origin='lower')
        plt.colorbar()
        plt.title('Incidence angle')
        plt.show()

        plt.figure()
        plt.imshow(np.rad2deg(northing_i_asc), vmin=np.min(northing),
                   vmax=np.max(northing), cmap=plt.cm.jet, origin='lower')
        plt.colorbar()
        plt.title('Northing angle')
        plt.show()

    # Descending
    lat2 = (orbit.swathData.lat*GP_mask)[desc_idx[0]:desc_idx[1]+1, :]
    lon2 = (orbit.swathData.lon*GP_mask)[desc_idx[0]:desc_idx[1]+1, :]
    time2 = orbit.timevec[desc_idx[0]:desc_idx[1] + 1]
    v_ecef2 = orbit.v_ecef[desc_idx[0]:desc_idx[1] + 1]

    # repeat it
    time2 = np.repeat(time2, lat2.shape[1]).reshape(lat2.shape)
    v_ecef2_x = np.repeat(v_ecef2[:, 0], lat2.shape[1]).reshape(lat2.shape)
    v_ecef2_y = np.repeat(v_ecef2[:, 1], lat2.shape[1]).reshape(lat2.shape)
    v_ecef2_z = np.repeat(v_ecef2[:, 2], lat2.shape[1]).reshape(lat2.shape)
    inc_angle2 = (orbit.swathData.incident*GP_mask)[desc_idx[0]:desc_idx[1]+1,
                                                    :]
    northing2 = (orbit.swathData.Northing*GP_mask)[desc_idx[0]:desc_idx[1]+1,
                                                   :]
    slant2 = (orbit.swathData.R*GP_mask)[desc_idx[0]:desc_idx[1]+1, :]
    # set edges of arrays to zero (prevent interpolation issues)
    inc_angle2[0, :] = 0
    inc_angle2[-1, :] = 0
    inc_angle2[:, 0] = 0
    inc_angle2[:, -1] = 0
    slant2[0, :] = 0
    slant2[-1, :] = 0
    slant2[:, 0] = 0
    slant2[:, -1] = 0
    indx2 = np.where((lat2 > -maxlat_value) & (lat2 < maxlat_value))
    # caveat: this spoils the zero edges if maxlat_value is < 90° !
    lat2_ = lat2[indx2]
    lon2_ = lon2[indx2]
    inc_angle2_ = inc_angle2[indx2]
    northing2_ = northing2[indx2]
    slant2_ = slant2[indx2]
    time2_ = time2[indx2]
    v_ecef2_x_ = v_ecef2_x[indx2]
    v_ecef2_y_ = v_ecef2_y[indx2]
    v_ecef2_z_ = v_ecef2_z[indx2]
    # unwrap longitudes to avoid wrapping issues
    lon2_ = np.degrees(np.unwrap(np.radians(lon2_)))

    # lat_min = np.min(lat2_)
    # lat_max = np.max(lat2_)
    lon_min = np.min(lon2_)
    lon_max = np.max(lon2_)

    # reshaping for the interpolation
    lat = np.reshape(lat2_, np.prod(np.size(lat2_)))
    lon = np.reshape(lon2_, np.prod(np.size(lon2_)))
    inc_angle = np.reshape(inc_angle2_, np.prod(np.size(inc_angle2_)))
    northing = np.reshape(northing2_, np.prod(np.size(northing2_)))
    slant = np.reshape(slant2_, np.prod(np.size(northing2_)))

    # Regular grid construction
    Nlat = np.int(np.abs(lat_max-lat_min)/dlat)+1
    Nlon = np.int(np.abs(lon_max-lon_min)/dlon)+1
    lat_i = np.linspace(lat_min, lat_max, Nlat)  # regularly spaced lat vector
    lon_i = np.linspace(lon_min, lon_max, Nlon)  # regularly spaced long vector
    lon_i_desc, lat_i_desc = np.meshgrid(lon_i, lat_i)

    # Interpolation
    inc_angle_i_desc = interpol.griddata((lon, lat), inc_angle,
                                         (lon_i_desc, lat_i_desc),
                                         method='linear',
                                         fill_value=999)
    northing_i_desc = interpol.griddata((lon, lat), northing,
                                        (lon_i_desc, lat_i_desc),
                                        method='linear')
    slant_i_desc = interpol.griddata((lon, lat), slant,
                                     (lon_i_desc, lat_i_desc),
                                     method='linear')
    time_i_desc = interpol.griddata((lon, lat), time2_.flatten(),
                                    (lon_i_desc, lat_i_desc),
                                    method='linear',
                                    fill_value=-999)
    velocity_i_desc_x = interpol.griddata((lon, lat), v_ecef2_x_.flatten(),
                                          (lon_i_desc, lat_i_desc),
                                          method='linear',
                                          fill_value=-999)
    velocity_i_desc_y = interpol.griddata((lon, lat), v_ecef2_y_.flatten(),
                                          (lon_i_desc, lat_i_desc),
                                          method='linear',
                                          fill_value=-999)
    velocity_i_desc_z = interpol.griddata((lon, lat), v_ecef2_z_.flatten(),
                                          (lon_i_desc, lat_i_desc),
                                          method='linear',
                                          fill_value=-999)

    mask_desc = np.logical_and((inc_angle_i_desc > inc_angle_min),
                               (inc_angle_i_desc < inc_angle_max))

    if flag_plot:

        plt.figure()
        v = [0.0, np.size(lat), -180.0, 180.0]
        plt.axis(v)
        plt.plot(lat, label='latitude', color='red')
        plt.plot(lon, label='longitude', color='blue')
        plt.title('Vector of latitudes (red) and longitudes (blue)')
        plt.grid(True)
        plt.show()

        plt.figure()
        plt.imshow(np.rad2deg(inc_angle_i_desc), vmin=inc_angle_min,
                   vmax=inc_angle_max, cmap=plt.cm.jet, origin='lower')
        plt.colorbar()
        plt.title('Incidence angle')
        plt.show()

        plt.figure()
        plt.imshow(np.rad2deg(northing_i_desc), vmin=np.min(northing),
                   vmax=np.max(northing), cmap=plt.cm.jet, origin='lower')
        plt.colorbar()
        plt.title('Northing angle')
        plt.show()

#    SingleTrack = namedtuple('SingleTrack',
#                             ['lat', 'lon', 'inc_angle', 'northing', 'mask',
#                              'time'])
    ascending = SingleTrack(lat_i_asc[:, 0], lon_i_asc[0, :],
                            inc_angle_i_asc,
                            northing_i_asc, slant_i_asc,
                            mask_asc, time_i_asc,
                            velocity_i_asc_x, velocity_i_asc_y,
                            velocity_i_asc_z)

    descending = SingleTrack(lat_i_desc[:, 0], lon_i_desc[0, :],
                             inc_angle_i_desc,
                             northing_i_desc, slant_i_desc,
                             mask_desc, time_i_desc,
                             velocity_i_desc_x, velocity_i_desc_y,
                             velocity_i_desc_z)
    norb = orbit.norb

#    SwathInterpData = namedtuple('SwathInterpData',
#                                 ['Ascending', 'Descending',
#                                  'timevec', 'norb', 'dlat', 'dlon',
#                                  'Torb', 'Horb', 'repeat_cycle', 'T0'])

    swathInterpData = SwathInterpData(ascending, descending, orbit.timevec,
                                      norb, dlat, dlon, orbit.Torb, orbit.Horb,
                                      orbit.repeat_cycle, orbit.T0)

    return swathInterpData


def orbit_geoc(orb_type='sunsync', look='left', ext_source=False,
                 parFile=None, inc_angle=None, dlat=0.5, dlon=0.5,
                 ROI_lat=[-90,+90], ROI_lon=[-180,+180]):
    """ Calculates a single orbit with given parameters and prepares a grid for
        a subsequent backward geocoding routine. This module is strongly based
        on the single_swath function.

        :author: Thomas Boerner

        :param look: left or right
        :type look: string
        :param orb_type: sunsync or repeat
        :type orb_type: string
        :param ext_source: if True, use external data source
        :type ext_source: boolean
        :param parFile: full path to parameter file
        :type parFile: string
        :param inc_angle: 2-element array containing near and far range
                          incidence angles [deg] (replacing those c.f.
                          parameter file)
        :type inc_angle: 2-element float array
        :param dlat: latitude grid spacing [deg].
        :type dlat: float
        :param dlon: longitude grid spacing [deg].
        :type dlon: float
        :param ROI_lat: 2-element array with min/max lat coordinates [deg].
        :type ROI_lat: 2-element float array
        :param ROI_lon: 2-element array with min/max lon coordinates [deg].
        :type ROI_lon: 2-element float array

        :returns: something.

    """
    parFile = misc.get_parFile(parFile)
    inData = cfg.ConfigFile(parFile)

    # Retrieve data for a single orbit
    Single_orbData = so.one_orbit(orb_type, look, ext_source, parFile)
    Horb = Single_orbData.Horb
    r_ecef = Single_orbData.r_ecef
    v_ecef = Single_orbData.v_ecef

    # create look angle vector
    if inc_angle is None:
        la_near = np.degrees(geom.inc_to_look(np.radians(inData.sar.near_1),
                                              Horb))  # [deg]
        la_far = np.degrees(geom.inc_to_look(np.radians(inData.sar.far_1),
                                             Horb))  # [deg]
    else:
        la_near = np.rad2deg(geom.inc_to_look(np.deg2rad(inc_angle[0]), Horb))
        la_far = np.rad2deg(geom.inc_to_look(np.deg2rad(inc_angle[1]), Horb))

    if (look == 'right'):
        la_near = abs(la_near)
        la_far = abs(la_far)
    elif (look == 'left'):
        la_near = -abs(la_near)
        la_far = -abs(la_far)

    # look angle vector [deg]
    la_vector = np.array([la_near, la_far])

    # Get lat, lon, incident & Northing information
    swathData = line_of_sight(la_vector, r_ecef, v_ecef)

    # define desired lat/lon grid
    Nlat = np.int(np.abs(ROI_lat[1] - ROI_lat[0])/dlat) + 1
    Nlon = np.int(np.abs(ROI_lon[1] - ROI_lon[0])/dlon) + 1
    lat_grid = np.linspace(ROI_lat[0], ROI_lat[1], Nlat)
    lon_grid = np.linspace(ROI_lon[0], ROI_lon[1], Nlon)

    # choose grid points within swath polygon
    desc_idx = Single_orbData.desc_idx
    asc_idx = Single_orbData.asc_idx

    lat_asc_n  = swathData.lat[asc_idx[0]:asc_idx[1] + 1, 0]
    lon_asc_n  = swathData.lon[asc_idx[0]:asc_idx[1] + 1, 0]
    lat_asc_f  = swathData.lat[asc_idx[0]:asc_idx[1] + 1, 1]
    lon_asc_f  = swathData.lon[asc_idx[0]:asc_idx[1] + 1, 1]
    time_asc   = Single_orbData.timevec[asc_idx[0]:asc_idx[1] + 1]
    lat_desc_n = swathData.lat[desc_idx[0]:desc_idx[1] + 1, 0]
    lon_desc_n = swathData.lon[desc_idx[0]:desc_idx[1] + 1, 0]
    lat_desc_f = swathData.lat[desc_idx[0]:desc_idx[1] + 1, 1]
    lon_desc_f = swathData.lon[desc_idx[0]:desc_idx[1] + 1, 1]
    time_desc  = Single_orbData.timevec[desc_idx[0]:desc_idx[1] + 1]

    # unwrapping of longitudes
    idx_lan = np.where(np.abs(np.gradient(lon_asc_n)) > 170)[0]
    if np.shape(idx_lan)[0] == 2:
        lon_asc_n_uw = np.concatenate([lon_asc_n[0:idx_lan[0] + 1] + 360,
                                       lon_asc_n[idx_lan[1]:]])
    else:
        lon_asc_n_uw = lon_asc_n
    idx_laf = np.where(np.abs(np.gradient(lon_asc_f)) > 170)[0]
    if np.shape(idx_laf)[0] == 2:
        lon_asc_f_uw = np.concatenate([lon_asc_f[0:idx_laf[0] + 1] + 360,
                                       lon_asc_f[idx_laf[1]:]])
    else:
        lon_asc_f_uw = lon_asc_f
    idx_ldn = np.where(np.abs(np.gradient(lon_desc_n)) > 170)[0]
    if np.shape(idx_ldn)[0] == 2:
        lon_desc_n_uw = np.concatenate([lon_desc_n[0:idx_ldn[0]+ 1] + 360,
                                        lon_desc_n[idx_ldn[1]:]])
    else:
        lon_desc_n_uw = lon_desc_n
    idx_ldf = np.where(np.abs(np.gradient(lon_desc_f)) > 170)[0]
    if np.shape(idx_ldf)[0] == 2:
        lon_desc_f_uw = np.concatenate([lon_desc_f[0:idx_ldf[0] + 1] + 360,
                                        lon_desc_f[idx_ldf[1]:]])
    else:
        lon_desc_f_uw = lon_desc_f


    polygon_asc = np.concatenate([np.array([lon_asc_n_uw,lat_asc_n]).T,
                                  np.array([lon_asc_f_uw[::-1],
                                            lat_asc_f[::-1]]).T])

    polygon_asc[:,0] = (polygon_asc[:,0] + 180)/dlon
    polygon_asc[:,1] = (polygon_asc[:,1] + 90)/dlat
    polygon_asc = polygon_asc.flatten().tolist()

    polygon_desc = np.concatenate([np.array([lon_desc_n_uw,lat_desc_n]).T,
                                   np.array([lon_desc_f_uw[::-1],
                                             lat_desc_f[::-1]]).T])

    polygon_desc[:,0] = (polygon_desc[:,0])/dlon
    polygon_desc[:,1] = (polygon_desc[:,1] + 90)/dlat
    polygon_desc = polygon_desc.flatten().tolist()

    img = Image.new('L', (Nlon, Nlat), 0)
    ImageDraw.Draw(img).polygon(polygon_asc, outline=1, fill=1)
    mask_asc = np.array(img)
    plt.figure()
    plt.imshow(mask_asc,origin='lower')
    plt.colorbar()
    plt.show()

    img = Image.new('L', (Nlon, Nlat), 0)
    ImageDraw.Draw(img).polygon(polygon_desc, outline=1, fill=1)
    mask_desc = np.array(img)
    plt.figure()
    plt.imshow(mask_desc,origin='lower')
    plt.colorbar()
    plt.show()



    # Add SwathData to the tuple containing one_orbit parameters
    #OrbTrack = namedtuple('OrbTrack', Single_orbData._fields+('swathData', ))
    #swathD = namedtuple('swathD', ['swathData'])
    #swd = swathD(swathData)
    #result = OrbTrack(*(Single_orbData + swd))





    return lon_desc_n, lon_desc_n_uw