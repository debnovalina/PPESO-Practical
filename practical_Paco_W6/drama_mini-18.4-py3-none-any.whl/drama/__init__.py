"""
====================================
TRAMPA Documentation (:mod:`drama`)
====================================

.. currentmodule:: trampa

DRAMA: **D**\elft **RA**\dar **M**\odeling and **P**\erformance **A**\ nalysis

Misc
====

.. autosummary::
   :toctree: generated/

Subpackages
===========

.. toctree::
   :maxdepth: 1

   drama.bistatic_coverage
   drama.compat
   drama.coverage
   drama.geo
   drama.io
   drama.performance
   drama.utils
   drama.constants
   drama.orbits
   drama.mission

"""

#__all__ = ['io', 'performance', 'geo']
