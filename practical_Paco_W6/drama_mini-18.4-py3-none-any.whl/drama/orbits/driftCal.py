import numpy as np
from drama import constants as const


def nodal_regression(e, a, i, accuracy='j4'):
    """ Calculate the nodal regression for certain orbit parameters

    :author: Jalal Matar

    :date: 19.01.2015

    :param e: eccentricity
    :param a: semi-major axis [m]
    :param i: orbit inclination [deg]
    :param accuracy: j2 or j4

    :returns: nodal regression [rad/s]
    """
    # define constants
    r_earth = const.r_earth
    GM_earth = const.gm_earth
    j2 = const.j2
    j4 = const.j4

    i_rad = np.deg2rad(i)
    n = np.sqrt(GM_earth/(a**3))  # mean motion
    p = a*(1-e**2)  # semi-latus rectum

    if accuracy == 'j2':
        asc_node_dot = -3*n*(r_earth**2)*j2*np.cos(i_rad)/(2*p**2)

    elif accuracy == 'j4':
        t1 = -3*n*(r_earth**2)*j2*np.cos(i_rad)/(2*p**2)

        t2 = ((3*n*(r_earth**4)*(j2**2)*np.cos(i_rad)/(32.*p**4)) *
              (12 - 4*e**2 - (80 + 5*e**2)*(np.sin(i_rad)**2)))

        t3 = ((15*n*(r_earth**4)*j4*np.cos(i_rad)/(32.*p**4)) *
              (8 + 12*e**2 - (14 + 21*e**2)*(np.sin(i_rad)**2)))
        asc_node_dot = t1 + t2 + t3
    return asc_node_dot


def omega_per_dot(e, a, i, accuracy='j4'):
    """  Calculates argument of perigee drift

    :date: 27.01.2015

    :author: Jalal Matar

    :param e: eccentricity
    :param a: semi-major axis [m]
    :param i: orbit inclination [deg]
    :param accuracy: j2 or j4

    :returns: drift of argument of perigee [rad/s]
    """
    GM_earth = const.gm_earth
    r_earth = const.r_earth
    j2 = const.j2
    j4 = const.j4

    i_rad = np.deg2rad(i)
    n = np.sqrt(GM_earth/(a**3))  # mean motion
    p = a*(1-e**2)  # semi-latus rectum

    if accuracy == 'j2':
        omega_per_dot = ((3.0/4)*n*j2*((r_earth/p)**2) *
                         (4.0 - 5.0*(np.sin(i_rad))**2))

    elif accuracy == 'j4':
        t1 = ((3.0/4)*n*j2*((r_earth/p)**2) *
              (4.0 - 5.0*(np.sin(i_rad))**2))

        t2 = ((9.0/384)*n*(j2**2)*((r_earth/p)**4) *
              (56.0*e**2 + (760.0 - 36.0*e**2)*((np.sin(i_rad))**2) -
               (890.0 + 45.0*e**2)*((np.sin(i_rad))**4)))

        t3 = ((-15.0/128)*n*j4*((r_earth/p)**4) *
              (64.0 + 72.0*e**2 - (248.0 + 252.0*e**2)*((np.sin(i_rad))**2) +
               (196.0 + 189.0*e**2)*((np.sin(i_rad))**4)))

        omega_per_dot = t1 + t2 + t3

    return omega_per_dot
