import numpy as np
import drama.constants as const
import drama.utils.matrix_manipulate as mm


def coord_transform(coord_vec, reci, veci, time_vec=None):
    """ Transform coordinates from space relative (r,t,n) system to local
        tangent one

        :date: 02.03.2015

        :author: Jalal Matar

        :param coord_vec: coordinates to be transformed [3xN]
        :param reci: coordinate system center in ECI frame [3xN]
        :param veci: coordinate system velocity in ECI frame [3xN]
        :param time_vec: time instant of point in orbit [3xN]

        :return: coordinates in local tangent frame
    """
    ome_earth = const.omega_earth
    recf = np.zeros(reci.shape, dtype='float')
    vecf = np.zeros(veci.shape, dtype='float')
    coord_ECI = np.zeros(coord_vec.shape, dtype='float')
    coord_ECEF = np.zeros(coord_vec.shape, dtype='float')
    coord_lt = np.zeros(coord_vec.shape, dtype='float')

    if time_vec is None:
        time_vec = np.ones(coord_vec.shape[1], dtype=float)

    for k in range(0l, reci.shape[1]):

        # position in ECEF
        recf[:, k] = mm.rot_z(reci[:, k], np.rad2deg(ome_earth*time_vec[k]))

        # velocity in ECEF
        vecf[:, k] = (mm.rot_z(veci[:, k], np.rad2deg(ome_earth*time_vec[k])) +
                      (ome_earth *
                       mm.rot_z_prime(reci[:, k],
                                      np.rad2deg(ome_earth*time_vec[k]))))

        # space relative to ECI transformation matrix
        t1 = reci[:, k]/np.sqrt(reci[:, k].dot(reci[:, k]))
        t2 = veci[:, k]/np.sqrt(veci[:, k].dot(veci[:, k]))
        t3 = np.cross(t1, t2)

        T_mat = np.concatenate(([t1], [t2], [t3])).T

        coord_ECI[:, k] = np.dot(T_mat, coord_vec[:, k])
        coord_ECEF[:, k] = mm.rot_z(coord_ECI[:, k],
                                    np.rad2deg(ome_earth*time_vec[k]))

        # ECEF to space relative transformation matrix
        e1 = reci[:, k]/np.sqrt(reci[:, k].dot(recf[:, k]))
        e2 = veci[:, k]/np.sqrt(veci[:, k].dot(vecf[:, k]))
        e3 = np.cross(e1, e2)

        E = np.concatenate(([e1], [e2], [e3]))

        coord_lt[:, k] = np.dot(E, coord_ECEF[:, k])

    return coord_lt
