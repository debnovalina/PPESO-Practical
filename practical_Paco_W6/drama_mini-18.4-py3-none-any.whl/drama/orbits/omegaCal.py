import numpy as np
from drama import constants as const


def omega_dot(i, e, a, acc='j4'):
    """ Calculates nodal drift per day up to order of j2 and j4

        :date: 20.10.2014

        :author: Jalal Matar

        :param i: inclination [deg]
        :param e: eccentricity
        :param a: semi-major axis [m]
        :param acc: accuracy (j2 or j4), if omitted defaults to 'j4'

        :returns: nodal drift [deg/day]

    """

    gm_earth = const.gm_earth
    r_earth = const.r_earth
    j2 = const.j2
    j4 = const.j4

    n = np.sqrt(gm_earth/(a**3))  # mean motion
    p = a*(1.0 - e**2)  # semi-latus rectum
    i_rad = np.deg2rad(i)

    cosi = np.cos(i_rad)

    k1 = -(3.0/2) * n * j2 * ((r_earth**2)/p**2) * cosi
    k2 = (3.0 / 32) * n * (r_earth / p)**4 * cosi
    e2 = 1.0 - e**2
    e1 = np.sqrt(e2)

    k3 = (j2**2)*(-5.0 + 12*e1 + 9.0*e2 - (35.0 + 36.0*e1 + 5.0*e2*(cosi**2)))
    - 5.0*j4*(5.0 - 3.0*e2)*(3.0 - 7.0*(cosi**2))

    if(acc == 'j2'):
        omega_dot_tmp = k1
    else:
        omega_dot_tmp = k1 + k2*k3

    omega_dot_tmp = omega_dot_tmp*86400.0

    # convert to degrees  [deg/86400s]
    omega_dot_tmp = np.rad2deg(omega_dot_tmp)

    return omega_dot_tmp


def omega_perigee_dot(i, e, a):
    """  Calculates argument of perigee drift per day

        :date: 20.10.2014

        :author: Jalal Matar

        :param i: inclination [deg]
        :param e: eccentricity
        :param a: semi-major axis [m]

        :returns: drift of argument of perigee [deg/day]
    """

    gm_earth = const.gm_earth
    r_earth = const.r_earth
    j2 = const.j2

    n = np.sqrt(gm_earth/(a**3))  # mean motion
    i_rad = np.deg2rad(i)

    omega_per_dot = (3.0/4)*n*j2*(r_earth**2)/(a**2)*(4.0-5.0*(np.sin(i_rad))**2)/((1-e**2)**2)

    omega_per_dot = omega_per_dot*86400.0
    omega_per_dot = np.rad2deg(omega_per_dot)  # convert to degrees[deg/86400s]

    return omega_per_dot
