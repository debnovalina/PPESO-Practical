import numpy as np
from drama import constants as const
from drama.io import cfg
import dateutil.parser
import os
from drama.orbits import sunsync_orbit as sso
from drama.orbits import repeat_design as rd
from drama.orbits import calc_orbit as clco
from drama.orbits import rw_XML as rwXML
from drama.utils import misc as misc
from collections import namedtuple

OrbitData = namedtuple('OrbitData', ['timevec', 'timestep', 'T0',
                                     'desc_idx', 'asc_idx', 'norb',
                                     'r_ecef', 'v_ecef', 'Torb', 'Horb',
                                     'repeat_cycle', 'aei'])

def one_orbit(orb_type='sunsync', look='left', ext_source=False, parFile=None,
              parTuple=None, companion_delay=None, aei=None, dao=0):
    """ Calculates many geometrical variables for one orbit at a user defined
        grid as basic input for all subsequent coverage analysis.

        :author: Jalal Matar

        :param look: left or right
        :param orb_type: sunsync or repeat
        :param ext_source: if True, use external data source
        :param -: All orbit parameters should be in parFile.
        :param companion_delay: if not None, it returns the positions of a
                                hypothetical companion S/C on the same orbit,
                                but with the given delay (in seconds)
        :param aei: tuple with semi-major axis, eccentricity, and inclination
        :param dao: horizontal offset at equator due to ascending node offset,
                    only applica

        :returns: named tuple containing geometrical outputs.

    """
    if parTuple is None:
        # Open parameter file to derive user inputs
        parFile = misc.get_parFile(parFile)
        # Retrieve input parameters from file
        inData = cfg.ConfigFile(parFile)
    else:
        inData = parTuple

    # define constants
    T_sidereal = 86164.09053  # [sec]

    dDays = inData.orbit.days_cycle
    nRevs = inData.orbit.orbits_nbr
    # Add Multi use Functionality
    ######################################################################
    if type(aei) is tuple:
        (a, e, i) = aei
        if orb_type == 'sunsync':
            # Generate parameters for sunsync orbit
            Torb = 24.*dDays/nRevs  # orbital period [hrs]
        elif orb_type == 'repeat':
            Tao = float(dDays)/nRevs
            Torb = (T_sidereal/3600.)*Tao
    elif orb_type == 'sunsync':
        # Generate parameters for sunsync orbit
        Torb = 24.*dDays/nRevs  # orbital period [hrs]
        (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs)

    elif orb_type == 'repeat':
        # Aquire repeat specific orbit params
        i = inData.orbit.inc
        e = inData.orbit.ecc
        Tao = float(dDays)/nRevs
        Torb = (T_sidereal/3600.)*Tao  # orbital period [hrs]

        # Generate parameters for repeat orbit
        repeat_orb = rd.all_repeat_orbs(i, e, dDays, dDays, doPlot=0)
        repeat_nRd = repeat_orb[repeat_orb[:, 1] == nRevs, :]
        a = repeat_nRd[0, 2]
    ######################################################################
    if (not ext_source):
        omega = inData.orbit.omega_p
        timestep = inData.orbit.timestep  # [s]
        starttime = inData.orbit.starttime
        asc_node = inData.orbit.asc_node
        # Invent an arbitrary time stamp
        # FIXME
        T0 = dateutil.parser.parse('2014-12-05T07:57:25.000000Z')


        # Continue Normally

        Horb = a - const.r_earth

        # Calculate period of one orbit
        n0 = np.sqrt(const.gm_earth/(a**3))  # mean motion
        orbit_period = 2*np.pi/n0  # orbital period [s]
        orbit_period = orbit_period/86400  # orbital period [days]
        timeduration = orbit_period + starttime/86400.  # [days]

        # Get ECF velocity and position arrays from calc_orbit
        orbitData = clco.calc_orb_gen(e, a, i, omega, asc_node, timeduration,
                                      timestep, starttime, noinfo=True,
                                      omega_per_dot=0)
        if (not (companion_delay is None)) or (dao != 0):
            do_companion = True
            asc_node_c = (asc_node - companion_delay * 360 / 86400 +
                          np.degrees(dao/a * 2 * np.pi))
        else:
            do_companion = False



        # separate data into ascending and descending nodes
        v_indices = misc.asc_desc(orbitData.vecf)
        asc_idx = v_indices.asc_idx
        desc_idx = v_indices.desc_idx

        # search for continuous indices ranges
        if asc_idx.shape[0] < desc_idx.shape[1]:  # desc-asc-desc
            timeduration = (orbit_period + starttime/86400. +
                            ((asc_idx[0, 1]+1)*timestep/86400))
            orbitData = clco.calc_orb_gen(e, a, i, omega, asc_node,
                                          timeduration, timestep, starttime,
                                          noinfo=True,
                                          omega_per_dot=0)
            v_indices2 = misc.asc_desc(orbitData.vecf)
            asc_idx2 = v_indices2.asc_idx
            desc_idx2 = v_indices2.desc_idx
            timevec_new = orbitData.timevec[desc_idx2[1, 0]:asc_idx2[1, 1]]
            if do_companion:
                orbitData = clco.calc_orb_gen(e, a, i, omega,
                                              asc_node_c,
                                              timeduration,
                                              timestep,
                                              starttime - companion_delay,
                                              noinfo=True,
                                              omega_per_dot=0)
            # select the organized range of data for one period
            v_ecf_new = orbitData.vecf[desc_idx2[1, 0]:asc_idx2[1, 1], :]
            r_ecf_new = orbitData.recf[desc_idx2[1, 0]:asc_idx2[1, 1], :]


            # for output purposes
            desc_idx_new = desc_idx2[1, :] - desc_idx2[1, 0]
            asc_idx_new = asc_idx2[1, :] - desc_idx2[1, 0]

        elif asc_idx.shape[0] > desc_idx.shape[1]:  # asc-desc-asc
            timeduration = (orbit_period + starttime/86400. +
                            ((desc_idx[0, 0]+1)*timestep/86400))
            orbitData = clco.calc_orb_gen(e, a, i, omega, asc_node,
                                          timeduration, timestep, starttime,
                                          noinfo=True,
                                          omega_per_dot=0)
            v_indices2 = misc.asc_desc(orbitData.vecf)
            asc_idx2 = v_indices2.asc_idx
            timevec_new = orbitData.timevec[desc_idx[0, 0]:asc_idx2[1, 1]]
            if do_companion:
                orbitData = clco.calc_orb_gen(e, a, i, omega,
                                              asc_node_c,
                                              timeduration,
                                              timestep,
                                              starttime - companion_delay,
                                              noinfo=True,
                                              omega_per_dot=0)
            # select the organized range of data for one period
            v_ecf_new = orbitData.vecf[desc_idx[0, 0]:asc_idx2[1, 1], :]
            r_ecf_new = orbitData.recf[desc_idx[0, 0]:asc_idx2[1, 1], :]


            desc_idx_new = desc_idx[0, :] - desc_idx[0, 0]  # for output purp.
            asc_idx_new = asc_idx2[1, :] - desc_idx[0, 0]  # for output purp.

        else:
            timevec_new = orbitData.timevec
            if do_companion:
                orbitData = clco.calc_orb_gen(e, a, i, omega,
                                              asc_node_c,
                                              timeduration,
                                              timestep,
                                              starttime - companion_delay,
                                              noinfo=True,
                                              omega_per_dot=0)
            v_ecf_new = orbitData.vecf
            r_ecf_new = orbitData.recf
            desc_idx_new = desc_idx
            asc_idx_new = asc_idx


##############################################################################
    # ################## external sunsync data source ###################### #
    else:
        # Read data from XML file
        xmlFilePath = os.path.dirname(parFile)
        xmlFile = os.path.join(xmlFilePath, inData.orbit.xmlFileName)
        [oHInfo, stateVecInfo] = rwXML.read_XMLorbit(xmlFile)

        # Retrieve output variables
        Torb = 24.*dDays/nRevs  # orbital period [hrs]
        (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs)
        Horb = a - const.r_earth

        # Create velocity vector [vecf]
        Xvel = np.array(stateVecInfo.velX)
        Yvel = np.array(stateVecInfo.velY)
        Zvel = np.array(stateVecInfo.velZ)
        vecf = np.vstack((Xvel, Yvel, Zvel)).T

        # Create poition vector [recf]
        Xpos = np.array(stateVecInfo.posX)
        Ypos = np.array(stateVecInfo.posY)
        Zpos = np.array(stateVecInfo.posZ)
        recf = np.vstack((Xpos, Ypos, Zpos)).T

        # Create time vector [timevec]
        timevec = np.array(stateVecInfo.timeGPS)

        # separate data into ascending and descending nodes
        v_indices = misc.asc_desc(vecf)
        asc_idx = v_indices.asc_idx
        desc_idx = v_indices.desc_idx

        diff = desc_idx[0, 1] - desc_idx[0, 0]
        for idx in range(1, len(desc_idx)):
            diff2 = desc_idx[idx, 1] - desc_idx[idx, 0]
            if diff2 == diff:
                desc_idx2 = desc_idx[idx-1, :]
                asc_idx2 = asc_idx[asc_idx[:, 0] == (desc_idx2[1] + 1), :]
                asc_idx2 = asc_idx2[0, :]
                break
            diff = diff2

        # select data of one_orbit
        v_ecf_new = vecf[desc_idx2[0]:asc_idx2[1], :]
        r_ecf_new = recf[desc_idx2[0]:asc_idx2[1], :]
        timevec_new = timevec[desc_idx2[0]:asc_idx2[1]]
        desc_idx_new = desc_idx2 - desc_idx2[0]  # for output purposes
        asc_idx_new = asc_idx2 - desc_idx2[0]  # for output purposes
        # Absolute time stamp of first sample
        T0 = stateVecInfo.timeUTC[int(desc_idx2[0])]
###############################################################################


    # make timevec_new start at 0
    timevec_new = timevec_new - timevec_new[0]
    result = OrbitData(timevec_new, timestep, T0, desc_idx_new, asc_idx_new,
                       nRevs, r_ecf_new, v_ecf_new, Torb, Horb, dDays,
                       (a, e, i))

    return result


def par_calc(K, Horb_approx, orb_type='sunsync', look='left', timeduration=12,
             timestep=1., starttime=3., i=98., e=0., omega=90,
             asc_node=359.145, look_ang=[20, 45], gr_res=1000):
    """ Calculate orbital parameters for certain repeat days and approximate
        orbital height

        :date: 14.07.2015

        :author: Jalal Matar

        :param K: number of cycles (days) for repeat  [d]
        :param Horb_approx: approximate orbital height required
        :param orb_type: sunsync or repeat
        :param look: left or right
        :param timeduration: duration of orbit [days]
        :param timestep: step size of sampling
        :param starttime: time (starting at perigee)
        :param i: inclination [deg] (ignored in case of sunsync orbit)
        :param omega: argument of perigee
        :param asc_node: right ascension of the ascending node [deg]
        :param look_ang: range of sar look angles [deg]
        :param gr_res: sar ground resolution [m]

        :returns: tuple containing all parameters
    """

    orbs_K = rd.all_repeat_orbs(i, e, min_cycle=K, max_cycle=K, doPlot=0)
    loc = np.where(abs(orbs_K[:, 2] - Horb_approx - const.r_earth) ==
                   np.min(abs(orbs_K[:, 2] -
                          Horb_approx - const.r_earth)))[0][0]
    orb = orbs_K[loc, :]
    N = orb[1]  # Number of revolutions per repeat cycle

    if orb_type == 'sunsync':
        [a, e, i] = sso.get_sunsync_repeat_orbit(K, N)
    elif orb_type == 'repeat':
        a = orb[3]

    Horb = a - const.r_earth

    Orbit = namedtuple('Orbit', ['Horb', 'days_cycle', 'orbits_nbr',
                                 'omega_p', 'asc_node', 'starttime',
                                 'timeduration', 'timestep', 'inc', 'ecc'])

    orbit = Orbit(Horb, K, N, omega, asc_node, starttime, timeduration,
                  timestep, i, e)

    SAR = namedtuple('SAR', ['near_1', 'far_1', 'gr_res'])

    sar = SAR(look_ang[0], look_ang[1], gr_res)

    ParTuple = namedtuple('ParTuple', ['orbit', 'sar'])
    result = ParTuple(orbit, sar)

    return result
