"""
=====================================
Orbits Package (:mod:`trampa.orbits`)
=====================================

.. currentmodule:: trampa.orbits

Orbits
======

.. autosummary::
    :toctree: generated/

    get_frozen_ecc
    get_sunsync_inclination
    get_sunsync_orbit
    get_sunsync_repeat_orbit
    omega_dot
    omega_perigee_dot
    calc_orb_gen
    one_orbit
    basic_orbit_param
    nodal_regression
    omega_per_dot
    repeat_ERO
    repeat_SRG
    repeat_EROr
    all_repeat_orbs
    Tao_ERO
    alt_inc_sunsync
    read_XMLorbit
    write_XMLorbit
    par_calc
    write_SV
    rv_to_elem

"""
from .driftCal import nodal_regression, omega_per_dot
from .eccentricityCal import get_frozen_ecc
from .sunsync_orbit import get_sunsync_repeat_orbit, get_sunsync_orbit,\
                           get_sunsync_inclination, alt_inc_sunsync
#from .omegaCal import omega_dot, omega_perigee_dot
from .calc_orbit import calc_orb_gen
from .repeat_design import repeat_SRG, repeat_ERO, repeat_EROr,\
                           all_repeat_orbs, Tao_ERO, basic_orbit_param
from .rw_XML import write_XMLorbit, read_XMLorbit, write_SV
from .single_orbit import one_orbit, par_calc
from .kep_elements import rv_to_elem
# from formation import ClohessyWiltshire, FormationTimeline