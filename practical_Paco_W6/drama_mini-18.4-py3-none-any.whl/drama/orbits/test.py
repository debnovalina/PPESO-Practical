import drama.orbits.formation as fo
from drama.coverage import tools as tl
import drama.constants as const
import numpy as np
import coord_trans as ct
import drama.utils.matrix_manipulate as mm


omega_earth = const.omega_earth

one_or = tl.one_orbit()
data_in = fo.ClohessyWiltshire(7118602.15795, 98.4, 400, 0.02)

r_ecef = one_or.r_ecef.T
v_ecef = one_or.v_ecef.T
timevec = one_or.timevec.T

reci = np.zeros(r_ecef.shape, dtype='float')
veci = np.zeros(v_ecef.shape, dtype='float')

for k in range(0l, r_ecef.shape[1]):

    # position in ECI
    reci[:, k] = mm.rot_z(r_ecef[:, k], np.rad2deg(omega_earth*timevec[k]),
                          inverse_transform=True)

    # velocity in ECI
    veci[:, k] = (mm.rot_z(v_ecef[:, k], np.rad2deg(omega_earth*timevec[k]),
                           inverse_transform=True) +
                  (omega_earth *
                   mm.rot_z_prime(r_ecef[:, k],
                                  np.rad2deg(omega_earth * timevec[k]),
                                  inverse_transform=True)))

coord_vec = np.concatenate(([data_in.dr_r], [data_in.dr_t], [data_in.dr_n]))

coord_new = ct.coord_transform(coord_vec, reci, veci)
