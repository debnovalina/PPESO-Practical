from __future__ import absolute_import, division, print_function
import numpy as np
import lxml.etree as ET
from collections import namedtuple
from dateutil import parser
import datetime
from drama.io import cfg as cfg
from drama.utils import misc as misc
from drama.orbits import calc_orbit as cco
from drama.orbits import sunsync_orbit as sso
from drama.orbits import repeat_design as rd
from astropy.time import Time
import os
from drama.orbits import kep_elements as kp
from drama.geo.sar import geometry as geo


def read_XMLorbit(filename=None):
    """ Function to read the orbit information provided by HR-STL (XML file)
        and returns such information as a tuple.

        :param fileName: Name of the file. Default=None.
        :type fileName: string

        :returns: two named-tuples - the first one with general information
                  about the orbit, numer of orbits in a cycle, nominal start
                  and end times, state vector time spacing, etc; the second one
                  contains all the state vectors with time, (x,y,z) positions
                  and (x,y,z) velocities.

    """

    # Open parameter file to derive user inputs
    filename = misc.get_parFile(filename)

    tree = ET.parse(filename)
    root = tree.getroot()

    # -------------------------------------------------------------------------
    # orbitHeader is root[1]
    #
    # orbitHeader: general information about the reference orbit, as reference
    # frame and time, nominal start and end times, ...
    #
    # The information is extracted in lists which are collected together in a
    # named tuple
    # -------------------------------------------------------------------------
    orbitHeader = root[1]

    for field in orbitHeader[0:]:
        if field.tag == 'product':
            for subfield in field:
                if subfield.tag == 'sensor':
                    # 'PROP' for predicted (propagated) orbit
                    # 'GPSS' for single GPS
                    # 'GPSD' for differential GPS
                    sensor = subfield.text
                if subfield.tag == 'type':
                    typee = subfield.text
                if subfield.tag == 'accuracy':
                    # 'REFE' for reference
                    # 'REFC' for reference complementary
                    # 'PRED' for predicted
                    # 'QUKL' for quicklook
                    # 'RAPD' for rapid
                    # 'SCIE' for science
                    # 'COPR' for Complementary predicted (for TanDEM-X mission)
                    accuracy = subfield.text
                if subfield.tag == 'qualityInspection':
                    # 'AUTO_APPROVED' to indicate automatic product generation
                    # and quality check
                    qualityInspection = subfield.text
        if field.tag == 'orbit':
            for subfield in field:
                if subfield.tag == 'orbitPhase':
                    # -1 for prelaunch phase
                    # 0 for LEOP
                    # 1 for nominal Orbit
                    # ... each phase means an new reference orbit
                    orbitPhase = int(subfield.text)
                if subfield.tag == 'orbitCycle':
                    # cycle number for first state vector in file
                    orbitCycle = int(subfield.text)
                if subfield.tag == 'absOrbit':
                    # absolute orbit number for first state vector in file
                    # -1 for reference orbit
                    absOrbit = int(subfield.text)
                if subfield.tag == 'relOrbit':
                    # relative orbit number for first state vector in file
                    relOrbit = int(subfield.text)
                if subfield.tag == 'numOrbitsInCycle':
                    # nominal number of orbits per cycle, which depends on phase
                    # 167 for TanDEM-X (currently)
                    numOrbitsInCycle = int(subfield.text)
        if field.tag == 'stateVectorRefFrame':
            # state vector reference frame indicator, e.g. WGS84
            stateVectorRefFrame = field.text
        if field.tag == 'stateVectorRefTime':
            # state vector reference time indicator, e.g. GPS
            stateVectorRefTime = field.text
        if field.tag == 'nominalStartTimeUTC':
            # nominal start time of orbit product
            # for quicklook, first statevector time
            nominalStartTimeUTC = field.text
        if field.tag == 'nominalStopTimeUTC':
            # nominal stop time of orbit product
            # for quicklook, last statevector time
            nominalStopTimeUTC = field.text
        if field.tag == 'numStateVectors':
            # total number of state vectors
            numStateVectors = int(field.text)
        if field.tag == 'firstStateTime':
            for subfield in field:
                if subfield.tag == 'firstStateTimeUTC':
                    # UTC time of first state vector
                    firstStateTimeUTC = subfield.text
                if subfield.tag == 'firstStateTimeGPS':
                    # GPS time of first state vector (integer second counter)
                    firstStateTimeGPS = int(subfield.text)
                if subfield.tag == 'firstStateTimeGPSFraction':
                    # fraction GPS time of first state vector as fraction of second
                    firstStateTimeGPSFraction = float(subfield.text)
                if subfield.tag == 'firstStateMJD2000':
                    # MJD of first state vector
                    firstStateMJD2000 = float(subfield.text)
                if subfield.tag == 'firstStateDiffUT1_UTC':
                    # UT1-UTC difference [sec]
                    firstStateDiffUT1_UTC = float(subfield.text)
        if field.tag == 'lastStateTime':
            for subfield in field:
                if subfield.tag == 'lastStateTimeUTC':
                    # UTC time of last state vector
                    lastStateTimeUTC = subfield.text
                if subfield.tag == 'lastStateTimeGPS':
                    # GPS time of first state vector (integer second counter)
                    lastStateTimeGPS = int(subfield.text)
                if subfield.tag == 'lastStateTimeGPSFraction':
                    # fraction GPS time of first state vector as fraction of second
                    lastStateTimeGPSFraction = float(subfield.text)
        if field.tag == 'lastLeapSecondUTC':
            # UTC time of last leap second at time of last state vector
            lastLeapSecondUTC = field.text
        if field.tag == 'leapSecondFlag':
            # indicates, if a leap second is contained in this orbit file
            # and specifies the sign of the leap second
            # -1 for subtract
            # +1 for add
            leapSecondFlag = int(field.text)
        if field.tag == 'stateVectorTimeSpacing':
            # state vector time spacing [sec]
            stateVectorTimeSpacing = float(field.text)
        if field.tag == 'positionAccuracyMargin':
            # 3D RMS value [m]
            positionAccuracyMargin = float(field.text)
        if field.tag == 'velocityAccuracyMargin':
            # 3D RMS value [m]
            velocityAccuracyMargin = float(field.text)
        if field.tag == 'recProcessingTechnique':
            # recommended processing (interpolation or approximation) technique
            recProcessingTechnique = field.text
        if field.tag == 'recPolDegree':
            # recommended polynomial degree for orbit processing
            # (interpolation or approximation)
            recPolDegree = int(field.text)

    # Convert the variables with times as strings to "datatime" format
    # NOTE!!!: to access to the complete time information, e.g.:
    # year = startTimeUTC.year
    # month = startTimeUTC.month
    # day = startTimeUTC.day
    # hour = startTimeUTC.hour
    # minute = startTimeUTC.minute
    # second = startTimeUTC.second
    # microsecond = startTimeUTC.microsecond
    startTimeUTC = np.datetime64(parser.parse(nominalStartTimeUTC[0],
                                              fuzzy=True), dtype='M8[s]')
    stopTimeUTC = np.datetime64(parser.parse(nominalStopTimeUTC[0],
                                             fuzzy=True), dtype='M8[s]')
    firstTimeUTC = np.datetime64(parser.parse(firstStateTimeUTC[0],
                                              fuzzy=True), dtype='M8[s]')
    lastTimeUTC = np.datetime64(parser.parse(lastStateTimeUTC[0], fuzzy=True),
                                dtype='M8[s]')
    leapSecondUTC = np.datetime64(parser.parse(lastLeapSecondUTC[0],
                                               fuzzy=True), dtype='M8[s]')

    OrbitHeader = namedtuple('orbitHeaderInfo', ['sensor', 'typee', 'accuracy',
                                                 'qualityInspection',
                                                 'orbitPhase', 'orbitCycle',
                                                 'absOrbit', 'relOrbit',
                                                 'numOrbitsInCycle',
                                                 'stateVectorRefFrame',
                                                 'stateVectorRefTime',
                                                 'nominalStartTimeUTC',
                                                 'nominalStopTimeUTC',
                                                 'numStateVectors',
                                                 'firstStateTimeUTC',
                                                 'firstStateTimeGPS',
                                                 'firstStateTimeGPSFraction',
                                                 'firstStateMJD2000',
                                                 'firstStateDiffUT1_UTC',
                                                 'lastStateTimeUTC',
                                                 'lastStateTimeGPS',
                                                 'lastStateTimeGPSFraction',
                                                 'lastLeapSecondUTC',
                                                 'leapSecondFlag',
                                                 'stateVectorTimeSpacing',
                                                 'positionAccuracyMargin',
                                                 'velocityAccuracyMargin',
                                                 'recProcessingTechnique',
                                                 'recPolDegree'])
    orbitHeaderInformation = OrbitHeader(sensor, typee, accuracy,
                                         qualityInspection, orbitPhase,
                                         orbitCycle, absOrbit, relOrbit,
                                         numOrbitsInCycle, stateVectorRefFrame,
                                         stateVectorRefTime, startTimeUTC,
                                         stopTimeUTC, numStateVectors,
                                         firstTimeUTC, firstStateTimeGPS,
                                         firstStateTimeGPSFraction,
                                         firstStateMJD2000,
                                         firstStateDiffUT1_UTC,
                                         lastTimeUTC, lastStateTimeGPS,
                                         lastStateTimeGPSFraction,
                                         leapSecondUTC, leapSecondFlag,
                                         stateVectorTimeSpacing,
                                         positionAccuracyMargin,
                                         velocityAccuracyMargin,
                                         recProcessingTechnique, recPolDegree)

    # -------------------------------------------------------------------------
    # stateVec is root[2:]
    #
    # stateVec: state vectors vith UTC time, GPS time and GPS time fraction,
    # x,y and z positions, and x,y and z velocities.
    #
    # The information for each state vector is extracted in lists which are
    # collected together in a named tuple
    # -------------------------------------------------------------------------

    stateVec = root[2:]

    stateVec_Id = []
    timeUTC = []
    timeGPS = []
    timeGPSFraction = []
    posX = []
    posY = []
    posZ = []
    velX = []
    velY = []
    velZ = []
    for field in stateVec:
        stateVec_Id.append(field.attrib['num'])
        for subfield in field:
            if subfield.tag == 'timeUTC':
                # UTC time
                timeUTC.append(subfield.text)
            if subfield.tag == 'timeGPS':
                # GPS time (integer second counter)
                timeGPS.append(int(subfield.text))
            if subfield.tag == 'timeGPSFraction':
                # fraction GPS time as fraction of second
                timeGPSFraction.append(float(subfield.text))
            if subfield.tag == 'posX':
                # X position [m]
                posX.append(float(subfield.text))
            if subfield.tag == 'posY':
                # Y position [m]
                posY.append(float(subfield.text))
            if subfield.tag == 'posZ':
                # Z position [m]
                posZ.append(float(subfield.text))
            if subfield.tag == 'velX':
                # X velocity [m/s]
                velX.append(float(subfield.text))
            if subfield.tag == 'velY':
                # Y velocity [m/s]
                velY.append(float(subfield.text))
            if subfield.tag == 'velZ':
                # Z velocity [m/s]
                velZ.append(float(subfield.text))

    # Convert the list with times as strings to "datatime" format
    for iii in range(len(timeUTC)):
        timeUTC[iii] = np.datetime64(parser.parse(timeUTC[iii], fuzzy=True),
                                     dtype='M8[s]')

    StateVectors = namedtuple('stateVecInfo', ['stateVecId', 'timeUTC',
                                               'timeGPS', 'timeGPSFraction',
                                               'posX', 'posY', 'posZ', 'velX',
                                               'velY', 'velZ'])
    stateVecInformation = StateVectors(stateVec_Id, timeUTC, timeGPS,
                                       timeGPSFraction, posX, posY, posZ,
                                       velX, velY, velZ)

    return orbitHeaderInformation, stateVecInformation


def write_XMLorbit(parFile=None):
    """ Writes an orbit in XML file

    """
    parFile = misc.get_parFile(parFile)
    filePath = os.path.split(parFile)[0]
    inData = cfg.ConfigFile(parFile)

    # File generation date
    generated_on = datetime.datetime.now()
    generated_on = generated_on.isoformat() + "Z"
    # Root File
    PH = inData.productHeader
    xsi = PH.xsi
    noNamespaceSchemaLocation = PH.noNamespaceSchemaLocation
    root = ET.Element("orbitProduct", nsmap={'xsi': xsi},
                      attrib={"{" + xsi + "}noNamespaceSchemaLocation":
                              noNamespaceSchemaLocation})
    comment = ET.Comment("XML file generated by rw_XML of DLR HR Institut")
    root.addprevious(comment)
    # ########################## Create Headers ########################### #
    # Retrieve General Header Data
    GH = inData.generalHeader
    # Retrieve Orbit Header Data
    OH = inData.orbitHeader

    # Dates
    utc_date0 = OH.nominalStartTimeUTC
    t0 = Time(utc_date0, format='isot', scale='utc')
#    mjd2000 = mjd - 51544.5
    t0_gps = int(t0.gps)
    t0_gps_frac = t0.gps - t0_gps

    filename0, file_extension = os.path.splitext(GH.xmlFileName)
    file_ver = str(0000.001)
    generalHd = ET.Element("generalHeader", fileName=filename0,
                           fileVersion=file_ver)
    orbitHd = ET.Element("orbitHeader")

    root.append(generalHd)
    root.append(orbitHd)
    # ##################################################################### #
    # Calculate orbital data
    orb_type = inData.orbit.type
    dDays = inData.orbit.days_cycle
    nRevs = inData.orbit.orbits_nbr
    omega = inData.orbit.omega_p
    omega_per_dot = inData.orbit.omega_p_dot
    if omega_per_dot is None:
        acc = None
    else:
        acc = 1.
    timeduration = inData.orbit.timeduration
    timestep = inData.orbit.timestep
    starttime = inData.orbit.starttime
    asc_node = kp.mltan2raan(inData.orbit.ltan, utc_date0)
#    asc_node = kp.mjd_to_gmst(t0.mjd)/3600*15 + inData.glon

    if orb_type == 'sunsync':
        # Generate parameters for sunsync orbit
        (a, e, i) = sso.get_sunsync_repeat_orbit(dDays, nRevs, acc=acc)

    elif orb_type == 'repeat':
        # Generate parameters for repeat orbit
        all_repeats = rd.all_repeat_orbs(i, e, dDays, dDays,
                                         doPlot=0)
        repeat = all_repeats[all_repeats[:, 0] == dDays, :]
        repeat_nRd = repeat[repeat[:, 1] == nRevs, :]
        a = repeat_nRd[0, 2]

    # extend data and force to start at equator
    data = cco.calc_orb_gen(e, a, i, omega, asc_node, timeduration+1,
                            timestep, starttime, noinfo=1,
                            omega_per_dot=omega_per_dot)

    Torb = 24.*dDays/nRevs  # orbital period [hrs]
    torb_s = Torb*3600.  # orbital period [sec]
    extra_elements = 1*24*3600/timestep  # due to 1 extra day
    # first orbit
    mask = data.timevec <= torb_s
    lat_arr0 = data.lat_arr[mask]

    # find intersection with equator
    bz = np.where(np.diff(np.sign(lat_arr0)))[0]
    maskz = lat_arr0[bz] < lat_arr0[bz+1]  # ascending
    bz = bz[maskz]
    idx = bz

    # new data set for the defined timeduration
    size_org = data.timevec.shape[0] - extra_elements
    timevec = data.timevec[idx:idx+size_org] - data.timevec[idx]
#    lon_arr = data.lon_arr[idx:idx+size_org]
#    lat_arr = data.lat_arr[idx:idx+size_org]
    recf = data.recf[idx:idx+size_org]
#    vecf = data.vecf[idx:idx+size_org]
    vcomp = data.vcomp[idx:idx+size_org]

    v = vcomp  # use complimentary velocity

#    timevec = data.timevec
#    recf = data.recf
#    vecf = data.vecf
    # Fill in the State Vectors
    for i in range(0, timevec.shape[0]):
        t_datetime = t0.datetime + datetime.timedelta(seconds=timestep*i)
        t_i = Time(t_datetime.isoformat() + "Z", format='isot', scale='utc')
        t_gps = int(t_i.gps)
        t_gps_frac = t_i.gps - t_gps
        state = write_SV(str(i+1), t_i.isot + "Z", str(t_gps),
                         str(t_gps_frac), recf[i, :], v[i, :])
        if (i == 0) or (i == 1):
            print(geo.ecef_to_geodetic(recf[i, :]))
        root.append(state)
    # ##################################################################### #
    # ############################# Modify Filename ####################### #
    filename = (filename0 + "_" + OH.type + "_" + OH.accuracy +
                "_" + t0.datetime.strftime("%Y%m%d%H%M%S") +
                "_" + t_i.datetime.strftime("%Y%m%d%H%M%S") +
                file_extension)
    generalHd.attrib["fileName"] = filename
    # ################### Fill General Header Data ######################## #
    ET.SubElement(generalHd, "itemName").text = GH.itemName
    ET.SubElement(generalHd, "mission").text = GH.mission
    ET.SubElement(generalHd, "source").text = GH.source
    ET.SubElement(generalHd, "destination").text = GH.destination
    ET.SubElement(generalHd, "generationSystem",
                  version=str(GH.generationSystem_ver)).text = (
                  GH.generationSystem)
    ET.SubElement(generalHd, "generationTime").text = generated_on
    ET.SubElement(generalHd, "referenceDocument").text = GH.referenceDocument
    ET.SubElement(generalHd, "revision").text = str(GH.revision)
    ET.SubElement(generalHd, "revisionComment").text = GH.revisionComment
    ET.SubElement(generalHd, "remark").text = GH.remark

    # ################### Fill in Orbit Header Data ####################### #
    product = ET.Element("product")
    ET.SubElement(product, "sensor").text = OH.sensor
    ET.SubElement(product, "type").text = OH.type
    ET.SubElement(product, "accuracy").text = OH.accuracy
    ET.SubElement(product, "qualityInspection").text = OH.qualityInspection
    orbitHd.append(product)

    orbit = ET.Element("orbit")
    ET.SubElement(orbit, "orbitPhase").text = str(OH.orbitPhase)
    ET.SubElement(orbit, "orbitCycle").text = str(OH.orbitCycle)
    ET.SubElement(orbit, "absOrbit").text = str(OH.absOrbit)
    ET.SubElement(orbit, "relOrbit").text = str(OH.relOrbit)
    ET.SubElement(orbit,
                  "numOrbitsInCycle").text = str(inData.orbit.orbits_nbr)
    orbitHd.append(orbit)

    ET.SubElement(orbitHd, "stateVectorRefFrame").text = OH.stateVectorRefFrame
    ET.SubElement(orbitHd, "stateVectorRefTime").text = OH.stateVectorRefTime
    ET.SubElement(orbitHd, "nominalStartTimeUTC").text = OH.nominalStartTimeUTC
    ET.SubElement(orbitHd, "nominalStopTimeUTC").text = t_i.isot + "Z"
    ET.SubElement(orbitHd, "numStateVectors").text = str(timevec.shape[0])

    firstStateTime = ET.Element("firstStateTime")
    ET.SubElement(firstStateTime,
                  "firstStateTimeUTC").text = utc_date0
    ET.SubElement(firstStateTime,
                  "firstStateTimeGPS").text = str(t0_gps)
    ET.SubElement(firstStateTime,
                  "firstStateTimeGPSFraction").text = str(t0_gps_frac)
    ET.SubElement(firstStateTime,
                  "firstStateMJD2000").text = str(t0.mjd - 51544.0)
    ET.SubElement(firstStateTime,
                  "firstStateDiffUT1_UTC").text = str(t0.delta_ut1_utc)
    orbitHd.append(firstStateTime)

    lastStateTime = ET.Element("lastStateTime")
    ET.SubElement(lastStateTime,
                  "lastStateTimeUTC").text = t_i.isot + "Z"
    ET.SubElement(lastStateTime,
                  "lastStateTimeGPS").text = str(t_gps)
    ET.SubElement(lastStateTime,
                  "lastStateTimeGPSFraction").text = str(t_gps_frac)
    orbitHd.append(lastStateTime)

    ET.SubElement(orbitHd, "lastLeapSecondUTC").text = OH.lastLeapSecondUTC
    ET.SubElement(orbitHd, "leapSecondFlag").text = str(OH.leapSecondFlag)
    ET.SubElement(orbitHd,
                  "stateVectorTimeSpacing").text = str(inData.orbit.timestep)
    ET.SubElement(orbitHd,
                  "maneuverCounter").text = str(OH.maneuverCounter)
    ET.SubElement(orbitHd,
                  "positionAccuracyMargin").text = (
                  str(OH.positionAccuracyMargin))
    ET.SubElement(orbitHd,
                  "velocityAccuracyMargin").text = (
                  str(OH.velocityAccuracyMargin))
    ET.SubElement(orbitHd,
                  "recProcessingTechnique").text = (
                  str(OH.recProcessingTechnique))
    ET.SubElement(orbitHd, "recPolDegree").text = str(OH.recPolDegree)
    # ##################################################################### #

    # Write xml File
    doc = ET.ElementTree(root)
    doc.write(os.path.join(filePath, filename),  pretty_print=True,
              with_tail=True, encoding="ISO-8859-1")
    return doc


def write_SV(sv_num, time_UTC, time_GPS, time_GPS_fr, pos, vel, mn="NA",
             qI="1"):

    stateVec = ET.Element("stateVec", num=sv_num, maneuver=mn, qualInd=qI)
    ET.SubElement(stateVec, "timeUTC").text = time_UTC
    ET.SubElement(stateVec, "timeGPS").text = time_GPS
    ET.SubElement(stateVec, "timeGPSFraction").text = time_GPS_fr
    ET.SubElement(stateVec, "posX").text = str(pos[0])
    ET.SubElement(stateVec, "posY").text = str(pos[1])
    ET.SubElement(stateVec, "posZ").text = str(pos[2])
    ET.SubElement(stateVec, "velX").text = str(vel[0])
    ET.SubElement(stateVec, "velY").text = str(vel[1])
    ET.SubElement(stateVec, "velZ").text = str(vel[2])
    return stateVec
