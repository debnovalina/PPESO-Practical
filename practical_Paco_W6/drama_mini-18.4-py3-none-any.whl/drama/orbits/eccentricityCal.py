import numpy as np
from drama import constants as const


def get_frozen_ecc(h, i, uptoj5=0, doPrint=0, deg=1):
    """ Calculate frozen eccentricity for Earth

        :date: 20.10.2014

        :author: Jalal Matar

        :param h: orbit height [m]
        :param i: iclination
        :param doPrint: If equals 1, prints output
        :param deg: If equals 1, return answer in degrees

        :returns: Keplerian eccentricity
    """

    if (deg == 0):
        deg = np.rad2deg(1)

    r_earth = const.r_earth  # Earth's radius
    a = r_earth + h  # semi-major axis

    # Zonal Coefficients
    j2 = const.j2
    j3 = const.j3
    j5 = const.j5

    i_rad = np.deg2rad(i*deg)  # inclination [rad]

    e = -0.5*(j3/j2)*(r_earth/a)*np.sin(i_rad)

    if (uptoj5 == 1):
        f1 = -(5./8)*(j5/j2)*((r_earth/a)**3)*np.sin(i_rad)
        f2 = 1.0 - 9.0*(np.cos(i_rad))**2
        -24.0*((np.cos(i_rad))**4)/(1 - 5*(np.cos(i_rad))**2)

        e = e + f1*f2

    if (doPrint == 1) & (uptoj5 == 0):
        print('\n Taking J2 and J3 into account, e = ', e, '\n')
    elif (doPrint == 1) & (uptoj5 == 1):
        print('\n Taking J2,J3 and J5 into account, e = ', e, '\n')

    return e
