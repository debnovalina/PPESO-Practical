from __future__ import absolute_import, division, print_function
import numpy as np
from drama import constants as const
from drama.geo.sar import geometry as geo
from drama.orbits import driftCal as dc
from collections import namedtuple


def calc_orb_gen(e, a, i, omega, asc_node, timeduration, timestep, starttime,
                 accuracy=1e-08, offset_time=0.0, noinfo=0,
                 orbit_period=None, asc_node_dot=None, omega_per_dot=None):
    """ Calculate Keplerian orbit for general Orbits

        :date: 27.01.2015

        :author: Jalal Matar De-looped by Paco Lopez-Dekker :-)

        :param e: eccentricity
        :param a: semi-major axis [m]
        :param i: inclination [deg]
        :param omega: argument of perigee
        :param asc_node: right ascension of the ascending node [deg]
        :param timeduration: duration of orbit [days]
        :param timestep: step size of sampling
        :param starttime: time (starting at perigee)
        :param accuracy: accuracy, defaults to 1e-08
        :param offset_time: additional time for additional earth rotation,
                            defaults to zero
        :param noinfo: flag for silent execution
        :param orbit_period: orbital period (default- calculated automatically)
        :param asc_node_dot: nodal precession [rad/s]
        :param omega_per_dot: perigee drift [rad/s]

        :returns: associative list (dict) containing timevec, reci (N,3),
                  recf (N,3), veci(N,3), vecf (N,3), AE, AM, x, y, z, vel_abs,
                  r_abs, anomaly, u_all, r_all, lon_arr, lat_arr,
                  velocity_vec (N,3)

    """
    # define constants
    omega_earth = const.omega_earth  # omega earth

    # Print Parameters
    if (noinfo == 0):
        print(' Parameters:     ')
        print(' -----------     ')
        print(' Inclination:    ', i, 'deg')
        print(' Semi major:     ', a, 'm')
        print(' Above Ground:   ', (a-const.r_earth), 'm')
        print(' Eccentricity:   ', e)
        print(' Ascend. Node:   ', asc_node, 'deg')
        print(' Arg. of Perigee:', omega, 'deg')
        print(' Starttime:      ', starttime)
        print(' Duration:       ', timeduration, 'days')
        print(' Time increment: ', timestep)
        print(' Offset Time:    ', offset_time)

    # Include nodal drift
    if asc_node_dot is None:
        asc_node_dot = dc.nodal_regression(e, a, i, 'j4')  # [rad/sec]

    # include argument of perigee drift
    if omega_per_dot is None:
        omega_per_dot = dc.omega_per_dot(e, a, i, 'j2')  # [rad/sec]

    # Convert angles from degrees to radians
    [i_rad, asc_node_rad0, omega_rad0] = np.deg2rad([i, asc_node, omega])

    # Calculate Orbital Period & mean motion
    if (orbit_period is None):
        n0 = np.sqrt(const.gm_earth/(a**3.))  # mean motion
    else:
        n0 = 2*np.pi/orbit_period  # mean motion

    timeduration = timeduration*24.*3600  # timeduration in seconds
    # get 5 more values for calc. velocity etc.
    offset = 3
    tottime = starttime - (offset * timestep)
    numpoints = int(np.ceil(timeduration/timestep)) + offset   # extra values
    timevec = np.arange(numpoints) * timestep + tottime

    # solve angle with Newtonian algorithm for each point
    # ascending node and argument of perigee after adding orbital
    # pertubation effects
    omega_rad = omega_rad0 + omega_per_dot * timevec

    # Mean anomaly; changes by 360 degrees during one revolution
    M = np.mod((n0 * timevec), (2.0 * np.pi))
    Ep = M  # Previous eccentric anomaly (here initial state)
    delta_E = np.ones(numpoints)
    # Eccentric anomaly difference (to check convergence)

    # check for convergence
    while (delta_E.max() >= accuracy):
        # Eccentric Anomaly of next state
        En = Ep - ((Ep - (e * np.sin(Ep)) - M) / (1.0 - (e * np.cos(Ep))))
        # Update difference
        delta_E = np.abs(En - Ep)
        Ep = En

    # true anomaly
    true_anom = np.arctan2((np.sqrt(1.0 - (e**2.)) * np.sin(En)),
                           (np.cos(En) - e))

    AE = En  # Eccentric Anomaly
    AM = M  # Mean anomaly

    u_all = np.mod((omega_rad + AM), (2. * np.pi))

    # orbit radius
    r = a * (1.0 - (e**2.)) / (1.0 + (e * np.cos(true_anom)))

#    arg_lat = omega_rad + true_anom  # argument of latitude
#    asc_node_rad = asc_node_rad0 + asc_node_dot * timevec
#    # Earth-centered inertial (ECI) coordinates
#    xeci = r * ((np.cos(arg_lat) * np.cos(asc_node_rad)) -
#                (np.sin(arg_lat) * np.cos(i_rad) *
#                np.sin(asc_node_rad)))
#
#    yeci = r * ((np.cos(arg_lat) * np.sin(asc_node_rad)) +
#                (np.sin(arg_lat) * np.cos(i_rad) *
#                np.cos(asc_node_rad)))
#
#    zeci = r * (np.sin(arg_lat) * np.sin(i_rad))

    asc_node_ = asc_node + timevec * asc_node_dot  # [deg]

    # Finding Velociy
    asc_node_rad2 = np.deg2rad(asc_node_)
    f = np.sqrt(const.gm_earth * a)/(a*(1.0 - e*np.cos(true_anom)))

    # unit vector pointing towards the perigee
    P = np.array([[np.cos(omega_rad0)*np.cos(asc_node_rad2) -
                   np.sin(omega_rad0)*np.cos(i_rad)*np.sin(asc_node_rad2)],
                 [np.cos(omega_rad0)*np.sin(asc_node_rad2) +
                  np.sin(omega_rad0)*np.cos(i_rad)*np.cos(asc_node_rad2)],
                 [np.sin(omega_rad0)*np.sin(i_rad) *
                  np.ones(len(asc_node_rad2))]], dtype='float')

    # unit vector corresponding to true anomaly of 90 degrees
    Q = np.array([[-np.sin(omega_rad0)*np.cos(asc_node_rad2) -
                   np.cos(omega_rad0)*np.cos(i_rad)*np.sin(asc_node_rad2)],
                  [-np.sin(omega_rad0)*np.sin(asc_node_rad2) +
                   np.cos(omega_rad0)*np.cos(i_rad)*np.cos(asc_node_rad2)],
                  [np.cos(omega_rad0)*np.sin(i_rad) *
                   np.ones(len(asc_node_rad2))]], dtype='float')

    # Velocity vector ECI
    veci = -f*((np.sin(true_anom))*P -
               np.sqrt(1 - e**2) * np.cos(true_anom) * Q)
    veci = veci.reshape(3, timevec.shape[0]).T

    # Position vector ECI
    reci = (a*(np.cos(true_anom) - e)*P +
            a * np.sqrt(1 - e**2) * np.sin(true_anom)*Q)
    reci = reci.reshape(3, timevec.shape[0]).T

    # rotate velocity vector:
    ang_tmp = np.rad2deg(omega_earth * (timevec + offset_time))
    velocity_vec = geo.rot_z(veci, ang_tmp).T

    # rotate position and velocity vectors to ECEF reference frame
    alpha = offset_time * omega_earth
    argR = np.rad2deg(omega_earth*timevec + alpha)
    recf = geo.rot_z(reci, argR).T
    vecf = (geo.rot_z(veci, argR).T + omega_earth *
            geo.rot_z_prime(reci, argR).T)

    # declination (gamma)
    latitude = np.arctan(reci[:, 2] /
                         (np.sqrt((reci[:, 0]**2.) + (reci[:, 1]**2.))))

    # right ascension (alpha)
    longitude = np.arctan2(reci[:, 1], reci[:, 0])

    # Due to earth rotation: modify longitude
    longitude = longitude - omega_earth * (timevec + offset_time)

    # To ensure that longitude lies within valid range
    longitude = np.arctan2(np.sin(longitude), np.cos(longitude))

    # Outputs
    lon_arr = np.rad2deg(longitude)
    lat_arr = np.rad2deg(latitude)

    # geocentric distance
    r_abs = np.sqrt(reci[:, 0]**2. + reci[:, 1]**2. + reci[:, 2]**2.)

    # absolute velocity relative to Earth
    vel_abs = np.sqrt(const.gm_earth * (2./r_abs - 1./a))

    # cut back arrays to exact repeat cycle (remove additional time steps)
    timevec = timevec[offset:]

    reci = reci[offset:, :]
    recf = recf[offset:, :]
    veci = veci[offset:, :]
    vecf = vecf[offset:, :]
    velocity_vec = velocity_vec[offset:, :]
    AE = AE[offset:]
    AM = AM[offset:]
    vel_abs = vel_abs[offset:]
    r_abs = r_abs[offset:]
    true_anom = true_anom[offset:]
    u_all = u_all[offset:]
    r_all = r[offset:]
    lon_arr = lon_arr[offset:]
    lat_arr = lat_arr[offset:]

    Out = namedtuple('out', ['timevec', 'reci', 'recf', 'veci', 'vecf', 'AE',
                             'AM', 'vel_abs', 'r_abs',
                             'anomaly', 'u_all', 'r_all', 'lon_arr', 'lat_arr',
                             'velocity_vec'])
    out = Out(timevec, reci, recf, veci, vecf, AE, AM, vel_abs, r_abs,
              np.degrees(true_anom), u_all, r_all, lon_arr, lat_arr,
              velocity_vec)
    return out
