from drama import constants as const
from drama.orbits import driftCal as dc
import numpy as np
import matplotlib.pyplot as plt
from drama.utils import misc as misc
from collections import namedtuple


def repeat_ERO(i_deg, Tao, hmin=0.0, hmax=45000.0e03, doPlot=0):
    """ Calculates the semi major axis for a certain Tao value

    :author: Jalal Matar

    :date: 15.01.2015

    :param i_deg: iclination [deg]
    :param Tao: ratio d/k (number of days to repeat/ number of revs per repeat)
    :param hmin: minimum orbital height [m]
    :param hmax: maximum orbital height [m]

    :returns: a list of possible semi-major axis corresponding to a valid
              to a certain inclination for the input value of Tao
    """

    # retrieve constants
    GM_earth = const.gm_earth
    r_earth = const.r_earth
    omega_earth = const.omega_earth
    amax = hmax + r_earth
    amin = hmin + r_earth

    j2 = const.j2
    j4 = const.j4

    # convert i_deg to a list, in case one value was entered
    idx = 0
    if not isinstance(i_deg, (list, np.ndarray)):
        i_deg = [i_deg]

    # initialize an array to fill with possible values of "a"
    a_ero = np.zeros((2, len(i_deg)), dtype=float)

    # iterate through the given values of i_deg
    for i in range(0, len(i_deg)):
        # define some constants for simplification
        i_rad = np.deg2rad(i_deg[i])
        sin_ero = np.sin(i_rad)
        cos_ero = np.cos(i_rad)

        # Implement the polynomial equation corresponding to ERO method:
        # f(x) = c11*(x**11) + c8*(x**8) + c4*(x**4) + c0 (where a = x**2)
        # source: Aorpimai & Palmer

        c11 = -omega_earth/(j2*(r_earth**2)*np.sqrt(GM_earth))
        c8 = Tao/((r_earth**2)*j2)
        c4 = Tao*(3 - (15./4)*(sin_ero**2)) - 1.5*cos_ero

        c01 = ((-15./16)*Tao*(j4/j2)*(r_earth**2)*((34./5) -
               25*(sin_ero**2) + (77./4)*(sin_ero**4)))
        c02 = (((3./16)*Tao*j2*(r_earth**2)*(14 + 17*(sin_ero**2) -
               35*(sin_ero**4))))
        c03 = (15./16)*(j4/j2)*(r_earth**2)*cos_ero*(4 - 7*(sin_ero**2))
        c04 = (3./8)*j2*(r_earth**2)*cos_ero*(11 - 20*(sin_ero**2))

        c0 = c01 + c02 + c03 + c04

        # define the polynomial
        p_ero = [c11, 0, 0, c8, 0, 0, 0, c4, 0, 0, 0, c0]
        # Get roots of the polynomial equation
        x_ero = np.roots(p_ero)

        a_ero_all = (x_ero**2)  # semi-major axis [m]
        # extract real values of a
        a_ero_chosen = np.real(a_ero_all[np.angle(a_ero_all) == 0])

        # remove values which are outside our orbital range
        a_ero_chosen = np.delete(a_ero_chosen,
                                 np.where(a_ero_chosen < amin))
        a_ero_chosen = np.delete(a_ero_chosen,
                                 np.where(a_ero_chosen > amax))

        # fill in the values of a in the output array
        if len(a_ero_chosen) > 1:
            a_ero = np.pad(a_ero, ((0, 0), (0, len(a_ero_chosen)-1)),
                           mode='constant')
            for j in range(0, len(a_ero_chosen)):
                a_ero[0, i + idx + j] = i_deg[i]
                a_ero[1, i + idx + j] = a_ero_chosen[j]
            idx = idx + len(a_ero_chosen)-1
        elif len(a_ero_chosen) == 1:
            a_ero[0, i+idx] = i_deg[i]
            a_ero[1, i+idx] = a_ero_chosen
        else:
            a_ero = []

    # Plot
    if doPlot:
        plt.figure()
        plt.plot(a_ero[0, :], a_ero[1, :]/1000., '-+')
        plt.xlabel('Inclination [deg]')
        plt.ylabel('Semi-major axis [km]')
        plt.ylim([min(a_ero[1, :]/1000.)-10.0, max(a_ero[1, :]/1000.)+10.0])

    return a_ero


def repeat_EROr(i_deg, Tao, e, hmin=0.0, hmax=45000.0e03, doPlot=0):
    """ Calculate semi-major axis using ERO and SRG refinement

    :author: Jalal Matar

    :date: 16.01.2015

    :param i_deg: iclination [deg]
    :param Tao: ratio d/k (number of days to repeat/ number of revs per repeat)
    :param e: eccentricity
    :param hmin: minimum orbital height [m]
    :param hmax: maximum orbital height [m]

    :returns: a list of possible semi-major axis corresponding to a certain
              inclination, eccentricity and Tao
    """
    # define constants
    # r_earth = const.r_earth
    omega_earth = const.omega_earth
    # Find the intitial value of semi-major axis using ERO method
    all_ero = repeat_ERO(i_deg, Tao, hmin, hmax, 0)

    # Refine a using SRG
    if all_ero == []:
        all_ero_r = [[[]], [[]]]
    else:
        all_ero_r = repeat_SRG(all_ero[0, :], all_ero[1, :], e, Tao)

    # Plot
    if doPlot == 1:
        plt.figure()
        plt.plot(all_ero_r[0, :], all_ero_r[1, :]/1000., marker='o', ls='--',
                 color='red', label="EROr e=" + str(e))
        plt.xlabel('Inclination [deg]')
        plt.ylabel('Semi-major axis [km]')
        plt.ylim([min(all_ero_r[1, :]/1000.)-10.0,
                  max(all_ero_r[1, :]/1000.)+10.0])
        plt.title("Tao = " + str(Tao))

    elif doPlot == 2:
        plt.figure()
        EROr, = plt.plot(all_ero_r[0, :], (all_ero_r[1, :])/1000.,
                         marker='o', ls='--', color='red',
                         label="EROr e=" + str(e))
        ERO, = plt.plot(all_ero[0, :], (all_ero[1, :])/1000.,
                        '-o', color='blue', label="ERO e=" + str(e))
        plt.xlabel('Inclination [deg]')
        plt.ylabel('Semi-major axis [km]')
        plt.ylim([min((all_ero_r[1, :])/1000.)-10.0,
                  max((all_ero_r[1, :])/1000.)+10.0])
        plt.title("Tao = " + str(Tao), size=16)
        plt.legend()
        plt.ticklabel_format(useOffset=False)

    elif doPlot == 3:  # Plot includes Period in hours
        # start by calculating the nodal regression and corresponding period
        asc_node_dot = dc.nodal_regression(e, all_ero_r[1, :], all_ero_r[0, :])
        T_day = 2*np.pi/(omega_earth - asc_node_dot)  # period in sec
        T_day = T_day/3600.  # period in hour

        plt.figure()
        plt.plot(all_ero_r[0, :], all_ero_r[1, :]/1000., marker='o',
                 ls='--', color='red', label="EROr e=" + str(e))
        plt.xlabel('Inclination [deg]', fontsize=14)
        plt.ylabel('Semi-major axis [km]', fontsize=14)
        plt.ylim([min(all_ero_r[1, :]/1000.)-10.0,
                  max(all_ero_r[1, :]/1000.)+10.0])
        plt.grid(b=True, which='both', color='0.65', linestyle='-')

        for i in range(0, len(T_day)):
            plt.text(all_ero_r[0, i], all_ero_r[1, i]/1000.,
                     str(round(T_day[i]*100000)/100000.) + "hrs",
                     color="blue", fontsize=12)
        plt.title("Repeat Orbits (16/231)", fontsize=16)#Tao =" + str(Tao) + ")", fontsize=16)
        plt.legend()
        plt.show()

    return all_ero_r


def repeat_SRG(i_deg, a0, e, Tao):
    """ Calculates the semi major axis for certain inclination and eccentricity

    :author: Jalal Matar

    :date: 19.01.2015

    :param i_deg: iclination [deg]
    :param a0: initial semi-major axis [m]
    :param e: eccentricity
    :param Tao: ratio Nd/Np (number of days to repeat/ number of revs
                per repeat)

    :returns: array containing incident angles and corresponding srg
              semi-major axis

    """

    ########################################################
    ########################################################
    # SRG func = Q*x**7 + x**3 - omega_earth/Tao
    def f(x):
        """ SRG function

            :param x: x = n**(1/3)
        """
        return Q*x**7 + x**3 - omega_earth/Tao

    def derivative(f):
        def compute(x, dx):
            return (f(x+dx) - f(x))/dx
        return compute

    def newtons_method(f, x, dx=0.000001, tolerance=0.000001):
        """f is the function f(x)"""
        df = derivative(f)
        while True:
            x1 = x - f(x)/df(x, dx)
            t = abs(x1 - x)
            if t < tolerance:
                break
            x = x1
        return x
    ######################################################
    ######################################################

    # convert i_deg to a list
    if not isinstance(i_deg, (list, np.ndarray)):
        i_deg = [i_deg]

    # convert a0 to a list
    if not isinstance(a0, (list, np.ndarray)):
        a0 = [a0]

    GM_earth = const.gm_earth
    r_earth = const.r_earth
    omega_earth = const.omega_earth
    j2 = const.j2

    # x = n**(1./3) and n = np.sqrt(GM_earth/(a**3))
    x0 = (GM_earth/(a0**3))**(1./6)

    all_srg = np.zeros((2, len(i_deg)), dtype=float)
    all_srg[0, :] = i_deg

    for kk in range(0, len(x0)):
        i_rad = np.deg2rad(i_deg[kk])
        psi_srg = (3*((1 - e**2)**(-1.5))*(1./3 - 0.5*((np.sin(i_rad))**2)) -
                   (1/((1-e**2)**2))*(0.5 - 2.5*(np.cos(i_rad))**2) -
                   (1/Tao)*(np.cos(i_rad))/(1/((1-e**2)**2)))

        Q = 1.5*j2*(r_earth**2)*psi_srg/(GM_earth**(2./3))

        xout = newtons_method(f, x0[kk])
        nout = xout**3
        all_srg[1, kk] = (GM_earth/(nout**2))**(1./3)

    return all_srg


def Tao_ERO(a, i_deg):
    """ Calculates the ratio Tao = Nd/Np for a RGT orbit

    :author: Jalal Matar

    :date: 22.01.2015

    :param a: semi-major axis [m]
    :param i: inclination [deg]

    :returns: The ratio Nd/Np (number of days/number of revolutions)
    """
    # define constants
    r_earth = const.r_earth
    GM_earth = const.gm_earth
    omega_earth = const.omega_earth
    j2 = const.j2
    j4 = const.j4
    i_rad = np.deg2rad(i_deg)

    num1 = (omega_earth/j2)*np.sqrt((a**3)/GM_earth)*((a/r_earth)**2)
    num2 = 1.5*np.cos(i_rad)
    num3 = ((-15./16)*(j4/j2)*((r_earth/a)**2)*np.cos(i_rad) *
            (4 - 7*(np.sin(i_rad)**2)))
    num4 = ((-3./8)*j2*((r_earth/a)**2)*np.cos(i_rad) *
            (11 - 20*(np.sin(i_rad)**2)))

    den1 = ((a/r_earth)**2)/j2
    den2 = 3 - (15./4)*(np.sin(i_rad)**2)
    den3 = ((-15./16)*(j4/j2)*((r_earth/a)**2) *
            ((34./5) - 25*(np.sin(i_rad)**2) + (77./4)*(np.sin(i_rad)**4)))
    den4 = ((3./16)*j2*((r_earth/a)**2) *
            (14 + 17*(np.sin(i_rad)**2) - 35*(np.sin(i_rad)**4)))

    Tao = (num1 + num2 + num3 + num4)/(den1 + den2 + den3 + den4)
    return Tao


def all_repeat_orbs(i_deg, e, min_cycle=1, max_cycle=10, hmin=580.0e03,
                    hmax=35786.0e03, doPlot=1, type='EROr'):
    """ Calculates and plots all possible repeat orbits orbital heights

    :author: Jalal Matar

    :date: 23.01.2015

    :param i_deg: inclination [deg]
    :param e: eccentricity
    :param min_cycle: minimum number of days to repeat
    :param max_cycle: maximum number of days to repeat
    :parma hmin: minimum orbital height [m]
    :param hmax: maximum orbital height [m]

    :returns: an array containing repeat number of days, number of revs and
              corresponding semimajor axis
    """

    # define constants
    r_earth = const.r_earth

    # Start by finding all possible variations of Tao = Nd/Np according to the
    #  input parameters

    amin = hmin + r_earth
    amax = hmax + r_earth
    Tao_min = Tao_ERO(amin, i_deg)
    Tao_max = int(Tao_ERO(amax, i_deg))

    Tao_poss = []  # ratio Nd/Np (Tao_num/Tao_den)
    Tao_num = []  # number of repeat days
    Tao_den = []  # number of revolutions per repeat day

    for elm in range(min_cycle, max_cycle + 1):
        if Tao_max == 0:
            den_initial = 1.0
        else:
            den_initial = max(1.0, int(elm/Tao_max))
        den_add = 0.0
        tao_add = elm/den_initial

        while(tao_add > Tao_min):
            if tao_add not in Tao_poss:
                Tao_poss.append(tao_add)
                Tao_num.append(elm)
                Tao_den.append(int(den_add + den_initial))

            den_add = den_add + 1
            tao_add = elm/(den_initial + den_add)

    all_Tao = np.concatenate(([Tao_poss], [Tao_num], [Tao_den]), axis=0).T
    # all combinations of Tao for the height range
    all_Tao = all_Tao[all_Tao[:, 0].argsort(), ]

    # Retrieve semi major axis height corresponding to all_Tao
    a_ero = []
    if type == 'EROr':
        for i in range(0, all_Tao.shape[0]):
            a = repeat_EROr(i_deg, all_Tao[i, 0], e, hmin, hmax)
            a_ero.append(a[1][0])
    elif type == 'ERO':
        for i in range(0, all_Tao.shape[0]):
            a = repeat_ERO(i_deg, all_Tao[i, 0], hmin, hmax)
            a_ero.append(a[1][0])

    # remove empty fields from a_ero and all_Tao
    indices = [i for i, x in enumerate(a_ero) if x == []]
    all_Tao = np.delete(all_Tao, indices, 0)
    a_ero = [i for j, i in enumerate(a_ero) if j not in indices]

    # Plotting
    if doPlot:
        # Start Plotting
        plt.figure()
        X = all_Tao[:, 1]
        Y = np.array(a_ero, dtype=float)/1000000.
        Z = all_Tao[:, 2]
        plt.plot(X, Y, '+')
        plt.xlabel('Repeat Cycle [days]', size=14)
        plt.ylabel('Semi-major axis [x1000 km]', size=14)
        plt.title('Repeat Orbits (inclination = ' + str(i_deg) + ' degrees)',
                  size=16)
        plt.ylim([max(0, min(Y) - 1), max(Y) + 1])
        plt.xlim([min(X)-1, max(X)+1])
        plt.grid(b=True, which='both', color='0.65', linestyle='-')

        for i in range(0, len(Z)):
            plt.text(X[i], Y[i], str(int(Z[i])), color="red", fontsize=12)
        plt.show()

    out = np.zeros(all_Tao.shape, dtype=object)
    out[:, 0] = all_Tao[:, 1].astype(int)
    out[:, 1] = all_Tao[:, 2].astype(int)
    out[:, 2] = a_ero

    #  out[out[:,0]==1.0,:]  (To select entries with one day as repeat cycle)
    return out


def basic_orbit_param(hmin=580.0e03, hmax=780.0e03, start_cycle=6,
                      stop_cycle=13, latitude=0, doPlot=1):
    """ Calculates valid combinations of repeat_cycle, orbital height and
        orbits per cycle

        :date: 20.11.2014

        :author: Jalal Matar

        :param hmin: minimum orbital height [m]
        :param hmax: maximum orbital height [m]
        :param start_cycle: minimum repeat cycle [days]
        :param stop_cycle: maximum repeat cycle [days]
        :param latitude: latitude [deg]
        :param doPlot: if set show the plots

        :returns: associative list (dict) containing days, h_sat, n_orbit,
                  swath, covered_latitude

    """

    R_earth = const.r_earth
    GM_earth = const.gm_earth
    T_day = 24*60.0*60.0

    # minimum orbital period
    T_orb_min = 2*np.pi*np.sqrt((hmin+R_earth)**3/GM_earth)
    # maximum orbital period
    T_orb_max = 2*np.pi*np.sqrt((hmax+R_earth)**3/GM_earth)

    # minimum repeats
    n_repeat_min = np.floor(T_day*start_cycle/T_orb_max)
    # maximum repeats
    n_repeat_max = np.ceil(T_day*stop_cycle/T_orb_min)

    repeat_cycle = np.array(range(start_cycle, stop_cycle + 1), dtype='int')
    n_repeat = np.array(range(int(n_repeat_min), int(n_repeat_max) + 1),
                        dtype='float')

    h_sat = np.zeros((len(repeat_cycle), len(n_repeat)))  # satellite height
    ds = np.zeros((len(repeat_cycle), len(n_repeat)))  # swath
    valid = np.ones((len(repeat_cycle), len(n_repeat)), dtype='int')
    repeat_number_array = np.zeros((len(repeat_cycle), len(n_repeat)))
    repeat_cycle_array = np.zeros((len(repeat_cycle), len(n_repeat)),
                                  dtype='int')

    for i in range(0, len(repeat_cycle)):
        for j in range(0, len(n_repeat)):
            repeat_number_array[i, j] = n_repeat[j]
            repeat_cycle_array[i, j] = repeat_cycle[i]
            T_orbit = repeat_cycle[i]*T_day/n_repeat[j]

            # semi-major axis
            a = (((T_orbit/(2.*np.pi))**2)*GM_earth)**(1./3)
            # satellite height
            h_sat[i, j] = a - R_earth  # satellite height

            # covered swath
            ds[i, j] = ((2*np.pi*R_earth*np.cos(np.deg2rad(latitude))) /
                        n_repeat[j])

            # If repeat_cycle & n_repeat have common divisor then invalid
            if (misc.checkcommondivisors(repeat_cycle[i], n_repeat[j]) == 1):
                valid[i, j] = 0

    # Get indices of valid heights
    tmp = (h_sat > (hmin + 1000.0)) & (h_sat < (hmax - 1000.0)) & (valid > 0)
    tmp = np.reshape(tmp, (np.product(tmp.shape)))
    tmp = np.where(tmp == True)[0]

    Out = namedtuple('out', ['days', 'h_sat', 'n_orbits', 'swath'])

    # Convert to one dimensional arrays
    repeat_cycle_array = np.reshape(repeat_cycle_array,
                                    (np.product(repeat_cycle_array.shape)))
    h_sat = np.reshape(h_sat, (np.product(h_sat.shape)))
    repeat_number_array = np.reshape(repeat_number_array,
                                     (np.product(repeat_number_array.shape)))
    ds = np.reshape(ds, (np.product(ds.shape)))

    out = Out(repeat_cycle_array[tmp], h_sat[tmp], repeat_number_array[tmp],
              ds[tmp])

    if doPlot:
        # Start Plotting
        plt.figure()
        X = repeat_cycle_array[tmp]
        Y = h_sat[tmp]/1000.0
        Z = repeat_number_array[tmp]
        plt.plot(X, Y, '+')
        plt.xlabel('Repeat Cycle [days]')
        plt.ylabel('Orbital Height [km]')
        plt.ylim([hmin/1000.0, hmax/1000.0])
        plt.xlim([min(repeat_cycle)-1, max(repeat_cycle)+1])
        plt.grid(b=True, which='both', color='0.65', linestyle='-')

        for i in range(0, len(Z)):
            plt.text(X[i], Y[i], str(int(Z[i])), color="red", fontsize=12)
        plt.show()
    return out
