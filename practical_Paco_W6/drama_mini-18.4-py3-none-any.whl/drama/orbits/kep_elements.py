from __future__ import absolute_import, division, print_function
import numpy as np
from drama import constants as const
from collections import namedtuple
import math
from astropy.time import Time


def rv_to_elem(pos, vel):
    """ Compute Keplerian elements from position and velocity
    This function works well for e & i > 0

    :param pos: ECEF location of the satellite [3, 1]
    :param vel: ECEF velocity of the satellite [3, 1]

    :returns, a, e, i, omega, asc_node, mean_anomaly
    """

    # ditance
    r = np.linalg.norm(pos)

    # areal velocity vector
    h = np.cross(pos, vel)
    h_mag = np.linalg.norm(h)
    W = h/h_mag

    # inclination and asc_node
    i = np.arctan2(np.sqrt(W[0]**2 + W[1]**2), W[2])
    asc_node = np.arctan2(W[0], -W[1])
    asc_node = float(np.where(asc_node > 0, asc_node, asc_node + np.pi*2))

    # eccentricity
    p = (h_mag**2) / (const.gm_earth)
    a = (2/r - (np.linalg.norm(vel)**2)/const.gm_earth)**-1
    n = np.sqrt(const.gm_earth / a**3)
    e = np.sqrt(1 - p/a)

    # Mean anomaly
    E = np.arctan2((np.dot(pos, vel)/(n * a**2)), (1 - r/a))
    M = E - e*np.sin(E)

    # argument of perigee
    u = np.arctan2(pos[2], (-pos[0]*W[1] + pos[1]*W[0]))
    v = np.arctan2((np.sqrt(1 - e**2) * np.sin(E)), (np.cos(E) - e))
    w = u - v
    w = float(np.where(w > 0, w, w + np.pi*2))

    Elements = namedtuple('Elements', ['a', 'e', 'i', 'asc_node', 'omega_p',
                                       'mean_anomaly'])
    elements = Elements(a, e, np.degrees(i), np.degrees(asc_node),
                        np.degrees(w), np.degrees(M))
    return elements


def rv2_to_elem(pos, vel):
    """ Compute Keplerian elements from position and velocity
    This function works well for e ~ 0 & i~0

    :param pos: ECEF location of the satellite [3, 1]
    :param vel: ECEF velocity of the satellite [3, 1]

    :returns, a, e, i, omega, asc_node, mean_anomaly
    """
    if isinstance(pos, list):
        pos = np.array(pos)
    if isinstance(vel, list):
        vel = np.array(vel)

    a = (2/np.linalg.norm(pos) - (np.linalg.norm(vel)**2)/const.gm_earth)**-1

    # Orbital plane normal vector
    W = np.cross(pos, vel)/np.linalg.norm(np.cross(pos, vel))

    # Equinotical Elements
    p = W[0] / (1 + W[2])
    q = -W[1] / (1 + W[2])

    # Runge-Lenz vector
    A = (np.cross(vel, (np.cross(pos, vel))) -
         const.gm_earth*pos/np.linalg.norm(pos))

    # Orthogonal unit vectors
    fg = 1 / (1 + p**2 + q**2)
    f = fg * np.array([1 - p**2 + q**2, 2 * p * q, -2 * p])
    g = fg * np.array([2 * p * q, 1 + p**2 + q**2, 2 * q])

    # Eccentricity components
    k = np.dot(A, f)/const.gm_earth
    k_mag = np.linalg.norm(k)
    h = np.dot(A, g)/const.gm_earth
    h_mag = np.linalg.norm(h)
    betta = 1 / (1 + np.sqrt(1 - h_mag**2 - k_mag**2))
    # In-plane coordinates
    X1 = np.dot(pos, f)
    Y1 = np.dot(pos, g)

    cosF = (k_mag + (((1 - betta * k_mag**2)*X1 - h_mag*k_mag*betta*Y1) /
                     (a * np.sqrt(1 - h_mag**2 - k_mag**2))))

    sinF = (h_mag + (((1 - betta * h_mag**2)*Y1 - h_mag*k_mag*betta*X1) /
                     (a * np.sqrt(1 - h_mag**2 - k_mag**2))))

    # Eccentric longitude
    F = np.arccos(cosF)

    # mean longitude
    l = F - k_mag*sinF + h_mag*cosF

    Elements = namedtuple('Elements', ['a', 'h', 'p', 'l', 'k', 'q'])
    elements = Elements(a, h_mag, p, np.degrees(l), k_mag, q)
    return elements


def mltan2raan(mltan, utc_date):
    """ Converts MLTAn to RAAN at a certain epoch

    :param mltan: mean local time at ascending node (hh:mm:ss)
    :param utc_date: univesal time at epoch

    """
    (h, m, s) = mltan.split(':')
    MLTAN = int(h) + int(m) / 60 + float(s) / 3600  # hrs

    # utc to ut1
    t = Time(utc_date, format='isot', scale='utc')
    UT = t.ut1
    ut_time = UT.datetime.time()
    ut_hr = (ut_time.hour * 3600 + ut_time.minute*60 + ut_time.second +
             ut_time.microsecond/10**6)/3600
    GAST = mjd_to_gast(t.mjd)/3600
    # right ascension of mean Sun
    ram_sun = GAST*15 - 15*ut_hr + 180  # degrees
    asc_node = ram_sun + 15*(MLTAN - 12)  # degrees

    return np.mod(asc_node, 360)


def mjd_to_gmst(mjd):
    """
       Estimate the Greenwich Mean Sidereal Time (in seconds) based on
       Modified Julian Date.
    """

    # Calculate GMST (from http://aa.usno.navy.mil/faq/docs/GAST.php)
    # Unmodified Julian date.
    JD = mjd + 2400000.5
    # Julian date of previous midnight UT.
    if JD >= 0.5:
        JD0 = int(JD-0.5) + 0.5
    else:
        JD0 = int(JD-0.5) - 0.5
    # Hours since previous midnight.
    H = (JD - JD0) * 24.
    # Number of days from 2000-01-01T12:00:00.
    D = JD - 2451545.0
    D0 = JD0 - 2451545.0
    # Centuries since 2000-01-01T12:00:00.
    T = D/36525
    # Greenwich mean sidereal time in hours.
    GMST = 6.697374558 + 0.06570982441908*D0 + 1.00273790935*H + 0.000026*T**2
    # Alternate calculation loses 0.1 second per century with the benefit
    # of not needing to calculate UT midnight.
    # GMST = 18.697374558 + 24.06570982241908*D
    # Convert to seconds.
    GMST *= 3600
    # Yet another alternate caclulation (in seconds) using only the
    # century measure.
    # GMST = 24110.54841 + 8640184.812866*T + 0.093104*T**2 +
    #        0.0000062*T**3 + H*3600

    # Correct for 0 < GMST < 86400 seconds.
    GMST %= 86400

    return GMST


def mjd_to_gast(mjd):
    """
       Estimate the Greenwich Apparent Sidereal Time (in seconds) based
       on Modified Julian Date.
    """

    # Calculate GAST (from http://aa.usno.navy.mil/faq/docs/GAST.php)
    # Greenwich mean sidereal time converted to hours.
    GMST = mjd_to_gmst(mjd) / 3600
    # Number of days from 2000-01-01T12:00:00.
    D = mjd - 51544.5
    # Longitude of the ascending node of the Moon.
    OMEGA = 125.04 - 0.052954*D
    # Mean Longitude of the Sun
    L = 280.47 + 0.98565*D
    # Nutation in longitude.
    DELTA_PSI = -0.000319*math.sin(OMEGA) - 0.000024*math.sin(2*L)
    # Obliquity of the ecliptic.
    EPSILON = 23.4393 - 0.0000004*D
    # Correct GMST with the equation of the equinoxes (nutation in RA)
    GAST = GMST + DELTA_PSI*math.cos(EPSILON)
    # Convert to seconds.
    GAST *= 3600

    return GAST

#    # Calculate ascending node
#    ltan = inData.orbit.ltan
#    (h, m, s) = ltan.split(':')
#    ltan_h = int(h) + int(m) / 60 + float(s) / 3600  # hrs
#    prev_eq = ephem.previous_equinox(t0.datetime).datetime()
#    prev_eq = Time(prev_eq.isoformat() + "Z", format='isot', scale='utc')
#    # days since last vernal equinox
#    d_veq = ((t0.datetime - prev_eq.datetime).total_seconds())/24/3600
#    asc_node = ltan_h*360/24 - 180 - 360/365.242199*d_veq
#    asc_node = float(np.where(asc_node > 0, asc_node, asc_node + 360))