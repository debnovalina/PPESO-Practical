"""
====================================
Geometry Package (:mod:`trampa.geo`)
====================================

.. currentmodule:: trampa.geo

Orbits
======

.. autosummary::
    :toctree: generated/

    orbit_to_vel
    SquintedGeo
    compareAllOut

Subpackages
===========
.. toctree::
   :maxdepth: 1

   trampa.geo.sar

"""

from .orbit import orbit_to_vel
#from .squinted  import SquintedGeo, compareAllOut
