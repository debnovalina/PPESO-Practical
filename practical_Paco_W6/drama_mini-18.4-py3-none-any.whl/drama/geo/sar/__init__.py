"""
============================================
SAR Geometry Package (:mod:`trampa.geo.sar`)
============================================

.. currentmodule:: trampa.geo.sar

SAR Geometry
============

.. autosummary::
    :toctree: generated/

    inc_to_sr
    inc_to_gr
    inc_to_look
    look_to_inc
    max_look_angle
    gr_to_geo
    blind_ranges
    ecef_to_geodetic
    pt_get_intersection_ellipsoid
    find_slant
    eci_to_ecef
    rot_z
    rot_z_prime
    latlon_to_quat
    latlon_from_quat
    create_LoS

"""

from .geometry import inc_to_sr, inc_to_gr, inc_to_look, \
                      look_to_inc, look_to_sr, \
                      max_look_angle, gr_to_geo, sr_to_geo, ecef_to_geodetic,\
                      pt_get_intersection_ellipsoid, find_slant, eci_to_ecef,\
                      rot_z, rot_z_prime, latlon_to_quat, latlon_from_quat,\
                      create_LoS
from .timing import blind_ranges, timing_diagram, mode_on_timing
