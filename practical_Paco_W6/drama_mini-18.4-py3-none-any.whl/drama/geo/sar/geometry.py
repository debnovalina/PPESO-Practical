import numpy as np
from scipy import interpolate
from collections import namedtuple
from drama.geo import orbit_to_vel
from drama import constants as const
import drama.utils.gohlke_transf as trans
from drama.utils.coord_trans import (rot_z, rot_z_prime)


def inc_to_sr(theta_i, orbit_alt, r_planet=const.r_earth):
    """ Calculates slant range angle given incidence angle

        :param theta_i: Incidence angle
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: Slant range
    """

    theta_l = inc_to_look(theta_i, orbit_alt, r_planet=r_planet)
    delta_theta = theta_i - theta_l

    return np.sqrt((orbit_alt + r_planet -
                    r_planet * np.cos(delta_theta))**2 +
                   (r_planet * np.sin(delta_theta))**2)


def inc_to_gr(theta_i, orbit_alt, r_planet=const.r_earth):
    """ Calculates incidence angle given ground range

        :param theta: Incidence angle
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: Ground range
    """
    return r_planet * (theta_i - inc_to_look(theta_i,
                                             orbit_alt,
                                             r_planet=r_planet))


def inc_to_look(theta_i, orbit_alt, r_planet=const.r_earth):
    """ Calculates look angle given incidence angle

        :param theta_i: Incidence angle [rad]
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: Look angle [rad]
    """

    return np.arcsin(np.sin(theta_i)/(r_planet + orbit_alt) * r_planet)


def look_to_inc(theta_l, orbit_alt, r_planet=const.r_earth):
    """ Calculates incidence angle given look angle

        :param theta_l: Look angle
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: Incidence angle
    """
    return np.arcsin(np.sin(theta_l)*(r_planet + orbit_alt)/r_planet)


def look_to_sr(theta_l, orbit_alt, r_planet=const.r_earth):
    """ Calculates slant range angle given look angle

        :param theta_l: Look angle
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: slant range
    """
    theta_i = look_to_inc(theta_l, orbit_alt, r_planet=r_planet)
    delta_theta = theta_i - theta_l
    return np.sqrt((orbit_alt + r_planet -
                    r_planet * np.cos(delta_theta))**2 +
                   (r_planet * np.sin(delta_theta))**2)


def sr_to_geo(slant_range, orbit_alt,
              r_planet=const.r_earth,
              m_planet=const.m_earth):
    """ Calculates zero Dopplerinterpolated SAR geometric parameters given a
        set of slant range points

        :param slant_range: Set of ground range points
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius
        :param m_planet: mass of planet, defaults to Earth's mass

        :returns: ground range, incidence angle, look angle
    """
    # Calculate look/incident angles
    theta_l = np.linspace(0, max_look_angle(orbit_alt, r_planet=r_planet),
                          500)
    theta_i = look_to_inc(theta_l, orbit_alt, r_planet=r_planet)
    delta_theta = theta_i - theta_l
    r_track = np.cos(delta_theta) * r_planet
    v_orb = orbit_to_vel(orbit_alt, r_planet=r_planet, m_planet=m_planet)
    b = v_orb**2 * r_track / (r_planet + orbit_alt)

    # Calculate Ground Range and Slant Range
    gr = r_planet * delta_theta
    sr = np.sqrt((orbit_alt + r_planet - r_planet * np.cos(delta_theta))**2 +
                 (r_planet * np.sin(delta_theta))**2)

    # Interpolate look/incidence angles and Slant Range
    val_mask = np.logical_and(slant_range < sr.max(),
                              slant_range > sr.min())
    theta_l_interp = np.where(val_mask, interpolate.interp1d(sr, theta_l, 'linear',
                                                             bounds_error=False, fill_value=np.NaN)(slant_range),
                              np.NaN)
    theta_i_interp = np.where(val_mask, interpolate.interp1d(sr, theta_i, 'linear',
                                                            bounds_error=False, fill_value=np.NaN)(slant_range),
                              np.NaN)
    gr_interp = np.where(val_mask, interpolate.interp1d(sr, gr, 'linear',
                                                        bounds_error=False, fill_value=np.NaN)(slant_range),
                         np.NaN)
    b_interp = np.where(val_mask, interpolate.interp1d(sr, b, 'linear',
                                                       bounds_error=False, fill_value=np.NaN)(slant_range),
                        np.NaN)
    return (gr_interp, theta_i_interp, theta_l_interp, b_interp)


def gr_to_geo(ground_range, orbit_alt, r_planet=const.r_earth):
    """ Calculates interpolated SAR geometric parameters given a set of
        ground range points

        :param ground_range: Set of ground range points
        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: slant range, incidence angle, look angle
    """
    # Calculate look/incident angles
    theta_l = np.linspace(0, max_look_angle(orbit_alt), 500)
    theta_i = look_to_inc(theta_l, orbit_alt, r_planet=r_planet)
    delta_theta = theta_i - theta_l

    # Calculate Ground Range and Slant Range
    gr = r_planet * delta_theta
    sr = np.sqrt((orbit_alt + const.r_earth -
                  r_planet * np.cos(delta_theta))**2 +
                 (r_planet * np.sin(delta_theta))**2)

    # Interpolate look/incidence angles and Slant Range
    theta_l_interp = interpolate.interp1d(gr, theta_l, 'linear',
                                          bounds_error=False, fill_value=np.NaN)(ground_range)
    theta_i_interp = interpolate.interp1d(gr, theta_i, 'linear',
                                          bounds_error=False, fill_value=np.NaN)(ground_range)
    sr_interp = interpolate.interp1d(gr, sr, 'linear',
                                     bounds_error=False, fill_value=np.NaN)(ground_range)

    return sr_interp, theta_i_interp, theta_l_interp


def max_look_angle(orbit_alt, r_planet=const.r_earth):
    """ Calculates maximum look angle given satellite orbit altitude

        :param orbit_alt: Satellite orbit altitude
        :param r_planet: radious of planet, defaults to Earth's radius

        :returns: Maximum look angle
    """
    return np.arcsin(r_planet / (r_planet + orbit_alt))


def ecef_to_geodetic(coords, inverse=False):
    """ convert ecef coords to geodetic or opposite (accurate)

        :param coords: (ecef -> [x, y, z]) (geodetic -> [lat, lon, alt]
                        lat and lon in degrees)
        :param inverse: inverse the transformation
    """
    retrans = False  # flag to return coords with same format
    if isinstance(coords, list):
        coords = np.array(coords)
    if coords.ndim == 1:
        coords = coords[np.newaxis, :]
    if not inverse:  # ecef-to-geodetic
        # convert ecef to eci
        coords = rot_z(coords, const.omega_earth, True)
        if coords.shape[1] != 3:
            coords = coords.T
            retrans = True  #

        a = const.r_equatorial('wgs84')
        b = const.r_polar('wgs84')
        e = np.sqrt((a**2 - b**2) / (a**2))
        e_prime = np.sqrt((a**2 - b**2) / (b**2))
        p = np.sqrt((coords[:, 0]**2) + (coords[:, 1]**2))
        theta = np.arctan(coords[:, 2] * a / p / b)

        lon = np.degrees(np.arctan2(coords[:, 1], coords[:, 0]))
        lat = np.degrees(np.arctan((coords[:, 2] +
                                    ((e_prime**2) * b * (np.sin(theta))**3)) /
                                   (p - ((e**2) * a * (np.cos(theta)**3)))))

        N = a / np.sqrt(1 - (e**2)*(np.sin(np.radians(lat))**2))
        alt = p/np.cos(np.radians(lat)) - N

        new_coords = np.hstack((lat[:, np.newaxis], lon[:, np.newaxis],
                               alt[:, np.newaxis])).T
    else:  # geodetic-to-ecef
        if coords.shape[1] != 3:
            coords = coords.T
            retrans = True

        a = const.r_equatorial('wgs84')
        b = const.r_polar('wgs84')
        e = np.sqrt((a**2 - b**2) / (a**2))
        # Radius of curvature [m]
        N = a / np.sqrt(1 - (e**2)*(np.sin(np.radians(coords[:, 0])))**2)

        X = ((N + coords[:, 2]) * np.cos(np.radians(coords[:, 0])) *
             np.cos(np.radians(coords[:, 1])))
        Y = ((N + coords[:, 2]) * np.cos(np.radians(coords[:, 0])) *
             np.sin(np.radians(coords[:, 1])))
        Z = ((b**2)/(a**2)*N + coords[:, 2]) * np.sin(np.radians(coords[:, 0]))

        new_coord0 = np.vstack((X[np.newaxis, :], Y[np.newaxis, :],
                               Z[np.newaxis, :]))
        # convert  eci to ecef

        # rotational matrix from ECI to ECEF
        new_coords = rot_z(new_coord0, const.omega_earth)
        if retrans:
            new_coords = new_coords.T
    return new_coords.T


def ecef_to_geodetic2(coords, inverse=False):
    """ convert ecef coords to geodetic or opposite

        :param coords: (ecef -> [x, y, z]) (geodetic -> [lat, lon, alt]
                        lat and lon in degrees)
        :param inverse: inverse the transformation
    """
    retrans = False  # flag to return coords with same format
    if isinstance(coords, list):
        coords = np.array(coords)
    if coords.ndim == 1:
        coords = coords[np.newaxis, :]
    if not inverse:  # ecef-to-geodetic
        # convert ecef to eci
        coords = rot_z(coords, const.omega_earth, True)
        if coords.shape[1] != 3:
            coords = coords.T
            retrans = True  #
        lon = np.degrees(np.arctan2(coords[:, 1], coords[:, 0]))
        lat = np.degrees(np.arctan(coords[:, 2]/np.sqrt((coords[:, 0]**2) +
                                                        (coords[:, 1]**2))))
        new_coords = np.append(lat[:, np.newaxis], lon[:, np.newaxis],
                               axis=1).T
    else:  # geodetic-to-ecef
        if coords.shape[1] != 3:
            coords = coords.T
            retrans = True
        new_coord0 = ((coords[:, 2] + const.r_earth) *
                      ([(np.cos(np.radians(coords[:, 0])) *
                         np.cos(np.radians(coords[:, 1]))),
                        (np.cos(np.radians(coords[:, 0])) *
                         np.sin(np.radians(coords[:, 1]))),
                        np.sin(np.radians(coords[:, 0]))]))
        # convert  eci to ecef

        # rotational matrix from ECI to ECEF
        new_coords = rot_z(new_coord0, const.omega_earth)
        if retrans:
            new_coords = new_coords.T
    return new_coords.T


def eci_to_ecef(r_var, v_var, t_vec=0, inverse_transform=False):
    """ Converts ECI coordinates to ECEF and vice versa

        :param r_var: position vecor [N x 3]
        :param v_var: 2D velocity vector [N x 3]
        :param t_vec: time vector [N, ]

        :returns: converted coordinates
    """

    if r_var.shape[1] != 3:
        r_var = r_var.T
    if t_vec == 0:
        t_vec = np.zeros(r_var.shape[0])

    # Initialize
    r_inv = np.zeros(r_var.shape[0])
    v_inv = np.zeros(r_var.shape[0])

    if inverse_transform:  # ECEF to ECI
        for k in range(0, r_var.shape[0]):
            argR = np.rad2deg(const.omega_earth*t_vec[k])
            r_inv[k, :] = rot_z(r_var[k, :], argR, True)
            v_inv[k, :] = (rot_z(v_var[k, :], argR) +
                           (const.omega_earth*rot_z_prime(r_var[k, :], argR)))
    else:
        for k in range(0, r_var.shape[0]):
            argR = np.rad2deg(const.omega_earth*t_vec[k])
            r_inv[k, :] = rot_z(r_var[k, :], argR)
            fact = (v_var[k, :] -
                    const.omega_earth*rot_z_prime(r_inv[k, :], argR))
            v_inv[k, :] = rot_z(fact, argR, True)

    return r_inv, v_inv


def rotation_matrix(axis, theta):
    """
        Return the rotation matrix associated with counterclockwise rotation
        about he given axis by theta radians.
        # np.dot(rotation_matrix(axis,theta), vector)

        :param axis: axis to be rotated, either as a 1 to 3 number or as a
                     vector
        :param theta: angle in radian
    """
    axis = np.asarray(axis)
    if axis.size == 1:
        axs = np.zeros(3)
        axs[axis-1] = 1
    else:
        axs = axis
    theta = np.asarray(theta)
    axs = axs/np.sqrt(np.dot(axs, axs))
    a = np.cos(theta/2)
    b, c, d = -axs * np.sin(theta/2)
    aa, bb, cc, dd = a*a, b*b, c*c, d*d
    bc, ad, ac, ab, bd, cd = b*c, a*d, a*c, a*b, b*d, c*d
    return np.array([[aa+bb-cc-dd, 2*(bc+ad), 2*(bd-ac)],
                     [2*(bc-ad), aa+cc-bb-dd, 2*(cd+ab)],
                     [2*(bd+ac), 2*(cd-ab), aa+dd-bb-cc]])


def latlon_to_quat(lat, lon):
    """ Returns a quaternion computed from latitude and longitude coordinates.

        :author: Thomas Boerner

        :param lat: latitude [deg]
        :type lat: float
        :param lon: longitude [deg]
        :type lon: float

        :returns: lat/lon quaternion q[w,x,y,z]
    """

    lat = np.deg2rad(lat)
    lon = np.deg2rad(lon)

    clat = np.cos(lat/2.)
    clon = np.cos(lon/2.)
    slat = np.sin(lat/2.)
    slon = np.sin(lon/2.)

    qw = clat*clon
    qx = clat*slon
    qy = slat*clon
    qz = -slat*slon

    return np.array([qw, qx, qy, qz])


def latlon_from_quat(q):
    """ Returns latitude and longitude coordinates from a quaternion.

        :author: Thomas Boerner

        :param q: quaternion
        :type q: 4-element float array q[w,x,y,z]

        :returns: lat/lon coordinates [deg]
    """

    lat = np.rad2deg(np.arcsin(2*(q[2]*q[0] - q[1]*q[3])))
    lon = np.rad2deg(np.arctan2(2*(q[2]*q[3] + q[1]*q[0]),
                                q[0]**2 - q[1]**2 - q[2]**2 + q[3]**2))

    return np.array([lat, lon])


def pt_get_intersection_ellipsoid(position, direction):
    """ Calculate intercept point of antenna look direction with ellipsoid.

        :author: Thomas Boerner, Paco Lopez-Dekker

        :param position: antenna origins (satellite's position) [m].
        :type position: float 2-D array
        :param direction: look directions of the antenna [deg].
        :type direction: float 2-D array

        :returns: float 2-D array giving the intercept point(s) with the
                  ellipsoid [m].

    """
    # make valid for single position
    if position.ndim == 1:
        position = position.reshape((1, 3))
    if direction.ndim == 1:
        direction = direction.reshape((1, 1, 3))
    # Set some default values for earth ellipsoid
    r_x = const.r_equatorial()  # earth equatorial radius [m]
    r_y = const.r_equatorial()   # earth equatorial radius [m]
    r_z = const.r_polar()   # earth radius at pole [m]

    # Some initialization
    dir_shape = direction.shape

    # Map input arrays to vectors with short names
    dir_x = direction[:, :, 0]
    dir_y = direction[:, :, 1]
    dir_z = direction[:, :, 2]

    pos_x = position[:, 0].reshape((dir_shape[0], 1))
    pos_y = position[:, 1].reshape((dir_shape[0], 1))
    pos_z = position[:, 2].reshape((dir_shape[0], 1))

    # Calculate coefficients of quadradic equation
    af = (dir_x/r_x)**2 + (dir_y/r_y)**2 + (dir_z/r_z)**2
    bf = (2.*((dir_x/r_x)*(pos_x/r_x) +
          (dir_y/r_y)*(pos_y/r_y) +
          (dir_z/r_z)*(pos_z/r_z)))
    cf = (pos_x/r_x)**2 + (pos_y/r_y)**2 + (pos_z/r_z)**2 - 1.

    # Check if solution of quadratic equation is real. Print informational
    # message if there would be one or many complex results.
    radicand = bf**2 - 4.*af*cf
    index0 = np.where(radicand < 0.)
    if radicand[index0].size > 0:
        print('At some positions there is no intersection with the ellipsoid.')

    # Solve quadratic equation to get intersection. Negative values of radicand
    # result in 'NaN'.
    solution1 = (-bf + np.sqrt(radicand))/(2.*af)
    solution2 = (-bf - np.sqrt(radicand))/(2.*af)

    # Negative solutions appear if there is an intersection in the
    # backward direction.
    # They are excluded by setting the solution to 'NaN'.
    index1 = np.where(solution1 < 0.)
    index2 = np.where(solution2 < 0.)
    if solution1[index1].size > 0:
        solution1[index1] = np.nan
    if solution2[index2].size > 0:
        solution2[index2] = np.nan
    if (solution1[index1].size + solution2[index2].size) > 1.:
        print('There are some intersections in the backward direction.\
               Please check your inputs.')

    # The smaller of the two solutions is the first intercept point
    jf = np.minimum(solution1, solution2)

    # Calculate coordinates of the intercept point
    target_x = jf*dir_x + pos_x
    target_y = jf*dir_y + pos_y
    target_z = jf*dir_z + pos_z
    intercept_point = np.zeros(dir_shape)
    intercept_point[:, :, 0] = target_x
    intercept_point[:, :, 1] = target_y
    intercept_point[:, :, 2] = target_z

    return intercept_point


def antenna_squinted_LoS(v_ver, r_ver, look_ang, squint_ang,
                         right_looking=True):
    """ Find LoS vector given a satellite coordinate system, a number
        of look angles, and a squint angle
        :param v_ver: (N, 3) array containing typically the flight direction
                      (not if we mechanically rotate the antenna)
        :param r_ver: (N, 3) array with the radial (vertical) versor
        :param look_ang: look angles (rad)
        :param squint_ang: antenna squint
    """
    n_ver = np.cross(v_ver, r_ver)
    Nv = v_ver.shape[0]
    Nla = look_ang.size
    npts = 180
    phi = np.linspace(0, np.pi/2, npts).reshape((1, npts))
    if not right_looking:
        phi = - phi
    v_ver_ = np.array([0, 1, 0]).reshape((3, 1))
    r_ver_ = np.array([0, 0, 1]).reshape((3, 1))
    n_ver_ = np.array([1, 0, 0]).reshape((3, 1))
    # 3 x npts
    LoS_ = (v_ver_ * np.sin(squint_ang) +
            np.cos(squint_ang) * (np.sin(phi) * n_ver_ -
                                  np.cos(phi) * r_ver_))
    la_ = np.arccos(np.cos(squint_ang) * np.cos(phi))
    la2LoS = interpolate.interp1d(la_.flatten(), LoS_)
    LoS_b = la2LoS(look_ang)
    LoS = (v_ver.reshape((Nv, 1, 3)) * LoS_b[1, :].reshape((1, Nla, 1)) +
           r_ver.reshape((Nv, 1, 3)) * LoS_b[2, :].reshape((1, Nla, 1)) +
           n_ver.reshape((Nv, 1, 3)) * LoS_b[0, :].reshape((1, Nla, 1)))
    return LoS


def create_LoS(position, velocity, look_ang, squint_a=0,
               force_zero_Doppler=True, right_looking=True):
    """ Find the LoS vector corresponding to a certain position and velocity
        vector, taking into consideration the look angle and squint

        :param position: antenna origins (satellite's position) [m].
        :type position: float 2-D array [N x 3]
        :param velocity: velocity of the antenna [m/s].
        :type velocity: float 2-D array [N x 3]
        :param look_ang: look angle [deg]
        :param squint_a: antenna squint, defaults to zero [deg]

        returns: float 3-D array
        """

    Nla = look_ang.size
    ant_squint_rad = np.radians(squint_a)
    if velocity.ndim == 1:
        ax = 0
        Nv = 1
    else:
        ax = 1
        Nv = velocity.shape[0]

    # Calculate velocity and positions versor
    v_ver = velocity/np.linalg.norm(velocity, axis=ax).reshape((Nv, 1))
    r_ver = position/np.linalg.norm(position, axis=ax).reshape((Nv, 1))

    n_ver = np.cross(v_ver, r_ver)    # cross product of versors
    if force_zero_Doppler:
        r_ver2 = np.cross(n_ver, v_ver)
    else:
        r_ver2 = r_ver

    if ant_squint_rad != 0:
        LoS = antenna_squinted_LoS(v_ver, r_ver2, look_ang,
                                   ant_squint_rad,
                                   right_looking=right_looking)
    else:
        if not right_looking:
            look_ang = -look_ang
        LoS = (-np.cos(look_ang.reshape(1, Nla, 1))*r_ver2.reshape(Nv, 1, 3) +
               np.sin(look_ang.reshape(1, Nla, 1))*n_ver.reshape(Nv, 1, 3))
    return LoS


def antenna_axes(ant_x, ant_y):
    # x for antenna pointing
    # y-z plane is antenna plane, z would be elevation cut, y azimuth
    """ Calculate principal axes of antenna
        :param ant_y: (3,) np.array defining y axis
        :param ant_z: (3,) np.array defining z axis
    """
    if len(ant_x.shape) == 1:
        ant_y_n = ant_y/np.linalg.norm(ant_y)
        ant_x_n = ant_x/np.linalg.norm(ant_x)
        ant_z_n = np.cross(ant_x_n, ant_y_n)
    else:
        Npts = ant_y.shape[0]
        ant_y_n = ant_y/np.linalg.norm(ant_y, axis=1).reshape((Npts, 1))
        ant_x_n = ant_x/np.linalg.norm(ant_x, axis=1).reshape((Npts, 1))
        ant_z_n = np.cross(ant_x_n, ant_y_n)
    return (ant_x_n, ant_y_n, ant_z_n)


def companion_pointing(swpts, r_ecef, v_ecef, tilt=0):
    """ Calculates mechanical pointing of a companion satellite to maximize
        the swath overlap, according to a number of assumptions :-)

        :param swpts: Nl x 3 or Na x Nl x 3 array with points in center of
                      reference footprint
        :param r_ecef: Na x 3 or 3-element array with spacecraft position
        :param v_ecef: Na x 3 or 3-element array with spacecraft velocity
        :param tilt: antenna tilt with respect to Nadir

        :returns: a named tuple with 'ant_xyz', 'sat_xyz', 'sat', 'euler_xyz',
                  the xyz rotation matrices to antenna coordinates, the
                  xyz rotation matrix for the spacecraft, the rotation matrix
                  of for the satellite in satellite coordinates, and the
                  corresponding Euler rotations, respectively
    """
    if swpts.ndim == 2:
        swpts = swpts.reshape((1,) + swpts.shape)
    if r_ecef.ndim == 1:
        r_ecef = r_ecef.reshape((1, 3))
        v_ecef = v_ecef.reshape((1, 3))
    s2r_near = swpts[:, 0, :] - r_ecef
    s2r_far = swpts[:, -1, :] - r_ecef
    Npts = r_ecef.shape[0]
    LoS_s_near = s2r_near / np.linalg.norm(s2r_near, axis=1).reshape((Npts, 1))
    LoS_s_far = s2r_far / np.linalg.norm(s2r_far, axis=1).reshape((Npts, 1))
    w = np.linspace(0, 1, swpts.shape[1]).reshape((1, swpts.shape[1], 1))
    LoS_s = (LoS_s_near.reshape((Npts, 1, 3)) * (1 - w) +
             LoS_s_far.reshape((Npts, 1, 3)) * w)
    swpts_s = pt_get_intersection_ellipsoid(r_ecef, LoS_s)

    LoS_s_ZD = create_LoS(r_ecef, v_ecef,
                          np.array([np.radians(tilt)]),
                          force_zero_Doppler=True)
    SE_x_ref = LoS_s_ZD[:, 0, :]

    SE_y = np.cross(LoS_s_far, LoS_s_near)

    # Desired antenna axes
    SE_x_n, SE_y_n, SE_z_n = antenna_axes((LoS_s_far + LoS_s_near) / 2, SE_y)
    # ZD antenna axes
    SE_ref_x_n, SE_ref_y_n, SE_ref_z_n = antenna_axes(SE_x_ref / 2, v_ecef)
    # Satellite axes
    LoS_hor = create_LoS(r_ecef, v_ecef, np.array([np.pi/2]),
                         force_zero_Doppler=True).reshape((Npts, 3))
    SE_sref_x_n, SE_sref_y_n, SE_sref_z_n = antenna_axes(LoS_hor, v_ecef)
    rot_SE = np.stack((SE_x_n, SE_y_n, SE_z_n), axis=2)
    rot_ref_SE = np.stack((SE_ref_x_n, SE_ref_y_n, SE_ref_z_n), axis=2)
    sat_ref_SE = np.stack((SE_sref_x_n, SE_sref_y_n, SE_sref_z_n), axis=2)
    rot_xyz_sat = np.einsum('ijk,ikl->ijl', rot_SE, np.linalg.inv(rot_ref_SE))

    tmp = np.einsum('ijk,ikl->ijl', rot_xyz_sat, sat_ref_SE)
    rot_sat = np.einsum('ijk,ikl->ijl', np.linalg.inv(sat_ref_SE), tmp)
#    for u_ind in np.arange(0, r_m.shape[0], 100):
#        LOS_m =
    rxyz = np.zeros((Npts, 3))
    for u_ind in range(r_ecef.shape[0]):
        rxyz[u_ind] = np.array(trans.euler_from_matrix(rot_sat[u_ind],
                                                       axes='rxyz'))
    companion_rot = namedtuple('sar_rotations',
                               ['ant_xyz', 'sat_xyz', 'sat', 'euler_xyz'])
    return companion_rot(rot_SE, rot_xyz_sat, rot_sat, rxyz)


def find_slant(r_sat, look, r_earth=const.r_earth):
    """ finds the slant range to intersection with Earth at certain look angle
    :param r_sat: ECEF position of the satellite
    :param look: look angle [deg]
    """
    if r_sat.ndim == 1:
        ax = 0
        rs = 1
    else:
        ax = 1
        rs = r_sat.shape[0]

    R_sat = np.linalg.norm(r_sat, axis=ax)  # satellite's dist. to earth center
    b1 = -2*R_sat*np.cos(np.radians(look))
    c1 = R_sat**2 - r_earth**2

    if R_sat.ndim == 0:
        R_sat = np.array([R_sat])
        b1 = np.array([b1])
        c1 = np.array([c1])

    Rs = np.zeros(rs, dtype=float)
    for i in range(rs):
        coeff = np.array([1, b1[i], c1[i]])
        r_i = np.roots(coeff)
        cmpR = R_sat[i] - r_earth
        Rs[i] = r_i[np.where((np.roots(coeff)-cmpR) ==
                             np.min(np.roots(coeff)-cmpR))[0][0]]
    return Rs


def squinted_versor(squint, n_ver, v_ecf_ver):
    """ Rotates the versor perpendicular to orbital position and velocity
       (in ecef coordinates) of a mechanical squint

        :author: Mariantonietta Zonno, Paco Lopez-Dekker

        :param squint: squint angle to be applied [deg].
        :type squint: float
        :param n_ver: perpendicular versor in the case of zero squint
        :type n_ver: float 2-D array
        :param v_ecf_ver: orbital velocity (ecef).
        :type v_ecf_ver: float 2-D array
        :returns: float 2-D array: the versor rotated of the squint angle

    """

    squint_rad = np.radians(squint)
    n_ver_sq = n_ver * np.cos(squint_rad) + v_ecf_ver * np.sin(squint_rad)

    return n_ver_sq
