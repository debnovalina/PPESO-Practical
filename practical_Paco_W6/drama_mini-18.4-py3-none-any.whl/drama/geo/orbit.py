import numpy as np
from drama import constants as const


def orbit_to_vel(orbit_alt, ground=False,
                 r_planet=const.r_earth,
                 m_planet=const.m_earth):
    """ Calculates orbital/ground velocity assuming circular orbit

        :param orbit_alt: Satellite orbit altitude
        :param ground: If true, returned value will be ground velocity

        :returns: Orbital or Ground velocity
    """
    v = np.sqrt(const.G * m_planet/(r_planet + orbit_alt))

    # Convert to ground velocity if needed
    if ground:
        v = r_planet / (r_planet + orbit_alt) * v

    return v
