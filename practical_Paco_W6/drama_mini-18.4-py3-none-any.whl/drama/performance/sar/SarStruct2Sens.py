import os
import numpy as np
from drama import constants as const
from drama.geo.sar import inc_to_look
from drama.geo import orbit_to_vel
from drama.io import ConfigFile
from collections import namedtuple
import matplotlib.pyplot as plt


def sarsens_filename(sar):
    """ Function that gets the correct path for the configuaration file of
        the given SAR sensor.
        
        :author: Maria Sanjuan-Ferrer

        :param sar: Given SAR sensor.
        :type sar: string

        :returns: Complete file name including path and extension.
    """
    fullpath = os.getcwd()
    pdf_filename = fullpath+'/sensors/'+sar+'.cfg'

    return pdf_filename


def sarsens(h_sar=520.0e3, v_orb=None, f0=5.3e9, theta=23.0, Brg=None,
            grg_res=None, az_res=None, slope=0.0, swath=None,  L_el_tx=None,
            L_el_rx=None, L_az_tx=None, L_az_rx=None, G_tx=None, G_rx=None,
            Tant=300.0, ap_eff=0.5, eta_ant=0.70710678118654757, NF=None,
            L_proc_and_atm=0.0, sigma_noise=-10.0, P_avg=None, reflector=False,
            pulse_diversity=None, no_power_spread=None, silent_flag=False):

    """ Function that calculates NESZ or Pavg.

        Depending on the input parameters, calculates either::

            - Single look noise equivalent sigma zero (NESZ).
            - Required average power (Pavg).
            
        :author: Maria Sanjuan-Ferrer

        :param h_sar: float Platform altitude (m). Optional.
        :type h_sar: float
        :param v_orb: Orbital velocity. Optional.
        :type v_orb: float
        :param f0: Carrier frequency (Hz). Optional.
        :type f0: float
        :param theta: Incidence angle (deg).Optional.
        :type theta: float or 1-D float array
        :param Brg: Range bandwidth (Hz). Optional.
        :type Brg: float
        :param grg_res: Ground range resolution (m). Optional.
        :type grg_res: float
        :param az_res: Azimuth resolution. Optional.
        :type az_res: float
        :param slope: Slope (deg). Optional.
        :type slope: float
        :param swath: Swath (m). Optional. If not set, it is calculated as 
                      the maximum non ambiguous. If set but too large, it is 
                      modified.
        :type swath: float
        :param L_el_tx: Antenna width in tx (m). Optional.
        :type L_el_tx: float
        :param L_el_rx: Antenna width in rx (m). Optional.
        :type L_el_rx: float
        :param L_az_tx: Azimuth dimension of antenna in tx (m). Optional.
        :type L_az_tx: float
        :param L_az_rx: Azimuth dimension of antenna in rx (m). Optional.
        :type L_az_rx: float
        :param G_tx: Antenna gain in tx (dB). Optional.
        :type G_tx: float
        :param G_rx: Antenna gain in rx (dB). Optional.
        :type G_rx: float
        :param Tant: Antenna temperature (K). Optional.
        :type Tant: float  
        :param ap_eff: Aperture efficiency. Optional.
        :type ap_eff: float
        :param eta_ant: Radiation efficiency. Optional.
        :type eta_ant: float
        :param NF: Reciever Noise Figure (dB). Optional.
        :type NF: float
        :param L_proc_and_atm: Different losses due to processing or atmosphere (dB). 
                               Optional.
        :type L_proc_and_atm: float
        :param sigma_noise: Sigma noise (dB). Optional.
        :type sigma_noise: float 
        :param P_avg: Average power (W). Optional. If not set, it is calculated
                      to achieve a given sensitivity.
        :type P_avg: float
        :param reflector: Reflector flag. Optional. If True, both antennas in tx 
                          and rx are considered reflectors.
        :type reflector: bool
        :param pulse_diversity: Flag used for alternating waveforms to resolve 
                                range ambiguities and introducing autoclutter.
                                Optional.
        :type pulse_diversity: bool
        :param no_power_spread: Power spread flag. Optional.
        :type no_power_spread: bool
        :param silent_flag: Silent flag. Optional. If True, no prints during 
                            computation.
        :type silent_flag: bool

        :returns: tuple.
    """

    slope_angle = (np.pi*slope)/180.0
    if h_sar == 0.0:
        h_sar = 520.0e3
    if f0 == 0.0:
        f0 = 5.3e9
    if theta == 0.0:
        theta = 23.0
    if eta_ant == 0.0:
        eta_ant = np.sqrt(0.5)
    if NF == 0.0:
        NF = 4.5 
    if ap_eff == 0.0:
        ap_eff = 0.5
    if sigma_noise == 0.0:
        sigma_noise = -10.0

    # It is assumed that both antennas are reflector or they are not
    # However, two different flags are used for future modifications
    if reflector is True:
        reflector_tx = True
        reflector_rx = True
    else:
        reflector_tx = False
        reflector_rx = False
    # Constants
    c = const.c
    Re = const.r_earth
    kb = const.Boltzmann
    # Derived constants
    lambda_0 = c/f0     # Carrier wavelenght
    #k_0 = (2.0*np.pi)/lambda_0
    # Look angle [rad]
    theta_1 = np.deg2rad(theta)
    # Calculation of the necessary bandwidth
    #print Brg, grg_res
    if Brg == 0.0 or grg_res != 0.0:
        if grg_res == 0.0:
            grg_res_ = 10.0
        else:
            grg_res_ = grg_res
        srg_res = grg_res_*np.sin(theta_1)    # Slant-range resolution
        # Therefore, the range bandwidth is srg_res=c/(2*NBW)
        NBW = c/2./srg_res
    else:
        # Just the opposite, calculation of the resolution given the bandwidth
        srg_res = c/2./Brg
        NBW = Brg
        grg_res_ = srg_res/np.sin(theta_1)     # Nominal ground range resolution
    # R_1 = h_sar/cos(theta_1)
    look_angle = inc_to_look(theta_1, h_sar)
    alpha = theta_1-look_angle
    R_1 = np.sqrt((h_sar+Re-Re*np.cos(alpha))**2.+(Re*np.sin(alpha))**2.)
    # In stripmap mode, antenna length can be derived from azimuth resolution
    if L_az_tx is None or L_az_tx == 0.0:
        if silent_flag is False:
            print('sarsens: azimuth dimension of antenna not set, getting it from resolution')
        if az_res is None or az_res == 0.0:
            az_res = 5.0
        L_az_tx = 2.*az_res
    else:
        if az_res is None or az_res == 0.0:
            az_res = L_az_tx/2.
    if L_az_rx is None or L_az_rx == 0.0:
        L_az_rx = L_az_tx
    # This can be corrected by a spotlight factor in spotlight mode...
    if silent_flag is False:
        print('sarsens: range and azimuth resolutions are: ', grg_res_, az_res)
    # Azimuth beamwidth L_az_tx
    theta_az = lambda_0/L_az_tx
    # Doppler bandwidth
    if v_orb is None or v_orb == 0.0:
        v_orb = orbit_to_vel(h_sar, ground=False)
    B_dop = (2.0*v_orb*theta_az)/lambda_0
    PRFmin = B_dop
    PRTmax = 1.0/PRFmin
    Ramb = (c*PRTmax)/2.0
    # Non ambiguous swath
    swath_amb = Ramb/np.sin(theta_1)
    if silent_flag is False:
        print('sarsens: selected swath width: ', swath)
        print('sarsens: max unambiguous swath width: ', swath_amb)
    if swath is None or swath == 0.0:
        # If swath is not specified then set it to max unambiguous
        swath = swath_amb
        swath_set = False
    else:
        swath_set = True
        if swath > (Ramb/np.sin(theta_1)) and pulse_diversity is None:
            # If swath is set but too large then it is adjusted
            swath = swath_amb
            if silent_flag is False:
                print( 'sarsens: adjunsting swath to maximum allowable')
    # Elevation beamwidth adjusted to swath to get antenna width
    theta_el = 2.0*np.arcsin(np.cos(theta_1)*swath/2.0/R_1)
    L_el_swath = lambda_0/theta_el/ap_eff
    if silent_flag is False:
        print('sarsens: antenna width for selected swath: ', L_el_swath)
    # Same adjustment to ambiguous swath
    theta_el_amb = 2.0*np.arcsin(np.cos(theta_1)*swath_amb/2.0/R_1)
    L_el_amb = lambda_0/theta_el_amb/ap_eff
    print(theta_el, theta_el_amb)
    if silent_flag is False:
        print('sarsens: antenna width for unambigous swath', L_el_amb)
    if L_el_tx is None or L_el_tx == 0.0:
        L_el_tx = L_el_amb
    if L_el_rx is None or L_el_rx == 0.0:
        L_el_rx = L_el_tx
    if L_el_amb > (np.max(np.array([L_el_tx, L_el_rx]))) and silent_flag is False:
        print('sarsens: antenna width is too small!')
    if silent_flag is False:
        print('sarsens: L_el_tx = ', L_el_tx)
    # Tx antenna parameters
    if reflector_tx is True:
        # Directivity
        D_tx = (ap_eff*np.pi**2.0*L_az_tx*L_el_tx)/(lambda_0**2.0)
        # Here it is assumed that the aperture efficiency's impact is the same
        # on azimuth and elevation
        theta_3dB_el_tx = (4.0*lambda_0)/(np.sqrt(ap_eff)*np.pi*L_el_tx)
        theta_3dB_az_tx = (4.0*lambda_0)/(np.sqrt(ap_eff)*np.pi*L_az_tx)
    else:
        ap_eff_tx = 1.0
        # This is a hack that assumes that for array antennas uniform
        # illumination on tx is always assumed!
        D_tx = ap_eff_tx*4.0*np.pi*(L_el_tx/lambda_0)*(L_az_tx/lambda_0)
        theta_3dB_el_tx = lambda_0/(ap_eff_tx*L_el_tx)
        theta_3dB_az_tx = lambda_0/L_az_tx
    if reflector_rx is True:
        # Repeat the same for rx
        D_rx = (ap_eff*np.pi**2.0*L_az_rx*L_el_rx)/(lambda_0**2.0)
        theta_3dB_el_rx = (4.0*lambda_0)/(np.sqrt(ap_eff)*np.pi*L_el_rx)
        theta_3dB_az_rx = (4.0*lambda_0)/(np.sqrt(ap_eff)*np.pi*L_az_rx)
    else:
        D_rx = ap_eff*4.0*np.pi*(L_el_tx/lambda_0)*(L_az_tx/lambda_0)
        # There is a hard-coded assumption: no tapering in azimuth but possible
        # tapering in elevation, which should be true for most azimuth config.
        theta_3dB_el_rx = lambda_0/(ap_eff*L_el_rx)
        theta_3dB_az_rx = lambda_0/L_az_rx
    ratio = 10.0*np.log10(np.abs(theta_3dB_el_tx/theta_3dB_el_rx))
    if np.abs(ratio) < 2.0:
        theta_3dB_el = (theta_3dB_el_tx+theta_3dB_el_rx)/(2.0*np.sqrt(2.0))
        # Approximation for Gaussian beam
        theta_3dB_el_sub = theta_3dB_el
    else:
        theta_3dB_el_sub = np.min(np.array([theta_3dB_el_tx, theta_3dB_el_rx]))
        # This is true only if difference is large
        theta_3dB_el = np.max(np.array([theta_3dB_el_tx, theta_3dB_el_rx]))
    sub_swath_3dB = (R_1*theta_3dB_el_sub)/np.cos(theta_1)
    swath_3dB = (R_1*theta_3dB_el)/np.cos(theta_1)
    P_avg_spread = 1.0
    # If a large swath is wanted doing beamforming, it is necessary to divide
    # the available power in multiple beams
    if swath_set is True:
        if swath > (np.sqrt(2.0)*swath_3dB):
            P_avg_spread = swath/swath_3dB/np.sqrt(2.0)
        dtheta_swath_edge = np.cos(theta_1)*swath/2.0/R_1
        rel_gain_swath_edge = np.exp(-np.log2(2.0)*(dtheta_swath_edge**2.0)/(theta_3dB_el**2.0))
    else:
        rel_gain_swath_edge = 0.5
    if no_power_spread is True:
        P_avg_spread = 1.0
    if silent_flag is False and P_avg_spread != 1.0:
        print('sarsens: average power spread to cover swath: ', P_avg_spread)
    D_tx_dB = 10.0*np.log10(abs(D_tx))
    D_rx_dB = 10.0*np.log10(abs(D_rx))
    if silent_flag is False:
        print('sarsens: antenna directivites: ', D_tx_dB, D_rx_dB)
    Tsys = Tant+((10.0**(NF/10.0))-1.)*290.0
    N = kb*NBW*Tsys
    #       eta_ant P_avg Gt^2 lambda_0^3 dRg sigma_0
    # SNR = -----------------------------------------
    #            2 (4*pi)^3 R^3 k Tsys v_sar
    if G_tx is None:
        G_tx_l = eta_ant*D_tx
    else:
        G_tx_l = 10.0**(G_tx/10.0)      # Linear values
    if G_rx is None:
        G_rx_l = eta_ant*D_rx
    else:
        G_rx_l = 10.0**(G_rx/10.0)
    G_2_way = G_tx_l*G_rx_l
    if P_avg is not None or P_avg != 0.0:
        if silent_flag is False:
            print('sarsens: calculanting sigma noise equivalent...')
        sigma_noise = (4.*(4.*np.pi*R_1)**3.*N*v_orb*np.sin(theta_1-slope_angle))/((P_avg/P_avg_spread)*G_2_way*lambda_0**3.*c)
        sigma_noise_edge = (4.*(4.*np.pi*R_1)**3.*N*v_orb*np.sin(theta_1-slope_angle))/((P_avg/P_avg_spread)*rel_gain_swath_edge*G_2_way*lambda_0**3.*c)
        sne = 10.0*np.log10(sigma_noise)+L_proc_and_atm
        sne_edge = 10.0*np.log10(sigma_noise_edge)+L_proc_and_atm
        # Return a named tuple!
        tuple_res = namedtuple('tuple_res', ['sigma_ne', 'sigma_ne_edge',
                                             'Brg', 'P_avg', 'swath_3dB',
                                             'subswath_3dB', 'R'])
        result = tuple_res(sne, sne_edge, NBW, P_avg, swath_3dB, sub_swath_3dB,
                           R_1)
        return result
    else:
        if silent_flag is False:
            print('sarsens: calculating average power...')
        sigma_noise_l = 10.0**(sigma_noise/10.0)
        Pow = (P_avg_spread*4.*(4.*np.pi*R_1)**3.*N*v_orb*np.sin(theta_1-slope_angle))/(G_2_way*lambda_0**3.*c*sigma_noise_l)
        Pow_tot = Pow+10.0**(L_proc_and_atm/10.0)
        # Return a tuple!
        tuple_res = namedtuple('tuple_res', ['P_avg', 'Brg', 'sigma_ne',
                                             'swath_3dB', 'subswath_3dB', 'R'])
        result = tuple_res(Pow_tot, NBW, sigma_noise, swath_3dB, sub_swath_3dB,
                           R_1)
        return result


def sarstruct2sens(sar, v_orb=None, theta_ang=None, Brg=None, grg_res=None,
                   az_res=None, swath=None, L_el_tx=None, L_el_rx=None,
                   L_az_tx=None, L_az_rx=None, ap_eff=None, eta_ant=None, 
                   NF=None, losses=None, sigma_ne=None, reflector=False, 
                   show=None, silent=False):

    """ Function that makes a sensitivity analysis in terms of NESZ for
        a given SAR sensor.

        Given a SAR defiened by a set of parameters passed as a configuration
        file, calculates::

            - Single look noise equivalent sigma zero.
            - Required average power.
            
        :author: Maria Sanjuan-Ferrer

        :param sar: Selected SAR sensor for the analysis.
                    Actual possibilities: 'airKa', 'arrsignal', 'asar',
                    'ESA_KaBand_p48', 'fsar', 'glistin', 'lupe', 'microsar',
                    'reflsignal', 'roksar', 'terrasar'.
        :type sar: string
        :param v_orb: Orbital velocity (m/s). Optional.
        :type v_orb: float
        :param theta_ang: Incidence angle (deg). Optional.
        :type theta_ang: float or 1-D float array
        :param Brg: Range bandwidth (Hz). Optional.
        :type Brg: float
        :param grg_res: Ground range resolution (m). Optional.
        :type grg_res: float
        :param az_res: Azimuth resolution (m). Optional.
        :type az_res: float
        :param swath: Swath (m). Optional.
        :type swath: float 
        :param L_el_tx: Antenna width in tx (m). Optional.
        :type L_el_tx: float
        :param L_el_rx: Antenna width in rx (m). Optional.
        :type L_el_rx: float
        :param L_az_tx: Azimuth dimension of antenna in tx (m). Optional.
        :type L_az_tx: float
        :param L_az_rx: Azimuth dimension of antenna in rx (m). Optional.
        :type L_az_rx: float
        :param ap_eff: Aperture efficiency. Optional.
        :type ap_eff: float
        :param eta_ant: Radiation efficiency of antenna. Optional.
        :type eta_ant: float
        :param NF: Noise Figure (dB). Optional.
        :type NF: float
        :param losses: Different losses due to processing or atmosphere (dB).
                       Optional.
        :type losses: float
        :param sigma_ne: Noise equivalent sigma zero (dB). Optional.
        :type sigma_ne: float 
        :param reflector: Reflector flag. Optional. If True, both antennas in tx
                          and rx are considered reflectors.
        :type reflector: bool
        :param show: Flag for plotting. Optional. If True, a figure with
                     sigma_ne as a function of incidence angle is displayed.
        :type show: bool
        :param silent: Silent flag. Optional. If True, no prints during computation.
        :type silent: bool

        :returns: tuple.
    """
    # Get the complete path to the configuration file
    sar_file = sarsens_filename(sar)
    # Read the file
    sensor = ConfigFile(sar_file)

    if v_orb is None:
        v_orb = sensor.param.v_orb
    if theta_ang is None:
        theta_ang = sensor.param.theta
    if Brg is None:
        Brg = sensor.param.Brg
    if grg_res is None:
        grg_res = sensor.param.grg_res
    if az_res is None:
        az_res = sensor.param.az_res
    if swath is None:
        swath = sensor.param.swath
    if L_el_tx is None:
        L_el_tx = sensor.param.L_el_tx
    if L_el_rx is None:
        L_el_rx = sensor.param.L_el_rx
    if L_az_tx is None:
        L_az_tx = sensor.param.L_az_tx
    if L_az_rx is None:
        L_az_rx = sensor.param.L_az_rx
    if ap_eff is None:
        ap_eff = sensor.param.ap_eff
    if eta_ant is None:
        eta_ant = sensor.param.eta_ant
    if losses is not None:
        L_proc_and_atm = 1.0*losses   # [dB]
    else:
        L_proc_and_atm = 0.0          # [dB]
    if NF is None:
        NF = sensor.param.NF
    if sigma_ne is not None:
        sigma_noise = sigma_ne
        P_avg = 0.0
    else:
        sigma_noise = sensor.param.sigma_noise
        P_avg = sensor.param.P_avg
    if reflector is None:
        reflector = sensor.param.reflector_flag

    #Passing the parameters to sarsens
    if np.size(theta_ang) is 1:
        res = sarsens(h_sar=sensor.param.h_sar, v_orb=v_orb,
                      f0=sensor.param.f0, theta=theta_ang, Brg=Brg,
                      grg_res=grg_res, az_res=az_res, swath=swath,
                      L_el_tx=L_el_tx, L_el_rx=L_el_rx, L_az_tx=L_az_tx,
                      L_az_rx=L_az_rx, ap_eff=ap_eff, eta_ant=eta_ant, NF=NF,
                      L_proc_and_atm=L_proc_and_atm, sigma_noise=sigma_noise,
                      P_avg=P_avg, reflector=reflector, silent_flag=silent)
        P_avg = res.P_avg
        sigma_noise = res.sigma_ne
         # Look angle
        theta_ang_1 = (np.pi*theta_ang)/180.0
        look_theta_1 = inc_to_look(theta_ang_1, sensor.param.h_sar)
        look_theta = (180.0*look_theta_1)/np.pi
         # Return a named tuple!
        final = namedtuple('final', ['theta', 'look_theta', 'P_avg',
                                     'sigma_ne', 'Brg', 'swath_3dB',
                                     'subswath_3dB', 'R'])
        res_final = final(theta_ang, look_theta, P_avg, sigma_noise, res.Brg,
                          res.swath_3dB, res.subswath_3dB, res.R)
        return res_final
    else:
        Nthetas = 100
        thetas = ((np.arange(Nthetas)/(Nthetas-1.0))*(np.max(theta_ang) -
                  np.min(theta_ang))+np.min(theta_ang))
        P_avgs = np.zeros(Nthetas)
        sigma_nes = np.zeros(Nthetas)
        sigma_nes_edge = np.zeros(Nthetas)
        Brgs = np.zeros(Nthetas)
        swaths_3dB = np.zeros(Nthetas)
        subswaths_3dB = np.zeros(Nthetas)
        srgs = np.zeros(Nthetas)
        for ind in range(Nthetas):
            res = sarsens(h_sar=sensor.param.h_sar, v_orb=v_orb,
                          f0=sensor.param.f0, theta=thetas[ind],
                          Brg=Brg, grg_res=grg_res, az_res=az_res,
                          swath=swath, L_el_tx=L_el_tx, L_el_rx=L_el_rx,
                          L_az_tx=L_az_tx, L_az_rx=L_az_rx, ap_eff=ap_eff,
                          eta_ant=eta_ant, NF=NF, L_proc_and_atm=L_proc_and_atm,
                          sigma_noise=sigma_noise, P_avg=P_avg,
                          reflector=reflector, silent_flag=silent)

            P_avgs[ind] = res.P_avg
            sigma_nes[ind] = res.sigma_ne
            sigma_nes_edge[ind] = res.sigma_ne_edge
            Brgs[ind] = res.Brg
            swaths_3dB[ind] = res.swath_3dB
            subswaths_3dB[ind] = res.subswath_3dB
            srgs[ind] = res.R
        sigma_nes = sigma_nes - 10.0*np.log10(np.abs(sensor.param.MAPS))
        if show is True:
            plt.figure()
            #plt.subplot(2, 1, 1)
            v = ([np.min(thetas), np.max(thetas), np.min(sigma_nes),
                  np.max(sigma_nes_edge)])
            plt.axis(v)
            plt.plot(thetas, sigma_nes, label='NESZ', color='red',
                     linewidth=2)
            plt.plot(thetas, sigma_nes_edge, label='NESZ'+r'$_{edge}$',
                     color='blue', linewidth=2)
            plt.xlabel('Incidence angle ['+r'$^{\circ}$'+']')
            plt.ylabel('NESZ [dB]')
            plt.grid(True)
            plt.legend(loc='upper left')
#            plt.subplot(2, 1, 2)
#            u = ([np.min(thetas), np.max(thetas), 0.0,
#                  np.max(swaths_3dB)/1.0e3])
#            plt.axis(u)
#            plt.plot(thetas, swaths_3dB/1.0e3, label='Swath', color='red',
#                     linewidth=2)
#            plt.plot(thetas, subswaths_3dB/1.0e3, label='Sub-swath',
#                     color='blue', linewidth=2)
#            plt.xlabel('Incidence angle ['+r'$^{\circ}$'+']')
#            plt.ylabel('3 dB swath [km]')
#            plt.grid(True)
#            plt.legend(loc='upper left')
            plt.show()
        thetas_1 = (np.pi*thetas)/180.
        look_thetas_1 = inc_to_look(thetas_1, sensor.param.h_sar)
        look_thetas = (180.0*look_thetas_1)/np.pi
        Re = const.r_earth
        grgs = (thetas_1-look_thetas_1)*Re
        # Return a named tuple!
        final = namedtuple('final', ['theta', 'look_theta', 'P_avg',
                                     'sigma_ne', 'sigma_ne_edge', 'Brg',
                                     'swath_3dB', 'subswath_3dB', 'coverage',
                                     'az_res', 'aasr', 'rasr', 'R', 'gR',
                                     'h_sar'])
        az_resol = L_az_tx/2.0
        res_final = final(thetas, look_thetas, P_avgs, sigma_nes,
                          sigma_nes_edge, Brgs, swaths_3dB, subswaths_3dB,
                          np.ones(Nthetas, int),
                          az_resol*np.ones(Nthetas),
                          (1./100.)*np.ones(Nthetas),
                          (1./1000.)*np.ones(Nthetas),
                          srgs, grgs, sensor.param.h_sar)
        return res_final
