
import numpy as np
from scipy import interpolate
from scipy import constants 

#from drama.performance.sar import sinc_bp
from drama.io import InstrumentErrorsFile


class InstrumentErrors(object):
    """ Instrument Error Model for SAR System with 1 TX channel and
        N RX Channels.

        This class provides a sinc antenna pattern with added errors
        and slow-time errors.

        * Pattern can be calculated using ``pattern`` function
        * Slow-time Error is held by ``beta_noise`` class property

    """

    def __init__(self):
        self.initialized = False

    def init(self, f0, ant_L, num_ch, num_az, num_rg,
             sigma_n_tx, phase_n_tx, sigma_beta_tx, phase_beta_tx,
             sigma_n_rx, phase_n_rx, sigma_beta_rx, phase_beta_rx,
             field=True, seed=None, num_tiles=8):

        """ Initialize Errors

            :param f0: Radar frequency
            :param ant_L: Antenna length (in azimuth)
            :param num_ch: Number of channels
            :param num_az: Azimuth samples
            :param num_rg: Range samples
            :param sigma_n_tx: TX (Spatial) Ampl. [dB]
            :param phase_n_tx: TX (Spatial) Phase [Rad]
            :param sigma_beta_tx: TX (Slow-time) Ampl. [dB]
            :param phase_beta_tx: TX (Slow-time) Phase [Rad]
            :param sigma_n_rx: RX (Spatial) Ampl. [dB]
            :param phase_n_rx: RX (Spatial) Phase [Rad]
            :param sigma_beta_rx: RX (Slow-time) Ampl. [dB]
            :param phase_beta_rx: RX (Slow-time) Phase [Rad]
            :param field: Pattern in field units
            :param num_tiles: defaults to 8
        """

        # Random seed
        if seed:
            np.random.seed(seed)

        
        samples_per_tile = 4
        zeropf = 15
        c0 = constants.speed_of_light
        ## PATTERN ##

        # TX (1-CH)
        ant_coef = np.ones(num_tiles * samples_per_tile)
        err_tx_amp = np.repeat((np.sqrt(10.**(sigma_n_tx/10.)) - 1)*np.random.normal(size=num_tiles), samples_per_tile)
        err_tx_pha = np.repeat(phase_n_tx*np.random.normal(size=num_tiles), samples_per_tile)

        bp_tx_fft = np.concatenate([ant_coef + err_tx_amp + 1j*err_tx_pha, np.zeros(num_tiles * samples_per_tile * zeropf)])

        delta_az_ang = 0.89 * c0 / f0 / ant_L / (1. + zeropf)

        self.az_ang = delta_az_ang * (np.arange(0, bp_tx_fft.shape[0])-np.round(0.5*(bp_tx_fft.shape[0]-1.)))
        self.sin_az = self.az_ang  # small angles!

        self.bp_tx_err_tot = np.fft.fftshift(np.fft.ifft(bp_tx_fft))

        # Initialize TX interpolators
        self.intp_tx_re = interpolate.interp1d(self.az_ang, self.bp_tx_err_tot.real)
        self.intp_tx_im = interpolate.interp1d(self.az_ang, self.bp_tx_err_tot.imag)

        # RX (N-CH)
        self.bp_rx_err_tot = np.zeros([num_ch, bp_tx_fft.shape[0]], dtype=np.complex)

        for ch in np.arange(num_ch):
            ant_coef_rx = np.ones(num_tiles * samples_per_tile / num_ch)
            err_rx_amp = np.repeat((np.sqrt(10.**(sigma_n_rx/10.)) - 1)*np.random.normal(size=num_tiles/num_ch), samples_per_tile)
            err_rx_pha = np.repeat(phase_n_rx*np.random.normal(size=num_tiles/num_ch), samples_per_tile)

            bp_rx_fft = np.concatenate([ant_coef_rx + err_rx_amp + 1j*err_rx_pha, np.zeros(ant_coef.shape[0]-ant_coef_rx.shape[0]), np.zeros(num_tiles * samples_per_tile * zeropf)])

            self.bp_rx_err_tot[ch] = np.fft.fftshift(np.fft.ifft(bp_rx_fft))


        # Range of computed values [sin(az_angle)]
        # FIXME: AVOID 'RANDOMLY' DECIDED CONSTANTS
        #delta_sin_az = np.pi/2.e5
        #num_points = 3600
        #self.sin_az = delta_sin_az*np.arange(-num_points/2, num_points/2)

        # TX (1-CH)
        #bp_tx = sinc_bp(self.sin_az, ant_L, f0, field=field)
        #err_tx_amp = np.sqrt(10.**(sigma_n_tx/10.) - 1)*np.random.normal(size=num_points)
        #err_tx_pha = phase_n_tx*np.random.normal(size=num_points)

        #bp_tx_fft = np.fft.fft(bp_tx)
        #wh = np.where(20.*np.log10(np.abs(bp_tx_fft)) < (np.max(20.*np.log10(np.abs(bp_tx_fft))) - 3.))
        #err_tx_amp[wh] = 0.
        #err_tx_pha[wh] = 0.
        #self.bp_tx_err_tot = np.fft.ifft(bp_tx_fft + err_tx_amp + 1j*err_tx_pha)

        # Initialize TX interpolators
        #self.intp_tx_re = interpolate.interp1d(self.sin_az, self.bp_tx_err_tot.real)
        #self.intp_tx_im = interpolate.interp1d(self.sin_az, self.bp_tx_err_tot.imag)

        # RX (N-CH)
        #self.bp_rx_err_tot = np.zeros([num_ch, num_points], dtype=np.complex)
        #for ch in np.arange(num_ch):
        #    bp_rx = sinc_bp(self.sin_az, ant_L/num_ch, f0, field=field)
        #    err_rx_amp = np.sqrt(10.**(sigma_n_rx/10.) - 1.)/np.sqrt(1./num_ch)*np.random.normal(size=num_points)
        #    err_rx_pha = phase_n_rx/np.sqrt(1./num_ch)*np.random.normal(size=num_points)
        #
        #    bp_rx_fft = np.fft.fft(bp_rx)
        #    wh = np.where(20.*np.log10(np.abs(bp_rx_fft)) < np.max(20.*np.log10(np.abs(bp_rx_fft))) - 3.)
        #    err_rx_amp[wh] = 0.
        #    err_rx_pha[wh] = 0.
        #    self.bp_rx_err_tot[ch] = np.fft.ifft(bp_rx_fft + err_rx_amp + 1j*err_rx_pha)

        ## SLOW-TIME ERROR ##
        self.rand_sigma_beta_tx = (np.sqrt(10.**(sigma_beta_tx/10.)) - 1.)*np.random.normal(size=[num_az])
        self.rand_sigma_beta_rx = (np.sqrt(10.**(sigma_beta_rx/10.)) - 1.)*np.random.normal(size=[num_ch, num_az])
        self.rand_sigma_phase_tx = phase_beta_tx*np.random.normal(size=[num_az])
        self.rand_sigma_phase_rx = phase_beta_rx*np.random.normal(size=[num_ch, num_az])

        # Replicate in RG axis
        self.rand_sigma_beta_tx = np.repeat(self.rand_sigma_beta_tx[:, np.newaxis], num_rg, axis=1)
        self.rand_sigma_beta_rx = np.repeat(self.rand_sigma_beta_rx[:, :, np.newaxis], num_rg, axis=2)
        self.rand_sigma_phase_tx = np.repeat(self.rand_sigma_phase_tx[:, np.newaxis], num_rg, axis=1)
        self.rand_sigma_phase_rx = np.repeat(self.rand_sigma_phase_rx[:, :, np.newaxis], num_rg, axis=2)

        # Initialize interpolators/noise
        self.__init_errors()


    def load(self, errors_file):

        # Open file
        errors = InstrumentErrorsFile(errors_file, 'r')

        # Load content
        self.sin_az = errors.get('sin_az')
        self.bp_tx_err_tot = errors.get('bp_tx_err_tot*')
        self.bp_rx_err_tot = errors.get('bp_rx_err_tot*')
        self.rand_sigma_beta_tx = errors.get('rand_sigma_beta_tx')
        self.rand_sigma_beta_rx = errors.get('rand_sigma_beta_rx')
        self.rand_sigma_phase_tx = errors.get('rand_sigma_phase_tx')
        self.rand_sigma_phase_rx = errors.get('rand_sigma_phase_rx')

        errors.close()

        # Initialize interpolators/noise
        self.__init_errors()

    def save(self, errors_file):

        if not self.initialized:
            raise Exception('Errors not initialized')

        # Create file
        errors = InstrumentErrorsFile(errors_file, 'w', self.bp_rx_err_tot.shape, self.rand_sigma_beta_rx.shape)

        # Save content
        errors.set('sin_az', self.sin_az)
        errors.set('bp_tx_err_tot*', self.bp_tx_err_tot)
        errors.set('bp_rx_err_tot*', self.bp_rx_err_tot)
        errors.set('rand_sigma_beta_tx', self.rand_sigma_beta_tx)
        errors.set('rand_sigma_beta_rx', self.rand_sigma_beta_rx)
        errors.set('rand_sigma_phase_tx', self.rand_sigma_phase_tx)
        errors.set('rand_sigma_phase_rx', self.rand_sigma_phase_rx)

        errors.close()

    def __init_errors(self):

        # Initialize TX interpolators
        self.intp_tx_re = interpolate.interp1d(self.sin_az, self.bp_tx_err_tot.real)
        self.intp_tx_im = interpolate.interp1d(self.sin_az, self.bp_tx_err_tot.imag)

        # Initialize RX interpolators
        self.intp_rx_re = []
        self.intp_rx_im = []
        for ch in np.arange(self.bp_rx_err_tot.shape[0]):
            self.intp_rx_re.append(interpolate.interp1d(self.sin_az, self.bp_rx_err_tot.real[ch]))
            self.intp_rx_im.append(interpolate.interp1d(self.sin_az, self.bp_rx_err_tot.imag[ch]))

        # Initialize beta noise
        self.beta_noise = np.zeros(self.rand_sigma_beta_rx.shape, dtype=np.complex)
        for ch in np.arange(self.rand_sigma_beta_rx.shape[0]):
            self.beta_noise[ch] = 1. + self.rand_sigma_beta_tx + 1j*self.rand_sigma_phase_tx + \
                                  self.rand_sigma_beta_rx[ch] + 1j*self.rand_sigma_phase_rx[ch]

        self.initialized = True

    def pattern(self, sin_angle, ch):

        if not self.initialized:
            raise Exception('Errors not initialized')

        # Evaluate at required values
        bp_tx_re = self.intp_tx_re(sin_angle.flatten()).reshape(sin_angle.shape)
        bp_tx_im = self.intp_tx_im(sin_angle.flatten()).reshape(sin_angle.shape)
        bp_rx_re = self.intp_rx_re[ch](sin_angle.flatten()).reshape(sin_angle.shape)
        bp_rx_im = self.intp_rx_im[ch](sin_angle.flatten()).reshape(sin_angle.shape)

        bp_tx = bp_tx_re + 1j*bp_tx_im
        bp_rx = bp_rx_re + 1j*bp_rx_im

        return bp_tx*bp_rx

