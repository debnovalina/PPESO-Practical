import numpy as np
from drama import constants as const
from drama.geo import orbit as orb
from drama.geo.sar import geometry as geo
import matplotlib.pyplot as plt
from matplotlib import gridspec


def calc_snr_post(Loss, Tsys, P_avg, wvlength, L_az, L_el, horb_spec=None,
                  orbit_alt=None, theta_inc=None, win=27, BW=None,
                  total_res=None, sw_tot=None, step=1000, plotFactors=0):
    """ calculates the NESZ and some other stuff

        :author: Jalal Matar

        :date: 05.11.2015

        :param Loss: System Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param Pavg: average power [Watt]
        :param wvlength: wavelength of transmitted signal
        :param L_az: antenna's length in azimuth [m]
        :param L_el: antenna's length in elivation [m]
        :param horb_spec: display single pt on plot with ths abscissa
        :param theta_inc: minimum incidence angle [deg]
        :param win: theta_inc span on each side [deg]
        :param BW: system bandwidth [Hz]
        :param total_res: required total resolution (delta_az x delta_gr)
        :param step: horb plot step in [m]

    """
    Loss = 10**(Loss/10)

    if orbit_alt is None:
        h_orb = np.arange(100e03, 35678e03, step, dtype=float)
    elif len(orbit_alt) > 1:
        h_orb = np.arange(orbit_alt[0], orbit_alt[1], step, dtype=float)
    else:
        h_orb = orbit_alt
    theta_inc_c = theta_inc + win/2
    # azimuthal gain factor
    G_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(np.radians(theta_inc_c) -
                   geo.inc_to_look(np.radians(theta_inc_c), h_orb)))
    theta_az = wvlength/L_az
    theta_el = wvlength/L_el

    # total antenna gain
    G_tx1 = 16/(np.sin(theta_el)*np.sin(theta_az))

    A_eff = L_el*L_az  # effective antenna area
    v_sat = orb.orbit_to_vel(h_orb)  # satellite's velocity

    # PRF (lower bound)
    PRF1 = 2*v_sat/L_az
    # PRF (upper bound)
    PRF2 = const.c*L_el/(2*wvlength*h_orb*np.tan(np.radians(theta_inc_c)))

    # look angles from incident angles
    look1 = geo.inc_to_look(np.radians(theta_inc), h_orb)
    look2 = geo.inc_to_look(np.radians(theta_inc + win), h_orb)

    # swath width limits (PRF related)
    sw1 = const.c/(2*PRF1*np.sin(np.radians(theta_inc_c)))  # upper bound
    sw2 = const.c/(2*PRF2*np.sin(np.radians(theta_inc_c)))  # lower bound

    # set total swath width to access area if not defined
    if sw_tot is None:
        sw0 = (2*const.r_earth *
               np.arcsin(h_orb*(np.tan(look2) - np.tan(look1)) /
                         (2*const.r_earth)))
    else:
        sw0 = sw_tot
        sw0 = np.ones(h_orb.shape[0])*sw0

    # get the total beamwidth (from required swath coverage)
    swi = geo.inc_to_gr(np.radians(theta_inc), h_orb)
    alpha0 = (sw0+swi)/const.r_earth
    R2 = np.sqrt((const.r_earth+h_orb)**2 + const.r_earth**2 -
                 2*(const.r_earth+h_orb)*const.r_earth*np.cos(alpha0))
    # total required beamwidth
    theta_tot = np.arcsin(np.sin(alpha0)*const.r_earth/R2) - look1

    # get the real swath from look and elivation angles
    Rg1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)  # ground range 1
    theta_lk = geo.inc_to_look(np.radians(theta_inc), h_orb)
    Rg2 = geo.inc_to_gr(geo.look_to_inc(theta_lk+theta_el, h_orb), h_orb)
    sw_real = Rg2 - Rg1  # real swath

    # loss factor (can be explained by the need to use multiple feeds inorder
    # to cover a larger swath , hence, dividing the total power among feeds)
    gFactor = theta_el/theta_tot
    G_tx = G_tx1*gFactor

    # Plot SNR
    if plotFactors:
        gFactor_dB = 10*np.log10(gFactor)
        plt.figure()
        plt.plot(h_orb*1e-06, gFactor_dB)
        orb_loc1 = np.where(h_orb == 745e03)
        orb_loc2 = np.where(h_orb == 6901e03)
        plt.scatter(h_orb[orb_loc1]*1e-06, gFactor_dB[orb_loc1], color='r',
                    alpha=1, s=45)
        plt.scatter(h_orb[orb_loc2]*1e-06, gFactor_dB[orb_loc2], color='r',
                    alpha=1, s=45)
        plt.annotate(str(int(gFactor_dB[orb_loc1]*100)/100),
                     (h_orb[orb_loc1]*1e-06, gFactor_dB[orb_loc1]),
                     fontsize=14)
        plt.annotate(str(int(gFactor_dB[orb_loc2]*100)/100),
                     (h_orb[orb_loc2]*1e-06, gFactor_dB[orb_loc2]),
                     fontsize=14)
        plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
        plt.ylabel("Gain Factor [dB]", fontsize=14)
        plt.title('Gain Loss Fator due to Required Swath Width of ' +
                  str(np.mean(sw0)/1000) + 'km')
        plt.xlim([0, 40])

    # azimuth and ground resolutions
    delta_az = G_az*L_az/2
    delta_gr = const.c/(2*BW*np.sin(np.radians(theta_inc_c)))
    delta_gr = delta_gr*np.ones(delta_az.shape)

    # Used for comparison reasons (flexible bandwidth)
    delta_gr2 = total_res/delta_az
    BW2 = const.c/(2*delta_gr2*np.sin(np.radians(theta_inc_c)))

    # Noise Equivalent Sigma Zero
    NESZ_1 = ((((4*np.pi)**2)*(h_orb**3)*Loss*const.k*Tsys) /
              (P_avg*G_tx*A_eff))
    NESZ_2 = 2*v_sat/(wvlength*delta_gr)
    NESZ = NESZ_1 * NESZ_2
    NESZ = 10*np.log10(NESZ)

    # if bandwidth requirements are flexible
    NESZ2 = 10*np.log10(NESZ_1*2*v_sat/(wvlength*delta_gr2))

    if horb_spec is not None:
        orb_loc = np.where(h_orb == horb_spec)
    # Plots
    plt.figure()
    gs = gridspec.GridSpec(2, 2)
    plt.suptitle('Area = ' + str(int(A_eff)) + '$m^2$' +
                 '   $\\theta_{inc}$ = ' + str(theta_inc) + '$\deg$',
                 fontsize=16)
    ax1 = plt.subplot(gs[0, 0])
    ax1.plot(h_orb*1e-06, NESZ, label='BW = '+str(BW*1e-06)+'MHz')
    ax1.plot(h_orb*1e-06, NESZ2, label='lower bandwidths')
    ax1.scatter(h_orb[orb_loc]*1e-06, NESZ[orb_loc], color='r',
                alpha=1, s=45)
    ax1.scatter(h_orb[orb_loc]*1e-06, NESZ2[orb_loc], color='r',
                alpha=1, s=45)
    ax1.annotate(str(int(NESZ[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, NESZ[orb_loc]), fontsize=14)
    ax1.annotate(str(int(NESZ2[orb_loc]*100)/100) + ', BW=' +
                 str(int(BW2[orb_loc]/1e04)/100) + 'MHz',
                 (h_orb[orb_loc]*1e-06, NESZ2[orb_loc]), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.ylabel("NESZ", fontsize=14)
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.legend()
    plt.grid()

    ax2 = plt.subplot(gs[0, 1])
    ax2.plot(h_orb*1e-06, PRF1/1000., label='lower bound')
    ax2.plot(h_orb*1e-06, PRF2/1000., label='upper bound')
    ax2.scatter(h_orb[orb_loc]*1e-06, PRF1[orb_loc]/1000., color='r',
                alpha=1, s=45)
    ax2.scatter(h_orb[orb_loc]*1e-06, PRF2[orb_loc]/1000., color='r',
                alpha=1, s=45)
    ax2.annotate(str(int(PRF1[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, PRF1[orb_loc]/1000), fontsize=14)
    ax2.annotate(str(int(PRF2[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, PRF2[orb_loc]/1000), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.ylabel("PRF [KHz]", fontsize=14)
    plt.legend()
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.ylim([0, 5])
    plt.grid()

    ax3 = plt.subplot(gs[1, 0])
    ax3.plot(h_orb*1e-06, sw2/1000., label='lower limit $PRF_{max}$')
    ax3.plot(h_orb*1e-06, sw1/1000., label='upper limit $PRF_{min}$')
    ax3.plot(h_orb*1e-06, sw0/1000., label='Required (orbit)')
    ax3.plot(h_orb*1e-06, sw_real/1000., label='Real ($\\theta _{el}$)')

    ax3.scatter(h_orb[orb_loc]*1e-06, sw1[orb_loc]/1000, color='r',
                alpha=1, s=45)
    ax3.scatter(h_orb[orb_loc]*1e-06, sw2[orb_loc]/1000, color='r',
                alpha=1, s=45)
    ax3.scatter(h_orb[orb_loc]*1e-06, sw0[orb_loc]/1000, color='r',
                alpha=1, s=45)
    ax3.scatter(h_orb[orb_loc]*1e-06, sw_real[orb_loc]/1000, color='r',
                alpha=1, s=45)
    ax3.annotate(str(int(sw1[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, sw1[orb_loc]/1000), fontsize=14)
    ax3.annotate(str(int(sw2[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, sw2[orb_loc]/1000), fontsize=14)
    ax3.annotate(str(int(sw0[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, sw0[orb_loc]/1000), fontsize=14)
    ax3.annotate(str(int(sw_real[orb_loc]/10)/100),
                 (h_orb[orb_loc]*1e-06, sw_real[orb_loc]/1000), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.ylabel("Swath width [km]", fontsize=14)
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.ylim([0, 2000])
    plt.legend()
    plt.grid()

    ax4 = plt.subplot(gs[1, 1])
    ax4.plot(h_orb*1e-06, delta_az, label='$\delta_{az}$')
    ax4.plot(h_orb*1e-06, delta_gr, label='$\delta_{gr}$')
    ax4.plot(h_orb*1e-06, delta_gr2,
             label='$\delta_{gr}$ lower BW, ($\delta_{tot}$=' +
                   str(total_res) + '$m^2$)')
    ax4.scatter(h_orb[orb_loc]*1e-06, delta_gr[orb_loc], color='r',
                alpha=1, s=45)
    ax4.scatter(h_orb[orb_loc]*1e-06, delta_az[orb_loc], color='r',
                alpha=1, s=45)
    ax4.scatter(h_orb[orb_loc]*1e-06, delta_gr2[orb_loc], color='r',
                alpha=1, s=45)
    ax4.annotate(str(int(delta_gr[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, delta_gr[orb_loc]), fontsize=14)
    ax4.annotate(str(int(delta_az[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, delta_az[orb_loc]), fontsize=14)
    ax4.annotate(str(int(delta_gr2[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, delta_gr2[orb_loc]), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.ylabel("Resolution [m]", fontsize=14)
    plt.legend()
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.grid()

    return NESZ


def snr_post_spec(Loss, Tsys, P_avg, orbit_alt, wvlength, delta_az,
                  delta_gr, theta_inc=None, BW=None, step=1, sw_tot=None,
                  antenna='planar'):
    """ Calculates and plots the NESZ, antenna dimensions and swath width
        for a sepcific orbit with variable incident angles

        :author: Jalal Matar

        :date: 06.11.2015

        :param Loss: Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param Pavg: average power [Watt]
        :param orbit_alt: orbital altitude [m]
        :param wvlength: wavelength of transmitted signal
        :param delta_az: azimuthal resolution [m]
        :param delta_el: elivation resolution [m]
        :param theta_inc: incidence angles [deg]
        :param BW: system bandwidth [Hz]
        :param step: horb plot step in [m]
        :param sw_tot: required swath cover [m] ( if None, make sure that
                       incidence angle limits represent  the ones required
                       for global coverage)
        :param antenna: planar or parabolic
    """
    Loss = 10**(Loss/10)
    h_orb = orbit_alt
    v_sat = orb.orbit_to_vel(h_orb)  # cst

    if theta_inc is None:
        theta_inc_deg = np.arange(20, 50, 1, dtype=float)
    else:
        theta_inc_deg = np.arange(int(theta_inc[0]), int(theta_inc[1]), step,
                                  dtype=float)
    theta_inc_rad = np.radians(theta_inc_deg)

#    BW = const.c / (2*delta_gr*np.sin(theta_inc_rad))

    # azimuthal gain factor
    G_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(theta_inc_rad -
                   geo.inc_to_look(theta_inc_rad, h_orb)))

    A_eff_min = np.ceil(4*v_sat*wvlength*h_orb*np.tan(theta_inc_rad)/const.c)

    if antenna == 'parabolic':
        eff = 0.7
        f_ant = 1.22
        D = 2*delta_az/G_az*f_ant/1.12
        A_eff = np.pi * ((D/2)**2) * eff  # assume 70% efficiency
        G_tx1 = 4 * np.pi * A_eff / (wvlength**2)
#        theta_az
        theta_el = np.radians(70*wvlength/D)
        L_el = wvlength/theta_el

    else:
        f_ant = 0.89
        L_az = 2*delta_az/G_az*f_ant
        L_el_min = A_eff_min/L_az
        L_el = L_el_min + 10
        A_eff = L_az*L_el
        theta_az = wvlength/L_az
        theta_el = wvlength/L_el
        G_tx1 = 16/(np.sin(theta_el)*np.sin(theta_az))

    theta_lk = geo.inc_to_look(theta_inc_rad, h_orb)

    # get the total beamwidth
    if sw_tot is None:
        sw0 = (2*const.r_earth *
               np.arcsin(h_orb*(np.tan(theta_lk[-1]) - np.tan(theta_lk[0])) /
                         (2*const.r_earth)))
        sw0 = int(np.ceil(sw0/1000)*1000)
    else:
        sw0 = sw_tot
    swi = geo.inc_to_gr(theta_inc_rad, h_orb)
    alpha0 = (sw0+swi)/const.r_earth
    R2 = np.sqrt((const.r_earth+h_orb)**2 + const.r_earth**2 -
                 2*(const.r_earth+h_orb)*const.r_earth*np.cos(alpha0))
    theta_tot = np.arcsin(np.sin(alpha0)*const.r_earth/R2) - theta_lk

    # get the real swath
#    Rg1 = geo.inc_to_gr(theta_inc_rad, h_orb)  # ground range 1
#    Rg2 = geo.inc_to_gr(geo.look_to_inc(theta_lk+theta_el, h_orb), h_orb)
#    sw_real = Rg2 - Rg1  # real swath
    theta_2 = np.arcsin(np.sin(theta_lk + theta_el)*(const.r_earth + h_orb) /
                        const.r_earth)
    sw_real = const.r_earth*(theta_2 - theta_inc_rad - theta_el)
    gFactor = theta_el/theta_tot
    G_tx = G_tx1*gFactor

    # PRF (lower bound)
    PRF1 = v_sat/delta_az
    # PRF (upper bound)
    PRF2 = const.c*L_el/(2*wvlength*h_orb*np.tan(theta_inc_rad))

    # Swath (upper bound)
    sw1 = const.c/(2*PRF1*np.sin(theta_inc_rad))

    NESZ_1 = ((((4*np.pi)**2)*(h_orb**3)*Loss*const.k*Tsys) /
              (P_avg*G_tx*A_eff))
    NESZ_2 = 2*v_sat/(wvlength*delta_gr)
    NESZ = NESZ_1 * NESZ_2
    NESZ = 10*np.log10(NESZ)

    # Plots
    plt.figure()
    gs = gridspec.GridSpec(2, 2)
    plt.suptitle('$H_{sat}$ = ' + str(int(h_orb/1000)) + 'km' +
                 '   $\delta _{az}$ = ' + str(delta_az) + 'm' +
                 '   $\delta _{gr}$ = ' + str(delta_gr) + 'm',
                 fontsize=16)
    ax1 = plt.subplot(gs[0, 0])
    ax1.plot(theta_inc_deg, NESZ)
    plt.xlabel("Incidence angle [deg]", fontsize=14)
    plt.ylabel("NESZ", fontsize=14)
    plt.grid()

    ax2 = plt.subplot(gs[0, 1])
    ax2.plot(theta_inc_deg, np.ones(theta_inc_deg.shape[0])*PRF1,
             label='$PRF_{min}$')
    ax2.plot(theta_inc_deg, PRF2, label='$PRF_{max}$')
    plt.xlabel("Incidence angle [deg]", fontsize=14)
    plt.ylabel("PRF [Hz]", fontsize=14)
    plt.grid()
    plt.legend()

    if antenna == 'planar':
        ax3 = plt.subplot(gs[1, 0])
        ax3.plot(theta_inc_deg, L_el_min, label='$width_{min}$')
        ax3.plot(theta_inc_deg, L_el, label='$width_{chosen}$')
        ax3.plot(theta_inc_deg, L_az, label='length')
        plt.xlabel("Incidence angle [deg]", fontsize=14)
        plt.ylabel("Antenna dimensions [m]", fontsize=14)
        plt.grid()
        plt.legend()
    elif antenna == 'parabolic':
        ax3 = plt.subplot(gs[1, 0])
        ax3.plot(theta_inc_deg, A_eff/eff)
        plt.xlabel("Incidence angle [deg]", fontsize=14)
        plt.ylabel("$A_{ant}$ [m2]", fontsize=14)
        plt.grid()

    ax4 = plt.subplot(gs[1, 1])
    ax4.plot(theta_inc_deg, sw1/1000., label='$swath_{max}$')
    ax4.plot(theta_inc_deg, sw_real/1000., label='$swath_{real}$')
#    ax4.plot(theta_inc_deg, np.ones(theta_inc_deg.shape[0])*sw0/1000.,
#             label='$swath_{req}$')
    plt.xlabel("Incidence angle [deg]", fontsize=14)
    plt.ylabel("Swath [km]", fontsize=14)
    plt.grid()
    plt.legend()
    return NESZ


def snr_post_spec2(Loss, Tsys, P_avg, orbit_alt, wvlength, A_ant,
                   near_theta_inc=None, BW=None, step=0.01, sw_tot=None,
                   antenna='parabolic'):
    """ Calculates and plots the NESZ, antenna dimensions and swath width
        for a sepcific orbit with variable incident angles and cst antenna
        size

        :author: Jalal Matar

        :date: 06.11.2015

        :param Loss: Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param Pavg: average power [Watt]
        :param orbit_alt: orbital altitude [m]
        :param wvlength: wavelength of transmitted signal
        :param delta_az: azimuthal resolution [m]
        :param delta_el: elivation resolution [m]
        :param theta_inc: incidence angles [deg]
        :param BW: system bandwidth [Hz]
        :param step: horb plot step in [m]
        :param sw_tot: required swath cover [m] ( if None, make sure that
                       incidence angle limits represent  the ones required
                       for global coverage)
        :param antenna: planar or parabolic
    """
    Loss = 10**(Loss/10)
    h_orb = orbit_alt
    v_sat = orb.orbit_to_vel(h_orb)  # cst

    if near_theta_inc is None:
        theta_inc_deg = np.arange(20, 50, 1, dtype=float)
    else:
        theta_inc_deg = np.arange(int(near_theta_inc[0]),
                                  int(near_theta_inc[1]), step, dtype=float)
    theta_inc_rad = np.radians(theta_inc_deg)
    # azimuthal gain factor
    G_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(theta_inc_rad -
                   geo.inc_to_look(theta_inc_rad, h_orb)))

    if antenna == 'parabolic':
        eff = 0.8  # assume 80% efficiency
        f_ant = 1.22
        D = 2*np.sqrt(A_ant/np.pi)
        delta_az = D/(2*f_ant)*G_az  # *1.12
        A_eff = A_ant * eff
        G_tx1 = 4 * np.pi * A_eff / (wvlength**2)
        theta_el = np.radians(70*wvlength/D)
        L_eff = wvlength/theta_el

    delta_gr = const.c/(2*BW*np.sin(theta_inc_rad))
    theta_lk = geo.inc_to_look(theta_inc_rad, h_orb)
    theta_inc_deg2 = geo.look_to_inc((theta_lk + theta_el/2), h_orb)
    theta_inc_deg2 = np.round(np.degrees(theta_inc_deg2)*100)/100

    # get the total beamwidth
    if sw_tot is None:
        sw0 = (2*const.r_earth *
               np.arcsin(h_orb*(np.tan(theta_lk[-1] + theta_el/2) -
                                np.tan(theta_lk[0]))/(2*const.r_earth)))
        sw0 = int(np.ceil(sw0/1000)*1000)
    else:
        sw0 = sw_tot
    swi = geo.inc_to_gr(theta_inc_rad, h_orb)
    alpha0 = (sw0+swi)/const.r_earth
    R2 = np.sqrt((const.r_earth+h_orb)**2 + const.r_earth**2 -
                 2*(const.r_earth+h_orb)*const.r_earth*np.cos(alpha0))
    theta_tot = np.arcsin(np.sin(alpha0)*const.r_earth/R2) - theta_lk

    # get the real swath
    theta_2 = np.arcsin(np.sin(theta_lk + theta_el)*(const.r_earth + h_orb) /
                        const.r_earth)
    sw_real = const.r_earth*(theta_2 - theta_inc_rad - theta_el)
    n_subswath = theta_tot/theta_el
    G_tx = G_tx1/n_subswath

    # PRF (lower bound)
    PRF1 = 2*v_sat/L_eff
#    PRF1 = v_sat/delta_az
    # PRF (upper bound)
    R1 = geo.inc_to_sr(theta_inc_rad, h_orb)  # slant range near
    R2 = geo.inc_to_sr(geo.look_to_inc(theta_lk+theta_el, h_orb), h_orb)
    PRF2 = const.c/(2*(R2 - R1))

    # Swath (upper bound)
#    sw1 = const.c/(2*PRF1*np.sin(theta_inc_rad))

    NESZ_1 = ((((4*np.pi)**2)*(h_orb**3)*Loss*const.k*Tsys) /
              (P_avg*G_tx*A_eff))
    NESZ_2 = 2*v_sat/(wvlength*delta_gr)
    NESZ = NESZ_1 * NESZ_2
    NESZ = 10*np.log10(NESZ)

    # Plots
    plt.figure()
    gs = gridspec.GridSpec(4, 1, width_ratios=[1, 1, 1, 1])
    plt.suptitle('$H_{sat}$ = ' + str(int(h_orb/1000)) + 'km' +
                 '   $A _{eff}$ = ' + str(int(A_eff)) + 'm2', fontsize=16)
    ax1 = plt.subplot(gs[0, 0])
    ax1.plot(theta_inc_deg2, NESZ)
#    plt.xlabel("Near Range Incidence angle [deg]", fontsize=16)
    plt.ylabel("NESZ", fontsize=16)
    plt.grid()

    ax2 = plt.subplot(gs[1, 0])
    ax2.plot(theta_inc_deg2, np.ones(theta_inc_deg.shape[0])*PRF1,
             label='$\mathrm{PRF}_\mathrm{min}$')
    ax2.plot(theta_inc_deg2, PRF2, label='$\mathrm{PRF}_\mathrm{max}$')
#    plt.xlabel("Near Range Incidence angle [deg]", fontsize=16)
    plt.ylabel("PRF [Hz]", fontsize=16)
    plt.grid()
    plt.legend()

    ax3 = plt.subplot(gs[2, 0])
    ax3.plot(theta_inc_deg2, delta_az, label='$\delta_\mathrm{az}$')
    ax3.plot(theta_inc_deg2, delta_gr, label='$\delta_\mathrm{gr}$')
#    plt.xlabel("Near Range Incidence angle [deg]", fontsize=16)
    plt.ylabel("Resolution [m]", fontsize=16)
    plt.grid()
    plt.legend()

    ax4 = plt.subplot(gs[3, 0])
    ax4.plot(theta_inc_deg2, sw_real/1000., label='$sw_\mathrm{real}$')
    ax4.set_xlabel("Incident angle [deg]", fontsize=16)
    ax4.grid()
    ax44 = ax4.twinx()
    ax44.plot(theta_inc_deg2, n_subswath, '-g', label='$n$')
    ax4.set_ylabel("Sub-Swath width [km]", fontsize=16)
    ax44.set_ylabel("Number of Sub-Swaths $n$", fontsize=16)
    lines, labels = ax4.get_legend_handles_labels()
    lines2, labels2 = ax44.get_legend_handles_labels()
    ax44.legend(lines + lines2, labels + labels2, loc=0)

    return NESZ


def calc_EIRP_post(Loss, Tsys, NESZ, wvlength, L_az, L_el, sw_tot,
                   horb_spec=None, orbit_alt=None, theta_inc=None, win=27,
                   BW=None, pulse_width=None, PRF=None, total_res=None,
                   step=1000):
    """ calculates the NESZ and some other stuff

        :author: Jalal Matar

        :date: 05.11.2015

        :param Loss: Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param NESZ: Noise Equivalent-Sigma zero [dB]
        :param wvlength: wavelength of transmitted signal
        :param L_az: antenna's length in azimuth [m]
        :param L_el: antenna's length in elivation [m]
        :param horb_spec: display single pt on plot with ths abscissa
        :param theta_inc: minimum incidence angle [deg]
        :param win: theta_inc span on each side [deg]
        :param BW: system bandwidth [Hz]
        :param total_res: required total resolution (delta_az x delta_gr)
        :param step: horb plot step in [m]

    """
    Loss = 10**(Loss/10)
    nesz = 10**(NESZ/10)

    if orbit_alt is None:
        h_orb = np.arange(100e03, 35678e03, step, dtype=float)
    elif len(orbit_alt) > 1:
        h_orb = np.arange(orbit_alt[0], orbit_alt[1], step, dtype=float)
    else:
        h_orb = orbit_alt
    # azimuthal gain factor
    G_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(np.radians(theta_inc) -
                   geo.inc_to_look(np.radians(theta_inc), h_orb)))

    theta_az = wvlength/L_az
    theta_el = wvlength/L_el

    G_tx1 = 16/(np.sin(theta_el)*np.sin(theta_az))
    look1 = geo.inc_to_look(np.radians(theta_inc), h_orb)
    sw0 = np.ones(h_orb.shape[0])*sw_tot
    # get the total beamwidth
    swi = geo.inc_to_gr(np.radians(theta_inc), h_orb)
    alpha0 = (sw0+swi)/const.r_earth
    R2 = np.sqrt((const.r_earth+h_orb)**2 + const.r_earth**2 -
                 2*(const.r_earth+h_orb)*const.r_earth*np.cos(alpha0))

    theta_tot = np.arcsin(np.sin(alpha0)*const.r_earth/R2) - look1

    # get the real swath
#    Ws1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)
#    Ws2 = geo.inc_to_gr(np.radians(theta_inc)+theta_el, h_orb)
#    alpha1 = (2*Ws1 + Ws2)/(2*const.r_earth)
#    Rm = np.sin(alpha1)*const.r_earth/np.sin(look1+theta_el/2)
#    Wg = Rm*theta_el/np.cos(np.radians(theta_inc))
#    sw_real = 2*const.r_earth*np.arcsin(Wg/(2*const.r_earth))  # real swath
    # get the real swath
    Rg1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)  # ground range 1
    theta_lk = geo.inc_to_look(np.radians(theta_inc), h_orb)
    Rg2 = geo.inc_to_gr(geo.look_to_inc(theta_lk+theta_el, h_orb), h_orb)
    sw_real = Rg2 - Rg1  # real swath
    gFactor = theta_el/theta_tot
    G_tx = G_tx1*gFactor

    A_eff = L_el*L_az
    v_sat = orb.orbit_to_vel(h_orb)

    # [lower bound, upper bound]
#    PRF_bounds = [2*v_sat/L_az, (const.c*L_el/(2*wvlength*h_orb) /
#                                 np.tan(np.radians(theta_inc)))]
#    PRF = np.average(PRF_bounds)
#    PRF = 2*v_sat/L_az + 100
    PRF = const.c*L_el/(2*wvlength*h_orb*np.tan(np.radians(theta_inc))) - 100

    delta_gr = const.c/(2*BW*np.sin(np.radians(theta_inc)))
    delta_az = L_az/2*G_az

    eirp = ((((4*np.pi)**2)*(h_orb**3)*2*v_sat*Loss*const.k*Tsys) /
            (nesz*A_eff*wvlength*delta_gr*PRF*pulse_width))
    EIRP = 10*np.log10(eirp)

    p = eirp/G_tx
    P = 10*np.log10(p)

    p_avg = eirp/G_tx*pulse_width*PRF
#    p_avg = ((((4*np.pi)**2)*(h_orb**3)*2*v_sat*Loss*const.k*Tsys) /
#             (nesz*A_eff*G_tx*wvlength*delta_gr))
    P_avg = 10*np.log10(p_avg)

    if horb_spec is not None:
        orb_loc = np.where(h_orb == horb_spec)
    # Plots
    plt.figure()
    gs = gridspec.GridSpec(2, 2)
    plt.suptitle("NESZ = " + str(NESZ) + "dB,  PRF(" +
                 str(int(horb_spec/1000)) + "km)= " +
                 str(int(PRF[orb_loc]/10.)/100) + "KHz",  fontsize=16)
    ax1 = plt.subplot(gs[0, 0])
    ax1.plot(h_orb*1e-06, P_avg, color='b')
    ax1.set_ylabel("P_avg [dBW]", fontsize=14, color='b')
    ax1.scatter(h_orb[orb_loc]*1e-06, P_avg[orb_loc], color='r',
                alpha=1, s=45)
    ax1.annotate(str(int(P_avg[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, P_avg[orb_loc]), fontsize=14)
    ax12 = ax1.twinx()
    ax12.plot(h_orb*1e-06, p_avg/1000., color='g')
    ax12.set_ylabel("P_avg [KW]", fontsize=14, color='g')
    ax12.scatter(h_orb[orb_loc]*1e-06, p_avg[orb_loc]/1000., color='r',
                 alpha=1, s=45)
    ax12.annotate(str(int(p_avg[orb_loc]/10)/100),
                  (h_orb[orb_loc]*1e-06, p_avg[orb_loc]/1000.), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.grid()

    ax2 = plt.subplot(gs[0, 1])
    ax2.plot(h_orb*1e-06, P, color='b')
    ax2.set_ylabel("P [dBW]", fontsize=14, color='b')
    ax2.scatter(h_orb[orb_loc]*1e-06, P[orb_loc], color='r',
                alpha=1, s=45)
    ax2.annotate(str(int(P[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, P[orb_loc]), fontsize=14)
    ax22 = ax2.twinx()
    ax22.plot(h_orb*1e-06, p/1000., color='g')
    ax22.set_ylabel("P [KW]", fontsize=14, color='g')
    ax22.scatter(h_orb[orb_loc]*1e-06, p[orb_loc]/1000., color='r',
                 alpha=1, s=45)
    ax22.annotate(str(int(p[orb_loc]/10)/100),
                  (h_orb[orb_loc]*1e-06, p[orb_loc]/1000.), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.grid()

    ax3 = plt.subplot(gs[1, 0])
    ax3.plot(h_orb*1e-06, EIRP, color='b')
    ax3.set_ylabel("EIRP [dBW]", fontsize=14, color='b')
    ax3.scatter(h_orb[orb_loc]*1e-06, EIRP[orb_loc], color='r',
                alpha=1, s=45)
    ax3.annotate(str(int(EIRP[orb_loc]*100)/100),
                 (h_orb[orb_loc]*1e-06, EIRP[orb_loc]), fontsize=14)
    ax32 = ax3.twinx()
    ax32.plot(h_orb*1e-06, eirp/1000., color='g')
    ax32.set_ylabel("EIRP [KW]", fontsize=14, color='g')
    ax32.scatter(h_orb[orb_loc]*1e-06, eirp[orb_loc]/1000, color='r',
                 alpha=1, s=45)
    ax32.annotate(str(int(eirp[orb_loc]/10)/100),
                  (h_orb[orb_loc]*1e-06, eirp[orb_loc]/1000.), fontsize=14)
    plt.xlabel("Satellite's height [x1000 km]", fontsize=14)
    plt.xlim([0, np.ceil(max(h_orb)*1e-6)])
    plt.grid()
#    ax4 = plt.subplot(gs[1, 1])

    return


def nesz_var(Loss, Tsys, P_avg, wvlength, L_az, L_el, orbit_alt=None,
             horb_spec=None, theta_inc=None, win=27, BW=None,
             total_res=None, sw_tot=None, step=1000, plots='linear'):
    """ calculates the NESZ and some other stuff

        :author: Jalal Matar

        :date: 05.10.2015

        :param Loss: Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param Pavg: average power [Watt]
        :param wvlength: wavelength of transmitted signal
        :param L_az: antenna's length in azimuth [m]
        :param L_el: antenna's length in elivation [m]
        :param orbit_alt: range of orbital altitude to be studied
        :param horb_spec: display single pt on plot with ths abscissa
        :param theta_inc: minimum incidence angle [deg]
        :param win: theta_inc span on each side [deg]
        :param BW: system bandwidth [Hz]
        :param total_res: required total resolution (delta_az x delta_gr)
        :param sw_tot: required swath cover [m]
        :param step: horb plot step in [m]
        :param plots: plot axis ('linear' or 'log')
    """
    Loss = 10**(Loss/10)  # system losses

    if orbit_alt is None:
        # h_orb = np.arange(500e03, 35678e03, step, dtype=float)
        h_orb = np.arange(500e03, 15000e03, step, dtype=float)

    elif len(orbit_alt) > 1:
        h_orb = np.arange(orbit_alt[0], orbit_alt[1], step, dtype=float)
    else:
        h_orb = orbit_alt

    theta_inc_c = theta_inc + win/2
    # azimuthal gain factor
    F_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(np.radians(theta_inc_c) -
                   geo.inc_to_look(np.radians(theta_inc_c), h_orb)))
    # antenna beamwidth (azimuth and elevation)
    theta_az = wvlength/L_az
    theta_el = wvlength/L_el

    # total antenna gain
    G_tx1 = 16/(np.sin(theta_el)*np.sin(theta_az))

    A_eff = L_el*L_az  # antenna's effective area [m^2]
    v_sat = orb.orbit_to_vel(h_orb)  # satellite's velocity

    # near- and far-range look angles from icident angles
    look1 = geo.inc_to_look(np.radians(theta_inc), h_orb)
    look2 = geo.inc_to_look(np.radians(theta_inc + win), h_orb)

#    theta_el_req = sw0*np.cos(np.radians(theta_inc))/h_orb
    # set required swath width to access area if not defined
    if sw_tot is None:
        sw0 = (2*const.r_earth *
               np.arcsin(h_orb*(np.tan(look2) - np.tan(look1)) /
                         (2*const.r_earth)))
    else:
        sw0 = sw_tot
        sw0 = np.ones(h_orb.shape[0])*sw0

    # get the total beamwidth according to required swath
    swi = geo.inc_to_gr(np.radians(theta_inc_c), h_orb)
    alpha0 = (sw0+swi)/const.r_earth
    R2 = np.sqrt((const.r_earth+h_orb)**2 + const.r_earth**2 -
                 2*(const.r_earth+h_orb)*const.r_earth*np.cos(alpha0))
    # total beamwidth (elevation)
    theta_tot = np.arcsin(np.sin(alpha0)*const.r_earth/R2) - look1

#    # get the real swath
#    Rg1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)  # ground range 1
#    theta_lk = geo.inc_to_look(np.radians(theta_inc), h_orb)
#    Rg2 = geo.inc_to_gr(geo.look_to_inc(theta_lk+theta_el, h_orb), h_orb)
#    sw_real = Rg2 - Rg1  # real swath
    gFactor = theta_el/theta_tot
    G_tx = G_tx1*gFactor

    delta_az = F_az*L_az/2
    delta_gr = const.c/(2*BW*np.sin(theta_inc_c))
    delta_gr = delta_gr*np.ones(delta_az.shape)
    # Used for comparison reasons (flrxible Bandwidth)
    delta_gr2 = total_res/delta_az
#    BW2 = const.c/(2*delta_gr2*np.sin(np.radians(theta_inc)))
    NESZ_1 = ((((4*np.pi)**2)*(h_orb**3)*Loss*const.k*Tsys) /
              (P_avg*G_tx*A_eff))
    NESZ_2 = 2*v_sat/(wvlength*delta_gr)
    NESZ = NESZ_1 * NESZ_2
    NESZ = 10*np.log10(NESZ)

    # if bandwidth requirements are flexible
    NESZ2 = 10*np.log10(NESZ_1*2*v_sat/(wvlength*delta_gr2))

    # Calculate different facor in [dB]
    R_factor = 10*np.log10(h_orb**3)
    v_factor = 10*np.log10(v_sat)
    az_factor = 10*np.log10(F_az)
    tx_factor = -10*np.log10(gFactor)
    # calculate Delta-Factors
    d_R_factor = R_factor - R_factor[0]
    d_v_factor = v_factor - v_factor[0]
    d_az_factor = az_factor - az_factor[0]
    d_tx_factor = tx_factor - tx_factor[0]
    d_NESZ = NESZ2 - NESZ2[0]
#    d_NESZ = d_R_factor + d_v_factor + d_tx_factor + d_az_factor
    # ##################################################################### #
    # Plots
    if horb_spec is not None:
        orb_loc = np.zeros(len(horb_spec), dtype=int)
        for i in range(len(orb_loc)):
            orb_loc[i] = int(np.where(h_orb == horb_spec[i])[0][0])

    if plots == 'log':
        R = 10*np.log10(h_orb)
        lR = "log(Satellite's height)"
    else:
        R = h_orb*1e-06
        lR = "Satellite's height [x1000km]"

    # Single Plot I
    plt.figure()
    plt.title('NESZ and its changing factors ($R_0 =$' +
              str(int(h_orb[0]/10.)/100) + 'km)', fontsize=18)
    plt.plot(R, d_R_factor, label='$\Delta R^3$', ls='--', lw=2)
    plt.plot(R, d_v_factor, label='$\Delta \mathrm{v}_\mathrm{sat}$', ls=':',
             lw=3)
    plt.plot(R, d_az_factor,
             label='$-\Delta \delta_\mathrm{gr} = \Delta F_\mathrm{az}$',
             ls='-.', lw=2)
    plt.plot(R, d_tx_factor, label='$-\Delta G$', ls='-', lw=2)
    plt.plot(R, d_NESZ, label='$\Delta \mathrm{NESZ}$', lw=4)

    yloc = plt.ylim()[1] - np.diff(plt.ylim())/20
    xshift = np.diff(plt.xlim())/len(R)*400
    for i in range(len(orb_loc)):
        plt.axvline(R[orb_loc[i]], color='k', linestyle='--')
#        plt.text(R[orb_loc[i]] + xshift,yloc,
#                 str(int(h_orb[orb_loc[i]]/10)/100) + 'km',rotation=90,
#                 color='r', fontsize=16)
    plt.text(R[orb_loc[0]] + xshift, yloc, '(LEO) ' +
             str(int(h_orb[orb_loc[0]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.text(R[orb_loc[1]] + xshift, yloc,
             str(int(h_orb[orb_loc[1]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.xlabel(lR, fontsize=18)
    plt.ylabel("[dB]", fontsize=18)
    plt.legend(prop={'size': 18})
    plt.grid()

#    # resolutions
#    plt.figure()
#    plt.plot(R, delta_az, label='$\delta_\mathrm{az}$', ls='--')
#    plt.plot(R, delta_gr2, label='$\delta_\mathrm{gr}$')
#    plt.legend(prop={'size':18})
#    plt.grid()

    # ##################################################################### #
#    # Change factor
#    diff_power = diff/dR
#    plt.figure()
#    plt.title('NESZ change factor in terms of $R^X$ ($R_0 =$' +
#              str(int(h_orb[0]/10.)/100) + 'km)', fontsize=16)
#    plt.plot(R, diff_power)
#    yloc = plt.ylim()[1] -np.diff(plt.ylim())/20
#    xshift = np.diff(plt.xlim())/len(R)*400
#    for i in range(len(orb_loc)):
#        plt.axvline(R[orb_loc[i]], color='k', linestyle='--')
#        plt.text(R[orb_loc[i]]+xshift,yloc,
#                 str(int(h_orb[orb_loc[i]]/10)/100) + 'km',rotation=90,
#                 color='r', fontsize=14)
#    plt.ylabel('$X$')
#    plt.xlabel(lR, fontsize=14)
#    plt.grid()

#    # ##################################################################### #
#    # Change factor all
#    r_power = d_R_factor/dR
#    v_power = d_v_factor/dR
#    az_power = d_az_factor/dR
#    tx_power = -d_tx_factor/dR
#    diff_power = diff/dR
#
#    plt.figure()
#    plt.title('NESZ changing factors in terms of $R^X$', fontsize=16)
#    plt.plot(R, r_power, label='$R^3$')
#    plt.plot(R, v_power, label='$v_{sat}$')
#    plt.plot(R, az_power, label='$F_{az}$')
#    plt.plot(R, tx_power, label='$G_{tx}$')
#    plt.plot(R, diff_power, label='diff')
#
#    plt.xlabel(lR, fontsize=14)
#    plt.ylabel("$X$", fontsize=14)
#    plt.legend()
#    plt.grid()


def nesz_var2(Loss, Tsys, P_avg, wvlength, orbit_alt=None, horb_spec=None,
              theta_inc=None, BW=None, delta_az=None, delta_gr=None,
              sw_tot=None, step=1000, plots='linear'):
    """ calculates the NESZ and some other stuff

        :author: Jalal Matar

        :date: 09.11.2015

        :param Loss: Losses [dB]
        :param Tsys: system noise temparatre [K] (excluding system losses)
        :param Pavg: average power [Watt]
        :param wvlength: wavelength of transmitted signal
        :param orbit_alt: range of orbital altitude to be studied
        :param horb_spec: display dashed line on plot at this height
        :param theta_inc: minimum incidence angle [deg]
        :param BW: system bandwidth [Hz]
        :param delta_az: azimuthal resolution [m]
        :param delta_el: elivation resolution [m]
        :param sw_tot: required swath cover [m]
        :param step: horb plot step in [m]
        :param plots: plot axis ('linear' or 'log')

    """
    Loss = 10**(Loss/10)  # system losses

    if orbit_alt is None:
        # h_orb = np.arange(500e03, 35678e03, step, dtype=float)
        h_orb = np.arange(500e03, 15000e03, step, dtype=float)

    elif len(orbit_alt) > 1:
        h_orb = np.arange(orbit_alt[0], orbit_alt[1], step, dtype=float)
    else:
        h_orb = orbit_alt

    # azimuthal gain factor
    F_az = (const.r_earth/(const.r_earth + h_orb) *
            np.cos(np.radians(theta_inc) -
                   geo.inc_to_look(np.radians(theta_inc), h_orb)))

    # exact elevation according to required swath (spherical earth)
    Rg1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)  # ground range 1
    Rg2 = sw_tot + Rg1
    alpha2 = Rg2/const.r_earth
    theta_inc2r = np.arctan(np.sin(alpha2) /
                            (np.cos(alpha2) -
                             const.r_earth/(const.r_earth + h_orb)))
#    # near- and far-range look angles
    theta_lk1 = geo.inc_to_look(np.radians(theta_inc), h_orb)
    theta_lk2 = geo.inc_to_look(theta_inc2r, h_orb)
    # elevation
    theta_tot = theta_lk2 - theta_lk1
    L_el0 = wvlength/theta_tot  # antenna's length (elevation)

    L_az = 2*delta_az/F_az  # antenna's length (azimuth)
    theta_az = wvlength/L_az
    v_sat = orb.orbit_to_vel(h_orb)  # satellite's velocity

    # test PRFs
    PRF_min = 2*v_sat/L_az
    PRF_max = const.c/(2*sw_tot*np.sin(theta_lk1))
    PRF_diff = PRF_max - PRF_min
    prf500 = 1000 - PRF_diff
    prf_max_new = np.array(PRF_max)
    lss = np.where(prf500 > 0)
    prf_max_new[lss] += prf500[lss]
    prf_ct = (prf_max_new + PRF_min)/2
    sw_ct = const.c/(2*prf_ct*np.sin(theta_lk1))
    sw_new = np.zeros(PRF_min.shape) + sw_tot
    sw_new[lss] = sw_ct[lss]
#    sw_new = sw_ct
    sw_new[sw_new > sw_tot] = sw_tot
    prf_used = const.c/(2*np.sin(theta_lk1)*sw_new)

    # exact elevation according to required swath (spherical earth)
    Rg1 = geo.inc_to_gr(np.radians(theta_inc), h_orb)  # ground range 1
    Rg2 = sw_new + Rg1
    alpha2 = Rg2/const.r_earth
    theta_inc2r = np.arctan(np.sin(alpha2) /
                            (np.cos(alpha2) -
                             const.r_earth/(const.r_earth + h_orb)))
    # near- and far-range look angles
    theta_lk1 = geo.inc_to_look(np.radians(theta_inc), h_orb)
    theta_lk2 = geo.inc_to_look(theta_inc2r, h_orb)
    # elevation
    theta_el = theta_lk2 - theta_lk1
    L_el = wvlength/theta_el  # antenna's length (elevation)

    # antenna's total gain
    gFactor = theta_el/theta_tot
    G_tx = 16/(np.sin(theta_el)*np.sin(theta_az))
    G_tx = G_tx*gFactor
    A_eff = L_el*L_az  # effective antenna area [m^2]
    # ground resolution
    if delta_gr is None:
        delta_gr = const.c/(2*BW*np.sin(np.radians(theta_inc)))

    # Noise Equivalent Sigma Zero
    NESZ_1 = ((((4*np.pi)**2)*(h_orb**3)*Loss*const.k*Tsys) /
              (P_avg*G_tx*A_eff))
    NESZ_2 = 2*v_sat/(wvlength*delta_gr)
    NESZ = NESZ_1 * NESZ_2
    NESZ = 10*np.log10(NESZ)

    # Calculate different facor in [dB]
    R_factor = 10*np.log10(h_orb**3)
    v_factor = 10*np.log10(v_sat)
    area_factor = -10*np.log10(A_eff)
    gain_factor = -10*np.log10(G_tx)
    gain_factor0 = -10*np.log10(16/(np.sin(theta_tot)*np.sin(theta_az)))
    area_factor0 = -10*np.log10(L_el0*L_az)

    # calculate Delta-Factors
    d_R_factor = R_factor - R_factor[0]
    d_v_factor = v_factor - v_factor[0]
    d_area_factor = area_factor - area_factor[0]
    d_gain_factor = gain_factor - gain_factor[0]
    d_gain_factor0 = gain_factor0 - gain_factor0[0]
    d_area_factor0 = area_factor0 - area_factor0[0]

    d_NESZ = NESZ - NESZ[0]
    d_NESZ = d_R_factor + d_v_factor + d_area_factor + d_gain_factor
    # ##################################################################### #
    # Start Plots
    if horb_spec is not None:
        orb_loc = np.zeros(len(horb_spec), dtype=int)
        for i in range(len(orb_loc)):
            orb_loc[i] = int(np.where(h_orb == horb_spec[i])[0][0])
    # Plots
    if plots == 'log':
        R = 10*np.log10(h_orb)
        lR = "log(Satellite's height)"
    else:
        R = h_orb*1e-06
        lR = "Satellite's height [x1000km]"

    # PRF plots
    plt.figure()
    plt.plot(R, PRF_min, label='$PRF_\mathrm{min}$', ls='-', lw=2)
    plt.plot(R, PRF_max, label='$PRF_\mathrm{max}$', ls='-', lw=2)
    plt.plot(R, prf_max_new, label='$PRF_\mathrm{new}$', ls='-', lw=2)
    plt.plot(R, prf_used, label='$PRF_\mathrm{used}$', ls='-', lw=4)

    # dashed lines labels
    yloc = plt.ylim()[1] - np.diff(plt.ylim())/20
    xshift = np.diff(plt.xlim())/len(R)*400
    for i in range(len(orb_loc)):
        plt.axvline(R[orb_loc[i]], color='k', linestyle='--')
    plt.text(R[orb_loc[0]] + xshift, yloc, '(LEO) ' +
             str(int(h_orb[orb_loc[0]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.text(R[orb_loc[1]] + xshift, yloc,
             str(int(h_orb[orb_loc[1]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.xlabel(lR, fontsize=18)
    plt.ylabel("PRF[Hz]", fontsize=18)
    plt.legend(prop={'size': 18})
    plt.grid()

    # swath plot
    plt.figure()
    plt.title('Maximum Swath width', fontsize=18)
    plt.plot(R, sw_new/1000)
    plt.ylabel('swath width [km]', fontsize=18)
    plt.xlabel(lR, fontsize=18)
    plt.grid()

    # Beamwidth
    plt.figure()
    plt.title('$\\theta_\mathrm{el}$', fontsize=18)
    plt.plot(R, np.degrees(theta_el), label='sub')
    plt.plot(R, np.degrees(theta_tot), label='tot')
    plt.ylabel('Beamwidth [deg]', fontsize=18)
    plt.xlabel(lR, fontsize=18)
    plt.grid()
    plt.legend()

    # gFactor + aeff
    plt.figure()
    plt.title('$-\Delta A_\mathrm{eff} + -\Delta G$', fontsize=18)
    plt.plot(R, d_gain_factor + d_area_factor, label='sub_swaths', lw=2)
    plt.plot(R, d_gain_factor, label='$-\Delta G$', ls='--', lw=2)
    plt.plot(R, d_area_factor, label='$-\Delta A_\mathrm{eff}$', ls=':', lw=2)

    plt.plot(R, d_gain_factor0 + d_area_factor0, label='one_swath', ls='-',
             lw=2)
    plt.plot(R, d_gain_factor0, label='$-\Delta G - os$', ls='--', lw=2)
    plt.plot(R, d_area_factor0, label='$-\Delta A_\mathrm{eff} - os$', ls=':',
             lw=2)
    plt.xlabel(lR, fontsize=18)
    plt.ylabel('[dB]', fontsize=18)
    plt.legend(prop={'size': 18})
    plt.grid()

    # Comparison plots
    plt.figure()
    plt.title('NESZ and its changing factors ($R_0 =$' +
              str(int(h_orb[0]/10.)/100) + 'km)', fontsize=18)
    plt.plot(R, d_R_factor, label='$\Delta R^3$', ls='--',  lw=2)
    plt.plot(R, d_v_factor, label='$\Delta \mathrm{v}_\mathrm{sat}$', ls=':',
             lw=3)
    plt.plot(R, d_area_factor, label='$-\Delta A_\mathrm{eff}$', ls='-.', lw=4)
    plt.plot(R, d_gain_factor, label='$-\Delta G$', ls='-', lw=2)
    plt.plot(R, d_NESZ, label='$\Delta \mathrm{NESZ}$', lw=4)
    # dashed lines labels
    yloc = plt.ylim()[1] - np.diff(plt.ylim())/20
    xshift = np.diff(plt.xlim())/len(R)*400
    for i in range(len(orb_loc)):
        plt.axvline(R[orb_loc[i]], color='k', linestyle='--')
#        plt.text(R[orb_loc[i]] + xshift,yloc,
#                 str(int(h_orb[orb_loc[i]]/10)/100) + 'km',rotation=90,
#                 color='r', fontsize=16)
    plt.text(R[orb_loc[0]] + xshift, yloc, '(LEO) ' +
             str(int(h_orb[orb_loc[0]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.text(R[orb_loc[1]] + xshift, yloc,
             str(int(h_orb[orb_loc[1]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.xlabel(lR, fontsize=18)
    plt.ylabel("[dB]", fontsize=18)
    plt.legend(prop={'size': 18})
    plt.grid()

    # Antenna Dimensions plot
    plt.figure()
    plt.title('Required Antenna dimensions', fontsize=18)
    plt.plot(R, L_az, label='$\mathrm{azimuth}$', ls='--')
    plt.plot(R, L_el, label='$\mathrm{elevation}$', ls='-')
    # dashed lines labels
    yloc = plt.ylim()[1] - np.diff(plt.ylim())/20
    xshift = np.diff(plt.xlim())/len(R)*400
    for i in range(len(orb_loc)):
        plt.axvline(R[orb_loc[i]], color='k', linestyle='--')
    plt.text(R[orb_loc[0]] + xshift, yloc, '(LEO) ' +
             str(int(h_orb[orb_loc[0]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.text(R[orb_loc[1]] + xshift, yloc,
             str(int(h_orb[orb_loc[1]]/10)/100) + 'km', rotation=90,
             color='r', fontsize=16)
    plt.xlabel(lR, fontsize=18)
    plt.ylabel("Length[m]", fontsize=18)
    plt.legend(prop={'size': 18})
    plt.grid()
