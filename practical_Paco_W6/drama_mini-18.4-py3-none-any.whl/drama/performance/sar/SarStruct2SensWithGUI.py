import os
from drama.performance.sar import sarstruct2sens
from Tkinter import *
from tkMessageBox import showerror, showinfo, askokcancel


inform = {
    'Sensor': 'asar',
    'theta_ang': 23.0,
    'theta_mult_ang': 0,
    'show': 0,
    'silent': 0
}


def notdone():
    showerror('Not implemented', 'Not yet available')


def infopopup():
    showinfo('About', 'GUI for SarStruct2Sens program')


def surequit(win):
    ans = askokcancel('Verify exit', 'Really quit?')
    if ans:
        win.quit()


def makemenu(window):
    menubar = Frame(window)
    menubar.config()
    menubar.pack(side=TOP, fill=X)

    fbutton = Menubutton(menubar, text='File', underline=0)
    fbutton.pack(side=LEFT, fill=BOTH)
    file = Menu(fbutton)
    file.add_command(label='New...', command=notdone, underline=0)
    file.add_command(label='Open...', command=notdone, underline=0)
    file.add_command(label='Quit', command=(lambda: surequit(window)),
                     underline=0)
    fbutton.config(menu=file, font=('arial', 11, 'normal'))

    ebutton = Menubutton(menubar, text='Edit', underline=0)
    ebutton.pack(side=LEFT, fill=BOTH)
    edit = Menu(ebutton)
    edit.add_command(label='Cut', command=notdone, underline=0)
    edit.add_command(label='Paste', command=notdone, underline=0)
    edit.add_separator()
    ebutton.config(menu=edit, font=('arial', 11, 'normal'))
    submenu = Menu(edit, tearoff=True)
    submenu.add_command(label='Spam', command=window.quit, underline=0)
    submenu.add_command(label='Other', command=notdone, underline=0)
    edit.add_cascade(label='Others', menu=submenu, underline=0)

    hbutton = Menubutton(menubar, text='Help', underline=0)
    hbutton.pack(side=LEFT, fill=BOTH)
    help = Menu(hbutton)
    help.add_command(label='Help', command=notdone, underline=0)
    help.add_command(label='About', command=infopopup, underline=0)
    hbutton.config(menu=help, font=('arial', 11, 'normal'))

    return menubar


def loadEntry():
    sensor = inform['Sensor']
    sensorVar.set(sensor)
    theta = inform['theta_ang']
    thetaVar.set(theta)
    thetamult = inform['theta_mult_ang']
    thetamultVar.set(thetamult)
    show = inform['show']
    showVar.set(show)
    silent = inform['silent']
    silentVar.set(silent)


def ok():
    sar = sensorVar.get()
    multflag = bool(thetamultVar.get())
    if multflag is True:
        theta_ang = None
    else:
        theta_ang = thetaVar.get()
    show = bool(showVar.get())
    silent = bool(silentVar.get())
    "Runs the sarstruct2sens program"
    res = sarstruct2sens(sar=sar, theta_ang=theta_ang, show=show,
                         silent=silent)
    print res


if __name__ == '__main__':

    global sensorVar, thetaVar, thetamultVar, showVar, silentVar
    win = Tk()
    win.title('SarStruct2Sens')
    makemenu(win)

    frame0 = Frame(win)
    frame0.config()
    frame0.pack()
    fullpath = os.getcwd()
    photo = PhotoImage(file=os.path.join(fullpath, 'others', 'logo.gif'))
    can = Canvas(frame0, width=photo.width(), height=photo.height())
    can.config(relief=RIDGE, bd=4)
    can.pack(expand=YES, fill=BOTH)
    can.create_image(5, 5, image=photo, anchor=NW)
    ilabel = Label(frame0, text='\nInput information\n')
    ilabel.config(fg='black', font=('arial', 14, 'bold'))
    ilabel.pack(side=TOP)

    frame1 = Frame(win)
    frame1.pack()
    L1 = Label(frame1, text=" Selected sensor ")
    L1.config(fg='black', font=('arial', 12, 'bold'))
    L1.grid(row=0, column=0, sticky=W)
    sensorVar = StringVar()
    sensorVar.set('Insert name')
    sensor = Entry(frame1, textvariable=sensorVar)
    sensor.config(fg='black', font=('arial', 12, 'normal'))
    sensor.grid(row=0, column=1, sticky=W)
    L2 = Label(frame1, text=" Single theta angle ")
    L2.config(fg='black', font=('arial', 12, 'bold'))
    L2.grid(row=1, column=0, sticky=W)
    thetaVar = DoubleVar()
    thetaVar.set(0.0)
    theta = Entry(frame1, textvariable=thetaVar)
    theta.config(fg='black', font=('arial', 12, 'normal'))
    theta.grid(row=1, column=1, sticky=W)

    frame2 = Frame(win)
    frame2.pack()
    Label(frame2, text='').pack()
    thetamultVar = IntVar()
    CB1 = Checkbutton(frame2, text=" Multiple theta angle ",
                      variable=thetamultVar)
    CB1.config(fg='black', font=('arial', 12, 'normal'))
    CB1.pack(side=LEFT)
    showVar = IntVar()
    CB2 = Checkbutton(frame2, text=" Show ", variable=showVar)
    CB2.config(fg='black', font=('arial', 12, 'normal'))
    CB2.pack(side=LEFT)
    silentVar = IntVar()
    CB3 = Checkbutton(frame2, text=" Silent ", variable=silentVar)
    CB3.config(fg='black', font=('arial', 12, 'normal'))
    CB3.pack(side=LEFT)

    frame3 = Frame(win)       # Row of buttons
    frame3.pack()
    Label(frame3, text='\n').pack()
    B1 = Button(frame3, text=' Default ', command=loadEntry)
    B1.config(fg='black', font=('arial', 12, 'normal'))
    B1.pack(side=LEFT)
    B2 = Button(frame3, text=' Run ', command=ok)
    B2.config(fg='black', font=('arial', 12, 'normal'))
    B2.pack(side=LEFT)

    win.mainloop()
