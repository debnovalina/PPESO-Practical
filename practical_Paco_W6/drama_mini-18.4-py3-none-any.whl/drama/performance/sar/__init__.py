"""
=======================================================
SAR Performance Package (:mod:`trampa.performance.sar`)
=======================================================

.. currentmodule:: trampa.performance.sar

Antenna patterns
================

.. autosummary::
   :toctree: generated/

    sinc_bp
    sinc_1tx_nrx

Instrument Errors
=================

.. autosummary::
   :toctree: generated/

    InstrumentErrors

SAR Sensitivity
===============

.. autosummary::
   :toctree: generated/

    sarsens_filename
    sarsens
    sarstruct2sens

Data Simulator
==============

.. autosummary::
   :toctree: generated/

    pointSim
    back_project
    find_patch
    pt_connect
        

"""

from .antenna_patterns import sinc_bp, sinc_1tx_nrx, pattern
# from .errors import InstrumentErrors
from .SarStruct2Sens import sarsens_filename, sarsens, sarstruct2sens
#from .simulators import pointSim, back_project
from .data_patch import find_patch, pt_connect
from .azimuth_performance import calc_aasr, calc_nesz
from .system import load_mod_perf
