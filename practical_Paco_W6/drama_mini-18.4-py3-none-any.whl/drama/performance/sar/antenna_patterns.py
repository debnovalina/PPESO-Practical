from __future__ import absolute_import, division, print_function
import numpy as np
from matplotlib import pyplot as plt
# import numexpr as ne
from scipy.constants import c
import drama.utils as utls


def sinc_bp(sin_angle, L, f0, *dummy, field=False, beamwidth=None,
            sin_squint=0):
    """ Calculate pattern for a uniform illumination (sinc)

        :param sin_angle: Sin of the angle
        :param L: Antenna length
        :param f0: Frequency
        :sin_squint: Named parameter with sin of squint angle.
        :param field: If true, returned values are in EM field units, else
                      they are in power units
    """
    l = c/f0
    if beamwidth is None:
        La = L
    else:
        # Force antenna length to correspond to beamwidth
        # bw = l / La
        La = l / beamwidth

    pattern = np.sinc(La / l * (sin_angle - sin_squint))
    return pattern if field else pattern**2


def sinc_1tx_nrx(sin_angle, L, f0, num_chan, field=False, sin_squint=0):
    """ Calculate pattern for a system with 1 TX and N RX

        :param sin_angle: Sin of the angle
        :param L: Antenna length
        :param f0: Frequency
        :param num_ch: Number of receiving channels
        :sin_squint: Named parameter with sin of squint angle.
        :param field: If true, returned values are in EM field units, else
                      they are in power units
    """

    bp_tx = sinc_bp(sin_angle - sin_squint, L, f0, field)
    bp_rx = sinc_bp(sin_angle - sin_squint, L/num_chan, f0, field)

    return bp_tx*bp_rx


def phased_array(sin_angle, L, f0, N, w, field=False, beamwidth=None,
                 sin_squint=0):
    """ Calculate phased array pattern. Element pattern is assumed to be
        an ideal sinc pattern, but this could be changed in the future
        easily
        :param sin_angle: Sin of the angle
        :param L: Total antenna length
        :param f0: Frequency
        :param N: Number of receiving channels
        :param w: complex weighting of the elements, in case one wants
                  to include a tapering. Only used if it a N element
                  ndarray or a list
        :param field: If true, returned values are in EM field units, else
                      they are in power units
        :sin_squint: Named parameter with sin of squint angle.

    """

    k0 = 2 * np.pi * f0 / c
    if type(sin_angle) != np.ndarray:
        sina = np.array([sin_angle])
    else:
        sina = sin_angle  # just a copy
    try:
        ww = np.zeros(N, dtype=np.complex64)
        ww[:] = np.array(w)
        ww = ww.reshape((1, N)) / N
        #print("Applied weighting")
        #print(ww)
    except:
        ww = 1 / N
        #print("No weighting!")
    sina_s = sina - sin_squint
    shp_res = sina.shape
    sina_s = sina_s.reshape((sina.size, 1))
    elpat = sinc_bp(sina, L/N, f0, field=False)
    nkd = (k0 * L/N * np.arange(N) - L/2 + L/N/2).reshape((1, N))
    array_fact = np.sum(ww * np.exp(1j * nkd * sina_s), axis=-1)
    if sina.size == 1:
        pattern = (array_fact * elpat.flatten())[0]
    else:
        pattern = (array_fact * elpat.flatten()).reshape(shp_res)
    return pattern if field else np.abs(pattern)**2


def gaussian_bp(sin_angle, L, f0, *dummy, field=False, beamwidth=None,
                sin_squint=0):
    """ Calculates gaussian beam pattern

        :param sin_angle: Sin of the angle
        :param L: Antenna length
        :param f0: Frequency
        :param field: If true, returned values are in EM field units, else
                      they are in power units
        :sin_squint: Named parameter with sin of squint angle.
        :param beamwidth: if set, this is the beamwidth, if left as None
        then the beamwidth is calculated from the L

    """
    # exp (-(b/2)**4 / bw**2) = 0.5
    # (b/2)**2 / bw**2 = log(2)
    # bw = b/2 / sqrt(log(2)
    if beamwidth is None:
        l = c / f0
        bw = (l / L) / np.sqrt(np.log(2)) / 2
    else:
        bw = beamwidth / np.sqrt(np.log(2)) / 2

    if field:
        pattern = np.exp(- ((sin_angle - sin_squint)**2) / (2 * bw**2))
    else:
        pattern = np.exp(- ((sin_angle - sin_squint)**2) / (bw**2))

    return pattern


class pattern():
    # dictionary of pattern functions
    models = {"gaussian": gaussian_bp,
              "sinc": sinc_bp,
              "phased_array": phased_array}

    def __init__(self, f0, type_a="sinc", type_e=None, La=10.0, Le=1.0,
                 beamwidth_a=None, beamwidth_e=None,
                 squint=0, el0=0, tilt=0, el_offset=0, az_offset=0,
                 xpol2cpol=0, G0=None, Nel_a=8, Nel_e=32,
                 wa=1, we=1):
        """ Initialize pattern class
            :param f0: Frequency
            :param type_e: Function used for elevation pattern. Currently
                           "sinc" or "gaussian"
            :param type_a: Function used for azimuth pattern
            :param La: Antenna length (defaults to 10 m)
            :param Le: Antenna height (defauls to 1 m)
            :param beamwidth_e: if set, this is the elevation beamwidth (deg),
                                if left as None then the beamwidth is
                                calculated from the L
            :param beamwidth_a: if set, this is the azimuth beamwidth (deg),
                                if left as None then the beamwidth is
                                calculated from the L
            :param squint: Azimuth pointing, in degree. Defaults to 9.
            :param el0: Elevation pointing w.r.t. boresight, in degree.
                        Defaults to 0.
            :param tilt: Mechanical tilt, in degree, defaults to 0.
            :param el_offset: an offset w.r.t. to nominal phase center in (m).
                              This causes a linear phase in elevation.
            :param az_offset: same in azimuth
            :param xpol2cpol: we assume that cross pol patterns are identical
                              to copol ones, scaled by this complex factor
            :param G0: antenna gain, in dB
            :param Nel_a: Number of elements in azimuth, for a phased array
            :param Nel_e: Number of elements in azimuth, for a phased array
        """
        if type_e is None:
            type_e = type_a

        self.func_e = self.models[type_e]
        self.func_a = self.models[type_a]
        self.La = La
        self.Le = Le
        self.Na = Nel_a
        self.Ne = Nel_e
        self.wa = wa
        self.we = we
        self.beamwidth_a = (None if (beamwidth_a is None)
                            else np.radians(beamwidth_a))
        self.beamwidth_e = (None if (beamwidth_e is None)
                            else np.radians(beamwidth_e))
        self.f0 = f0
        self.wavelength = c / f0
        self.k0 = 2 * np.pi / self.wavelength
        self.squint = np.radians(squint)
        self.rel0 = np.radians(el0) - np.radians(tilt)
        self.tilt = np.radians(tilt)
        self.az_offset = az_offset
        self.el_offset = el_offset
        self.xpol2cpol = xpol2cpol
        if G0 is None:
            if (beamwidth_a is None) or (beamwidth_e is None):
                g0 = 4 * np.pi * La * Le / (self.wavelength**2)
            else:
                g0 = 4 * np.pi / (self.beamwidth_a * self.beamwidth_e)
            self.g0 = np.sqrt(g0)
        else:
            self.g0 = utls.db2lin(G0, amplitude=True)
        self.G0 = 2 * utls.db(self.g0)

    # FIXME: add elevation steering so that array patterns are correcty
    # computed
    def elevation(self, ang, field=True):
        """ Returns elevation normalized pattern
            :param ang: angle in radians
            :param field: return field if True, intensity if False
        """
        sin_rang = np.sin(ang - self.tilt)
        pat = self.func_e(sin_rang - np.sin(self.rel0),
                          self.Le, self.f0,
                          self.Ne, self.we, field=field,
                          beamwidth=self.beamwidth_e)
        if self.el_offset != 0:
            # Add linear phase
            # Check sign!
            phase = self.k0 * self.el_offset * sin_rang
            pat = pat * np.exp(1j * phase)
        else:
            # Make the pattern complex
            pat = pat + 0j
        xpat = pat * self.xpol2cpol
        return (pat.astype(np.complex64), xpat.astype(np.complex64))

    def azimuth(self, ang, field=True, squint_rad=None):
        """ Returns azimuth normalized pattern
            :param ang: angle in radians
            :param field: return field if True, intensity if False
            :param squint_rad: overides init squint. If it is a vector then
                               it will be combined with ang, following numpy
                               rules. So, this could be sued to calculate a
                               stack of patterns with different squints, or
                               to compute the pattern seen by a target in
                               TOPS or Spotlight mode
        """
        if squint_rad is None:
            squint = self.squint
        else:
            squint = squint_rad
        sin_ang = np.sin(ang)
        pat = self.func_a(sin_ang,
                          self.La, self.f0,
                          self.Na, self.wa, field=field,
                          beamwidth=self.beamwidth_a,
                          sin_squint=np.sin(squint))
        if self.az_offset != 0:
            phase = self.k0 * self.az_offset * sin_ang
            pat = pat * np.exp(1j * phase)
        else:
            # Make the pattern complex
            pat = pat + 0j
        xpat = pat * self.xpol2cpol
        return (pat.astype(np.complex64), xpat.astype(np.complex64))

    def plot_azimuth(self, ang, squint_rad=None, vmin=-40):
        """ Plots the normalized azimuth pattern
            :param ang: angle in radians
            :param squint_rad: overides init squint. If it is a vector then
                               it will be combined with ang, following numpy
                               rules. So, this could be sued to calculate a
                               stack of patterns with different squints, or
                               to compute the pattern seen by a target in
                               TOPS or Spotlight mode
        """
        apat = self.azimuth(ang, squint_rad=squint_rad)
        plt.figure()
        apatdb = 10 * np.log10(np.abs(apat[0])**2)
        plt.plot(np.degrees(ang), apatdb)
        plt.xlabel('Azimuth angle [deg]')
        plt.title("One-way azimuth pattern")
        ax = plt.gca()
        ax.set_ylim((vmin, 0))
        ax.set_xlim((np.degrees(ang).min(), np.degrees(ang).max()))
        plt.grid(True)

    def pat_2D(self, el_ang, az_ang, field=True, grid=True, squint_rad=None):
        """ Returns normalized pattern for (elevation, azimuth)
            :param el_ang: elevation angle in radians
            :param az_ang: azimuth angle in radians
            :param field: return field if True, intensity if False
            :param squint_rad: overides init squint. If it is a vector then
                               it will be combined with ang, following numpy
                               rules. So, this could be sued to calculate a
                               stack of patterns with different squints, or
                               to compute the pattern seen by a target in
                               TOPS or Spotlight mode
        """
        az, xaz = self.azimuth(az_ang, field=field, squint_rad=squint_rad)
        el, xel = self.elevation(el_ang, field=field)
        if grid:
            pat = az.reshape((az.size, 1)) * el.reshape((1, el.size))
            xpat = xaz.reshape((az.size, 1)) * xel.reshape((1, el.size))
        else:
            pat = az * el
            xpat = xaz * xel
        return (pat.astype(np.complex64), xpat.astype(np.complex64))

    def Doppler2pattern(self, la_ref, fD, ghist, az_norm=False):
        """ Compute azimuth pattern as a function of Doppler, taking into
            account the geometry history

            :param la_ref: look angle in antenna coordiantes
            :param fD: vector of Doppler frequencies
            :param ghist: drama.geo.sar.geo_history.GeoHistory object
        """
        t, u, v, _, _ = ghist.Doppler2tuv(la_ref, fD, self.f0, ant_ref=True)
        pat, xpat = self.pat_2D(v.T, u.T, grid=False)

        # Now we want to normalize them with respect to elevation cut
        if az_norm:
            elpat, elxpat = self.elevation(la_ref)
            return (pat / elpat.reshape((elpat.size, 1)),
                    xpat / elxpat.reshape((elxpat.size, 1)))
        else:
            return (pat, xpat)

    def Doppler2pat_interp(self, la_ref, Dla, fD, ghist):
        """ Compute coefficients for quadratic interpolator w.r.t. to look
            angle within a region given by la_ref +/- dla of the azimuth
            pattern as a function of Doppler, taking into account the geometry
            history

            :param la_ref: vector of reference look angles, in antenna
            coordinates
            :param Dla: vector or single value giving the look_angle deviation
            around (each) reference look angle. If it is zero, then a value of
            0.1 radians is used instead (which should be irrelevant)
            :param fD: vector of Doppler frequencies
            :param ghist: drama.geo.sar.geo_history.GeoHistory object
        """
        # Some initial house keeping, and make sure that there are no zeros
        dla = np.array([Dla])  # just to be sure
        if dla.size == 1:
            # Make it a non-zero scalar
            dla = 0.1 if dla[0] == 0 else np.abs(dla[0])
        else:
            # Make it non-zero everywhere
            dla = np.where(dla != 0, np.abs(dla), 0.1)
            dla = dla.reshape((1, dla.size))  # or a column vector
        # Compute patterns reference look angle and at reference angles
        # +/- dla
        t, u, v, _, _ = ghist.Doppler2tuv(la_ref, fD, self.f0, ant_ref=True)
        pat_0, xpat_0 = self.pat_2D(v.T, u.T, grid=False)
        t, u, v, _, _ = ghist.Doppler2tuv(la_ref - Dla, fD,
                                          self.f0, ant_ref=True)
        pat_m1, xpat_m1 = self.pat_2D(v.T, u.T, grid=False)
        t, u, v, _, _ = ghist.Doppler2tuv(la_ref + Dla, fD,
                                          self.f0, ant_ref=True)
        pat_p1, xpat_p1 = self.pat_2D(v.T, u.T, grid=False)
        # The patterns will be expressed as a function of la and la_ref as
        # a(la_ref, fD) + b(la_ref, fD) * (la - la_ref) +
        # c(la_ref, fD) * (la - la_ref)**2
        #
        # So now we calculate these coefficients as
        # a = pat0
        # b = (pat_p1 - pat_m1) / (2 * Dla)
        # c = (pat_p1 - 2 * pat_0 + pat_m1) / (2 * Dla**2)
        pat_a = pat_0
        pat_b = (pat_p1 - pat_m1) / (2 * dla)
        pat_c = (pat_p1 - 2 * pat_0 + pat_m1) / (2 * (dla**2))
        xpat_a = xpat_0
        xpat_b = (xpat_p1 - xpat_m1) / (2 * dla)
        xpat_c = (xpat_p1 - 2 * xpat_0 + xpat_m1) / (2 * (dla**2))
        return ((pat_a, pat_b, pat_c), (xpat_a, xpat_b, xpat_c))
