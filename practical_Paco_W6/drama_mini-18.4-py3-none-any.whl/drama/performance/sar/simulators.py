import numpy as np
from drama import constants as const
from drama.geo.sar import geometry as geo
from drama.geo import orbit as orb
from drama.coverage import swath_calc as sc
from drama.performance.sar import antenna_patterns as ap
from drama.performance.sar import data_patch as dp
import scipy.interpolate as interpol
import matplotlib.pyplot as plt
import matplotlib
from collections import namedtuple
import time
import sys
from matplotlib import gridspec
from drama.utils import misc as misc
from drama.utils.coord_trans import rot_z
import os
from drama.io import cfg as cfg
from scipy.signal import argrelextrema
from mpl_toolkits.basemap import Basemap
# from scipy.interpolate import UnivariateSpline


def pointSim(tar_latlonalt, L_el, L_az, f0, f_samp, Br, T0, sep=120,
             orb_type='repeat', look='right', inc_angle=30., PRF=None,
             parFile=None, int_type='linear', silent_flag=False,
             force_zd=True):
    """ Single point Simulator (make sure timestep<=1) providing raw data

        :param tar_latlonalt: targets location [N, 3]
                              (lat: latitude [deg] (-90 -> +90),
                               lon: longitude [deg] (-180 -> +180),
                               alt: altitude above sea level [m])
        :param L_el: antenna's length in elivation [m]
        :param L_az: antenna's length in azimuth [m]
        :param f0: transmit frequency [Hz]
        :param f_samp: sampling frequency (fast time)
        :param Br: range chirp bandwidth (Hz)
        :param T0: range chirp duration (s)
        :param sep: maximum neighbouring targets separation [sec]
        :param orb_type: repeat or sunsync
        :param look: left or right
        :param inc_ang: incidence angle [deg]
        :param PRF: Pulse Repetition frequency [Hz]
        :param parFile: All orbit parameters should be in parFile.
        :param int_type: interpolaton type
        :param silent_flag: if True no figures are plotted

        :returns: tuple containing raw data compressed in range
    """
    # Few initialization parameters (later include in parFile)
    # convert longitude to [0 ,360] window
    if isinstance(tar_latlonalt, list):
        tar_latlonalt = np.array(tar_latlonalt)
    if tar_latlonalt.ndim == 1:
        tar_latlonalt = tar_latlonalt[np.newaxis, :]
    tar_lon = tar_latlonalt[:, 1]
    tar_lon[np.where(tar_lon < 0)[0]] += 360
    tar_latlonalt[:, 1] = tar_lon

    wvlength = const.c/f0

    # get targets ECEF coordinates
    tar_ecef = geo.ecef_to_geodetic(tar_latlonalt, True)

    # Get Single Orbit data
    Single_orbData = sc.single_swath(orb_type, look, parFile=parFile)

    # look angle:
#    la = geo.inc_to_look(np.radians(inc_angle), Single_orbData.Horb)

    v_sat = orb.orbit_to_vel(Single_orbData.Horb)  # satellite velocity

    # Find the PRF
    if PRF is None:
        theta_h = wvlength/L_az  # beam width in azimuth
        doppler_bw = 2*v_sat*np.sin(theta_h)/wvlength
        PRF = 1.2*np.ceil(doppler_bw)
        sampling_time = 1/int(PRF)
    else:
        sampling_time = 1/int(PRF)

    # ######################### Find all patches ########################## #
    patches = []  # contains time vector and location interpolater of patch
    #             # around target
    for ntar in range(tar_latlonalt.shape[0]):
        patch_tar = dp.find_patch(tar_ecef[ntar, :], Single_orbData, parFile,
                                  L_az, wvlength, inc_angle, PRF,
                                  orb_type=orb_type, int_type=int_type)
        if patch_tar != 0:
            patches.append(patch_tar)
    # ##################################################################### #

    if len(patches) < 1:
        print("Target no seen by radar")
        return 0

    elif len(patches) > 1:  # more than one target patch
        # Connect neighboring patches
        patch_all = dp.pt_connect(patches, sep, tar_ecef, int_type)
        patches = []
        patches.append(patch_all)
        nswath_new = patches[0].nswath
        tar_ecef_new = patch_all.tar_ecef
        nPat = tar_ecef_new.shape[0]
    else:  # 'At least a Target is seen by satellite'
        nPat = 1
        tar_ecef_new = tar_ecef
        nswath_new = [patches[0].nswath]
    asc_idx_all = patches[0].asc_idx_all
    timevec_new = patches[0].timevec_pat
    t2r = patches[0].r_interp
    t2v = patches[0].v_interp
    # ################################################################# #
    # #################### Start processing here ###################### #
    timespan = int(timevec_new[-1]) - np.ceil(timevec_new[0])
    timenew = np.arange(int(timespan/sampling_time))
    timenew = timenew*sampling_time + np.ceil(timevec_new[0])
    r_ecef_t = t2r(timenew).T  # zoomed version of needed segment
    v_ecef_t = t2v(timenew).T

    NP_F = int(T0*f_samp)  # number of samples in range
    for tarsnew in range(nPat):  # Iterate around multi targets
        if nPat == 1:
            # #################### try zoom centering ##################### #
            D_tx = tar_ecef_new[tarsnew, :] - r_ecef_t
            R_tx = np.linalg.norm(D_tx, axis=1)  # distance vector
            min_loc = np.argmin(R_tx)
            if min_loc > timenew.shape[0]/2:
                diff_l = timenew.shape[0] - min_loc - 1
                if diff_l > 10:
                    timenew = timenew[min_loc - diff_l:min_loc + diff_l]
                else:
                    print('Target exists on swath transition!')
            else:
                diff_l = min_loc - 1
                timenew = timenew[0:min_loc + diff_l]
            # ############################################################# #
            timenew0 = timenew
            timenew = timenew0[1:]
            r_ecef_t = t2r(timenew).T  # zoomed version of needed segment
            # ############################################################ #
        # New Range arrays for transmit and receive paths
        # Tx Path
        D_tx = tar_ecef_new[tarsnew, :] - r_ecef_t
        R_tx = np.linalg.norm(D_tx, axis=1)  # distance vector

        # Rx_path
        time_shift = 2*R_tx/const.c   # sampling_time
        time_rcv = timenew + time_shift
        r_ecef_r = t2r(time_rcv).T
        D_rx = tar_ecef_new[tarsnew, :] - r_ecef_r
        R_rx = np.linalg.norm(D_rx, axis=1)  # distance vector
        # Targets azimuthal signal without antenna pattern
        s = np.exp(-2j*np.pi/wvlength*(R_tx+R_rx))
        # ##################### Antenna patterns ######################### #
        # Transmit        # Paco's method
        v_ecef_t = t2v(timenew).T
        npts = v_ecef_t.shape[0]
        v_ver_t = v_ecef_t/np.linalg.norm(v_ecef_t, axis=1).reshape(npts, 1)
        r_ver_t = D_tx/np.linalg.norm(D_tx, axis=1).reshape(npts, 1)
        theta_az_tx = np.sum(r_ver_t * v_ver_t, axis=1)  # look

        # Receive
        v_ecef_r = t2v(time_rcv).T
        v_ver_r = v_ecef_r/np.linalg.norm(v_ecef_r, axis=1).reshape(npts, 1)
        r_ver_r = D_rx/np.linalg.norm(D_rx, axis=1).reshape(npts, 1)
        theta_az_rx = np.sum(r_ver_r * v_ver_r, axis=1)  # look

        time_pt = timevec_new[int(timevec_new.shape[0]/2)]
        ct_pt = np.where(time_pt == patches[0].timevec_all)[0][0]

        for i in range(asc_idx_all.shape[0]):
            if ct_pt < asc_idx_all[i, 1] and ct_pt > asc_idx_all[i, 0]:
                swath = 'ascending'
                org = 'lower'
                break
            else:
                swath = 'descending'
                org = 'upper'

        # 1D antenna patterns in azimuth (slow time)
        ant_az_tx = ap.sinc_bp(np.sin(theta_az_tx), L_az, f0, field=True)
        ant_az_rx = ap.sinc_bp(np.sin(theta_az_rx), L_az, f0, field=True)
        ant_pat = ant_az_tx * ant_az_rx
        raw_prior = s * ant_pat
        # ############# cut the time according to main lobe ############### #
        abs_raw = np.abs(raw_prior)
        loc_max = np.argmax(abs_raw)
        minm = argrelextrema(abs_raw, np.less)[0]
        half_cut = np.abs(loc_max - minm[np.argmin(np.abs(minm - loc_max))])

        timenew = timenew[loc_max - half_cut: loc_max + half_cut]
        time_rcv = time_rcv[loc_max - half_cut: loc_max + half_cut]
        time_shift = time_shift[loc_max - half_cut: loc_max + half_cut]
        raw_prior = raw_prior[loc_max - half_cut: loc_max + half_cut]
        r_ecef_tnew = r_ecef_t[loc_max - half_cut: loc_max + half_cut]
        v_ecef_tnew = v_ecef_t[loc_max - half_cut: loc_max + half_cut]
        r_ecef_rnew = r_ecef_r[loc_max - half_cut: loc_max + half_cut]
        v_ecef_rnew = v_ecef_r[loc_max - half_cut: loc_max + half_cut]
        R_tx = R_tx[loc_max - half_cut: loc_max + half_cut]
        D_tx = D_tx[loc_max - half_cut: loc_max + half_cut]
        theta_az_tx = theta_az_tx[loc_max - half_cut: loc_max + half_cut]
        theta_az_rx = theta_az_rx[loc_max - half_cut: loc_max + half_cut]

        # 1D antenna patterns in azimuth (slow time)
        ant_az_tx = ap.sinc_bp(np.sin(theta_az_tx), L_az, f0, field=True)
        ant_az_rx = ap.sinc_bp(np.sin(theta_az_rx), L_az, f0, field=True)
        ant_pat = ant_az_tx * ant_az_rx
        # ################################################################# #
        # Not taking natural steering into account
        zero_loc = np.argmin(R_tx)
        dot2 = np.dot(D_tx, D_tx[zero_loc])
        mag2 = R_tx*R_tx[zero_loc]
        arg = dot2/mag2
        arg[arg > 1] = 1
        theta_az0 = np.arccos(arg)
        theta_az0[np.isnan(theta_az0)] = 0
        az_center = np.argmin(abs(theta_az0))
        if swath == 'ascending':
            theta_az0[0:az_center] *= -1
        else:
            theta_az0[az_center:] *= -1
#        if not silent_flag:
#            ant_az0 = ap.sinc_bp(np.sin(theta_az0), L_az, f0, field=True)
#
#            plt.figure()
#            plt.plot(timenew, np.degrees(theta_az_tx), label='steered',
#                     linewidth=2)
#            plt.plot(timenew, np.degrees(theta_az0), label='non-steered',
#                     linewidth=2, linestyle='--')
#            plt.title('Natural Steering')
#            plt.ylabel('$\\theta _\mathrm{az}$', fontsize=18)
#            plt.xlabel('slow time', fontsize=16)
#            plt.legend()
#            plt.grid()
#
#            plt.figure()
#            plt.plot(timenew, np.abs(ant_az_tx), label='steered',
#                     linewidth=2)
#            plt.plot(timenew, np.abs(ant_az0), label='non-steered',
#                     linewidth=2, linestyle='--')
#            plt.title('Antenna Pattern (main lobe)')
#            plt.ylabel('magnitude', fontsize=16)
#            plt.xlabel('slow time', fontsize=16)
#            plt.legend()
#            plt.grid()
#
#            plt.figure()
#            plt.plot(np.degrees(theta_az0), np.degrees(theta_az_tx),
#                     linewidth=2)
#            plt.xlabel('$\\theta _\mathrm{tar}$', fontsize=18)
#            plt.ylabel('$\\theta _\mathrm{az}$', fontsize=18)
#            plt.grid()
#            plt.pause(10)
        # ################################################################# #
        # ##################### Fast time processing ###################### #
        time_fast = np.linspace(-NP_F/2, NP_F/2, NP_F)/f_samp
        # Center the slow time to patch midpoint
        min_R = np.argmin(R_tx)
        time_slow = time_shift - time_shift[min_R]
        t = -time_slow[:, np.newaxis] + time_fast
        p_t = np.sinc(t*Br)
        raw = np.zeros((nPat, time_slow.shape[0], time_fast.shape[0]),
                       dtype=complex)
        raw[tarsnew, :, :] = raw_prior[:, np.newaxis]*p_t
        # start point slant range
        R0 = time_shift[np.argmin(R_tx)]*const.c/2
        # ################################################################# #
    # Range Compressed Raw Data
    raw_rc = np.sum(raw, axis=0)
    # ##################### Reconstruct raw signal ######################## #
    # CONSTRUCT RANGE CHIRP
    GAMMA_R = Br/T0
    H = raw_rc.shape
    tf = np.linspace(-T0/2, T0/2, num=NP_F)
    chirp_rt = np.zeros(H[1], dtype=np.complex)
    chirp_rt[0: NP_F] = np.exp(1j*np.pi*GAMMA_R*(tf**2))
    chirp_r = np.roll(chirp_rt, int(-NP_F/2))

    # Range decompression
    raw_f = np.fft.fft(raw_rc, axis=1) * np.fft.fft(np.conj(chirp_r))
    raw_t = np.fft.ifft(raw_f, axis=1)

    # Range Compression (Go back to original data "just for testing")
#    rc_f = np.fft.fft(raw_t, axis=1) * np.fft.fft(chirp_r)
    rc_f = np.fft.fft(raw_rc)
    rc_t = raw_rc
#    rc_t = np.fft.ifft(rc_f, axis=1)

    if not silent_flag:
        # Raw data Plot
        plt.figure()
        plt.title('Raw signal')
        plt.xlabel('Range, sample')
        plt.ylabel('Azimuth, sample')
        plt.imshow(np.real(raw_t), origin=org, interpolation='nearest',
                   aspect='auto')
        plt.colorbar()

        # Range Compressed data plot
        plt.figure()
        plt.title('Range Compressed Signal')
        plt.xlabel('Range, sample')
        plt.ylabel('Azimuth, sample')
        plt.imshow(np.real(raw_rc), origin=org, interpolation='nearest',
                   aspect='auto')
        plt.colorbar()

    Sdata = namedtuple('Sdata', ['timevec', 'time_r', 'r_ecef_t', 'v_ecef_t',
                                 'r_ecef_r', 'v_ecef_r', 'rc_t', 'rc_f',
                                 'raw_t', 'raw_f', 'r_interp', 'v_interp',
                                 'orb_data', 'PRF', 'time_fast', 'sw_or',
                                 'sw_num', 'ant_pat', 'theta_az',
                                 'theta_az_ns', 'R0'])
    sdata = Sdata(timenew, time_rcv, r_ecef_tnew, v_ecef_tnew, r_ecef_rnew,
                  v_ecef_rnew, rc_t, rc_f, raw_t, raw_f, t2r, t2v,
                  Single_orbData, PRF, time_fast, swath,
                  int(nswath_new[tarsnew]), ant_pat, theta_az_tx, theta_az0,
                  R0)
    return sdata


def back_project(data, Nfft, deltaF, f0, pixel_pos0, ant_pos_t0, ant_vel_t,
                 ant_pos_r0, ant_vel_r, R0, R_mat, ant_pat, theta_az,
                 look_ang, L_az):
    """
    :param data: Phase history data [fast time x slow time] (freq. domain)
    :param Nfft: Size of the FFt to form the range profile
    :param deltaF: Step size of the frequency data [Hz]
    :param f0: transmit frequency [Hz]
    :param pixel_pos: [x, y, z]- positions of each pixel [m]
    :param ant_pos_t0: [x, y, z]- positions of each antenna (slow time) with
                     one additional value on transmit
    :param ant_vel_t: [x, y, z]- ecef velocity of transmit antenna
    :param ant_pos_t0: [x, y, z]- positions of each antenna (slow time) with
                     one additional value on receive
    :param ant_vel_t: [x, y, z]- ecef velocity of receive antenna
    :param R0: The range to scene center
    :param R_mat: range to each pixel
    :param ant_pat: antenna pattern
    :param look_ang: look angle [radians]

    :returns: complex image value at each pixel
    """
    print('Started Back Projection')
    ant_pos_t = ant_pos_t0[1:]
    ant_pos_r = ant_pos_r0[1:]
    pixel_pos = np.reshape(pixel_pos0,
                           (pixel_pos0.shape[0]*pixel_pos0.shape[1], 3))
    Np = data.shape[0]  # number of pulses (1 pulse per antenna location)
    k0 = 2 * np.pi * f0 / const.c

    # maximum scene size of the image [m]
    max_rw = const.c/(2*deltaF)

    # calculate range to every bin in the range profile
    r_bin = np.linspace(-Nfft/2, Nfft/2, Nfft)/Nfft*max_rw + R0

    # zero pad data to fit Nfft
    if data.shape[1] != Nfft:
        data_t = np.fft.ifft(data, axis=1)
        data = np.fft.fft(data_t, Nfft, axis=1)

    # Create 6dB mask
    loc_6dB = np.argmin(np.abs((ant_pat - np.max(ant_pat)/(10**0.3))))
    loc_max = np.argmax(ant_pat)
    half_win = np.abs(loc_max - loc_6dB)
    theta_az_win = theta_az[loc_max - half_win: loc_max + half_win]
    theta_min = np.min(theta_az_win)
    theta_max = np.max(theta_az_win)

    # empty matrix for final image
    im_bp = np.zeros(pixel_pos.shape[0], dtype=np.complex)

    # execution times for each pulse
    t = np.zeros(Np)
    # loop through every pulse
    for p_num in range(Np):
        # Display current status
        if p_num > 1:
            t_curr = np.sum(t[0:(p_num - 1)])
            t_est = (t_curr*Np/(p_num - 1) - t_curr)/60
            sys.stdout.write("\r"+'Pulse: ' + str(p_num) + ' of ' +
                             str(Np) + '; ' + str(int(t_est*100)/100) +
                             ' minutes remaining ')
            sys.stdout.flush()
        tic = time.time()

        # range profile with zero padding added
        r_profile = data[p_num, :]

        # differential range for each pixel
        # linalg is slower
        d_range_t = np.sqrt((pixel_pos[:, 0] - ant_pos_t[p_num, 0])**2 +
                            (pixel_pos[:, 1] - ant_pos_t[p_num, 1])**2 +
                            (pixel_pos[:, 2] - ant_pos_t[p_num, 2])**2)
        d_range_r = np.sqrt((pixel_pos[:, 0] - ant_pos_r[p_num, 0])**2 +
                            (pixel_pos[:, 1] - ant_pos_r[p_num, 1])**2 +
                            (pixel_pos[:, 2] - ant_pos_r[p_num, 2])**2)
        d_range = (d_range_t + d_range_r)/2.

        # Transmit
        D_tx = pixel_pos - ant_pos_t[p_num]
        npts = D_tx.shape[0]
        r_ver_t = D_tx/np.sqrt((D_tx[:, 0])**2 + (D_tx[:, 1])**2 +
                               (D_tx[:, 2])**2).reshape(npts, 1)
        v_ver_t = ant_vel_t[p_num]/np.linalg.norm(ant_vel_t[p_num])
        theta_az_tx = np.sum(r_ver_t * v_ver_t, axis=1)  # look

        # Receive
        D_rx = pixel_pos - ant_pos_r[p_num]
        r_ver_r = D_rx/np.sqrt((D_rx[:, 0])**2 + (D_rx[:, 1])**2 +
                               (D_rx[:, 2])**2).reshape(npts, 1)
        v_ver_r = ant_vel_r[p_num]/np.linalg.norm(ant_vel_r[p_num])
        theta_az_rx = np.sum(r_ver_r * v_ver_r, axis=1)  # look

        ant_az_tx = ap.sinc_bp(np.sin(theta_az_tx), L_az, f0, field=True)
        ant_az_rx = ap.sinc_bp(np.sin(theta_az_rx), L_az, f0, field=True)

        # image phase correction
        ph_corr = np.exp(2j * k0 * (d_range))
        corr = ph_corr/(ant_az_tx * ant_az_rx)

        # apply windowing based on theta values
        mask = np.ones(theta_az_tx.shape)
        mask[theta_az_tx < theta_min] = 0
        mask[theta_az_tx > theta_max] = 0
        corr *= mask

        # Determine which pixels fall within the range swath
        I = np.where((d_range > np.min(r_bin)) &
                     (d_range < np.max(r_bin)))[0]
        in1 = interpol.interp1d(r_bin, r_profile)
        im_bp[I] = (im_bp[I] + in1(d_range[I])*corr[I])
        t[p_num] = time.time() - tic
    im_bp = np.reshape(im_bp, (pixel_pos0.shape[0], pixel_pos0.shape[1]))
    im_bp *= np.exp(-2j * k0 * R_mat)

    return im_bp


def BPsim(tar_latlonalt, Wa, La, f0, Br, f_samp, T0, inc_angle, Nfft=None,
          dx=0.5, dgr=0.5, Da=250, Dgr=250, orb_type='repeat', PRF=None,
          look='right', parFile=None, int_type='linear', silent_flag=False,
          b_project=True, save=True, lk_save=None, force_zd=True,
          grid_method='shoot'):
    """ Full Simulator with back projection

        :author: Jalal Matar
        :date: 05.04.2016

        :param tar_latlonalt: geodetic coordinates of the target
        :param Wa: width of the antenna
        :param la: length of the antenna
        :param f0: transmit frequency [Hz]
        :param Br: system bandwidth [Hz]
        :param f_samp: sampling frequency (slow time) [Hz] > Br
        :param T0: range chirp duration [sec]
        :param inc_angle: center incident angle [deg]
        :param dx: cell resolution in azimuth
        :param dgr: cell resolution in ground range
        :param Da: total patch length in azimuth
        :param Dgr: total patch length in ground range
        :param orb_type: orbital type ['repeat'/'sunsync']
        :param t_win: display time in azimuth [sec] < 1
        :param d_theta: range display window [deg]
        :param Np_F: sampling frequency (fast time) [Hz]
        :param lk_save: look angle of target (only for saving name)
        :param force_zd: force zero Doppler in LoS calculation
        :param grid_method: 1point or shoot
    """
    Np_F = int(T0*f_samp)
    if Nfft is None:
        Nfft = Np_F

    tar_latlonalt_org = np.copy(tar_latlonalt)
    parFile = misc.get_parFile(parFile)
    fName = os.path.splitext(os.path.basename(parFile))[0]
    # make sure that the timstep is equals 1
    inData = cfg.ConfigFile(parFile)
    if inData.orbit.timestep > 1:
        print('Error! Please set "timestep" to 1 in the parameter File')
        return
    # Create raw data
    sdata = pointSim(tar_latlonalt, Wa, La, f0, f_samp, Br, T0,
                     orb_type=orb_type, look='right', inc_angle=inc_angle,
                     PRF=1200, parFile=parFile, int_type=int_type,
                     silent_flag=silent_flag, force_zd=force_zd)
    # ##################################################################### #
    # ################ Creating a regular R_az, Rs grid ################### #
    if sdata != 0:
        # convert longitude to [0 ,360] window
        if isinstance(tar_latlonalt, list):
            tar_latlonalt = np.array(tar_latlonalt)
        if tar_latlonalt.ndim == 1:
            tar_latlonalt = tar_latlonalt[np.newaxis, :]
        tar_lon = tar_latlonalt[:, 1]
        tar_lon[np.where(tar_lon < 0)[0]] += 360
        tar_latlonalt[:, 1] = tar_lon
        tar_ecef = geo.ecef_to_geodetic(tar_latlonalt[0, :], True)

        r_ecef_new = sdata.r_interp(sdata.timevec).T
#        v_ecef_new = sdata.v_interp(sdata.timevec).T
        R_sat = np.linalg.norm(r_ecef_new, axis=1)
        D_tx = tar_ecef[0, :] - r_ecef_new
        R_tx = np.linalg.norm(D_tx, axis=1)  # distance vector
        loc0 = np.argmin(R_tx)
        # center point
        t_center = sdata.timevec[loc0]
        v_ecef_c = sdata.v_interp(t_center).T
        v_center = np.linalg.norm(v_ecef_c)
#
#        LoSr = geo.create_LoS(r_ecef_new[loc0], v_ecef_new[loc0],
#                              np.array((0)), force_zero_Doppler=force_zd)
#        rs = geo.pt_get_intersection_ellipsoid(r_ecef_new[loc0], LoSr)
#        r_earth_t = np.linalg.norm(rs, axis=2)[0][0]  # exact earth radius

        r_earth_t = np.linalg.norm(tar_ecef[0, :])  # exact earth radius
        h_orb = np.linalg.norm(r_ecef_new[loc0, :]) - r_earth_t

        # look angle at patch center (here target location)
        tar_lk = np.arccos((R_sat[loc0]**2 + R_tx[loc0]**2 - r_earth_t**2) /
                           (2*R_tx[loc0]*R_sat[loc0]))
        tar_inc = geo.look_to_inc(tar_lk, h_orb)

        G_az = (r_earth_t/(r_earth_t + h_orb) * np.cos(tar_inc - tar_lk))
        v_gr = v_center*G_az
        t_step = dx/v_gr  # approximate time step
        t_win = int(Da/v_gr/2*1e06)/1e06  # appox total time window
        t0 = int((t_center - t_win)*1e06)/1e06
        t1 = t0 + 2*t_win
        Na = int(round((t1 - t0)/t_step))

        t_step = int((t1-t0)/Na*1e06)/1e06
        t_vec0 = np.arange(Na+1)*t_step + t0  # new time vec
#        az_shift = 40*t_step  # uncenter the target in azimuth
#        t_vec0 += az_shift

        t_vec = t_vec0[:-1]
        r_sat = sdata.r_interp(t_vec).T  # Na satellite locations
        R_sat = np.linalg.norm(r_sat, axis=1)  # r_sat dist to earth's center
        v_sat = sdata.v_interp(t_vec).T
        # slant ranges
        R_tar = np.linalg.norm(tar_ecef[0, :] - r_sat, axis=1)
        R0_tar = np.min(R_tar)
        idx_r = np.argmin(R_tar)

        # From ground ranges
        # look angle at patch center (here target location)
        theta_c = np.arccos((R_sat[idx_r]**2 + R0_tar**2 - r_earth_t**2) /
                            (2*R0_tar*R_sat[idx_r]))
        Rgc = r_earth_t*(geo.look_to_inc(theta_c, h_orb, r_earth_t) - theta_c)
        Rg = [Rgc - Dgr/2, Rgc + Dgr/2]

        # find min and max slant ranges for all satellite positions
        r_min = np.sqrt(R_sat**2 + r_earth_t**2 - (2 * R_sat * r_earth_t *
                                                   np.cos(Rg[0]/r_earth_t)))
        r_max = np.sqrt(R_sat**2 + r_earth_t**2 - (2 * R_sat * r_earth_t *
                                                   np.cos(Rg[1]/r_earth_t)))

        # create a matrix of all slant ranges for all satellites positions
        Nr = int(Dgr/dgr)
        dsr = int((r_max[idx_r] - r_min[idx_r])/Nr*1e06)/1e06
        dgr = dsr/np.sin(geo.look_to_inc(theta_c, h_orb))
        Rs_all = np.arange(Nr)*dsr + r_min[idx_r]

        la = np.arccos((R_sat[idx_r]**2 + Rs_all**2 - r_earth_t**2) /
                       (2*Rs_all*R_sat[idx_r]))
        la_shift = 0  # 10*(la[0] - la[1])  # uncentering target in range
        la += la_shift
        LoS = geo.create_LoS(r_sat, v_sat, la, force_zero_Doppler=force_zd)
        # ################################################################ #
        if grid_method == 'shoot':
            pixel_pos0 = geo.pt_get_intersection_ellipsoid(r_sat, LoS)
        elif grid_method == '1point':  # 1 point strategy
            locs_r = np.array([0, int((Nr-1)/2), Nr-1])
            pts0 = np.empty((3, 3))
            pts1 = np.empty((3, 3))
            pts2 = np.empty((3, 3))
            p1 = tar_ecef
            v_ver = v_ecef_c/np.linalg.norm(v_ecef_c)

            r_c = sdata.r_interp(t_center).T
            looks = np.array([la[int(la.shape[0]*0.5)],
                              la[int(la.shape[0]*0.75)]])
            LoS_c = geo.create_LoS(r_c, v_ecef_c, looks,
                                   force_zero_Doppler=force_zd)
            pts = geo.pt_get_intersection_ellipsoid(r_c, LoS_c)
            r_vec = np.diff(pts, axis=1)
            r_ver = r_vec/np.linalg.norm(r_vec)

            p0 = -v_ver*Da/2 + p1
            p2 = v_ver*Da/2 + p1

            pts0[0, :] = -r_ver*Dgr/2 + p0
            pts1[0, :] = -r_ver*Dgr/2 + p1
            pts2[0, :] = -r_ver*Dgr/2 + p2
            pts0[1, :] = p0
            pts1[1, :] = p1
            pts2[1, :] = p2
            pts0[2, :] = r_ver*Dgr/2 + p0
            pts1[2, :] = r_ver*Dgr/2 + p1
            pts2[2, :] = r_ver*Dgr/2 + p2

            inter0 = interpol.interp1d(locs_r, pts0.T, kind='quadratic')
            inter1 = interpol.interp1d(locs_r, pts1.T, kind='quadratic')
            inter2 = interpol.interp1d(locs_r, pts2.T, kind='quadratic')
            point1 = inter0(range(Nr)).T
            point2 = inter1(range(Nr)).T
            point3 = inter2(range(Nr)).T

            pixel_pos0 = np.empty((Na, Nr, 3))
            locs_a = np.array([0, int((Na-1)/2), Na-1])
            for i in range(Nr):
                points = np.array([point1[i, :], point2[i, :], point3[i, :]])
                inter = interpol.interp1d(locs_a, points.T, kind='quadratic')
                pixel_pos0[:, i, :] = inter(range(Na)).T
        # ################################################################ #
        pixel_pos = np.reshape(pixel_pos0,
                               (pixel_pos0.shape[0]*pixel_pos0.shape[1],
                                3))
        # center pixel
        cx = int(pixel_pos0.shape[0]/2)
        cr = int(pixel_pos0.shape[1]/2)
        # scene size & resolution
        pr = np.linalg.norm(pixel_pos0[cx, cr, :] - pixel_pos0[cx, cr+1, :])
        px = np.linalg.norm(pixel_pos0[cx, cr, :] - pixel_pos0[cx+1, cr, :])
        sc_rw = np.linalg.norm(pixel_pos0[0, 0, :] - pixel_pos0[0, -1, :])
        sc_xw = np.linalg.norm(pixel_pos0[0, 0, :] - pixel_pos0[-1, 0, :])
        print("\n"+'Scene Size = ' + str(int(sc_xw*100)/100) + ' x ' +
              str(int(sc_rw*100)/100) + ' m^2' +
              ' (cross-range x ground-range)')
        # image resolution
        print('Grid approx. Resolution = ' + str(int(px*1000)/1000) + 'm x ' +
              str(int(pr*1000)/1000) + 'm' + ' (cross-range x ground-range)')
        # Real resolution
        delta_az = G_az*La/2
        delta_gr = const.c/(2*Br*np.sin(geo.look_to_inc(theta_c, h_orb)))
        print('Real Resolution = ' + str(int(delta_az*1000)/1000) + 'm x ' +
              str(int(delta_gr*1000)/1000) + 'm' +
              ' (cross-range x ground-range)')
        # ########################### Grid testing ######################## #
        pt_ct = pixel_pos0[cx, cr, :]
        ang = np.arccos(np.dot(v_sat[idx_r], r_sat[idx_r]) /
                        np.linalg.norm(v_sat[idx_r]) /
                        np.linalg.norm(r_sat[idx_r]))
        print('x-diff = ' + str(int((pt_ct[0] - tar_ecef[0, 0])*100)/100))
        print('y_diff = ' + str(int((pt_ct[1] - tar_ecef[0, 1])*100)/100))
        print('z_diff = ' + str(int((pt_ct[2] - tar_ecef[0, 2])*100)/100))
        print('angle r-v = ' + str(np.degrees(ang)))
        # ################################################################# #
        # /////////////////// Back projection preparation \\\\\\\\\\\\\\\\\ #
        if b_project:
            # Start Back Projection
            data = sdata.rc_t
#            Nfft = data.shape[1]  # 1024
            deltaF = f_samp/Np_F  # 1/(sdata.time_fast[-1]-sdata.time_fast[0])
            ant_vel_t = sdata.v_ecef_t
            r0t = sdata.r_interp(sdata.timevec[0]-np.diff(sdata.timevec[0:2]))
            ant_pos_t0 = np.vstack((r0t.T, sdata.r_ecef_t))
            ant_vel_r = sdata.v_ecef_r
            r0r = sdata.r_interp(sdata.time_r[0]-np.diff(sdata.time_r[0:2]))
            ant_pos_r0 = np.vstack((r0r.T, sdata.r_ecef_r))

            look_ang = geo.inc_to_look(np.radians(inc_angle),
                                       sdata.orb_data.Horb)

            # find minimum distance from each pixel
            R_mat = np.zeros(pixel_pos.shape[0])
            for ii in range(pixel_pos.shape[0]):
                range_px = np.linalg.norm(pixel_pos[ii, :] - sdata.r_ecef_t,
                                          axis=1)
                R_mat[ii] = np.min(range_px)
            R_mat = np.reshape(R_mat, (pixel_pos0.shape[0],
                                       pixel_pos0.shape[1]))

            # Ranges to scene center
#            R0 = np.min(np.linalg.norm(tar_ecef - sdata.r_ecef, axis=1))
            # /////////////////// Perform Back Projection \\\\\\\\\\\\\\\\\ #
            im_bp = back_project(data, Nfft, deltaF, f0, pixel_pos0,
                                 ant_pos_t0, ant_vel_t, ant_pos_r0, ant_vel_r,
                                 sdata.R0, R_mat, sdata.ant_pat,
                                 sdata.theta_az, look_ang, La)

            if not silent_flag:
                # Plot back projected image
                if sdata.sw_or == 'ascending':
                    org = 'lower'
                else:
                    org = 'upper'
                plt.figure()
                plt.title('Real Resolution = ' +
                          ' $\delta_\mathrm{az} \\times \delta_\mathrm{gr}$' +
                          ' = ' + str(int(delta_az*1000)/1000) + 'm x ' +
                          str(int(delta_gr*1000)/1000) + 'm' + '\n' +
                          'Image Resolution = ' + str(int(pr*1000)/1000) +
                          'm x ' + str(int(px*1000)/1000) + 'm' + ' (gr x az)')
                plt.imshow(np.abs(im_bp), origin=org)
                plt.xlabel('Range', fontsize=16)
                plt.ylabel('Azimuth', fontsize=16)
                plt.colorbar()

                # Find and plot target cuts
                [y_max, x_max] = np.unravel_index(np.argmax(np.abs(im_bp)),
                                                  im_bp.shape)
                r_signal = np.abs(im_bp[y_max, :])
                az_signal = np.abs(im_bp[:, x_max])

                # Find exact resolutions with interpolation
                # azimuth
                loc_maxa = np.argmax(az_signal)
                minm = argrelextrema(az_signal, np.less)[0]
                half_cut = np.abs(loc_maxa - minm[np.argmin(np.abs(minm -
                                                                   loc_maxa))])
                newax1 = np.arange(loc_maxa - half_cut, loc_maxa + 1)
                inaz1 = interpol.interp1d(az_signal[newax1], newax1,
                                          kind='cubic')
                loc_3dB1 = inaz1(np.max(az_signal)/(10**0.15))
                newax2 = np.arange(loc_maxa, loc_maxa + half_cut + 1)
                inaz2 = interpol.interp1d(az_signal[newax2], newax2,
                                          kind='cubic')
                loc_3dB2 = inaz2(np.max(az_signal)/(10**0.15))
                az_res = np.abs(loc_3dB2 - loc_3dB1)*px

                # range
                loc_maxr = np.argmax(r_signal)
                minm = argrelextrema(r_signal, np.less)[0]
                half_cut = np.abs(loc_maxr - minm[np.argmin(np.abs(minm -
                                                                   loc_maxr))])
                newr1 = np.arange(loc_maxr - half_cut, loc_maxr + 1)
                inr1 = interpol.interp1d(r_signal[newr1], newr1, kind='cubic')
                loc_3dB1 = inr1(np.max(r_signal)/(10**0.15))
                newr2 = np.arange(loc_maxr, loc_maxr + half_cut + 1)
                inr2 = interpol.interp1d(r_signal[newr2], newr2, kind='cubic')
                loc_3dB2 = inr2(np.max(r_signal)/(10**0.15))
                r_res = np.abs(loc_3dB2 - loc_3dB1)*pr

                res = ('Resolution = ' + str(int(az_res*1000)/1000) + 'm x ' +
                       str(int(r_res*1000)/1000) + 'm' +
                       ' (cross-range x ground-range)')
                plt.figure()
                gs = gridspec.GridSpec(2, 1)
                swath = sdata.sw_or + str(sdata.sw_num)
                plt.suptitle('swath: ' + swath + '\n' + res, fontsize=16)
                ax1 = plt.subplot(gs[0, 0])
                ax1.plot(az_signal, label='dx='+str(int(px*1000)/1000))
                plt.xlabel("Azimuth Signal", fontsize=14)
                plt.ylabel("Magnitude", fontsize=14)
                plt.legend()
                ax2 = plt.subplot(gs[1, 0])
                ax2.plot(r_signal, label='dgr='+str(int(dgr*1000)/1000))
                plt.xlabel("Range Signal", fontsize=14)
                plt.ylabel("Magnitude", fontsize=14)
                plt.legend()

            ImData = namedtuple('ImData', ['raw_t', 'rc_t', 'bp_data',
                                           'grid_data', 'Horb', 'delta_gr',
                                           'delta_az', 'Na', 'Nr', 'dgr',
                                           'tar_latlonalt', 'sw_or', 'sw_num'])
            imdata = ImData(sdata.raw_t, sdata.rc_t, im_bp, pixel_pos0, h_orb,
                            delta_gr, delta_az, Na, Nr, dgr, tar_latlonalt,
                            sdata.sw_or, sdata.sw_num)
            typ = 'bp-'  # back porjected
        else:
            ImData = namedtuple('ImData', ['raw_t', 'rc_t', 'Horb', 'delta_gr',
                                           'delta_az', 'tar_latlonalt',
                                           'sw_or', 'sw_num', 'dgr'])
            imdata = ImData(sdata.raw_t, sdata.rc_t, h_orb, delta_gr, delta_az,
                            tar_latlonalt, sdata.sw_or, sdata.sw_num, dgr)
            typ = 'rd-'  # raw data

    # Save the data
    if save:
        if tar_latlonalt_org[0, 0] >= 0:
            lat = 'N'
        else:
            lat = 'S'
        if tar_latlonalt_org[0, 1] >= 0:
            lon = 'E'
        else:
            lon = 'W'
        tar0 = str(abs(int(round(tar_latlonalt_org[0, 0]))))
        tar1 = str(abs(int(round(tar_latlonalt_org[0, 1]))))
        tar2 = str(abs(int(round(tar_latlonalt_org[0, 2]))))
        tar = tar0 + lat + tar1 + lon + tar2  # target's geodetic coordinates

        if lk_save is None:
            lk_save = np.degrees(tar_lk)
        lk = 'lk' + str(int(lk_save))
        tar += lk

        n = 0
        fdir = '/home/mata_ja/pythonCodes/drama/'
        file_name = (typ + fName + '-' + str(int(f0/1e06)) + 'MHz-' +
                     tar + '-v' + str(n) + '.npz')
        while os.path.isfile(fdir + file_name):
            n = n + 1
            file_name = (typ + fName + '-' + str(int(f0/1e06)) + 'MHz-' +
                         tar + '-v' + str(n) + '.npz')
        misc.save_tuple(imdata, fdir + file_name)
    print('Done!')
    print('')
    return imdata


def shoot_tar(parFile, track_n, t_step=10, look_angle=None, track='descending',
              look='right', orb_type='repeat', int_type='linear',
              silent_flag=True, force_zd=True):
    """ Finds targets by shooting points from satellite locations according
        to a certain look angle

        :param parFile: All orbit parameters should be in parFile.
        :param track_n: track number for which targets are to be found 1, 2,
        :param t_step: time between two consecutive target shots [sec]
        :param look_angle: look angle[deg] at which targets are to be found
        :param track: 'ascending', 'descending' or both
        :param look: 'right' or 'left'
        :param orb_type: 'repeat' or 'sunsync'
        :param int_type: interpolater type

        :returns: set of targets belonging to the swath at a given look angle

    """

    inData = cfg.ConfigFile(parFile)
    dDays = inData.orbit.days_cycle
    nRevs = inData.orbit.orbits_nbr
    Single_orbData = sc.single_swath(orb_type, look, parFile=parFile)

    # Retrieve useful data for the Single Orbit
    Horb = Single_orbData.Horb
    Single_swath = Single_orbData.swathData
    asc_idx = Single_orbData.asc_idx
    desc_idx = Single_orbData.desc_idx
    Torb = Single_orbData.Torb

    if look_angle is None:
        near_1 = geo.inc_to_look(np.radians(inData.sar.near_1), Horb)
        far_1 = geo.inc_to_look(np.radians(inData.sar.far_1), Horb)
        look_angle = [(near_1 + far_1)/2.]
    else:
        if type(look_angle) is int:
            look_angle = [look_angle]
        look_angle = np.radians(look_angle)

    # Check for all swaths
    T_sidereal = 86164.09053  # [sec]
    if orb_type == 'repeat':
        Tday = T_sidereal
    elif orb_type == 'sunsync':
        Tday = 86400.

    delta_lon = Torb*360./(Tday/3600.)  # shift in longitude between 2 swaths

    # Find the swath
    sw_lon = Single_swath.lon
    sw_lon = np.where(sw_lon > 0, sw_lon, sw_lon + 360)
    sw_lat_n = Single_swath.lat

    # Deal with satellite location and velocity
    latlon_recef = geo.ecef_to_geodetic(Single_orbData.r_ecef)
    lon_recef = latlon_recef[:, 1]
    # Unwrap the longitudes
    lon_recef = np.where(lon_recef > 0, lon_recef, lon_recef + 360)

    # Find according to specific track
    timevec = (Single_orbData.timevec +
               ((track_n - 1) * Single_orbData.timevec.shape[0] *
                Single_orbData.timestep))
    sw_lon_n = np.mod(sw_lon - (track_n - 1)*delta_lon, 360)
    sw_lon_n = np.where(sw_lon_n > 0, sw_lon_n, sw_lon_n + 360)
    sw_lon_n[np.where(sw_lon_n > (0 + 180))] -= 360

    lon_recef_n = np.mod(lon_recef - (track_n - 1)*delta_lon, 360)
    lon_recef_n = np.where(lon_recef_n > 0, lon_recef_n, lon_recef_n + 360)
    lon_recef_n[np.where(lon_recef_n > 0 + 180)[0]] -= 360
    latlon_recef_n = np.copy(latlon_recef)
    latlon_recef_n[:, 1] = lon_recef_n
    # convert back to ECEF Frame
#    r_ecef_n = geo.ecef_to_geodetic(latlon_recef_n, True)
    r_ecef_n = rot_z(Single_orbData.r_ecef, (track_n - 1)*delta_lon).T
    v_ecef_n = rot_z(Single_orbData.v_ecef, (track_n - 1)*delta_lon).T

    t2r = interpol.interp1d(timevec, r_ecef_n.T, kind=int_type)
    t2v = interpol.interp1d(timevec, v_ecef_n.T, kind=int_type)

    if track == 'ascending':
        timenew = timevec[asc_idx[0]:asc_idx[1] + 1]
    elif track == 'descending':
        timenew = timevec[desc_idx[0]:desc_idx[1] + 1]
    else:
        timenew = timevec

    # Find targets
    timespan = int(timenew[-1] - timenew[0])
    time = np.arange(int(timespan / t_step))
    time = time*t_step + np.ceil(timenew[0])

    r_ecef = t2r(time).T
    v_ecef = t2v(time).T

    LoS = geo.create_LoS(r_ecef, v_ecef, look_angle,
                         force_zero_Doppler=force_zd)
    targets = geo.pt_get_intersection_ellipsoid(r_ecef, LoS)
    targets = targets.reshape(targets.shape[0]*targets.shape[1], 3)
    targets = targets[1*len(look_angle):-1*len(look_angle)]
    tars_geo = geo.ecef_to_geodetic(targets)

    # testing ground velocity
    LoS2 = geo.create_LoS(r_ecef, v_ecef, np.array((0)),
                          force_zero_Doppler=force_zd)
    rs = geo.pt_get_intersection_ellipsoid(r_ecef, LoS2)
    rs = rs.reshape(rs.shape[0]*rs.shape[1], 3)
    rs = rs[1:-1]
    r_earth_t = np.linalg.norm(rs, axis=1)

    h_orb = np.linalg.norm(r_ecef[1:-1], axis=1) - r_earth_t
    inc_angle = geo.look_to_inc(look_angle, h_orb)
    G_az = (r_earth_t/(r_earth_t + h_orb) * np.cos(inc_angle - look_angle))
    v_norm = np.linalg.norm(v_ecef[1:-1], axis=1)
    v_gr = v_norm*G_az

    if not silent_flag:
        # Fo plotting swath
        if track == 'ascending':
            sw_lon_track = sw_lon_n[asc_idx[0]:asc_idx[1] + 1, :]
            sw_lat_track = sw_lat_n[asc_idx[0]:asc_idx[1] + 1, :]
            # For plotting ground track
            lats = latlon_recef_n[asc_idx[0]:asc_idx[1] + 1, 0]
            lons = latlon_recef_n[asc_idx[0]:asc_idx[1] + 1, 1]
        elif track == 'descending':
            sw_lon_track = sw_lon_n[desc_idx[0]:desc_idx[1] + 1, :]
            sw_lat_track = sw_lat_n[desc_idx[0]:desc_idx[1] + 1, :]
            # For plotting ground track
            lats = latlon_recef_n[desc_idx[0]:desc_idx[1] + 1, 0]
            lons = latlon_recef_n[desc_idx[0]:desc_idx[1] + 1, 1]
        else:
            sw_lon_track = sw_lon_n
            sw_lat_track = sw_lat_n
            lats = latlon_recef_n[:, 0]
            lons = latlon_recef_n[:, 1]

        plt.figure()
        matplotlib.rcParams.update({'font.size': 14})
        plt.title(str(dDays) + "/" + str(nRevs) + " RGT (" + track +
                  "),    track_num: " + str(track_n), fontsize=14)
        m = Basemap(projection='cyl', resolution='l', area_thresh=None,
                    lat_0=0, lon_0=0, llcrnrlon=-180, urcrnrlon=180)
        m.drawmeridians(np.arange(-180, 180, 10), labels=[1, 0, 0, 1],
                        fontsize=12)
        m.drawparallels(np.arange(-90, 90, 10),  labels=[1, 0, 0, 1],
                        fontsize=12)

        m.drawmapboundary()
        m.drawcoastlines()
        m.fillcontinents(color='#808080', lake_color='white')
        m.scatter(sw_lon_track, sw_lat_track, alpha=0.01, color='green',
                  zorder=3, marker='.')
        m.scatter(lons, lats, alpha=0.3, color='red', zorder=3, marker='.')
        m.scatter(tars_geo[:, 1], tars_geo[:, 0], alpha=0.8, color='blue',
                  marker='x', linewidth='2', zorder=10)
        plt.show()

#        plt.figure()
#        plt.plot(tars_geo[:, 0].astype(int), G_az)
#        plt.title('ground/orbital velocity')
#        plt.xlabel('latitude')
#        plt.ylabel('Factor')
    return tars_geo
