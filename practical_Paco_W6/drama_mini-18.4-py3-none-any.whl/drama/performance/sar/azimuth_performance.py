""" This module provides code to compute the azimuth performance for some SAR modes
"""

import numpy as np
import matplotlib
from matplotlib import pyplot as plt
import scipy.interpolate as interpol
import drama.constants as cnst
# import drama.performance.sar.antenna_patterns as trpat
from .antenna_patterns import pattern
import drama.geo.sar as geo
import drama.utils as trtls
from drama.geo.sar.geo_history import GeoHistory
from drama.io import cfg
import os


def mode_from_conf(conf, modename='stripmap'):
    try:
        mcnf = getattr(conf, modename)
        # inc
        incs = np.zeros((mcnf.inc_near.size, 2))
        incs[:, 0] = mcnf.inc_near
        incs[:, 1] = mcnf.inc_far
        PRFs = mcnf.PRF
        proc_bw = mcnf.proc_bw
        steering_rate = np.zeros(incs.shape[0])
        steering_rate[:] = np.radians(mcnf.steering_rate)
        burst_length = np.ones_like(steering_rate)
        burst_length[:] = mcnf.burst_length
        short_name = mcnf.short_name
        proc_tap = np.ones_like(steering_rate)
        pulse_length = mcnf.pulse_length
        pulse_bw = mcnf.pulse_bw
        if hasattr(mcnf, 'proc_tapering'):
            proc_tap[:] = mcnf.proc_tapering
        return (incs, PRFs, proc_bw, steering_rate, burst_length, short_name,
                proc_tap, pulse_length, pulse_bw)
    except:
        mesg = ("Mode %s is not defined" % modename)
        raise ValueError(mesg)


def beamcentertime_to_zeroDopplertime(bct, steering_rate, dudt):
    """
    Computes the zero Doppler time from the beamcenter and the steering rate
    :param bct: 
    :param steering_rate: 
    :param dudt: 
    :return: 
    """
    #t_bc = - steering_rate * t_in_b / (dudt - steering_rate)
    # if steering_rate == 0:
    #     # FIXME: no squint considered here!!!
    #     zdt = bct
    # else:
    #     #zdt = - bct * (dudt - steering_rate) / steering_rate
    zdt = bct * (1-steering_rate/dudt)
    return zdt


def calc_aasr(conf, modename, swth, t_in_bs=[-1, 0.0,  1],
              txname='sentinel', rxname='sesame',
              tx_ant=None, rx_ant=None,
              n_az_pts=11,
              Tanalysis=10,
              Namb=2, savedirr='',
              view_amb_patterns=False,
              view_patterns=False,
              plot_patterns=True,
              plot_AASR=True,
              fontsize=12,
              vmin=None, vmax=None):
    """ Computes azimuth ambiguities for single-channel systems. The operation
        mode is defined by the steering rates

        :param conf: configuration trampa.io.cfg.ConfigFile object with
                     configuration read from parameter file
        :param modename: name of section in configuration file describing
                         the mode
        :param swth: swath or subswath analyzed
        :param t_in_bs: zero Doppler time of target within burst. Note that
                        the burst length considering the zero Doppler times
                        of the imaged targets will be larger than the raw-data
                        time for TOPS-like modes with positive squint rates.
                       å For spotlight modes the oposite true.
        :param txname: name of section in parameter structure defining the
                       tx radar (antenna)
        :param rxname: same for rx radar (antenna)
        :param tx_ant: pattern class instance with tx antenna: if not given it is generated according to
                       definition in conf.
        :param rx_ant: pattern class instance with rx antenna: if not given bla, bla, bla...
        :param n_az_pts: number of points in burst, if times not explicitly given
        :param Namb: number of positive ambiguities considered; i.e. the
                     actual number of ambiguities accounted for is 2 * Namb
        :param savedirr: where to save the outputs

    """
    wl = cnst.c / conf.sar.f0
    (incs, PRFs, proc_bw,
     steering_rates,
     burst_lengths, short_name, proc_tap, tau_p, bw_p) = mode_from_conf(conf, modename)
    Npts = 256
    PRF = PRFs[swth]
    inc_range = incs[swth]
    inc_v = np.linspace(incs[swth, 0], incs[swth, 1])
    la_v = geo.inc_to_look(np.radians(inc_v), conf.orbit.Horb)
    inc_ve = np.linspace(incs[swth, 0] - 1, incs[swth, 1] + 1)
    la_ve = geo.inc_to_look(np.radians(inc_ve), conf.orbit.Horb)
    try:
        txcnf = getattr(conf, txname)
        rxcnf = getattr(conf, rxname)
    except:
        raise ValueError("Either transmitter or receicer section not defined")
    ghist = GeoHistory(conf,
                       tilt=txcnf.tilt,
                       tilt_b=rxcnf.tilt,
                       latitude=0,
                       bistatic=True,
                       dau=conf.formation_primary.dau[0],
                       inc_range=inc_range + np.array([-1, 1]))

    print("Compute Patterns")
    if hasattr(txcnf, 'wa_tx'):
        wa_tx = txcnf.wa_tx
    else:
        wa_tx = 1
    if tx_ant is None:
        tx_ant = pattern(conf.sar.f0,
                         type_a=txcnf.type_a,
                         type_e=txcnf.type_e,
                         La=txcnf.La,
                         Le=txcnf.Le,
                         el0=(np.degrees(np.mean(la_v)) - txcnf.tilt),
                         Nel_a=txcnf.Na,
                         Nel_e=txcnf.Ne,
                         wa=wa_tx)
    else:
        print("calc_aasr: using supplied tx pattern")
    if rx_ant is None:
        if hasattr(rxcnf, 'wa_rx'):
            if type(rxcnf.wa_rx) is np.ndarray:
                wa_rx = rxcnf.wa_rx
            else:
                c0 = rxcnf.wa_rx
                Na = rxcnf.Na
                wa_rx = (c0 -
                         (1 - c0) * np.cos(2 * np.pi * np.arange(Na) / (Na - 1)))
        else:
            wa_rx = 1
        rx_ant = pattern(conf.sar.f0,
                         type_a=rxcnf.type_a,
                         type_e=rxcnf.type_e,
                         La=rxcnf.La,
                         Le=rxcnf.Le,
                         Nel_a=rxcnf.Na,
                         Nel_e=rxcnf.Ne,
                         wa=wa_rx)
    else:
        print("calc_aasr: using supplied rx pattern")

    fdt0 = ghist.v_Dop_spl(la_v, 0) * 2 / wl
    fd0 = np.mean(fdt0)
    fd = fd0 + np.linspace(-(Namb + 0.5) * PRF, (Namb + 0.5) * PRF, Npts)
    tuv = ghist.Doppler2tuv(la_v, fd, conf.sar.f0)
    (t, u, v, u_b, v_b) = tuv
    steering_rate = steering_rates[swth]
    squint = steering_rate * t
    s1_pat, xpat = tx_ant.pat_2D(v, u, grid=False,
                                 squint_rad=squint)
    sesame_pat, xpat = rx_ant.pat_2D(v_b, u_b, grid=False)
    # plt.figure()
    # plt.imshow(np.abs(np.abs(s1_pat)), origin='lower', cmap='viridis')
    # In time domain
    burst_length = burst_lengths[swth]
    # Tanalysis = Tanalysis
    # Time vector
    t0 = 0
    tv = np.arange(int(Tanalysis * 2 * PRF))/PRF/2 - Tanalysis/2
    # Time in burst, this is also azimuth time of target in zero Doppler geometry
    # FIXME: this is not valid for spotlight modes
    dudt = ghist.dudt(la_v)[0]  # The second element in tuple is for the receiver
    if t_in_bs is None:
        print("calc_aasr: nor burt times given, calculating them from burst length")
        burst_length = burst_lengths[swth]
        # FIXME: course approximation
        dr_approx = 2 / wl * ghist.v_orb**2 / ghist.sr_spl.ev(np.mean(la_v), t0)
        t_int = proc_bw[swth] / dr_approx
        burst_length_eff = burst_length - t_int
        bcts = np.linspace(-burst_length_eff/2, burst_length_eff/2, n_az_pts)
        t_in_bs = beamcentertime_to_zeroDopplertime(bcts, steering_rate, np.mean(dudt))
    else:
        t_in_bs = np.array(t_in_bs)
        n_az_pts = t_in_bs.size
    # relative to busrt center
    # t_in_bs = [-0.3, 0.0,  0.3]
    # Set font..
    font = {'family': "Arial",
            'weight': 'normal',
            'size': fontsize}
    matplotlib.rc('font', **font)

    AASR_out = np.zeros((n_az_pts, la_v.size))
    AASR_tap_out = np.zeros_like(AASR_out)

    u = ghist.t2u_spl(la_v, tv)
    v = ghist.t2v_spl(la_v, tv)
    u_b = ghist.t2u_b_spl(la_v, tv)
    v_b = ghist.t2v_b_spl(la_v, tv)
    # Delta Doppler to ambiguities
    dfamb = (PRF *
             (np.concatenate((np.arange(-Namb, 0),
                              np.arange(1, Namb + 1))).reshape((1, 2 * Namb))))

    for t_in_b_ind in range(n_az_pts):
        t_in_b = t_in_bs[t_in_b_ind]
        #  Antenna squint will be
        squint = steering_rate * (tv - t_in_b)
        if rxcnf.az_steer:
            sesame_squint = steering_rate * (tv - t_in_b)
        else:
            sesame_squint = None
        if hasattr(rxcnf, 'DBF'):
            if rxcnf.DBF:
                # Simplest Doppler dependent DBF
                sesame_squint = u_b
        # u for target is approximately given by
        # u = dudt * t
        # Thus target is at beam center when
        # squint = u -> t_bc

        t_bc = - steering_rate * t_in_b / (dudt - steering_rate)
        # t_bc = t_in_b * dudt / (dudt - steering_rate)
        u_bc = steering_rate * t_bc

        # Slant range and Doppler
        sr = ghist.sr_spl(la_v, tv)
        # Time at which we see Doppler ambiguities
        fdt0 = ghist.v_Dop_spl.ev(la_v.reshape((la_v.size, 1)), t_bc) * 2 / wl
        famb = fdt0 + dfamb
        tuv = ghist.Doppler2tuv(la_v, famb, conf.sar.f0)

        t_amb = tuv[0]
        dt_amb = t_amb - t_bc
        sr0 = ghist.sr_spl.ev(la_v.reshape((la_v.size, 1)), t0)
        sr_amb = ghist.sr_spl.ev(la_v.reshape((la_v.size, 1)), t_amb)
        dsr_amb = sr_amb - sr0
        sr_amb = sr0 - dsr_amb

        # Look angle at t0 of ambiguity; we correct for range migration
        sr0e = ghist.sr_spl.ev(la_ve.reshape((la_ve.size, 1)), t0)
        sr2look = interpol.interp1d(sr0e.flatten(), la_ve)
        la_amb = sr2look(sr_amb).reshape(dt_amb.shape + (1,))

        # Geometry of ambiguities
        tv_rshp = tv.reshape((1, 1, tv.size))
        tv_amb = tv_rshp + dt_amb.reshape(dt_amb.shape + (1,))
        u_amb = ghist.t2u_spl.ev(la_amb, tv_amb)
        v_amb = ghist.t2v_spl.ev(la_amb, tv_amb)
        u_b_amb = ghist.t2u_b_spl.ev(la_amb, tv_amb)
        v_b_amb = ghist.t2v_b_spl.ev(la_amb, tv_amb)

        Dop = ghist.v_Dop_spl(la_v, tv) * 2 / wl

        s1_pat, xpat = tx_ant.pat_2D(v, u, grid=False,
                                     squint_rad=squint)
        sesame_pat, xpat = rx_ant.pat_2D(v_b, u_b, grid=False,
                                             squint_rad=sesame_squint)
        # Ambiguous patterns
        s1_pat_amb, xpat = tx_ant.pat_2D(v_amb, u_amb, grid=False,
                                         squint_rad=squint)
        if hasattr(rxcnf, 'DBF'):
            if rxcnf.DBF:
                # Simplest Doppler dependent DBF
                sesame_squint = sesame_squint.reshape((u.shape[0],
                                                       1, u.shape[1]))
        sesame_pat_amb, xpat = rx_ant.pat_2D(v_b_amb, u_b_amb, grid=False,
                                             squint_rad=sesame_squint)

        # Two way patterns
        tw_pat = np.abs(s1_pat * sesame_pat)**2
        tw_pat_amb = np.abs(s1_pat_amb * sesame_pat_amb)**2
        tw_sumpat_amb = np.sum(tw_pat_amb, axis=1)

        # AASR spectrum
        AASRt = tw_sumpat_amb / tw_pat

        # Azimuth ambiguity
        dDop = Dop - fdt0
        mask = np.where(np.abs(dDop) < proc_bw[swth]/2, 1, 0)
        AASR = (np.sum(tw_sumpat_amb * mask, axis=-1) /
                np.sum(tw_pat * mask, axis=-1))
        AASR_out[t_in_b_ind, :] = AASR

        if proc_tap[swth] != 1:
            c0 = proc_tap[swth]
            rDop = (dDop + proc_bw[swth] / 2) / proc_bw[swth]
            azwin = (mask *
                     (c0 - (1 - c0) * np.cos(2 * np.pi * rDop))) ** 2
            AASR_tap = (np.sum(azwin * AASRt, axis=-1) /
                        np.sum(azwin, axis=-1))
            AASR_tap_out[t_in_b_ind, :] = AASR_tap
#            plt.figure()
#            plt.plot(dDop[25,:], azwin[25,:])
#            plt.figure()
#            plt.plot(dDop[25,:], trtls.db(AASRt[25]))

        # Plots
        title = ("%s, sw%i, $\Delta t_{az}$=%4.2f s" % (short_name, swth + 1,
                                                        t_in_b))
        modeandswth = ("%s_sw%i" % (short_name, swth + 1))
        modedir = os.path.join(savedirr, modeandswth)
        name = ("%s_sw%i_dtaz%ims" % (short_name, swth + 1,
                                      int(1000 * t_in_b)))
        plt_this_one =  t_in_b_ind in [0, int(n_az_pts/2), n_az_pts-1]

        if view_patterns and plt_this_one:
            plt.figure()
            extent = [np.min(tv), np.max(tv), inc_range[0], inc_range[1]]
            plt.imshow(trtls.db(np.abs(s1_pat)**2), origin='lower',
                       extent=extent, aspect='auto', cmap='viridis',
                       vmin=-25, vmax=0)
            plt.xlabel('Time [s]')
            plt.ylabel('Incident angle [deg]')
            plt.colorbar()
            plt.figure()
            plt.imshow(trtls.db(np.abs(sesame_pat)**2), origin='lower',
                       extent=extent, aspect='auto', cmap='viridis',
                       vmin=-25, vmax=0)
            plt.xlabel('Time [s]')
            plt.ylabel('Incident angle [deg]')
            plt.colorbar()
            savefile = os.path.join(modedir, name) + "_2D_pat.png"
            os.makedirs(os.path.dirname(savefile), exist_ok=True)
            plt.savefig(savefile, bbox_inches='tight')

        if view_amb_patterns and plt_this_one:
            for ind in range(2*Namb):
                plt.figure()
                extent = [np.min(tv), np.max(tv), inc_range[0], inc_range[1]]
                plt.imshow(trtls.db(np.abs(s1_pat_amb[:, ind, :])**2), origin='lower',
                           extent=extent, aspect='auto', cmap='viridis',
                           vmin=-25, vmax=0)
                plt.xlabel('Time [s]')
                plt.ylabel('Incident angle [deg]')
                plt.colorbar()


        if plot_patterns and plt_this_one:
            lat_ind = 25
            goodf = np.where(np.abs(dDop[lat_ind]) < proc_bw[swth]/2)
            plt.figure()
            plt.plot(tv, trtls.db(np.abs(s1_pat[lat_ind])**2),
                     label='$G_{tx}$')
            plt.plot(tv, trtls.db(np.abs(sesame_pat[lat_ind])**2),
                     label='$G_{rx}$')
            plt.plot(tv, trtls.db(tw_pat[lat_ind]), 'g', lw=1)
            plt.plot(tv[goodf], trtls.db(tw_pat[lat_ind][goodf]),
                     'g', label='$G_{2w}$', lw=3)
            for ind in range(2 * Namb):
                plt.plot(tv, (trtls.db(tw_pat_amb[lat_ind, ind])), '--', lw=1)
            plt.plot(tv, (trtls.db(tw_sumpat_amb[lat_ind])), 'r', lw=1)
            plt.plot(tv[goodf], (trtls.db(tw_sumpat_amb[lat_ind][goodf])),
                     'r', lw=3, label='$\sum G_{2w,a}$ ')
            plt.xlabel('Integration window [s]')
            plt.ylabel('G [dB]')
            plt.ylim(-40, 0)
            plt.xlim(-1 + t_bc[lat_ind], 1 + t_bc[lat_ind])
            plt.title(title)
            plt.grid(True)
            plt.legend()
            savefile = os.path.join(modedir, name) + "_az_pat.png"
            os.makedirs(os.path.dirname(savefile), exist_ok=True)
            plt.savefig(savefile, bbox_inches='tight')
    #        plt.figure()
    #        plt.plot(Dop[lat_ind], trtls.db(AASRt[lat_ind]))
    #        plt.xlim(fdt0[lat_ind] - PRF/2, fdt0[lat_ind] + PRF/2)
    #        plt.ylim(trtls.db(AASRt[lat_ind]).min(), 10)
    #        plt.grid(True)
    #
    #        plt.plot(Dop[lat_ind][goodf], trtls.db(AASRt[lat_ind][goodf]),
    #                 lw=2)
    #        plt.xlabel("$f_\mathrm{Doppler}$ [Hz]")
    #        plt.ylabel('AASR')
    #        plt.title(mode_names[mode])
        if plot_AASR and plt_this_one:
            plt.figure()
            #plt.plot(inc_v, trtls.db(AASR))
            if proc_tap[swth] != 1:
                plt.plot(inc_v, trtls.db(AASR), label='Intrinsic')
                plt.plot(inc_v, trtls.db(AASR_tap),
                         label=("Tap. coef. %3.2f" % proc_tap[swth]))
                plt.legend(loc='best')
            else:
                plt.plot(inc_v, trtls.db(AASR))
            plt.grid(True)
            plt.xlabel("Incident angle [deg]")
            plt.ylabel("AASR [dB]")
            plt.title(title)
            savefile = os.path.join(modedir, name) + "_AASR.png"
            os.makedirs(os.path.dirname(savefile), exist_ok=True)
            plt.savefig(savefile, bbox_inches='tight')

    # Output
    title = ("%s, sw%i" % (short_name, swth + 1))
    modeandswth = ("%s_sw%i" % (short_name, swth + 1))
    modedir = os.path.join(savedirr, modeandswth)
    name = ("%s_sw%i" % (short_name, swth + 1))
    if plot_AASR:
        plt.figure()
        # plt.plot(inc_v, trtls.db(AASR))
        for t_in_b_ind in range(n_az_pts):
            t_in_b = t_in_bs[t_in_b_ind]
            if proc_tap[swth] != 1:
                plt.plot(inc_v, trtls.db(AASR_tap_out[t_in_b_ind]),
                         label=('Intr. $\Delta t_{az}$=%4.2f s' % t_in_b))
                #plt.plot(inc_v, trtls.db(AASR_tap_out[t_in_b_ind]), '--',
                #         label=("Tap. coef. %3.2f" % proc_tap[swth]))

            else:
                plt.plot(inc_v, trtls.db(AASR),
                         label=('Intr. $\Delta t_{az}$=%4.2f s' % t_in_b))
        plt.grid(True)
        plt.legend(loc='best')
        plt.xlabel("Incident angle [deg]")
        plt.ylabel("AASR [dB]")
        plt.title(title)
        savefile = os.path.join(modedir, name) + "_AASR.png"
        os.makedirs(os.path.dirname(savefile), exist_ok=True)
        plt.savefig(savefile, bbox_inches='tight')
        if n_az_pts > 8:
            plt.figure()
            AASR_final = np.where(AASR_tap_out > AASR_out, AASR_out, AASR_tap_out)
            corners = [np.min(t_in_bs), np.max(t_in_bs), inc_range[0], inc_range[1]]
            aspect = 4 * (np.max(t_in_bs) - np.min(t_in_bs)) / (inc_range[1] - inc_range[0])
            AASR_dB = 10 * np.log10(AASR_final.transpose())
            if vmin is None:
                vmin = np.nanmin(AASR_dB)
            if vmax is None:
                vmax = np.nanmax(AASR_dB)
            ims = plt.imshow(AASR_dB,
                             origin='lower', aspect=aspect, interpolation='nearest',
                             cmap='viridis_r', extent=corners, vmin=vmin, vmax=vmax)
            plt.xlabel('Zero Doppler Time [s]')
            ax = plt.gca()
            ax.locator_params(axis='x', nbins=3)
            plt.ylabel('Incident angle [deg]')
            plt.title('AASR')
            cbar = trtls.add_colorbar(ims)
            cbar.set_label('dB')
            savefile = os.path.join(modedir, name) + "_AASR_all.png"
            plt.savefig(savefile, bbox_inches='tight')

    return la_v, inc_v, AASR_out, AASR_tap_out


def calc_nesz(conf, modename, swth, t_in_bs=[-1, 0.0,  1],
              txname='sentinel', rxname='sesame',
              tx_ant=None, rx_ant=None,
              n_az_pts=11,
              Tanalysis=2.5,
              extra_losses=0,
              savedirr='',
              plot_NESZ=True,
              fontsize=12,
              vmin=None,
              vmax=None):
    """ Computes azimuth ambiguities for single-channel systems. The operation
        mode is defined by the steering rates

        :param conf: configuration trampa.io.cfg.ConfigFile object with
                     configuration read from parameter file
        :param modename: name of section in configuration file describing
                         the mode
        :param swth: swath or subswath analyzed
        :param t_in_bs: zero Doppler time of target within burst. Note that
                        the burst length considering the zero Doppler times
                        of the imaged targets will be larger than the raw-data
                        time for TOPS-like modes with positive squint rates.
                       å For spotlight modes the oposite true.
        :param txname: name of section in parameter structure defining the
                       tx radar (antenna)
        :param rxname: same for rx radar (antenna)
        :param tx_ant: pattern class instance with tx antenna: if not given it is generated according to
                       definition in conf.
        :param rx_ant: pattern class instance with rx antenna: if not given bla, bla, bla...
        :param n_az_pts: number of points in burst, if times not explicitly given
        :param extra_losses: losses not considered elsewhere, in dB (thus not included in noise 
                             temperature of receiver, nor Tx power.
        :param savedirr: where to save the outputs

    """
    wl = cnst.c / conf.sar.f0
    (incs, PRFs, proc_bw,
     steering_rates,
     burst_lengths, short_name, proc_tap, tau_p, bw_p) = mode_from_conf(conf, modename)
    Npts = 256
    PRF = PRFs[swth]
    inc_range = incs[swth]
    time_bandwidth = tau_p[swth] * bw_p[swth]
    print("Time bandwidth: %3.2f" % time_bandwidth)
    inc_v = np.linspace(incs[swth, 0], incs[swth, 1])
    la_v = geo.inc_to_look(np.radians(inc_v), conf.orbit.Horb)
    inc_ve = np.linspace(incs[swth, 0] - 1, incs[swth, 1] + 1)
    la_ve = geo.inc_to_look(np.radians(inc_ve), conf.orbit.Horb)
    try:
        txcnf = getattr(conf, txname)
        rxcnf = getattr(conf, rxname)
    except:
        raise ValueError("Either transmitter or receicer section not defined")
    ghist = GeoHistory(conf,
                       tilt=txcnf.tilt,
                       tilt_b=rxcnf.tilt,
                       latitude=0,
                       bistatic=True,
                       dau=conf.formation_primary.dau[0],
                       inc_range=inc_range + np.array([-1, 1]))

    print("Compute Patterns")
    if hasattr(txcnf, 'wa_tx'):
        wa_tx = txcnf.wa_tx
    else:
        wa_tx = 1
    if tx_ant is None:
        tx_phase_attr = ("w_tx_phase_%i" % int(swth+1))
        mcnf = getattr(conf, modename)
        if hasattr(mcnf, tx_phase_attr):
            we_tx = np.exp(1j * np.radians(getattr(mcnf, tx_phase_attr)))
            # print(np.angle(we_tx))
            print("calc_nesz: applying elevation weighting to tx pattern!")
            el0 = 0  # Pointing given in phase!
        else:
            we_tx = 1
            el0 = (np.degrees(np.mean(la_v)) - txcnf.tilt)
        tx_ant = pattern(conf.sar.f0,
                         type_a=txcnf.type_a,
                         type_e=txcnf.type_e,
                         La=txcnf.La,
                         Le=txcnf.Le,
                         el0=el0,
                         Nel_a=txcnf.Na,
                         Nel_e=txcnf.Ne,
                         wa=wa_tx,
                         we=we_tx)
    else:
        print("calc_aasr: using supplied tx pattern")
    if rx_ant is None:
        if hasattr(rxcnf, 'wa_rx'):
            if type(rxcnf.wa_rx) is np.ndarray:
                wa_rx = rxcnf.wa_rx
            else:
                c0 = rxcnf.wa_rx
                Na = rxcnf.Na
                wa_rx = (c0 -
                         (1 - c0) * np.cos(2 * np.pi * np.arange(Na) / (Na - 1)))
        else:
            wa_rx = 1
        rx_ant = pattern(conf.sar.f0,
                         type_a=rxcnf.type_a,
                         type_e=rxcnf.type_e,
                         La=rxcnf.La,
                         Le=rxcnf.Le,
                         Nel_a=rxcnf.Na,
                         Nel_e=rxcnf.Ne,
                         wa=wa_rx)
    else:
        print("calc_nesz: using supplied rx pattern")

    fdt0 = ghist.v_Dop_spl(la_v, 0) * 2 / wl
    fd0 = np.mean(fdt0)
    Namb = 1
    fd = fd0 + np.linspace(-(Namb + 0.5) * PRF, (Namb + 0.5) * PRF, Npts)
    tuv = ghist.Doppler2tuv(la_v, fd, conf.sar.f0)
    (t, u, v, u_b, v_b) = tuv
    steering_rate = steering_rates[swth]
    squint = steering_rate * t
    s1_pat, xpat = tx_ant.pat_2D(v, u, grid=False,
                                 squint_rad=squint)
    sesame_pat, xpat = rx_ant.pat_2D(v_b, u_b, grid=False)
    # plt.figure()
    # plt.imshow(np.abs(np.abs(s1_pat)), origin='lower', cmap='viridis')
    # In time domain
    burst_length = burst_lengths[swth]
    # Tanalysis = Tanalysis
    # Time vector
    t0 = 0
    tv = np.arange(int(Tanalysis * PRF)) / PRF - Tanalysis / 2
    # Time in burst, this is also azimuth time of target in zero Doppler geometry
    # FIXME: this is not valid for spotlight modes
    dudt = ghist.dudt(la_v)[0]  # The second element in tuple is for the receiver
    if t_in_bs is None:
        print("calc_aasr: nor burt times given, calculating them from burst length")
        burst_length = burst_lengths[swth]
        # FIXME: course approximation
        dr_approx = 2 / wl * ghist.v_orb**2 / ghist.sr_spl.ev(np.mean(la_v), t0)
        t_int = proc_bw[swth] / dr_approx
        burst_length_eff = burst_length - t_int
        bcts = np.linspace(-burst_length_eff/2, burst_length_eff/2, n_az_pts)
        t_in_bs = beamcentertime_to_zeroDopplertime(bcts, steering_rate, np.mean(dudt))
    else:
        t_in_bs = np.array(t_in_bs)
        n_az_pts = t_in_bs.size
    # relative to busrt center
    # t_in_bs = [-0.3, 0.0,  0.3]
    # Set font..
    font = {'family': "Arial",
            'weight': 'normal',
            'size': fontsize}
    matplotlib.rc('font', **font)

    NESZ_out = np.zeros((n_az_pts, la_v.size))
    NESZ_tap_out = np.zeros_like(NESZ_out)

    u = ghist.t2u_spl(la_v, tv)
    v = ghist.t2v_spl(la_v, tv)
    u_b = ghist.t2u_b_spl(la_v, tv)
    v_b = ghist.t2v_b_spl(la_v, tv)
    # Delta Doppler to ambiguities
    v_ground = ghist.v_orb * cnst.r_earth / (cnst.r_earth + conf.orbit.Horb)

    for t_in_b_ind in range(n_az_pts):
        t_in_b = t_in_bs[t_in_b_ind]
        #  Antenna squint will be
        squint = steering_rate * (tv - t_in_b)
        if rxcnf.az_steer:
            sesame_squint = steering_rate * (tv - t_in_b)
        else:
            sesame_squint = None
        if hasattr(rxcnf, 'DBF'):
            if rxcnf.DBF:
                # Simplest Doppler dependent DBF
                sesame_squint = u_b
        # u for target is approximately given by
        # u = dudt * t
        # Thus target is at beam center when
        # squint = u -> t_bc

        t_bc = - steering_rate * t_in_b / (dudt - steering_rate)
        # t_bc = t_in_b * dudt / (dudt - steering_rate)
        u_bc = steering_rate * t_bc

        # Slant range and Doppler
        sr = ghist.sr_spl(la_v, tv)
        # Time at which we see Doppler ambiguities
        fdt0 = ghist.v_Dop_spl.ev(la_v.reshape((la_v.size, 1)), t_bc) * 2 / wl

        sr0 = ghist.sr_spl.ev(la_v.reshape((la_v.size, 1)), t0)

        # Look angle at t0 of ambiguity; we correct for range migration
        sr0e = ghist.sr_spl.ev(la_ve.reshape((la_ve.size, 1)), t0)
        sr2look = interpol.interp1d(sr0e.flatten(), la_ve)

        # Geometry of ambiguities
        tv_rshp = tv.reshape((1, 1, tv.size))

        Dop = ghist.v_Dop_spl(la_v, tv) * 2 / wl

        s1_pat, xpat = tx_ant.pat_2D(v, u, grid=False,
                                     squint_rad=squint)
        sesame_pat, xpat = rx_ant.pat_2D(v_b, u_b, grid=False,
                                         squint_rad=sesame_squint)

        if hasattr(rxcnf, 'DBF'):
            if rxcnf.DBF:
                # Simplest Doppler dependent DBF
                sesame_squint = sesame_squint.reshape((u.shape[0],
                                                       1, u.shape[1]))

        # Two way patterns
        tw_pat = np.abs(s1_pat * sesame_pat)
        # Amplitude of received signal for NESZ = 1 (0 dB)
        # Pulse energy
        E_p = txcnf.P_peak * time_bandwidth
        # 2-D Resolution
        A_res = cnst.c / 2 / bw_p[swth] / np.sin(np.radians(inc_v)) * v_ground / proc_bw[swth]
        A_1 = (np.sqrt(E_p) * tw_pat * wl / ((4 * np.pi)**1.5 * sr**2) *
               np.sqrt(A_res.reshape((inc_v.size, 1))) * tx_ant.g0 * rx_ant.g0)

        dDop = Dop - fdt0
        mask = np.where(np.abs(dDop) < proc_bw[swth]/2, 1, 0)

        Es = np.sum(A_1 * mask, axis=-1)**2
        En = np.sum(cnst.k * rxcnf.T_sys * bw_p[swth] * mask, axis=-1)
        NESZ = trtls.db(En / Es) + extra_losses
        NESZ_out[t_in_b_ind, :] = NESZ

        if proc_tap[swth] != 1:
            c0 = proc_tap[swth]
            rDop = (dDop + proc_bw[swth] / 2) / proc_bw[swth]
            azwin = (mask *
                     (c0 - (1 - c0) * np.cos(2 * np.pi * rDop)))
            azwin = azwin / tw_pat
            Es = np.sum(azwin * A_1 * mask, axis=-1) ** 2
            En = np.sum(cnst.k * rxcnf.T_sys * bw_p[swth] * mask * azwin**2, axis=-1)
            NESZ_tap = trtls.db(En / Es) + extra_losses

            NESZ_tap_out[t_in_b_ind, :] = NESZ_tap
#            plt.figure()
#            plt.plot(dDop[25,:], azwin[25,:])
#            plt.figure()
#            plt.plot(dDop[25,:], trtls.db(AASRt[25]))

        # Plots
        title = ("%s, sw%i, $\Delta t_{az}$=%4.2f s" % (short_name, swth + 1,
                                                        t_in_b))
        modeandswth = ("%s_sw%i" % (short_name, swth + 1))
        modedir = os.path.join(savedirr, modeandswth)
        name = ("%s_sw%i_dtaz%ims" % (short_name, swth + 1,
                                      int(1000 * t_in_b)))
        plt_this_one = t_in_b_ind in [0, int(n_az_pts/2), n_az_pts-1]


        if plot_NESZ and plt_this_one:
            plt.figure()
            #plt.plot(inc_v, trtls.db(AASR))
            if proc_tap[swth] != 1:
                plt.plot(inc_v, NESZ, label='Intrinsic')
                plt.plot(inc_v, NESZ_tap,
                         label=("Tap. coef. %3.2f" % proc_tap[swth]))
                plt.legend(loc='best')
            else:
                plt.plot(inc_v, NESZ)
            plt.grid(True)
            plt.xlabel("Incident angle [deg]")
            plt.ylabel("NESZ [dB]")
            plt.title(title)
            savefile = os.path.join(modedir, name) + "_NESZ.png"
            os.makedirs(os.path.dirname(savefile), exist_ok=True)
            plt.savefig(savefile, bbox_inches='tight')

    # Output
    title = ("%s, sw%i" % (short_name, swth + 1))
    modeandswth = ("%s_sw%i" % (short_name, swth + 1))
    modedir = os.path.join(savedirr, modeandswth)
    name = ("%s_sw%i" % (short_name, swth + 1))
    if plot_NESZ:
        plt.figure()
        # plt.plot(inc_v, trtls.db(AASR))
        for t_in_b_ind in range(n_az_pts):
            t_in_b = t_in_bs[t_in_b_ind]
            if proc_tap[swth] != 1:
                plt.plot(inc_v, NESZ_tap_out[t_in_b_ind],
                         label=('Intr. $\Delta t_{az}$=%4.2f s' % t_in_b))
                #plt.plot(inc_v, trtls.db(AASR_tap_out[t_in_b_ind]), '--',
                #         label=("Tap. coef. %3.2f" % proc_tap[swth]))

            else:
                plt.plot(inc_v, NESZ,
                         label=('Intr. $\Delta t_{az}$=%4.2f s' % t_in_b))
        plt.grid(True)
        plt.legend(loc='best')
        plt.xlabel("Incident angle [deg]")
        plt.ylabel("NESZ [dB]")
        plt.title(title)
        savefile = os.path.join(modedir, name) + "_NESZ.png"
        os.makedirs(os.path.dirname(savefile), exist_ok=True)
        plt.savefig(savefile, bbox_inches='tight')
        if n_az_pts > 8:
            plt.figure()
            NESZ_final = np.where(NESZ_tap_out > NESZ_out, NESZ_out, NESZ_tap_out)
            corners = [np.min(t_in_bs), np.max(t_in_bs), inc_range[0], inc_range[1]]
            aspect = 4 * (np.max(t_in_bs) - np.min(t_in_bs)) / (inc_range[1] - inc_range[0])
            if vmax is None:
                vmax = np.nanmax(NESZ_final)
            if vmin is None:
                vmin =np.nanmin(NESZ_final)
            ims = plt.imshow(NESZ_final.transpose(),
                             origin='lower', aspect=aspect, interpolation='nearest',
                             cmap='viridis_r', extent=corners, vmin=vmin, vmax=vmax)
            plt.xlabel('Zero Doppler Time [s]')
            ax = plt.gca()
            ax.locator_params(axis='x', nbins=3)
            plt.ylabel('Incident angle [deg]')
            plt.title('NESZ')
            cbar = trtls.add_colorbar(ims)
            cbar.set_label('dB')
            savefile = os.path.join(modedir, name) + "_NESZ_all.png"
            plt.savefig(savefile, bbox_inches='tight')

    return la_v, inc_v, NESZ_out, NESZ_tap_out


if __name__ == "__main__":
    pardir = "/Users/plopezdekker/Documents/WORK/SESAME/PAR"
    savedirr = r"/Users/plopezdekker/Documents/WORK/SESAME/PAR/RESULTS/SARPERF/SESAME_5.5_10001/200km/DBF_f"
    parfile = os.path.join(pardir, 'SESAME_Nodrift_A.par')
    conf = cfg.ConfigFile(parfile)
    print(savedirr)
    azimuth_performance(conf, 'IWS', 1, savedirr=savedirr)