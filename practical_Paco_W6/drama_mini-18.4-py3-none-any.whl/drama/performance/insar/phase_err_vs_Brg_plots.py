import numpy as np
from drama.performance.insar import coh_m, phase_err_vs_coh
from drama.utils import db
import scipy.interpolate as interpol
import matplotlib.pyplot as plt


def phase_err_vs_Brg_plots(SNR_ref=10.0, mBrg=20., scene_coh=None,
                           looks_ref=16.0):
    """ Function that plots the interferometric phase error as a function
        of the range resolution and the number of looks.

        :author: Maria Sanjuan-Ferrer.
        
        :param SNR_ref: SNR value (dB). Optional.
        :type SNR_ref: float 
        :param mBrg: Range resolution (m). Optional.
        :type mBrg: float
        :param scene_coh: Coherence values of the scene. Optional.
                          Default = [0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,1.].
        :type scene_coh: float or 1-D float array
        :param looks_ref: Reference number of looks. Optional.
        :type looks_ref: float

        :returns: figure.
    """

    #if (np.size(SNR_ref) != 1):
        #SNR_ref = 10.
    if scene_coh is None:
        scene_coh = np.array([0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.])

#    looks = 2*L**np.arange(np.ceil(np.log2(mBrg*looks_ref)))
    n_Brg = np.size(looks)
    Brgs = looks/looks_ref
    SNR = SNR_ref - db(Brgs)
    coh_snr = coh_m(SNR, db=True)
    perr = np.empty([np.size(scene_coh), n_Brg])
    for index in range(n_Brg):
        nl = looks[index]
        if nl < 1.:
            nl = 1.
        phaseerr_rho, phaseerr_err = phase_err_vs_coh(nl, pp=True)
        f_interp = (interpol.interp1d(phaseerr_rho, phaseerr_err,
                    kind='quadratic'))
        perr_ = (f_interp(coh_snr[index]*scene_coh))/(2.*np.pi)
        perr[:, index] = perr_
    colors = np.array(['black', 'blue', 'red', 'green', 'magenta', 'firebrick',
                       'indigo', 'olive', 'maroon'])
    plt.figure()
    v = [np.min(SNR), np.max(SNR), 0., np.ceil((180.*np.max(perr))/np.pi)]
    plt.axis(v)
    plt.plot(SNR, (180.*perr[-1, :])/np.pi,
             label=r'$\gamma_{s}=$'+str(scene_coh[-1]), color=colors[0])
    for index in range(1, np.size(scene_coh)):
        plt.plot(SNR, (180.*perr[-1-index, :])/np.pi,
                 label=r'$\gamma_{s}=$'+str(scene_coh[-1-index]),
                 color=colors[index % np.size(colors)])
    plt.xlabel('SNR [dB]')
    plt.ylabel('%90 Phase error '+'['+r'$^\circ$'+']')
    plt.grid(True)
    plt.legend(loc='upper left')
    plt.show()
