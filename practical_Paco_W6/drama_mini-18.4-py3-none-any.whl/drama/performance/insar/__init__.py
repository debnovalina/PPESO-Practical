"""
===========================================================
InSAR Performance Package (:mod:`trampa.performance.insar`)
===========================================================

.. currentmodule:: trampa.performance.insar

Coherence as a function or SNR
==============================

.. autosummary::
   :toctree: generated/

    coh_m
    coh_n
    snr2coh_plots

Gauss hypergeometric function
=============================

.. autosummary::
   :toctree: generated/

    gauss_hypergeo_function

PDF of the interferometric phase error
======================================

.. autosummary::
   :toctree: generated/

    p_Delta_Phi

Table values of the PDF of the interferometric phase error
==========================================================

.. autosummary::
   :toctree: generated/

    tbl_delta_phi_pdf_filename
    tbl_delta_phi_pdf

Performance of coherent and incoherent correlation
==================================================

.. autosummary::
   :toctree: generated/

    coh_correlation_norm_accuracy
    incoh_correlation_norm_accuracy
    coh_incoh_perf_plots

Std of the interferometric phase
================================

.. autosummary::
   :toctree: generated/

    stdv_phase_vs_coh

Interferometric phase error as a function of the coherence
==========================================================

.. autosummary::
   :toctree: generated/

    phase_err_vs_coh
    phase_err_vs_coh_plots

Interferometric phase error as a function of SNR
================================================

.. autosummary::
   :toctree: generated/

    phase_err_vs_snr_plots

Interferometric phase error as a function of range resolution
=============================================================

.. autosummary::
   :toctree: generated/

    phase_err_vs_Brg_plots

DInSAR performance analysis
===========================

.. autosummary::
   :toctree: generated/

   hcrb
   hcrb_az
   get_3d_accuracy
   dinsar_perf_tool
   dinsar_pat_main

Coherence Maps
==============

.. autosummary::
   :toctree: generated/

   get_gamma_SNR_ambig_map
   get_gamma_vol_map
   do_plots
"""

from .snr2coh import coh_m, coh_n, snr2coh_plots
from .gauss_hypergeometric import gauss_hypergeo_function
from .p_delta_phi import p_Delta_Phi
from .tbl_delta_phi_pdf import tbl_delta_phi_pdf_filename, tbl_delta_phi_pdf
from .coh_and_incoh_correlation_perfplots import (coh_correlation_norm_accuracy,
                                                  incoh_correlation_norm_accuracy,
                                                  coh_incoh_perf_plots)
from .stdv_phase_vs_coh import stdv_phase_vs_coh
from .phase_err_vs_coh_plots import phase_err_vs_coh, phase_err_vs_coh_plots
from .phase_err_vs_snr_plots import phase_err_vs_snr_plots
from .phase_err_vs_Brg_plots import phase_err_vs_Brg_plots
from .dinsar_pat import (hcrb, hcrb_az, get_3d_accuracy, dinsar_perf_tool,
                         dinsar_pat_main)
#from .coh_maps import (get_gamma_SNR_ambig_map, get_gamma_forestvol_map,
#                       get_gamma_icevol_map,  do_plots)
from .coh_maps import get_gamma_SNR_ambig_map
from .coherence_models import get_gamma_SNR_ambig, get_gamma_Volume