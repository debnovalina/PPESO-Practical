import numpy as np
from scipy import integrate
from drama.performance.insar import tbl_delta_phi_pdf


def add_noise(normdata, SNRdB):
    """ This function adds noise, assuming that the signal power is normalized to 1"""
    noiseamp = np.sqrt((10 ** (-SNRdB/10)) / 2)
    shp = normdata.shape
    return normdata + noiseamp * (np.random.randn(*shp) + 1j * np.random.randn(*shp))


def k_distributed_data(shp, coh, gamma_shape=1, gamma_scale=1, SNRdB=10):
    """
    This function generates a pair of complex matrices according to a K compound distribution and
    assuming a certain coherence between the two (this coherence is applied at the circular Gaussian level)
    :param shp: shape of output matrix
    :param coh: coherence of speckle component
    :param gamma_shape: shape parameter of K-distribution
    :param gamma_scale: scale parameter
    :param SNRdB: SNR in dB
    :return: A tuple with the two matrices. Powers are normalized to 1.
    """

    pow_theor = 2 * gamma_shape * (gamma_shape + 1) * gamma_scale ** 2
    normf = 1 / np.sqrt(pow_theor)
    gamma_amp = np.random.gamma(gamma_shape, gamma_scale, shp)
    slc0_mst = normf * (np.random.randn(*shp) + 1j * np.random.randn(*shp))
    # Here we generate compound signal
    mst = gamma_amp * slc0_mst
    slc0_slv = (coh * slc0_mst +
                normf * np.sqrt(1-coh**2) * (np.random.randn(*shp) + 1j * np.random.randn(*shp)))
    slv = gamma_amp * slc0_slv
    mst = add_noise(mst, SNRdB)
    slv = add_noise(slv, SNRdB)
    return mst, slv


def cGaussian_distributed_data(shp, coh, SNRdB=10):
    """
    This just generates a pair of circular-Gaussian distributed complex matrice
    :param shp: shape of output matrix
    :param coh: coherence between the images
    :param SNRdB: SNR in dB
    :return: A tuple with the two matrices. Powers are normalized to 1.
    """
    mst = (np.random.randn(*shp) + 1j * np.random.randn(*shp)) / np.sqrt(2)
    slv =  coh * mst + np.sqrt(1- coh ** 2) * (np.random.randn(*shp) + 1j * np.random.randn(*shp)) / np.sqrt(2)
    #print("cGPower: %f, %f" % (np.mean(np.abs(mst) ** 2), np.mean(np.abs(mst) ** 2)))
    mst = add_noise(mst, SNRdB)
    slv = add_noise(slv, SNRdB)
    return (mst, slv)


def num_phase_stats(ml, coh, gamma_shape=None, nim=1000,  SNRdB=30, verbose=False):
    """
    This computes the statistics of the interferometric phase error for circular-Gaussian distributed speckle and
    K-distributed speckle
    :param nim: number of realizations used to estimate the statistics
    :param ml: number of looks assumed.
    :param coh: interferometric coherence
    :param gamma_shape: shape parameter of K-distribution. This can be a list, or tuple, or an array, or a scalar
    :param SNRdB: SNR in dB
    :param verbose: True to print some output
    :return: Estimated standard deviations
    """
    mst_cG, slv_cG = cGaussian_distributed_data((int(nim), int(ml)), coh, SNRdB=SNRdB)
    intf_cG = np.sum(mst_cG * np.conj(slv_cG), axis=-1)
    cG_phasestd = np.std(np.angle(intf_cG))
    if verbose:
        # Coherence test
        cohest = np.sum(mst_cG * np.conj(slv_cG))/slv_cG.size
        print("Estimated coherence: %f" % np.real(cohest))
    if gamma_shape is None:
        # we are done here
        return cG_phasestd

    if isinstance(gamma_shape, (list, tuple, np.ndarray)):
        gamms = np.array(gamma_shape)
        K_phasestd = []
        verbose = False
        for gamm in gamms:
            mst_k, slv_k = k_distributed_data((nim, ml), coh, gamma_shape=gamm, SNRdB=SNRdB)
            intf_k = np.sum(mst_k * np.conj(slv_k), axis=-1)
            K_phasestd.append(np.std(np.angle(intf_k)))
        K_phasestd = np.array(K_phasestd)
    else:
        mst_k, slv_k = k_distributed_data((nim, ml), coh, gamma_shape=gamma_shape, SNRdB=SNRdB)
        intf_k = np.sum(mst_k * np.conj(slv_k), axis=-1)
        K_phasestd = np.std(np.angle(intf_k))



    if verbose:
        print("Circular Gaussian, phase std:%f deg" % (np.degrees(cG_phasestd)))
        print("K-distribution, phase std:%f deg" % (np.degrees(K_phasestd)))
    return (cG_phasestd, K_phasestd)


def num_stdv_phase_vs_coh(N, drho=0.01, nim=2000):
    if drho is None:
        drho = 0.01
    else:
        drho = abs(drho)
    if drho > 1.:
        drho = 0.01
    Nr = int(np.floor(1. / abs(drho)))
    rho = 1. / (Nr - 1.) * np.arange(Nr - 1.) + drho
    std = np.zeros_like(rho)
    v_0 = np.array([0.])
    v_1 = np.array([1.])
    # Analitical expression
    stdv_max = np.pi / np.sqrt(3.)

    for ind in range(std.size):
        std[ind] = num_phase_stats(N, rho[ind], nim=nim)

    v_stdv_max = np.array([stdv_max])
    rho_f, stdv_f = (np.concatenate((v_0, rho, v_1)),
                     np.concatenate((v_stdv_max, std, v_0)))
    return rho_f, stdv_f


def stdv_phase_vs_coh(N, drho=0.01, dphi=None, method='analytic', N_num=1000):

    """ Function that calculates the standard deviation of the interferometric
        phase as a function of the coherence and the number of looks.

        :author: Maria Sanjuan-Ferrer

        :param N: Number of looks.
        :type N: float
        :param drho: Coherence steps. Optional.
        :type drho: float
        :param dphi: Resolution of pdf (rad). Optional. Default = 2*pi/1023 rad.
        :type dphi: float
        :param method: 'analytic' (default), 'numeric', or 'approx'. For N>171 it will analytic reverts to
        numeric
        :param N_num: number of realizations for numeric computation

        :returns: tuple.

                  - **rho**: Coherence values.
                  - **phi_err**: Std of interferometric phase.
    """
    if N > 171:
        if method == 'analytic':
            method = 'numeric'
            print("Computing phase error statistics numerically")

    if dphi is None:
        dphi = (2.*np.pi)/1023.
    v_0 = np.array([0.])
    v_1 = np.array([1.])

    if method == 'approx':
        if drho is None:
            drho = 0.01
        else:
            drho = abs(drho)
        if drho > 1.:
            drho = 0.01
        Nr = int(np.floor(1./abs(drho)))
        rho = 1./(Nr-1.)*np.arange(Nr-1.)+drho
        stdv = np.sqrt((1.-rho**2.)/(2.*N*rho**2.))
        # Analytical expression
        stdv_max = np.pi/np.sqrt(3.)
        ind = np.where(stdv > stdv_max)
        if np.size(ind) > 0:
            stdv[ind] = stdv_max
        v_stdv_max = np.array([stdv_max])
        rho_f, stdv_f = (np.concatenate((v_0, rho, v_1)),
                         np.concatenate((v_stdv_max,stdv,v_0)))
        return rho_f, stdv_f
    elif method == 'numeric':
        return num_stdv_phase_vs_coh(N, drho, nim=N_num)
    else:
        rhod, phid, pdfd = tbl_delta_phi_pdf(N, drho=drho, dphi=dphi, out=True)
        adphi = float(phid[1])
        phi = phid.reshape((1, phid.size))
        # stdv = np.sqrt(2.*np.sum(adphi*pdfd*phi**2., axis=1))
        stdv = np.sqrt(2 * integrate.simps(pdfd * (phi**2), phid, axis=1))
        rho_f, stdv_f = (np.concatenate((rhod, v_1)), np.concatenate((stdv, v_0)))
        return rho_f, stdv_f
