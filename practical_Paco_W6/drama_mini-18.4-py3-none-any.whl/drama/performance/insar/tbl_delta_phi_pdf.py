import os
import numpy as np
from drama.performance.insar import p_Delta_Phi


def tbl_delta_phi_pdf_filename(N):
    """ Function that gets the correct path for tbl_delta_phi_pdf program.
    
        :author: Maria Sanjuan-Ferrer.

        :param N: Number of looks.
        :type N: float

        :returns: Complete file name including path and extension (npz).
    """
    # fullpath = os.getcwd()
    fullpath = os.path.dirname(__file__)
    pdf_filename = os.path.join(os.path.join(fullpath, 'TBLS'), 'tlb_delta_phi_pdf_N'+str(int(N))+'.npz')

    return pdf_filename


def tbl_delta_phi_pdf(N, drho=0.01, dphi=None, clean=False, out=False, tbl_save=False):
    """ Function that creates a table values of the PDF of the interferometric
        phase errors as a function of the coherence (i.e. between [0,1]) and
        the number of looks.
        
        :author: Maria Sanjuan-Ferrer.

        :param N: Number of looks.
        :type N: float
        :param drho: Coherence steps. Optional.
        :type drho: float.
        :param dphi: Resolution of pdf (rad). Optional. Default = 2*pi/1000 rad.
        :type dphi: float
        :param clean: If True, the table is regenerated, even if it exists. Optional.
        :type clean: bool.
        :param out: If True, the fuction returns the result as a tuple. Optional.
        :type out: bool

        :returns: tuple.

                  - **rho**: Coherence values.
                  - **phi**: Phase values.
                  - **pdf**: PDF of the interferometric phase error (2-D matrix).
    """
    if N > 171.:
        return "Cannot compute gamma function for N>171"
    if dphi is None:
        dphi = (2.*np.pi)/1000.

    pdf_file_name = tbl_delta_phi_pdf_filename(N)

    #1) Since the pdf is symmetric, only values between [0,pi] are calculated
    Np = int(np.floor(np.pi/dphi)+1.)
    Nr = int(np.floor(1./np.abs(drho)))
    #2) Check if file already exists
    try:
        pdf_file_info = os.stat(pdf_file_name)
    except OSError:
        pdf_file_exists = False
    else:
        pdf_file_exists = True

    if clean is True:
        #Forced to regenerate the table, but only if better than existing
        pdf_file_exists = False

    if pdf_file_exists is True:
        file_content = np.load(pdf_file_name)
        #3) Regenerate a table that is equal or better than the existing one
        Np = int(np.amax([Np, file_content['sNp']]))
        Nr = int(np.amax([Nr, file_content['sNr']]))
        sphi = file_content['sphi']
        srho = file_content['srho']
        pdf = file_content['pdf']
        if Np > file_content['sNp'] or Nr > file_content['sNr']:
            if tbl_save:
                print('tbl_delta_phi_pdf: the file will be regenerated!')
            pdf_file_exists = False
    if pdf_file_exists is not True:
        print('tbl_delta_phi_pdf: the table will be generated!')
        sphi = (np.pi)/(Np-1)*np.arange(Np)
        srho = 1./(Nr)*np.arange(Nr)
        pdf = np.empty([Nr, Np])
        #for index in np.arange(Nr):
        #    pdf[index, :] = p_Delta_Phi(sphi, N, srho[index])
        pdf = p_Delta_Phi(sphi.reshape((1, Np)), N, srho.reshape((Nr, 1)))
        sNp = Np
        sNr = Nr
        sN = N
        if tbl_save:
            np.savez(pdf_file_name, sN=sN, sNp=sNp, sNr=sNr, sphi=sphi, srho=srho,
                     pdf=pdf)

    if out is True:
        #return a tuple!
        pdf_rho, pdf_phi, pdf_pdf = (srho, sphi, pdf)
        return pdf_rho, pdf_phi, pdf_pdf
    else:
        return 'tbl_delta_phi_pdf: done!'
