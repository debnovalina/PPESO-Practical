import numpy as np
import matplotlib.pyplot as plt


def coh_correlation_norm_accuracy(coh=None):
    """ Closed-form expression of the performance (normalized accuracy)
        of coherent correlation.

        :author: Maria Sanjuan-Ferrer.
        
        :param coh: Coherence values. Optional.
                    Default = 101 points between [0.2,0.95].
        :type coh: 1-D float array

        :returns: Normalized error.
    """

    if coh is None:
        coh = np.arange(101.)/100.*0.75+0.2

    result1 = np.sqrt(1.5)*np.sqrt(1.-coh**2.)/(np.pi*coh)
    return result1


def incoh_correlation_norm_accuracy(coh=None):
    """ Closed-form expression of the performance (normalized accuracy)
        of incoherent correlation (i.e. speckle tracking).
        
        :author: Maria Sanjuan-Ferrer.

        :param coh: Coherence values. Optional.
                    Default = 101 points between [0.2,0.95].
        :type coh: 1-D float array

        :returns: Normalized error.
    """
    if coh is None:
        coh = np.arange(101.)/100.*0.75+0.2

    result2 = np.sqrt(0.3)*np.sqrt(2.+5*coh**2.-7.*coh**4.)/(np.pi*coh**2.)
    return result2


def coh_incoh_perf_plots():
    """ Function that plots the the performance (normalized accuracy)
        both coherent and incoherent correlation.

        :author: Maria Sanjuan-Ferrer.
        
        :returns: figures.
    """

    coh_v = np.arange(101.)/100.

    plt.figure()
    v = [0.0, 1.0, 0.0, 3.0]
    plt.axis(v)
    plt.plot(coh_v, coh_correlation_norm_accuracy(coh_v), label='Coherent',
             color='red', linewidth=2)
    plt.plot(coh_v, incoh_correlation_norm_accuracy(coh_v), label='Incoherent',
             color='blue', linewidth=2)
    plt.xlabel('Coherence')
    plt.ylabel('Normalized error  '+r'$\sigma$'+r'$\sqrt{N}$')
    plt.grid(True)
    plt.legend(loc='upper right')

    plt.figure()
    v = [0.0, 1.0, 1e-3, 1e2]
    plt.axis(v)
    N = np.array([1., 10., 100., 1000.])
    colors = np.array(['red', 'blue', 'green', 'yellow'])
    plt.semilogy(coh_v, coh_correlation_norm_accuracy(coh_v)/np.sqrt(N[0]),
                 label='N'+str(int(N[0])), color=colors[0], linewidth=2)
    for ind in range(1, N.size):
        plt.semilogy(coh_v, coh_correlation_norm_accuracy(coh_v)/np.sqrt(N[ind]),
                     label='N'+str(int(N[ind])), color=colors[ind], linewidth=2)
    plt.title('Coherent correlation')
    plt.xlabel('Coherence')
    plt.ylabel('Error standard deviation  '+r'$\sigma_C$')
    plt.grid(True)
    plt.legend(loc='upper right')

    plt.figure()
    v = [0.0, 1.0, 1e-3, 1e2]
    plt.axis(v)
    plt.semilogy(coh_v, incoh_correlation_norm_accuracy(coh_v)/np.sqrt(N[0]),
                 label='N'+str(int(N[0])), color=colors[0], linewidth=2)
    for ind in range(1, N.size):
        plt.semilogy(coh_v, incoh_correlation_norm_accuracy(coh_v)/np.sqrt(N[ind]),
                     label='N'+str(int(N[ind])), color=colors[ind], linewidth=2)
    plt.title('Incoherent correlation')
    plt.xlabel('Coherence')
    plt.ylabel('Error standard deviation  '+r'$\sigma_I$')
    plt.grid(True)
    plt.legend(loc='upper right')
    plt.show()
