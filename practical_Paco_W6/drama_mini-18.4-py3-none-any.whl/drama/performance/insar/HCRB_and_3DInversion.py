# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 16:58:46 2016

@author: zonn_ma
"""
import numpy as np


def get_3d_accuracy(elos, stddev, option):

    """ Function for calculating the accuracy of the 3D vector.

        :author: Mariantonietta Zonno

        :param elos: Line-of-sight vectors, where (x,y,z)=(East,North,Up).
        :type elos: 2-D float array
        :param stddev: Standard deviations of the LoS measurements.
        :type stddev: 1-D float array
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer

        :returns: 3d motion covariance matrix

    """

    nTracks = np.size(stddev)

    # Building covariance matrix
    weights = np.zeros([nTracks, nTracks])
    for mm in range(np.size(stddev)):
        weights[mm, mm] = 1./(stddev[mm]**2.)

    # Options
    if option == 1:
        # Constraining motion only in the up-down direction
        # x is East, y is North, z is Up
        elos_ = elos[:, 2]
        variance3d = 1./(elos_.dot(weights).dot(elos_[:, np.newaxis]))

        aux = np.ones((3, 3))*1.e6
        aux[2, 2] = variance3d

        variance3d = np.copy(aux)

    elif option == 2:
        # Constrining motion only in the east-west, up-down plane
        # x is East, y is North, z is Up
        aux = np.copy(elos)
        aux[:, 1] = aux[:, 2]
        elos_ = aux[:, 0:2]
        variance3d = np.linalg.inv(np.transpose(elos_).dot(weights).dot(elos_))

        aux = np.ones((3, 3))*1.e6
        aux[0, 0] = variance3d[0, 0]
        aux[2, 0] = variance3d[1, 0]
        aux[2, 2] = variance3d[1, 1]
        aux[0, 2] = variance3d[0, 1]

        variance3d = np.copy(aux)

    elif option == 3:
        matrix = np.transpose(elos).dot(weights).dot(elos)
        variance3d = np.linalg.inv(matrix)
    else:
        print('Singular matrix, SVD inversion ')
        variance3d = np.zeros((3, 3))+np.nan
        # SVD inversion of observation matrix
        # x is East, y is North, z is Up
        A = np.transpose(elos).dot(weights).dot(elos)
        U, s, V = np.linalg.svd(A)
        poszero = np.where(s < 0.002)
        diag = np.zeros((3, 3))
        for ix in range(3):
            if s[ix] != 0.0:
                diag[ix, ix] = 1./s[ix]
        if np.size(poszero) > 0:
            diag[poszero, poszero] = 0.0

        variance3d = V.dot(diag).dot(np.transpose(U))

        if np.size(poszero) > 0:
            variance3d[1, 1] = 1.e6

    return variance3d


def hcrb(acqTime, nLooks, lambdaa, aps1, SNR, sigmaOrb=0,  tau=60.,
         gamma0=0.95, gammaInf=0.15, sigmaIono=0.01):

    """ Function for calculating the performance of DINSAR with a stack of
        images using the hybrid Cramer-Rao bound.

        :author: Mariantonietta Zonno

        :param acqTime: Acquistion time vector (1-D float array)
        :param nLooks: Number of looks (float)
        :param lambdaa: Wavelenght (m).
        :param sigmaTot: Standard deviations of the APS (rad) and  orbit.
        :param SNR: Signal-to-noise ratio (linear).
        :param tau: Decorrelation time (days). Optional.
        :param gamma0: Coherence at time = 0.
        :param gammaInf: Coherence at time = inf.

        :returns: standard deviation
    """

    rTemp = np.exp(-1./tau)     # Default: tau = 40 days

    # Some variables
    nAcq = np.size(acqTime)

    gammaSnr = SNR/(1. + SNR)

    # Hybrid Cramer-Rao bound
    m1 = np.outer(acqTime, np.ones(nAcq))

    gamma = (gammaSnr*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gammaSnr*gamma0)*np.eye(nAcq))
#    gamma = (gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))+gammaInf
    theta = np.transpose(m1[:, 0])
    X = 2.*nLooks*(gamma*np.linalg.inv(gamma)-np.eye(nAcq))
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    sigmaAtm = 4 * np.pi * aps1.sigma_atm_m / lambdaa

    Vww = (sigmaAtm)**2.*np.eye(nAcq)

    sigmaOrb_ = 4 * np.pi * sigmaOrb / lambdaa
    sigmaIono_ = 4 * np.pi * sigmaIono / lambdaa
    Vww1 = (sigmaOrb_)**2.*np.eye(nAcq)
    Vww2 = (sigmaIono_)**2.*np.eye(nAcq)
    kk4 = X + np.linalg.inv(Vww+Vww1+Vww2)

    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    sigma = np.sqrt(kk[0, 0])   # radians/day

    return sigma


def hcrb_az(acqTime, nLooks, lambdaa, SNR, sigmaAz, azRes, tau=40.,
            gamma0=0.95, gammaInf=0.15):

    """ Function for calculating the performance of DINSAR with a stack of
        images using the hybrid Cramer-Rao bound (in azimuth direction).

        :author: Mariantonietta Zonno

        :param acqTime: Acquistion time vector.
        :param nLooks: Number of looks.
        :param lambdaa: Wavelenght (m).
        :param SNR: Signal-to-noise ratio (linear).
        :param azRes: Azimuth resolution (m).
        :param tau: Decorrelation time (days).
        :param gamma0: Coherence at time = 0.
        :param gammaInf: Coherence at time = inf.
        :returns: standard deviation
    """
    rTemp = np.exp(-1./tau)     # Default: tau = 40 days

    # Some variables
    nAcq = np.size(acqTime)

    gammaSnr = SNR/(1. + SNR)

    # Hybrid Cramer-Rao bound
    m1 = np.outer(acqTime, np.ones(nAcq))

    gamma = (gammaSnr*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf)+(1.-gammaSnr*gamma0)*np.eye(nAcq))
#    gamma = (gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))+gammaInf

    cte = nLooks*2./3.*np.pi**2.
    FIM_az = cte*(acqTime.dot(gamma*np.linalg.inv(gamma) -
                  np.eye(nAcq)).dot(np.transpose(acqTime)))

    sigmaAz = np.sqrt(1./FIM_az)
    sigma = azRes*sigmaAz*365.*1000.   # mm/year

    return sigma


def hcrb_rg_az(aps1, at_atmo, acqTime, nLooks_M, nLooks_S, lambdaa, SNR_M,
               SNR_S, tau=40., gamma0=0.95, gammaInf=0.15, sigmaClock=0,
               sigmaOrb=0, theta_squint=0, mode='mono', sigmaIono=0.0):

    """ Function for calculating the performance in the along and across track
        direction for of DINSAR using the hybrid Cramer-Rao bound.

        :author: Mariantonietta Zonno

        :param aps1: instance of the class for the APS delay variance
        :type aps1: class instance
        :param at_atmo: along track separation at the height of atmosphere from
                        ground
        :type at_atmo:  float
        :param acqTime: Acquistion time vector.
        :type acqTime:  1-D float array
        :param nLooks_M: Number of looks of the master
        :type nLooks_M: float
        :param nLooks_S: Number of looks of the slave
        :type nLooks_S: float
        :param lambdaa: Wavelenght (m).
        :type lambdaa: float
        :param SNR_M: Signal-to-noise ratio for the master system (linear).
        :type SNR_M: float
        :param SNR_S: Signal-to-noise ratio  for the slave system (linear).
        :type SNR_S: float
        :param theta_squint: Squint angle between master and slave (rad)
        :type theta_squint: float
        :param tau: Decorrelation time (days).
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: floatimport drama.geo.sar as geosar
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: float

        :returns: standard deviation in Los and azimuth
    """

    tau = 60
    gamma0 = 0.95
    gammaInf = 0.15
    sigma_atm_ref = aps1.sigma_atm_m
    sigma_atm_at_dx = aps1.get_auto_at_delta_x(at_atmo)
    sigmaOrb_ = 4 * np.pi * sigmaOrb / lambdaa

    if mode == 'bistatic':
        sigma_atm = 2 * np.pi / lambdaa * (np.sqrt(10.*sigma_atm_ref**2 +
                                                   6*sigma_atm_at_dx))
        # uncorrelated ionosphere
        sigmaIono_ = 2 * np.pi *np.sqrt(10)* sigmaIono / lambdaa
    else:
        # monostatic case
        sigma_atm = 4 * np.pi / lambdaa * (np.sqrt(2 * sigma_atm_ref**2 +
                                                   2 * sigma_atm_at_dx))
        # uncorrelated ionosphere
        sigmaIono_ = 4 * np.pi * np.sqrt(2)*sigmaIono / lambdaa


    # Some variables
    rTemp = np.exp(-1./tau)
    nAcq = np.size(acqTime)
    m1 = np.outer(acqTime, np.ones(nAcq))

    # define some matrixes
    theta = np.transpose(m1[:, 0])  # result in radians/day
    # GammaSNR for master and slave and resulting matrix X
    gamSnr_M = SNR_M/(1. + SNR_M)
    gamSnr_S = SNR_S/(1. + SNR_S)
    gam_M = (gamSnr_M*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_M*gamma0)*np.eye(nAcq))
    gam_S = (gamSnr_S*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_S*gamma0)*np.eye(nAcq))
    X = (nLooks_M*(gam_M*np.linalg.inv(gam_M)-np.eye(nAcq)) +
         nLooks_S*(gam_S*np.linalg.inv(gam_S)-np.eye(nAcq)))/2

    # sum of LoS

    # FIM construction
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    Vww = (sigma_atm)**2.*np.eye(nAcq)
    Vww1 = (sigmaOrb_)**2.*np.eye(nAcq)
    Vww2 = (sigmaIono_)**2.*np.eye(nAcq)
    kk4 = X + np.linalg.inv(Vww+Vww1+Vww2)
#    kk4 = X + np.linalg.inv(Vww)

    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)

    # sigma_sum
    sigma_LOS = np.sqrt(kk[0, 0])   # radians/day

    ##########################################################################
    ##########################################################################

    # along track: difference of LoS
    az_sigmaAtm = aps1.get_autodiff_at_delta_x(at_atmo)  # meters

    if mode == 'bistatic':
        az_sigmaAtm = 2 * np.pi * az_sigmaAtm / lambdaa
        sigmaIono_ = 2 * np.pi *np.sqrt(2)* sigmaIono / lambdaa
        sigmaClock_ = 4 * np.pi * np.sqrt(2)* sigmaClock / lambdaa
    else:
        az_sigmaAtm = 4 * np.pi * az_sigmaAtm / lambdaa
        sigmaIono_ = 4 * np.pi *np.sqrt(2)* sigmaIono / lambdaa

    Vww = 2*(az_sigmaAtm)**2.*np.eye(nAcq)
    Vww2 = (sigmaIono_)**2.*np.eye(nAcq)
    Vww3 = (sigmaClock_)**2.*np.eye(nAcq)
    kk4 = X + np.linalg.inv(Vww+Vww2+Vww3)
    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    # sigma_diff
    sigma_az = np.sqrt(kk[0, 0])   # radians/day

    return sigma_LOS, sigma_az


def Bistatic_hcrb(aps1, at_atmo, acqTime, nLooks_M, nLooks_S, lambdaa, SNR_M,
                  SNR_S, theta_squint, tau=40., gamma0=0.95, gammaInf=0.15,
                  sigmaClock=0, sigmaOrb=0):
        # old #
    """ Function for calculating the performance in the along and across track
        direction for of DINSAR using the hybrid Cramer-Rao bound.

        :author: Mariantonietta Zonno

        :param aps1: instance of the class for the APS delay variance
        :type aps1: class instance
        :param at_atmo: along track separation at the height of atmosphere from
                        ground
        :type at_atmo:  float
        :param acqTime: Acquistion time vector.
        :type acqTime:  1-D float array
        :param nLooks_M: Number of looks of the master
        :type nLooks_M: float
        :param nLooks_S: Number of looks of the slave
        :type nLooks_S: float
        :param lambdaa: Wavelenght (m).
        :type lambdaa: float
        :param SNR_M: Signal-to-noise ratio for the master system (linear).
        :type SNR_M: float
        :param SNR_S: Signal-to-noise ratio  for the slave system (linear).
        :type SNR_S: float
        :param theta_squint: Squint angle between master and slave (rad)
        :type theta_squint: float
        :param tau: Decorrelation time (days).
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: float

        :returns: standard deviation in Los and azimuth
    """

    # Some variables
    rTemp = np.exp(-1./tau)
    nAcq = np.size(acqTime)
    m1 = np.outer(acqTime, np.ones(nAcq))

    # Across Track Hybrid Cramer-Rao bound

    # GammaSNR for master and slave and resulting matrix X
    gamSnr_M = SNR_M/(1. + SNR_M)
    gamSnr_S = SNR_S/(1. + SNR_S)
    gam_M = (gamSnr_M*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_M*gamma0)*np.eye(nAcq))
    gam_S = (gamSnr_S*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_S*gamma0)*np.eye(nAcq))
    X = (nLooks_M*(gam_M*np.linalg.inv(gam_M)-np.eye(nAcq)) +
         nLooks_M*(gam_S*np.linalg.inv(gam_S)-np.eye(nAcq)))/2
    theta = 4.*np.pi / lambdaa * np.transpose(m1[:, 0])
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    sigmaAtm = 4 * np.pi * aps1.sigma_atm_m / lambdaa
    Vww = (sigmaAtm)**2.*np.eye(nAcq)

    if sigmaOrb == 0:
        kk4 = X + np.linalg.inv(Vww)
    else:
        sigmaOrb_ = 4 * np.pi * sigmaOrb / lambdaa
        Vww1 = (sigmaOrb_)**2.*np.eye(nAcq)
        kk4 = X + np.linalg.inv(Vww+Vww1)

    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    sigma_LOS = np.sqrt(kk[0, 0])*365.*1000.   # mm/year


    # Along Track Hybrid Cramer-Rao bound

    # Equivalent phase variance resulting from the combination of the variance
    # for the two different acquisitions:

    Vww = (np.sqrt(2)*az_sigmaAtm)**2.*np.eye(nAcq)

    if sigmaClock == 0:
        kk4 = X + np.linalg.inv(Vww)
    else:
        sigmaClock_ = 2 * np.pi * sigmaClock / lambdaa
        Vww1 = (np.sqrt(2)*sigmaClock_)**2.*np.eye(nAcq)
        kk4 = X + np.linalg.inv(Vww+Vww1)

    theta = 4.*np.pi / lambdaa * np.sin(theta_squint/2)*np.transpose(m1[:, 0])
    X = (nLooks_M*(gamma*np.linalg.inv(gamma) - np.eye(nAcq)))
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    sigmaAz = np.sqrt(kk[0, 0])*365.*1000.   # mm/year

    return sigma_LOS, sigmaAz















