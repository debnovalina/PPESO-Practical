import numpy as np
import matplotlib.pyplot as plt


def coh_m(snr1, snr2=None, db=False):
    """ Function that calculates coherence due to finite signal to noise
        (model).
        
        :author: Maria Sanjuan-Ferrer.

        :param snr1: Signal-to-noise ratio1 (dB or linear).
        :type snr1: float or 1-D float array
        :param snr2: Signal-to-noise ratio2 (dB or linear). Optional.
        :type snr2: float or 1-D float array
        :param db: If True, snr is assumed to be in dB. Optional.
        :type db: bool

        :returns: Model-based interferometric coherence.
    """
    if np.size(snr1) < 1:
        print('snr2coh: snr1 value missing')
        return -1
    if snr2 is None:
        snr2 = snr1.copy()
    else:
        if np.size(snr2) > 1 and np.size(snr2) != np.size(snr1):
            print('snr2coh: snr2 should have one element or the same number of elements as snr1, it will be ignored')
            snr2 = snr1.copy()

    if db is True:
        result1 = 1./np.sqrt((1.+pow(10., -snr1/10.))*(1.+pow(10., -snr2/10.)))
        return result1
    else:
        result2 = 1./np.sqrt(np.dot((1.+1./snr1), (1.+1./snr2)))
        return result2


def coh_n(snr1, snr2=None, db=False, Ns=1024, Nr=100):
    """ Function that calculates coherence due to finite signal to noise
        (numerical).
        
        :author: Maria Sanjuan-Ferrer.

        :param snr1: Signal-to-noise ratio1 (dB or linear).
        :type snr1: float or 1-D float array
        :param snr2: Signal-to-noise ratio2 (dB or linear). Optional.
        :type snr2: float or 1-D float array
        :param db: If True, snr is assumed to be in dB. Optional.
        :type db: bool
        :param Ns: Number of samples. Optional.
        :type Ns: integer
        :param Nr: Number of repetitions. Optional.
        :type Nr: integer

        :returns: Numerical interferometric coherence.
    """
    if np.size(snr1) < 1:
        print('snr2coh: snr1 value missing')
        return -1
    if snr2 is None:
        snr2 = snr1.copy()
    else:
        if np.size(snr2) > 1 and np.size(snr2) != np.size(snr1):
            print('snr2coh: snr2 should have one element or the same number of elements as snr1, it will be ignored')
            snr2 = snr1.copy()

    if db is True:
        snr1_ = 10**(snr1/10.)
        snr2_ = 10**(snr2/10.)
    else:
        snr1_ = snr1.copy()
        snr2_ = snr2.copy()

    s1 = 1.+(np.random.standard_normal((Ns, Nr))+1j*np.random.standard_normal((Ns, Nr)))/np.sqrt(2.*snr1_)
    s2 = 1.+(np.random.standard_normal((Ns, Nr))+1j*np.random.standard_normal((Ns, Nr)))/np.sqrt(2.*snr2_)
    result3 = np.mean(np.mean(s1*s2, axis=0)/np.sqrt(np.mean(pow(np.abs(s1), 2), axis=0)*np.mean(pow(np.abs(s2), 2), axis=0)), axis=0)
    return result3.real


def snr2coh_plots():
    """ Function that plots the coherence as a function of SNR
        (model and mumerical).
        
        :author: Maria Sanjuan-Ferrer.

        :returns: figure.
    """
    Nsnr = 31
    snr = np.linspace(-10, 10, Nsnr)

    coh_mod = np.zeros([Nsnr], float)
    coh_num = np.zeros([Nsnr], float)

    for index in range(Nsnr):
        coh_mod[index] = coh_m(snr[index], db=True)
        coh_num[index] = coh_n(snr[index], db=True, Ns=4096, Nr=200)

    plt.figure()
    plt.plot(snr, coh_mod, label='Model', color='red', linewidth=2)
    plt.plot(snr, coh_num, label='Numerical', color='blue')
    plt.xlabel('SNR [dB]')
    plt.ylabel('Coherence')
    plt.grid(True)
    plt.legend(loc='upper left')
    plt.show()
