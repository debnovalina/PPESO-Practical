from drama.utils.misc import db2lin
import numpy as np
from drama.geo.sar import geometry as geosar
from drama import constants as const
from scipy.interpolate import InterpolatedUnivariateSpline
from drama.geo import sar
import matplotlib.pyplot as plt
from drama import constants as const

def get_gamma_SNR_ambig(sigma0, nesz, AASR=0, RASR=0, Comb=True):

    """ Function to compute the decorrelation due SNR and ambiguities

        :param sigma0: backscattering value
        :type sigma0: float
        :param nesz: noise equivalent sigma 0
        :type nesz: float
        :param AASR: azimuth ambiguity
        :type AASR: float
        :param RASR: range ambiguity
        :type RASR: float
        :param Comb: flag to compute the coherence related to snr only or also
                     to ambiguities
        :type Comb: string
        :returns: coherence and kz
    """
    # if comb = true so it is computed the gamma due to snr and ambiguities
    # otherwise only that due to snr
    # SNR computation
    SNR = db2lin(sigma0 - nesz)

    # gamma_Combined (SNR, RASR and AASR) computation
    denom = 1 + SNR**(-1) + RASR + AASR
    gammaComb = 1./denom

    if Comb:
        return gammaComb
    else:
        # gamma_SNR computation
        gammaSnr = SNR/(1. + SNR)
    return gammaSnr


def get_gamma_Volume(f, dlat, inc_angle_, acqMode_, cycles, lat,
                     ROIType=None, icetype=None, TreeH=None):

    """ Function to compute the volume decorrelation due to ice penetration

        :param f: formation timeline
        :type f: 1d array
        :param dlat: latitude resolution of the lat lon grid
        :type dlat: float
        :param inc_angle: incidence angle
        :type inc_angle: float
        :param acqMode: if ascending or descending
        :type acqMode: string
        :param cycles: days of acquisition in totalTime
        :type cycles: 1d array
        :param lat: latitude of the considered point
        :type lat: float
        :param eps: real part of the dielectric constant
        :type eps: float
        :param ke: extinction coefficient [1/m]
        :type ke: float
        :returns: coherence and kz

    """

    orb_h = f.orb_h
    # ascending tracks
#    lambda0 = const.c / f.f0

    # ascending
    ind = np.where(acqMode_ == 'A')[0]
    inc_angle_a = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))
    # descending
    ind = np.where(acqMode_ == 'D')[0]
    inc_angle_d = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))

#    lats = lat*np.ones(inc_angle_a.size).reshape((inc_angle_a.size, 1))
    cycles = cycles.reshape((1, cycles.size))

    if inc_angle_a.shape[0] > 0:
        # kz has the inc_angle size * cycles (days) size
        kz_a = f.get_kz(np.degrees(inc_angle_a), lat, cycles, ascending=True)
        h_amb_a= 2 * np.pi / kz_a
    else:
        kz_a = np.empty(0)
        h_amb_a = np.empty(0)
    if inc_angle_d.shape[0] > 0:
        kz_d = f.get_kz(inc_angle_d, lat, cycles, ascending=False)
        h_amb_d = 2 * np.pi / kz_d
    else:
        kz_d = np.empty(0)
        h_amb_d = np.empty(0)

    if ROIType=='Cryo':
        if lat < 0:
            # Antarctica
            IceCoh_HoA_interpol  = glacierLUT_Antarctica(HorbSesame=orb_h,
                                                         thetaSes=inc_angle_a,
                                                         icetype=icetype)
            gamma_vol_a = IceCoh_HoA_interpol(h_amb_a)
            IceCoh_HoA_interpol = glacierLUT_Antarctica(HorbSesame=orb_h,
                                                    thetaSes=inc_angle_d,
                                                    icetype=icetype)
            gamma_vol_d = IceCoh_HoA_interpol(h_amb_d)
        else:
            # Greenland
            gamma_vol_a  = IceDecorr_Greenland(ha=h_amb_a, theta=inc_angle_a)
            gamma_vol_d = IceDecorr_Greenland(ha=h_amb_d, theta=inc_angle_d)

    elif ROIType=='Forest':

        gamma_vol_a = Boreal_forest_coherence(TreeH, h_amb_a)
        gamma_vol_d = Boreal_forest_coherence(TreeH, h_amb_d)

    # stack the ascendings and descendings
    if gamma_vol_d.shape == (0,):
        gamma_vol = gamma_vol_a
        ha = h_amb_a
    elif gamma_vol_a.shape == (0,):
        gamma_vol = gamma_vol_a
        ha = h_amb_d
    else:
        gamma_vol = np.vstack((gamma_vol_a, gamma_vol_d))
        ha = np.vstack((h_amb_a, h_amb_d))

    gamma_vol = np.where(gamma_vol < 0, 0, gamma_vol)
    gamma_vol = np.where(gamma_vol > 1, 1, gamma_vol)

    return gamma_vol, ha


def get_gamma_iceVol(fasc, fdesc, dlat, inc_angle_, acqMode_, cycles, lat,
                     eps=2.8, ke=1/20):

    """ Function to compute the volume decorrelation due to ice penetration

        :param f: formation timeline
        :type f: 1d array
        :param dlat: latitude resolution of the lat lon grid
        :type dlat: float
        :param inc_angle: incidence angle
        :type inc_angle: float
        :param acqMode: if ascending or descending
        :type acqMode: string
        :param cycles: days of acquisition in totalTime
        :type cycles: 1d array
        :param lat: latitude of the considered point
        :type lat: float
        :param eps: real part of the dielectric constant
        :type eps: float
        :param ke: extinction coefficient [1/m]
        :type ke: float
        :returns: coherence and kz

    """

    # ascending tracks
    lambda0 = const.c / fasc.f0
    ind = np.where(acqMode_ == 'A')[0]
    inc_angle_a = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))
    lats = lat*np.ones(inc_angle_a.size).reshape((inc_angle_a.size, 1))
    cycles = cycles.reshape((1, cycles.size))
#    inc_angle_a = inc_angle_a.reshape((1, inc_angle_a.size))
    # kz has the inc_angle size * cycles size
    kz_a = fasc.get_kz(np.degrees(inc_angle_), lats, cycles, ascending=True)
    sr = geosar.inc_to_sr(inc_angle_a, fasc.orb_h)
    h_amb = 2 * np.pi / kz_a
    Bp_a = sr * np.sin(inc_angle_a) * lambda0 / h_amb


    # descending tracks
    ind = np.where(acqMode_ == 'D')[0]
    inc_angle_d = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))
    # lat has the same size of the incidence angle: computation for the same
    # latitutde but considering the different possible inc angle.
    lats = lat*np.ones(inc_angle_d.size).reshape((inc_angle_d.size, 1))
    cycles = cycles.reshape((1, cycles.size))
    # kz has the inc_angle size * cycles size
    kz_d = fdesc.get_kz(np.degrees(inc_angle_d), lats, cycles, ascending=False)
    sr = geosar.inc_to_sr(inc_angle_d, fasc.orb_h)
    h_amb = 2 * np.pi / kz_d
    Bp_d = sr * np.sin(inc_angle_d) * lambda0 / h_amb

    # refraction angle
    refr_angle_a = np.arcsin(np.sin(inc_angle_a)/np.sqrt(eps))
    refr_angle_d = np.arcsin(np.sin(inc_angle_d)/np.sqrt(eps))

    # model
    kz_vol_a = (np.abs(kz_a)*np.sqrt(eps)*np.cos(inc_angle_a)/np.cos(refr_angle_a))
    kz_vol_d = (np.abs(kz_d)*np.sqrt(eps)*np.cos(inc_angle_d)/np.cos(refr_angle_d))
    gamma_vol_a = np.abs(1/(1+1j*np.cos(refr_angle_a)*kz_vol_a/(2*ke)))
    gamma_vol_d = np.abs(1/(1+1j*np.cos(refr_angle_d)*kz_vol_d/(2*ke)))

    # stack the ascendings and descendings
    gamma_vol = np.vstack((gamma_vol_a, gamma_vol_d))
    kz_cycles = np.vstack((np.abs(kz_a), np.abs(kz_d)))
    Bp = np.vstack((Bp_a, Bp_d))


    return gamma_vol, kz_cycles, Bp


def get_gamma_iceVol2(f1, f2, f3, dlat, inc_angle_, acqMode_, cycles, lat,
                      inc_range1, inc_range2, inc_range3, AreaFlag='Antarctica',
                      icetype=None):

    """ Function to compute the volume decorrelation due to ice penetration

        :param f: formation timeline
        :type f: 1d array
        :param dlat: latitude resolution of the lat lon grid
        :type dlat: float
        :param inc_angle: incidence angle
        :type inc_angle: float
        :param acqMode: if ascending or descending
        :type acqMode: string
        :param cycles: days of acquisition in totalTime
        :type cycles: 1d array
        :param lat: latitude of the considered point
        :type lat: float
        :param eps: real part of the dielectric constant
        :type eps: float
        :param ke: extinction coefficient [1/m]
        :type ke: float
        :returns: coherence and kz

    """

    orb_h = f1.orb_h
    # ascending tracks
    lambda0 = const.c / f1.f0

    ind = np.where(acqMode_ == 'A')[0]
    inc_angle_a = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))
#    lats = lat*np.ones(inc_angle_a.size).reshape((inc_angle_a.size, 1))
    cycles = cycles.reshape((1, cycles.size))
    kz_a = np.zeros((inc_angle_a.shape[0],  cycles.shape[1]))
    h_amb_a = np.zeros((inc_angle_a.shape[0],  cycles.shape[1]))
    # kz has the inc_angle size * cycles size
    for i in range(inc_angle_a.shape[0]):
        if np.degrees(inc_angle_a[i][0]) < inc_range1[1]:
            fasc = f1
        elif np.logical_and(np.degrees(inc_angle_a[i][0])  < inc_range2[1],
                            np.degrees(inc_angle_a[i][0]) >= inc_range2[0]):
            fasc = f2
        else:
            fasc = f3

        kz_a[i, :] = fasc.get_kz(inc_angle_a[i], lat, cycles, ascending=True)
#        sr = geosar.inc_to_sr(inc_angle_a[i][0], orb_h)
        h_amb_a[i, :]= 2 * np.pi / kz_a[i]
#        Bp_a[i, :] = sr * np.sin(inc_angle_a[i]) * lambda0 / h_amb_a[i, :]

    if AreaFlag == 'Antarctica':
        IceCoh_HoA_interpol  = glacierLUT_Antarctica(HorbSesame=orb_h,
                                                    thetaSes=inc_angle_a,
                                                    icetype=icetype)
        gamma_vol_a = IceCoh_HoA_interpol(h_amb_a)
    else:
        gamma_vol_a  = IceDecorr_Greenland(ha=h_amb_a, theta=inc_angle_a)

    if gamma_vol_a.shape == (0,):
        gamma_vol_a = np.empty(h_amb_a.shape)

    # descending tracks
    ind = np.where(acqMode_ == 'D')[0]
    inc_angle_d = inc_angle_[ind].reshape((inc_angle_[ind].size, 1))
    # lat has the same size of the incidence angle: computation for the same
    # latitutde but considering the different possible inc angle.
#    lats = lat*np.ones(inc_angle_d.size).reshape((inc_angle_d.size, 1))
    # kz has the inc_angle size * cycles size

    kz_d = np.zeros((inc_angle_d.shape[0],  cycles.shape[1]))
    h_amb_d = np.zeros((inc_angle_d.shape[0],  cycles.shape[1]))
    gamma_vol_d = np.zeros((inc_angle_d.shape[0],  cycles.shape[1]))

    for i in range(inc_angle_d.shape[0]):
        if np.degrees(inc_angle_d[i][0]) < inc_range1[1]:
            fdesc = f1
        elif np.logical_and(np.degrees(inc_angle_d[i][0]) < inc_range2[1],
                            np.degrees(inc_angle_d[i][0]) >= inc_range2[0]):
            fdesc = f2
        else:
            fdesc = f3
        kz_d[i, :] = fdesc.get_kz(inc_angle_d[i], lat, cycles, ascending=True)
#        sr = geosar.inc_to_sr(inc_angle_d[i][0], orb_h)
        h_amb_d[i, :] = 2 * np.pi / kz_d[i]
#        Bp_d[i, :] = sr * np.sin(inc_angle_d[i]) * lambda0 / h_amb

    if AreaFlag == 'Antarctica':
        IceCoh_HoA_interpol = glacierLUT_Antarctica(HorbSesame=orb_h,
                                                    thetaSes=inc_angle_d,
                                                    icetype=icetype)
        gamma_vol_d = IceCoh_HoA_interpol(h_amb_d)
    else:
        gamma_vol_d = IceDecorr_Greenland(ha=h_amb_d, theta=inc_angle_d)

    if gamma_vol_d.shape == (0,):
        gamma_vol_d = np.empty(h_amb_d.shape)

    # stack the ascendings and descendings
    gamma_vol = np.vstack((gamma_vol_a, gamma_vol_d))
    kz_cycles = np.vstack((np.abs(kz_a), np.abs(kz_d)))
    ha = np.vstack((h_amb_a, h_amb_d))
    gamma_vol = np.where(gamma_vol < 0, 0, gamma_vol)
    gamma_vol = np.where(gamma_vol > 1, 1, gamma_vol)

    return gamma_vol, kz_cycles, ha







def glacierLUT_Antarctica(HorbSesame, thetaSes, icetype='Ice',
                          thetaERS=np.radians(23), HorbERS=785e3,
                          do_plot=False, savedirr=None):
    # Orbit height Sesame
    RERS = sar.inc_to_sr(thetaERS, HorbERS)
    thetaSes = np.radians(thetaSes)
    RSes= sar.inc_to_sr(thetaSes, HorbSesame)
#    thetaSes1=np.radians(33)
#    thetaSes2=np.radians(38)
#    thetaSes3=np.radians(43)
#    RSes1 = sar.inc_to_sr(thetaSes1, HorbSesame)
#    RSes2 = sar.inc_to_sr(thetaSes2, HorbSesame)
#    RSes3 = sar.inc_to_sr(thetaSes3, HorbSesame)
    f0_ERS = 5.3e9
    f0_Sesame = 5.4e9
    c0 = const.c
    lambdaaERS = c0/f0_ERS
    lambdaaSes = c0/f0_Sesame
    HoA = np.arange(10, 150, 2)
    if icetype == 'Ice':
        Bpfix = np.array([100, 200, 300, 400, 450])
        gamma = np.array([0.75, 0.7, 0.6, 0.6, 0.55])/0.8
    elif icetype == 'Firn':
        Bpfix = np.array([100, 150, 200, 250, 300, 350, 400])
        gamma = np.array([0.72, 0.63, 0.58, 0.4, 0.35, 0.3, 0.2])/0.8

    HoAfixERS = RERS*np.sin((thetaERS))*lambdaaERS/Bpfix
    HoAfixSes = RSes*np.sin((thetaSes))*lambdaaSes/Bpfix
#    HoAfixSes1 = RSes1*np.sin((thetaSes1))*lambdaaSes/Bpfix
#    HoAfixSes2 = RSes2*np.sin((thetaSes2))*lambdaaSes/Bpfix
#    HoAfixSes3 = RSes3*np.sin((thetaSes3))*lambdaaSes/Bpfix

    s = InterpolatedUnivariateSpline(HoAfixERS[::-1], gamma[::-1], k=1)
    sSes = InterpolatedUnivariateSpline(HoAfixSes[::-1], gamma[::-1], k=1)
#    s1 = InterpolatedUnivariateSpline(HoAfixSes1[::-1], gamma[::-1], k=1)
#    s2 = InterpolatedUnivariateSpline(HoAfixSes2[::-1], gamma[::-1], k=1)
#    s3 = InterpolatedUnivariateSpline(HoAfixSes3[::-1], gamma[::-1], k=1)

    if do_plot:
        cohERS =s(HoA)
        cohSes = sSes(HoA)
#        cohS1 = s1(HoA)
#        cohS2 = s2(HoA)
#        cohS3 = s3(HoA)
        HoA = np.arange(10, 250, 2)
        cohERS = s(HoA)
#        cohS1 = s1(HoA)
#        cohS2 = s2(HoA)
#        cohS3 = s3(HoA)
#        cohERS = np.where(cohERS < 0, 0, cohERS)
#        cohS1 = np.where(cohS1 < 0, 0, cohS1)
#        cohS2 = np.where(cohS2 < 0, 0, cohS2)
#        cohS3 = np.where(cohS3 < 0, 0, cohS3)
#        cohERS = np.where(cohERS > 1, 1, cohERS)
#        cohS1 = np.where(cohS1 > 1, 1, cohS1)
#        cohS2 = np.where(cohS2 > 1, 1, cohS2)
#        cohS3 = np.where(cohS3 > 1, 1, cohS3)
        plt.figure()
        plt.plot(HoAfixERS[::-1], gamma[::-1])
        plt.title('Original Samples')

        plt.figure()
        plt.plot(HoA, cohERS, linewidth=2, label='ERS')
        plt.plot(HoAfixERS[::-1], gamma[::-1], 'o',markersize=8,
                 markerfacecolor='b')

        plt.plot(HoA, cohS1, linewidth=2, label='Sesame mode 1')
        plt.plot(HoA, cohS2, linewidth=2, label='Sesame mode 2')
        plt.plot(HoA, cohS3, linewidth=2, label='Sesame mode 3')
        plt.legend(loc='best', fontsize=14)
        plt.xlabel('HoA', fontsize=16)
        plt.ylabel('Coherence', fontsize=16)
        plt.title('Volume Decorellation into '+icetype, fontsize=16)
        plt.grid()
        plt.savefig(savedirr+'/Correl_vs_HoA_Antarct_'+icetype+'.png')
    return sSes


def glacierLUT_Greenland():

    Bpfix = np.array([0, 70, 90, 110, 170, 200, 250])
    gamma = np.array([1, 0.9, 0.8, 0.7, 0.5, 0.43, 0.35])

    ss = InterpolatedUnivariateSpline(Bpfix, gamma, k=1)

    return ss


def IceDecorr_Greenland(ha, dp=20, eps =1.8, theta=np.degrees(33)):

    num = (2*np.sqrt(eps)*dp*np.cos(theta))
    cc = num/ha
    gammaVol = 1/np.sqrt(1+cc)
    return gammaVol


def Boreal_forest_coherence(Tree_Height, HOA, a=2.44, b=0.46,
                            alfa=0.2*np.log(10), beta_min=0.004,
                            beta_max=0.013, s0gr_min=-10.3,
                            s0gr_max=-7.3, s0veg_min=-9.88, s0veg_max=-7.2,
                            Type='Max', complex=False):
    """
        a: constant in h-to-V allometry
        b: constant in h-to-V allometry
        alfa:extinction coefficient in canopy (= 2 dB/m)
        beta : [ha/m3]
        s0gr :[dB]
    """

    if Type.lower() == 'max':
        sigma0_veg = 10**(s0veg_max/10)
        sigma0_gr = 10**(s0gr_max/10)
        beta = beta_max
    else:
        sigma0_veg = 10**(s0veg_min/10)
        sigma0_gr = 10**(s0gr_min/10)
        beta = beta_min

    # derived model parameters
    V = (Tree_Height**(1/b))/a   # height to stem volume
    # eta = (1-np.exp(-beta*V))/(1-np.exp(-alfa*Tree_Height))  # area fill factor

    # Coherence as function of HoA for fixed tree height
    kz = 2*np.pi/HOA
    gamma_vol = (alfa/(alfa-1j*kz)*(np.exp(-1j*kz*Tree_Height) -
                                    np.exp(-alfa*Tree_Height)) /
                 (1-np.exp(-alfa*Tree_Height)))
    V = (Tree_Height**(1/b))/a
    eta = (1-np.exp(-beta*V))/(1-np.exp(-alfa*Tree_Height))
    m = (sigma0_gr/sigma0_veg * ((1-eta*(1-np.exp(-alfa*Tree_Height))) /
         (eta*((1-np.exp(-alfa*Tree_Height))))))
    gamma = (gamma_vol+m) / (1+m)
    if complex:
        return gamma
    else:
        return np.abs(gamma)
