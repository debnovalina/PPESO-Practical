__author__ = "Paco Lopez Dekker"
__email__ = "F.LopezDekker@tudelft.nl"

import numpy as np
from matplotlib import pyplot as plt

def add_noise(normdata, SNRdB):
    """ This function adds noise, assuming that the signal power is normalized to 1"""
    noiseamp = np.sqrt((10 ** (-SNRdB/10)) / 2)
    shp = normdata.shape
    return normdata + noiseamp *  (np.random.randn(*shp) + 1j * np.random.randn(*shp))


def k_distributed_data(shp, coh, gamma_shape=1, gamma_scale=1, SNRdB=10):
    """
    This function generates a pair of complex matrices according to a K compound distribution and
    assuming a certain coherence between the two (this coherence is applied at the circular Gaussian level)
    :param shp: shape of output matrix
    :param coh: coherence of speckle component
    :param gamma_shape: shape parameter of K-distribution
    :param gamma_scale: scale parameter
    :param SNRdB: SNR in dB
    :return: A tuple with the two matrices. Powers are normalized to 1.
    """

    pow_theor = 2 * gamma_shape * (gamma_shape + 1) * gamma_scale ** 2
    normf = 1 / np.sqrt(pow_theor)
    gamma_amp = np.random.gamma(gamma_shape, gamma_scale, shp)
    slc0_mst = normf * (np.random.randn(*shp) + 1j * np.random.randn(*shp))
    # Here we generate compound signal
    mst = gamma_amp *  slc0_mst
    slc0_slv =  (np.sqrt(coh) * slc0_mst +
                 normf * np.sqrt(1-coh**2) * (np.random.randn(*shp) + 1j * np.random.randn(*shp)))
    slv =  gamma_amp *  slc0_slv
    mst = add_noise(mst, SNRdB)
    slv = add_noise(slv, SNRdB)
    return (mst, slv)


def cGaussian_distributed_data(shp, coh, SNRdB=10):
    """
    This just generates a pair of circular-Gaussian distributed complex matrice
    :param shp: shape of output matrix
    :param coh: coherence between the images
    :param SNRdB: SNR in dB
    :return: A tuple with the two matrices. Powers are normalized to 1.
    """
    mst = (np.random.randn(*shp) + 1j * np.random.randn(*shp)) / np.sqrt(2)
    slv =  np.sqrt(coh) * mst + np.sqrt(1- coh ** 2) * (np.random.randn(*shp) + 1j * np.random.randn(*shp)) / np.sqrt(2)
    #print("cGPower: %f, %f" % (np.mean(np.abs(mst) ** 2), np.mean(np.abs(mst) ** 2)))
    mst = add_noise(mst, SNRdB)
    slv = add_noise(slv, SNRdB)
    return (mst, slv)


def phase_stats(nim, ml, coh, gamma_shape=1, SNRdB=10, verbose=True):
    """
    This computes the statistics of the interferometric phase error for circular-Gaussian distributed speckle and
    K-distributed speckle
    :param nim: number of realizations used to estimate the statistics
    :param ml: number of looks assumed.
    :param coh: interferometric coherence
    :param gamma_shape: shape parameter of K-distribution. This can be a list, or tuple, or an array, or a scalar
    :param SNRdB: SNR in dB
    :param verbose: True to print some output
    :return: Estimated standard deviations
    """
    if isinstance(gamma_shape, (list, tuple, np.ndarray)):
        gamms = np.array(gamma_shape)
        K_phasestd = []
        verbose = False
        for gamm in gamms:
            mst_k, slv_k = k_distributed_data((nim, ml), coh, gamma_shape=gamm, SNRdB=SNRdB)
            intf_k = np.sum(mst_k * np.conj(slv_k), axis=-1)
            K_phasestd.append(np.std(np.angle(intf_k)))
        K_phasestd = np.array(K_phasestd)
    else:
        mst_k, slv_k = k_distributed_data((nim, ml), coh, gamma_shape=gamma_shape, SNRdB=SNRdB)
        intf_k = np.sum(mst_k * np.conj(slv_k), axis=-1)
        K_phasestd = np.std(np.angle(intf_k))

    mst_cG, slv_cG = cGaussian_distributed_data((nim, ml), coh, SNRdB=SNRdB)
    intf_cG = np.sum(mst_cG * np.conj(slv_cG), axis=-1)
    cG_phasestd =  np.std(np.angle(intf_cG))

    if verbose:
        print("Circular Gaussian, phase std:%f deg" % (np.degrees(cG_phasestd)))
        print("K-distribution, phase std:%f deg" % (np.degrees(K_phasestd)))
    return (cG_phasestd, K_phasestd)


def phase_stats_vs_SNR(nim, ml, coh, gamma_shape=1, SNR_range=(0,20),
                       figsize=(6, 4.5), legendfntsize=8, LookNormalized=False):
    """
    Routine to call iteratively phase_stats and produce plots of phase errors vs SNR
    :param nim: number of realizations used to estimate the statistics
    :param ml: number of looks assumed.
    :param coh: interferometric coherence
    :param gamma_shape: shape parameter of K-distribution. This can be a list, or tuple, or an array, or a scalar
    :param SNR_range: a tuple with the minimum and maximum SNR to be considered (in dB)
    :param figsize: self-evident
    :param legendfntsize: to control the font size of the legend
    :param LookNormalized: if True, then the phase error is normalized by multiplying by the sqrt(ml). If the number of
    looks is large enough, this results in a number-of-look-independent output.
    """
    SNRs = np.arange(np.floor(SNR_range[0]), np.ceil(SNR_range[1]))
    gamms = np.array(gamma_shape)
    std_cGs = np.zeros_like(SNRs)
    std_Ks = np.zeros((SNRs.size, gamms.size))
    for ind in range(SNRs.size):
        (std_cGs[ind], std_Ks[ind, :]) = phase_stats(nim, ml, coh, gamma_shape=gamms,
                                                   SNRdB=SNRs[ind], verbose=False)
    if LookNormalized:
        errnormf = np.sqrt(ml)
        ylabel = "$\sigma_\phi \cdot \sqrt{N_\mathrm{l}}$ [deg]"
        ylim = [0, 5 * np.ceil(np.sqrt(ml) * np.degrees(std_Ks.max())/5)]
    else:
        errnormf = 1
        ylabel = "$\sigma_\phi$ [deg]"
        ylim = [0, 5 * np.ceil(np.degrees(std_Ks.max())/5)]
    plt.figure(figsize=figsize)
    plt.plot(SNRs, errnormf * np.degrees(std_cGs), label="Circ. Gaussian")
    for ind in range(gamms.size):
        plt.plot(SNRs, errnormf * np.degrees(std_Ks[:,ind]), label=(r"K-dist, $\nu$=%2.1f" % gamms[ind]))
    plt.xlabel("SNR [dB]")
    plt.ylabel(ylabel)
    plt.legend(prop={'size':legendfntsize})
    ax = plt.gca()
    ax.set_ylim(ylim)
    ax.grid(True)
    plt.tight_layout()


if __name__ == '__main__':
    phase_stats_vs_SNR(10000, 200, 0.9, gamma_shape=(1, 2, 4, 8), figsize=(6, 4.5), legendfntsize=10,
                       LookNormalized=True)
    phase_stats_vs_SNR(10000, 200, 0.5, gamma_shape=(1, 2, 4, 8), figsize=(6, 4.5), legendfntsize=10,
                       LookNormalized=True)
