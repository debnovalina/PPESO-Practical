import numpy as np
from drama.performance.insar import coh_m, phase_err_vs_coh
import scipy.interpolate as interpol
import matplotlib.pyplot as plt


def phase_err_vs_snr_plots(Ns=None):
    """ Function that plots the interferometric phase error as a function
        of the SNR and the number of looks.

        :author: Maria Sanjuan-Ferrer.
        
        :param Ns: Number of looks. Optional.
                   Default = [1.,2.,4.,8.,16.,32.,64.,128.].
        :type Ns: 1-D float array

        :returns: figure.
    """

    if Ns is None:
        Ns = np.array([1., 4., 16., 64., 128.])
    snr = np.arange(52.)/2.-5.
    coh_snr = coh_m(snr, db=True)
    phaerr_rho, phaerr_phi_err = phase_err_vs_coh(np.max(Ns), pp=True)
    scene_coh = np.array([0.95, 0.9])
    f_interp = interpol.interp1d(phaerr_rho, phaerr_phi_err, kind='linear')
    normh_err_best = (f_interp(np.amax(scene_coh)*coh_snr))/(2.*np.pi)
    #print np.min(normh_err_best)
    linestyles = np.array(['-', '--'])
    colors = np.array(['blue', 'red', 'green', 'magenta', 'firebrick',
                       'indigo', 'olive', 'maroon'])
    for cc in range(np.size(scene_coh)):
        for ll in range(np.size(Ns)):
            phaerr_rho, phaerr_phi_err = phase_err_vs_coh(Ns[ll], pp=True)
            f_interp2 = interpol.interp1d(phaerr_rho, phaerr_phi_err,
                                          kind='quadratic')
            normh_err = (f_interp2(scene_coh[cc]*coh_snr))/(2.*np.pi)
            if ll == 0 and cc == 0:
                plt.figure()
                v = ([np.min(snr), np.max(snr), np.min(normh_err_best),
                      np.max(normh_err)])
                plt.axis(v)
                plt.semilogy(snr, normh_err, linestyles[cc], color=colors[0],
                             label='N='+str(int(Ns[ll]))+' & '+r'$\gamma=$'+str(scene_coh[cc]))
            else:
                plt.semilogy(snr, normh_err, linestyles[cc], color=colors[ll],
                             label='N='+str(int(Ns[ll]))+' & '+r'$\gamma=$'+str(scene_coh[cc]))
    plt.xlabel('SNR [dB]')
    plt.ylabel(r'$\Delta h/h_{amb}$')
    plt.grid(True)
    plt.legend(loc='lower left', prop={'size': 9})
    plt.show()
