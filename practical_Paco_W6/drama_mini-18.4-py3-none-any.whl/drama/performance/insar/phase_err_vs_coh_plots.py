import numpy as np
import scipy.stats as sts
import scipy.interpolate as interpol
from drama.performance.insar import tbl_delta_phi_pdf, stdv_phase_vs_coh
import matplotlib.pyplot as plt


def phase_err_vs_coh(N, drho=0.01, dphi=None, pct=90.0, pp=False,
                     approx=False):
    """ Function that calculates the interferometric phase error as a
        function of the coherence and the number of looks.
        
        :author: Maria Sanjuan-Ferrer.

        :param N: Number of looks.
        :type N: float
        :param drho: Coherence steps. Optional.
        :type drho: float
        :param dphi: Resolution of pdf (rad). Optional. Default = 2*pi/1000 rad.
        :type dphi: float
        :param pct: Probability that error is lower than calculated error (%).
                    Optional.
        :type pct: float 
        :param pp: Flag. Optional.
        :type pp: bool
        :param approx: If True, approximated values are used. Optional.
        :type approx: bool

        :returns: tuple.

                  - **rho**: Coherence values.
                  - **phi_err**: Interferometric phase error.
    """
    if N > 171.:
        #Cannot compute gamma function for N>171
        approx = True
    if dphi is None:
        dphi = (2.*np.pi)/1000.
    prb = np.abs(pct)/100.
    if prb > 0.9:
        prb = 0.9
    if approx is False:
        rhod, phid, pdfd = tbl_delta_phi_pdf(N, drho=drho, dphi=dphi, out=True)
        #adrho = float(rhod[1])
        adphi = float(phid[1])
        #phi = np.multiply(np.ones((np.size(rhod)), float).reshape(-1, 1), phid)
        if pp is True:
            pdfde = np.concatenate((np.fliplr(pdfd), pdfd[:, 1:], np.zeros((np.size(rhod)), float).reshape(-1, 1)),axis=1)
            pdfd = np.real((np.roll(np.fft.ifft(np.fft.fft(pdfde, axis=1)**2., axis=1), 2, axis=1))[:, 0:np.size(phid)])
            pdfde = 0.
            scale = np.multiply(2.*adphi*(np.sum(pdfd, axis=1)-pdfd[:, 0]/2.).reshape(-1,1), np.ones(np.size(phid)))
            pdfd = pdfd/scale
        pdf0 = pdfd[:, 0]
        pdfd[:, 0] = pdf0/2.
        cum = 2.*np.cumsum(adphi*pdfd, axis=1)
        cum[:, 0] = adphi*pdf0
        phi_err = np.empty(rhod.size)
        for index in range(rhod.size):
            func_interp = interpol.interp1d(cum[index, :], phid, kind='linear')
            phi_err[index] = func_interp(prb)
        find_nans = np.where(np.isnan(phi_err))
        if np.size(find_nans) > 0:
            #Deal with NaNs
            pevc_a_rho, pevc_a_phi_err = phase_err_vs_coh(N, drho=drho,
                                                          dphi=dphi, pct=pct,
                                                          pp=pp, approx=True)
            phi_err[find_nans] = pevc_a_phi_err[find_nans]
        v_0 = np.array([0.])
        v_1 = np.array([1.])
        rho, phi_err = (np.concatenate((rhod, v_1)),
                        np.concatenate((phi_err, v_0)))
        return rho, phi_err
    else:
        stdvs_rho, stdvs_stdv = stdv_phase_vs_coh(N, drho=drho, dphi=dphi,
                                                  approx=True)
        if pp is True:
            stdvs_stdv = np.sqrt(2.)*stdvs_stdv
        norm_cut = np.abs(sts.norm.ppf((1.-prb)/2))
        rho, phi_err = (stdvs_rho, norm_cut*stdvs_stdv)
        return rho, phi_err


def phase_err_vs_coh_plots(Ns=None):
    """ Function that plots the interferometric phase error as a function
        of the coherence and the number of looks.
        
        :author: Maria Sanjuan-Ferrer.

        :param Ns: Number of looks. Optional.
                   Default = [1.,2.,4.,8.,16.,32.,64.,128.].
        :type Ns: 1-D float array

        :returns: figure.
    """
    if Ns is None:
        Ns = np.array([1., 2., 4., 8., 16., 32., 64., 128.])

    colors = np.array(['blue', 'red', 'green', 'magenta', 'firebrick',
                       'indigo', 'olive', 'maroon'])

    for index in range(np.size(Ns)):
        errs_rho, errs_phi_err = phase_err_vs_coh(Ns[index], pct=90., pp=True)
        #errs_rho, errs_phi_err = phase_err_vs_coh(Ns[index], pct=90., pp=True, approx=True)
        if index is 0:
            plt.figure()
            v = [0.0, 1.0, 0., 180.]
            plt.axis(v)
            plt.plot(errs_rho, (180.*errs_phi_err)/np.pi,
                     label='N='+str(int(Ns[index])), color=colors[index])
            maxerr = np.amax(errs_phi_err)
        else:
            x_plot = np.compress((errs_phi_err <= maxerr).flat, errs_rho)
            y_plot = np.compress((errs_phi_err <= maxerr).flat, errs_phi_err)
            plt.plot(x_plot, (180.*y_plot)/np.pi, label='N='+str(int(Ns[index])),
                     color=colors[index])
        plt.xlabel('Coherence')
        plt.ylabel('%90 Phase error '+'['+r'$^\circ$'+']')
        plt.grid(True)
        plt.legend(loc='upper right')
        plt.show()
