import os
import os.path
from collections import namedtuple
from tkinter import Tk
from tkinter import filedialog as filedial

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from mpl_toolkits.basemap import Basemap, maskoceans
from scipy.interpolate import interp1d
from scipy.ndimage.interpolation import zoom

import drama.mission.timeline as tl
from drama import constants as const
from drama.geo.orbit import orbit_to_vel
from drama.geo.sar import geometry as geometry
from drama.io import cfg
from drama.performance.insar import (stdv_phase_vs_coh,
                                     tbl_delta_phi_pdf_filename)
from drama.performance.insar.coherence_models import (get_gamma_SNR_ambig,
                                                      get_gamma_iceVol)
from drama.performance.insar.dinsar_pat import plot_ch
from drama.performance.sar.system import load_mod_perf
from drama.utils.read_backscattering import load_Cband_sigma0 as load_sigma0


def dem_perf_preliminary(h_amb=np.arange(5, 100), az_res=20, grg_res=5,
                         prod_res=150, sigma_0=-12.1, NESZ=-18, eps=2.8,
                         ke=np.array([1/20, 1/15, 1/10, 1/5]), inc_angle=35):

    """ Function to compute the height accuracy as function of number of looks
        and coherence, changing the height of ambiguity

        :author: Paco Lopez-Dekker, Mariantonietta Zonno

        :param makeit: flag to set the execution of this function
        :param h_amb: height of ambiguity
        :type h_amb: 1d array
        :param az_res: azimuth resolution
        :type az_res: float
        :param grg_res: ground range resolution
        :type grg_res: float
        :param prod_res: final product resolution
        :type prod_res: float
        :param sigma_0: backscattering [db]
        :type sigma_0: float
        :param NESZ: NESZ[db]
        :type NESZ: float
        :param eps: real part of the dielectric constant
        :type eps: float
        :param ke: extinction coefficient [1/m]
        :type ke: float
        :param inc_angle: incidence angle
        :type inc_angle: float

        :returns: height accuracy
    """

    h_amb = h_amb.reshape((h_amb.size, 1))
    kz = 2 * np.pi / h_amb

    Nlooks = (prod_res ** 2) / az_res / grg_res

    inc_angle = np.radians(inc_angle)
    ke = ke.reshape((1, ke.size))

    refr_angle_a = np.arcsin(np.sin(inc_angle)/np.sqrt(eps))

    gamma_snr = get_gamma_SNR_ambig(sigma_0, NESZ, 0, 0)
    gamma_vol = np.abs(1 / (1 + 1j * np.cos(refr_angle_a) * kz /(2 * ke)))

    gamma_tot = gamma_snr * gamma_vol

    flag = False
    fname = tbl_delta_phi_pdf_filename(Nlooks)
    flag = os.path.isfile(fname)

    if flag is False:
        # retrieve for the std correspondent to the looks
        rho, stdv = stdv_phase_vs_coh(Nlooks)
    else:
        v_0 = np.array([0.])
        v_1 = np.array([1.])
        npzfile = np.load(fname)
        rhod = npzfile['srho']
        phid = npzfile['sphi']
        pdfd = npzfile['pdf']

        adphi = float(phid[1])
        phi = np.multiply(np.ones((100), float).reshape(-1, 1), phid)
        stdv = np.sqrt(2.*np.sum(adphi*pdfd*phi**2., axis=1))
        rho, stdv = (np.concatenate((rhod, v_1)),
                     np.concatenate((stdv, v_0)))

    # interpolator
    interpol = interp1d(rho, stdv)

    stdv_new = interpol(gamma_tot)

    stdv_height = stdv_new/kz

    mpl.rcParams.update({'font.size': 15})
    plt.figure()
    ax = plt.subplot(111)
    for ind in range(stdv_height.shape[1]):
        plt.plot(h_amb, stdv_height[:, ind], linewidth=2.5,
                 label=('$\delta_p$ %3.0f [m]' % (1/ke[0, ind])))
    pos1 = ax.get_position()   # get the original position
    pos2 = [pos1.x0, pos1.y0 + 0.02,  pos1.width, pos1.height]
    ax.set_position(pos2)      # set a new position
    plt.xlabel('$h_{amb}$ [m]', fontsize=18)
    # plt.xscale('log')
    plt.ylabel('$\sigma_h$ [m]', fontsize=18)
    plt.legend(loc='best')




def open_icemask(lat_min, lat_max, lon_min, lon_max, ice_filename):

    """ Function to open the ice mask

        :author: Mariantonietta Zonno

        :param lat_min: minimum latitude of the defined grid
        :type lat_min: 1d array
        :param lat_max: maximum latitude of the defined grid
        :type lat_max: namedtuple
        :param lon_min: minimum longitude of the defined grid
        :type lon_min: namedtuple
        :param lon_max: maximum longitude of the defined grid
        :type lon_max: float
        :param ice_filename: ice mask filename
        :type ice_filename: string
        :returns: ice mask

    """
    # Open the ice mask
    im = Image.open(ice_filename)
    ice_mask = np.copy(im).astype(float)
    ice_mask = np.where(ice_mask > 0.0, 1.0, np.nan)

    ice_lats = np.linspace(-90, 90, ice_mask.shape[0])
    ice_lons = np.linspace(-180, 180, ice_mask.shape[1])

    # define for the forest map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(ice_lats >= lat_min,
                                               ice_lats <= lat_max)))
    lon_ind = np.array(np.where(np.logical_and(ice_lons >= lon_min,
                                               ice_lons <= lon_max)))

    ice_mask = ice_mask[lat_ind[0][0]:lat_ind[0][-1]+1,
                        lon_ind[0][0]:lon_ind[0][-1]+1]

    return ice_mask


def dem_perf_tool(f, AcqArray, SARPerf, deltax, deltagr, totalTime, dlat, GBM,
                  cycles, vg):
    """ Function to compute the standard deviation as function of the system
        geometry, sar performance and coherence

        :author: Mariantonietta Zonno

        :param f: formation timeline
        :type f: 1d array
        :param AcqArray: structure containing all the information for the
                         considered point (geometry, lat, lon, ... )
        :type AcqArray: namedtuple
        :param SARPerf: SAR performance parameters
        :type SARPerf: namedtuple
        :param deltax: product resolution in azimuth
        :type deltax: float
        :param deltagr: product resolution in range
        :type deltagr: float
        :param totalTime: Total time of the analysis
        :type totalTime: float
        :param dlat: latitude resolution of the lat lon grid
        :type dlat: float
        :param GBM: sigma0 map
        :type GBM: arrray
        :param cycles: days of acquisition in totalTime
        :type cycles: 1d array
        :param vg: ground velocity
        :type cycles: float
        :returns: standard deviation and kz
    """

    # output structure
    PI = namedtuple('PointInfo', ['stddev', 'kz_cycles', 'looks', 'sigma0',
                                  'gamma',  'gammaSNR', 'gammaVol'])

    c0 = const.c
    # Number of subswathscycles
    subswaths = len(SARPerf.theta)
    nTracks = len(AcqArray.inc_angle_slave)
    gammaSNR_arr = np.zeros((nTracks, 1))+np.nan

    looks = np.zeros((nTracks, cycles.size))
    stddev = np.zeros((nTracks, cycles.size))+np.nan

    inc_angle_slave = np.array(AcqArray.inc_angle_slave)

    gammaVol_, kz_cycles = get_gamma_iceVol(f, dlat, inc_angle_slave,
                                            AcqArray.acqMode, cycles,
                                            AcqArray.lat)
    gammaTot = np.zeros((gammaVol_.shape[0], gammaVol_.shape[1]))+np.nan

    for mm in range(nTracks):
        inc_angle_s = inc_angle_slave[mm]  # rad
        # read the sar performance correspondent to the incidence angle
        if subswaths > 1:
            positions = np.argwhere(SARPerf.theta <= inc_angle_s)
            if positions.size > 0:
                ind = positions[-1]
            else:
                ind = np.array([0, 0])
            bw = SARPerf.Brg[ind[0]]
            azRes = SARPerf.az_res  # np.mean(SARPerf.az_res[ind[0]])
            nesz = SARPerf.sigma_ne[ind[0], ind[1]]
            AASR = SARPerf.AASR[ind[0], ind[1]]
            RASR = SARPerf.RASR[ind[0], ind[1]]
        else:
            positions = np.argwhere(SARPerf.theta <= inc_angle_s)
            ind = positions[-1]
            bw = SARPerf.Brg
            azRes = np.mean(SARPerf.az_res)
            nesz = SARPerf.sperf_tooligma_ne[ind[0]]
            AASR = SARPerf.AASR[ind[0]]
            RASR = SARPerf.RASR[ind[0]]

        # read the backscatt

        sigma0 = load_sigma0(GBM, (AcqArray.lat),
                             (AcqArray.lon), inc_angle_s)
        if not np.isnan(sigma0):
            # coherence due to SNR and ambiguities
            gammaSNR_ = get_gamma_SNR_ambig(sigma0, nesz, AASR, RASR)
            gammaSNR_arr[mm] = gammaSNR_

            if AcqArray.iceFlag == 1:
                gammaTot = gammaSNR_arr*gammaVol_
            else:
                gammaTot = gammaSNR_arr*np.ones((nTracks, cycles.size))

#        # Common Bandwidth and change of the resolution
#        if AcqArray.acqMode[mm] == 'A':
#            asc_flag = True
#        else:
#            asc_flag = False

    if not np.isnan(sigma0):
        # ascending tracks
        ind = np.where(AcqArray.acqMode == 'A')[0]
        inc_angle_a = inc_angle_slave[ind].reshape((inc_angle_slave[ind].size,
                                                    1))
        lats = AcqArray.lat*np.ones(inc_angle_a.size).reshape((inc_angle_a.size, 1))
        cycles = cycles.reshape((1, cycles.size))
        # spec_shift has the inc_angle size * cycles size
        spec_shift_a = f.get_spectral_shift(np.degrees(inc_angle_a), lats,
                                            cycles, ascending=True)
        doppl_shift_a = f.get_Doppler_shift(np.degrees(inc_angle_a), lats,
                                            cycles, ascending=True)
        # descending tracks
        ind = np.where(AcqArray.acqMode == 'D')[0]
        inc_angle_d = inc_angle_slave[ind].reshape((inc_angle_slave[ind].size,
                                                    1))
        lats = AcqArray.lat*np.ones(inc_angle_d.size).reshape((inc_angle_d.size, 1))
        cycles = cycles.reshape((1, cycles.size))

        # spec_shift and doppler_shift have the inc_angle size * cycles size
        spec_shift_d = f.get_spectral_shift(np.degrees(inc_angle_d), lats,
                                            cycles, ascending=False)
        doppl_shift_d = f.get_Doppler_shift(np.degrees(inc_angle_d), lats,
                                            cycles, ascending=False)
        doppl_shift_ = np.vstack((doppl_shift_a, doppl_shift_d))
        spec_shift_ = np.vstack((spec_shift_a, spec_shift_d))


        Doppl_Band = vg/azRes
        # take the shifts value for every inc_angle and cycle
        # compute the new bandwidth and  change in resol
        New_Doppl_Band = Doppl_Band - np.abs(doppl_shift_)
        New_Rg_Band = bw - np.abs(spec_shift_)
        # check if it is greater than half of the bandwidth
        New_Doppl_Band = np.where(New_Doppl_Band > Doppl_Band/2, New_Doppl_Band,
                                  np.nan)
        New_Rg_Band = np.where(New_Rg_Band > bw/2, New_Rg_Band, np.nan)

        azRes = vg/New_Doppl_Band
        rgRes = c0/2./New_Rg_Band
        grRes = rgRes / np.cos(inc_angle_slave).reshape((inc_angle_slave.size,
                                                         1))

        # number of looks
        deltax = deltax*np.ones((inc_angle_slave.size, cycles.size))
        looks = np.round((deltax/azRes)*(deltagr/grRes))

        # where the configuration is such that there are looks
        ind1, ind2 = np.where((np.logical_and(np.logical_not(np.isnan(gammaTot)),
                                              np.logical_not(np.isnan(looks)))))

        for nn in range(len(ind1)):

            flag = False
            fname = tbl_delta_phi_pdf_filename(looks[ind1[nn], ind2[nn]])
            flag = os.path.isfile(fname)

            if flag is False:
                # retrieve for the std correspondent to the looks
                rho, stdv = stdv_phase_vs_coh(looks[ind1[nn], ind2[nn]])
            else:
                v_0 = np.array([0.])
                v_1 = np.array([1.])
                npzfile = np.load(fname)
                rhod = npzfile['srho']
                phid = npzfile['sphi']
                pdfd = npzfile['pdf']

                adphi = float(phid[1])
                phi = np.multiply(np.ones((100), float).reshape(-1, 1), phid)
                stdv = np.sqrt(2.*np.sum(adphi*pdfd*phi**2., axis=1))
                rho, stdv = (np.concatenate((rhod, v_1)),
                             np.concatenate((stdv, v_0)))
            # interpolator
            interpol = interp1d(rho, stdv)

            # retrieve the stddev correspondent to the coherence for the
            # specific point,  geometry and cycle
            # phase std
            stdv_new = interpol(gammaTot[ind1[nn], ind2[nn]])
            # heught std
            stddev[ind1[nn], ind2[nn]] = stdv_new

        stddev = stddev/kz_cycles
    PI_ = PI(stddev, kz_cycles, looks, sigma0, gammaTot, gammaSNR_arr,
             gammaVol_)
    return PI_


def dem_perf_main(param_File=None):

    """ Function to plot the compute dem accuracy over a lat lon grid as
        function of the coherence and number of looks

        :author: Mariantonietta Zonno

        :param par_: Path of the parameter file
        :type par_: string

        :returns: minimum, maximum, mean dem standard deviation and
                 correspondent kz for every lat lon point in the defined grid

    """

    if param_File is None:
        # Parameter File
        Tk().withdraw()
        param_File = filedial.askopenfilename(title='Select parameter file')
    # load the paths from the parameter file
    inData = cfg.ConfigFile(param_File)
    MainPath = inData.path.MainPath
    system = inData.path.system
    ice_filename = inData.path.ice_filename
    sigma0path = inData.path.sigma0path
    perf_File = inData.path.perf_File
    # Load SAR performance
    modeId = ['PicoSAR_SysID001_MonoScan', 'PicoSAR_SysID011_BiScan',
              'PicoSAR_SysID012_BiStrip']
    out = load_mod_perf(systemName=system, par_fileName=param_File,
                        perf_fileName=perf_File, polarization='HH',
                        mode=modeId[2])
    # Read the parameters from the input file
    deltax = inData.misc.deltax    # Posting requirement in along-track [m]
    deltagr = inData.misc.deltagr  # Posting requirement in ground-range [m]
    totalTime = inData.misc.totalTime
    # velocity on ground
    vg = orbit_to_vel(inData.orbit.Horb, ground=True)
    # at the moment the resolution must be that of the sigma0 map i.e, 0.5[deg]
    # Lat - lon grid
    lat_min = inData.misc.lat_min  # Minimum latitude (deg)
    lat_max = inData.misc.lat_max  # Maximum latitude (deg)
    lat_res = inData.misc.lat_res  # Latitude resolution (deg)
    lon_min = inData.misc.lat_min  # Minimum longitude (deg)
    lon_max = inData.misc.lon_max  # Maximum longitude (deg)
    lon_res = inData.misc.lon_res  # inData.misc.lon_res

    lat_arr = np.arange(lat_min, lat_max+lat_res, lat_res)
    lon_arr = np.arange(lon_min, lon_max+lon_res, lon_res)
    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)

    # formation timeline
    f1 = tl.FormationTimeline(param_File, secondary=True)
    # Ratio of valid incidence angles (according to swath)
    Horb1 = f1.track_prim.Horb
    min_ = np.degrees(geometry.look_to_inc(np.deg2rad(inData.sar.near_1),
                                           Horb1))
    max_ = np.degrees(geometry.look_to_inc(np.deg2rad(inData.sar.far_1),
                                           Horb1))
    inc_range = [np.abs(min_), np.abs(max_)]
#    min_ = inData.sar.near_1
#    max_ = inData.sar.far_1
#    inc_range = [np.abs(min_), np.abs(max_)]
    # timeline
    tl1 = tl.LatLonTimeline(par_file=param_File, lats=lat, lons=lon,
                            inc_angle_range=inc_range, ext_orbit=False,
                            form=f1)
    asc_tl = tl1.asc_acqs
    desc_tl = tl1.desc_acqs
    asc_tl_2 = tl1.asc_acqs2
    desc_tl_2 = tl1.desc_acqs2

    plot_ch(lon, lat, lat_arr, lon_arr, tl1, timeline=False)

    # cycles according to the repeat time
    repeat = int(f1.track.repeat_cycle)
    cycles = np.arange(0, totalTime, repeat)

    # ice_mask for identify points over which volume decorrelation occur
    ice_mask = open_icemask(lat_min, lat_max, lon_min, lon_max, ice_filename)
    # interpolation on the finer lat lon grid
    ice_mask = zoom(ice_mask, (lat_arr.size/ice_mask.shape[0],
                    lon_arr.size/ice_mask.shape[1]), order=1)

    # Open sigma0 map
    sigma0_map = np.load(sigma0path)

    # inizialization
    AcqArray = namedtuple('AcqArray', ['inc_angle_master', 'inc_angle_slave',
                                       'lat', 'lon', 'iceFlag', 'acqMode'])

    # Output matrices
    max_std = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    min_std = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    mean_std = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    kz = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    min_looks = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    max_looks = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    mean_looks = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    sigma0 = np.zeros((lat_arr.size, lon_arr.size))
    min_gamma = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    max_gamma = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    mean_gamma = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    max_gammaVol = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    max_gammaSNR = np.zeros((lat_arr.size, lon_arr.size))

    for i in range(lat_arr.size):
        for j in range(lon_arr.size):
            # sentinel
            inc_angle_asc_m = asc_tl[i][j].theta_i
            inc_angle_desc_m = desc_tl[i][j].theta_i
            inc_angle_m = np.hstack((inc_angle_asc_m, inc_angle_desc_m))

            # Picosar
            inc_angle_asc_s = asc_tl_2[i][j].theta_i
            inc_angle_desc_s = desc_tl_2[i][j].theta_i
            inc_angle_s = np.hstack((inc_angle_asc_s, inc_angle_desc_s))
            # if ascending or descending
            acqMode = 'A'*len(inc_angle_asc_s)+'D'*len(inc_angle_desc_s)
            acqMode = np.array([acqMode[i:i+1] for i in range(0, len(acqMode),
                                1)])

            iceFlag = ice_mask[i, j]
            AcqArray_ = AcqArray(inc_angle_m, inc_angle_s,
                                 lat_arr[i], lon_arr[j], iceFlag,
                                 acqMode)
            if inc_angle_s.size != 0:
                Output = dem_perf_tool(f1, AcqArray_, out, deltax, deltagr,
                                       totalTime, lat_res, sigma0_map, cycles,
                                       vg)

                max_gammaSNR[i, j] = np.nanmean(Output.gammaSNR)
                sigma0[i, j] = Output.sigma0
                max_std[i, j, :] = np.nanmax(Output.stddev, axis=0)
                min_std[i, j, :] = np.nanmin(Output.stddev, axis=0)
                mean_std[i, j, :] = np.nanmean(Output.stddev, axis=0)
                kz[i, j, :] = np.mean(Output.kz_cycles, axis=0)
                max_looks[i, j, :] = np.nanmax(Output.looks, axis=0)
                min_looks[i, j, :] = np.nanmin(Output.looks, axis=0)
                mean_looks[i, j, :] = np.nanmean(Output.looks, axis=0)
                max_gamma[i, j, :] = np.nanmax(Output.gamma, axis=0)
                min_gamma[i, j, :] = np.nanmin(Output.gamma, axis=0)
                mean_gamma[i, j, :] = np.nanmean(Output.gamma, axis=0)
                max_gammaVol[i, j, :] = np.nanmean(Output.gammaVol, axis=0)

    np.save(MainPath+'/sigma0', sigma0)
    np.save(MainPath+'/max_std', max_std)
    np.save(MainPath+'/min_std', min_std)
    np.save(MainPath+'/mean_std', mean_std)
    np.save(MainPath+'/kz', kz)
    np.save(MainPath+'/max_looks', max_looks)
    np.save(MainPath+'/min_looks', min_looks)
    np.save(MainPath+'/mean_looks', mean_looks)
    np.save(MainPath+'/max_gamma', max_gamma)
    np.save(MainPath+'/min_gamma', min_gamma)
    np.save(MainPath+'/mean_gamma', mean_gamma)
    np.save(MainPath+'/max_gammaVol', max_gammaVol)
    np.save(MainPath+'/max_gammaSNR', max_gammaSNR)
    do_DEMPlots(lat_arr, lon_arr, cycles, sigma0, max_std, min_std, mean_std,
                max_looks, min_looks, mean_looks, min_gamma, max_gamma,
                mean_gamma, kz, max_gammaVol, max_gammaSNR, MainPath, ice_mask)


def do_DEMPlots(lat_arr, lon_arr, cycles, sigma0, max_std, min_std, mean_std,
                max_looks, min_looks, mean_looks, min_gamma, max_gamma,
                mean_gamma, kz, max_gammaVol, max_gammaSNR, MainPath,ice_mask):

    """ Function to plot the minimum, mean and maximum of dem std for every
        cycle

        :param lat_arr: Latitude array
        :type lat_arr: 1d array

        :param lon_arr: Longitude array
        :type lon_arr: 1d array
        :param cycles: array of days considered in one year
        :type cycles: 1d array
        :param max_std: Maximum value of the standard deviation for each grid
                        point and cycle
        :type max_std: 3d array
        :param min_std: Minimum value of the standard deviation for each grid
                        point and cycle
        :type min_std: float
        :param mean_std: Mean value of the standard deviation for each grid
                        point and cycle
        :type mean_std: float
        :param MainPath: Path in which to save the figures
        :type MainPath: string
        :returns: plots

    """

    lat_min = np.min(lat_arr)
    lat_max = np.max(lat_arr)
    lon_min = np.min(lon_arr)
    lon_max = np.max(lon_arr)

    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)

    # plots
    yticks = np.arange(lat_min, lat_max+1, 10)
    xticks = np.arange(lon_min, lon_max+1, 20)

    # ice map
    plt.figure()
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    ice_mask_new = np.where(np.isnan(ice_mask), 999, 1)
    Masked_ = np.ma.masked_where(ice_mask_new==999, ice_mask_new)

    cmap = plt.cm.jet
    cmap.set_bad(color='w', alpha=1.)
    imag = m.pcolormesh(lon, lat, Masked_, shading='gouraud', cmap=cmap,
                        latlon=True,)
    m.drawmapboundary(fill_color='white')
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    plt.title('Ice mask')
    cb = m.colorbar(imag, "right", size="5%", pad="2%")
    plt.show()
    plt.savefig(MainPath+'/Ice map.png', dpi=200, bbox='tight')

    # backscattering
    plt.figure()
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    Masked_ = np.ma.array(sigma0, mask=sigma0)

    Im = maskoceans(lon, lat, sigma0)
    cmap = plt.cm.jet
    cmap.set_bad(color='w', alpha=1.)
    imag = m.pcolormesh(lon, lat, sigma0, shading='gouraud', cmap=cmap,
                        latlon=True, vmin=np.nanmin(sigma0),
                        vmax=np.nanmax(sigma0))
    m.drawmapboundary(fill_color='white')
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    plt.title('Backscattering map [dB]')
    cb = m.colorbar(imag, "right", size="5%", pad="2%")
    plt.show()
    plt.savefig(MainPath+'/Sigma0.png', dpi=200, bbox='tight')

    for ii in range(cycles.size):
        #  Max Gamma Tot
        plt.figure()
        # setup Lambert Conformal basemap.
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()

        Masked_ = np.ma.array(max_gamma[:, :, ii],
                              mask=np.isnan(max_gamma[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True, vmin=0.3, vmax=1)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Maximum Total Coherence - day '+str(cycles[ii]))
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.show()
        plt.savefig(MainPath+'/MaxGamma_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')

        #  Min Gamma
        plt.figure()
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()

        Masked_ = np.ma.array(min_gamma[:, :, ii],
                              mask=np.isnan(min_gamma[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True, vmin=0.3, vmax=1)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Minimum Total Coherence - day '+str(cycles[ii]))
        # add colorbar
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.show()
        plt.savefig(MainPath+'/MinGamma_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')
        plt.close('all')
        #  Mean Standard Deviation
        plt.figure()
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()
        Masked_ = np.ma.array(mean_gamma[:, :, ii],
                              mask=np.isnan(mean_gamma[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True, vmin=0.3, vmax=1)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Mean Total Coherence - day '+str(cycles[ii]))
        # add colorbar
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.title('Mean DEM error [meters]')
        plt.show()
        plt.savefig(MainPath+'/MeanGamma_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')

#        #  Max Standard Deviation
#        plt.figure()
#        # setup Lambert Conformal basemap.
#        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
#                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
#        # draw coastlines.
#        m.drawcoastlines()
#        Masked_ = np.ma.array(max_std[:, :, ii],
#                              mask=np.isnan(max_std[:, :, ii]))
#
#        Im = maskoceans(lon, lat, Masked_)
#        cmap = plt.cm.jet
#        cmap.set_bad(color='w', alpha=1.)
#        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
#                            latlon=True, vmin=0, vmax=3)
#        m.drawmapboundary(fill_color='white')
#        plt.xlabel('Longitude [deg]')
#        plt.ylabel('Latitude [deg]')
#        plt.xticks(xticks)
#        plt.yticks(yticks)
#        plt.title('Maximum DEM error [meters] - day '+str(cycles[ii]))
#        cb = m.colorbar(imag, "right", size="5%", pad="2%")
#        plt.show()
#        plt.savefig(MainPath+'/MaxStd_cycle'+str(ii)+'.png', dpi=200,
#                    bbox='tight')

        #  Min Standard Deviation
        plt.figure()
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()

        Masked_ = np.ma.array(min_std[:, :, ii],
                              mask=np.isnan(min_std[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True, vmin=0, vmax=0.5)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Minimum DEM error [meters] - day '+str(cycles[ii]))
        # add colorbar
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.show()
        plt.savefig(MainPath+'/MinStd_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')

#        #  Mean Standard Deviation
#        plt.figure()
#        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
#                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
#        # draw coastlines.
#        m.drawcoastlines()
#        Masked_ = np.ma.array(mean_std[:, :, ii],
#                              mask=np.isnan(mean_std[:, :, ii]))
#
#        Im = maskoceans(lon, lat, Masked_)
#        cmap = plt.cm.jet
#        cmap.set_bad(color='w', alpha=1.)
#        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
#                            latlon=True, vmin=0, vmax=3)
#        m.drawmapboundary(fill_color='white')
#        plt.xlabel('Longitude [deg]')
#        plt.ylabel('Latitude [deg]')
#        plt.xticks(xticks)
#        plt.yticks(yticks)
#        plt.title('DEM error [meters]')
#        # add colorbar
#        cb = m.colorbar(imag, "right", size="5%", pad="2%")
#        plt.title('Mean DEM error [meters] - day '+str(cycles[ii]))
#        plt.show()
#        plt.savefig(MainPath+'/MeanStd_cycle'+str(ii)+'.png', dpi=200,
#                    bbox='tight')

        #  Max N looks
        plt.figure()
        # setup Lambert Conformal basemap.
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()
        Masked_ = np.ma.array(max_looks[:, :, ii],
                              mask=np.isnan(max_looks[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Maximum number of looks - day '+str(cycles[ii]))
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.show()
        plt.savefig(MainPath+'/MaxLooks_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')

        #  Min looks
        plt.figure()
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()
        Masked_ = np.ma.array(min_looks[:, :, ii],
                              mask=np.isnan(min_looks[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('Minimum number of looks - day '+str(cycles[ii]))
        # add colorbar
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.show()
        plt.savefig(MainPath+'/MinLooks_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')

        #  Mean Number of looks
        plt.figure()
        m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                    llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
        # draw coastlines.
        m.drawcoastlines()
        Masked_ = np.ma.array(mean_looks[:, :, ii],
                              mask=np.isnan(mean_looks[:, :, ii]))

        Im = maskoceans(lon, lat, Masked_)
        cmap = plt.cm.jet
        cmap.set_bad(color='w', alpha=1.)
        imag = m.pcolormesh(lon, lat, Im, shading='gouraud', cmap=cmap,
                            latlon=True)
        m.drawmapboundary(fill_color='white')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.xticks(xticks)
        plt.yticks(yticks)
        plt.title('DEM error [meters] - day '+str(cycles[ii]))
        # add colorbar
        cb = m.colorbar(imag, "right", size="5%", pad="2%")
        plt.title('Mean number of looks')
        plt.show()
        plt.savefig(MainPath+'/MeanLooks_cycle'+str(ii)+'.png', dpi=200,
                    bbox='tight')
        plt.close('all')


if __name__ == '__main__':
    Dir = '/home/zonn_ma/Codes/Python/drama/drama/coverage/params/Sesame/'
    Filename = 'PICOSAR_CRYO_Drift.par'
    prel_perf = False
    if prel_perf:
        print('Preliminary performance')
        dem_perf_preliminary()
    else:
        print('Global performance')
        dem_perf_main(Dir+Filename)
