from drama.utils.misc import db2lin
from drama.utils.read_backscattering import load_sigma0
from scipy.ndimage.interpolation import zoom
import drama.mission.timeline as tl
import numpy as np
import drama.io.rat as rat
import matplotlib.pyplot as plt
import pickle
from scipy.interpolate import interp1d
from mpl_toolkits.basemap import Basemap, maskoceans
from tkinter import Tk
from tkinter import filedialog as filedial

font = {'family': 'normal',
        'size' : 16}


def get_coher_maps(system, param_File, file_backscatt, file_inc, lat_arr,
                   lon_arr, SARPerf_asc, SARPerf_desc, SARPerf_asc_B,
                   SARPerf_desc_B, asc_tl, desc_tl, path):

    """ Function to retrieve the coherence maps
        :param system: name of the system (is saocom, only ascending)
        :type system: string
        :param param_File: parameter file
        :type param_File: string
        :param file_backscatt: name of the file of the backscattering map
        :type file_backscatt: string
        :param file_inc: name of the file of the local incidence angle
        :type file_inc: float
        :param lat_arr: array of the latitude values
        :type lat_arr: array
        :param lon_arr: array of the longitude values
        :type lon_arr: array
        :param SARPerf_asc: sar performance in ascending mode
        :type SARPerf_asc: named tuple
        :param SARPerf_desc: sar performance in descending mode
        :type SARPerf_desc: named tuple
        :param asc_tl: array of ascending acquisition information (angles, ...)
        :type asc_tl: numpy.ndarray
        :param desc_tl: array of descending acquisition information
        :type desc_tl:  numpy.ndarray
        :returns: coherence maps

    """

    # gamma_snr computation
    get_gamma_SNR_ambig_map(system, file_backscatt, file_inc, asc_tl, desc_tl,
                            lat_arr, lon_arr, SARPerf_asc, SARPerf_desc,
                            SARPerf_asc_B, SARPerf_desc_B, path)

    get_gamma_vol_map(path, system, param_File, asc_tl, desc_tl, lat_arr,
                      lon_arr)


def get_gamma_SNR_ambig_map(system, file_backscatt, file_inc, asc_tl, desc_tl,
                            lat_arr, lon_arr, SARPerf_asc, SARPerf_desc,
                            SARPerf_asc_B, SARPerf_desc_B, path):

    """ Function to retrieve the gamma_SNR
        :param system: name of the system (is saocom, only ascending)
        :type system: string
        :param file_backscatt: name of the file of the backscattering map
        :type file_backscatt: string
        :param file_inc: name of the file of the local incidence angle
        :type file_inc: float
        :param asc_tl: array of ascending acquisition information (angles, ...)
        :type asc_tl: numpy.ndarray
        :param desc_tl: array of descending acquisition information
        :type desc_tl:  numpy.ndarray
        :param lat_arr: array of the latitude values
        :type lat_arr: array
        :param lon_arr: array of the longitude values
        :type lon_arr: array
        :param SARPerf_asc: sar performance in ascending mode
        :type SARPerf_asc: named tuple
        :param SARPerf_desc: sar performance in descending mode
        :type SARPerf_desc: named tuple
        :param SARPerf_asc_B: sar performance in ascending mode (Bistatic)
        :type SARPerf_asc_B: named tuple
        :param SARPerf_desc_B: sar performance in descending mode (Bistatic)
        :type SARPerf_desc_B: named tuple
        :param path: path to save the results
        :type path: string
        :returns:  gamma_snr and gamma_snr+ambiguities maps
    """
    nesz_min = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    nesz_max = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    # azimuth and range ambiguities
    aa_min = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    aa_max = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    ra_min = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    ra_max = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    nesz_min_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    nesz_max_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    # azimuth and range ambiguities
    aa_min_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    aa_max_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    ra_min_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan
    ra_max_B = np.zeros((lat_arr.size, lon_arr.size))+np.nan

    SARPerf = SARPerf_asc
    SARPerf_B = SARPerf_asc_B

    for i in range(lat_arr.size):
        for j in range(lon_arr.size):
            inc_angle_asc = asc_tl[i][j].theta_i
            # Takes only the number of different geometries
            angle_tmp = inc_angle_asc
            if len(angle_tmp) >0:
                nesz = []
                nesz_B = []
                aa = []
                ra = []
                aa_B = []
                ra_B = []
                for kk in range(len(angle_tmp)):
                    if np.min(SARPerf.theta) < angle_tmp[kk]:
                        pos = np.argwhere(SARPerf.theta <= angle_tmp[kk])
                        ind1 = pos[-1]
                        pos = np.argwhere(SARPerf_B.theta <= angle_tmp[kk])
                        ind2 = pos[-1]
                        nesz.append(SARPerf.sigma_ne[ind1[0], ind1[1]])
                        aa.append(SARPerf.AASR[ind1[0], ind1[1]])
                        ra.append(SARPerf.RASR[ind1[0], ind1[1]])
                        nesz_B.append(SARPerf_B.sigma_ne[ind2[0], ind2[1]])
                        aa_B.append(SARPerf_B.AASR[ind2[0], ind2[1]])
                        ra_B.append(SARPerf_B.RASR[ind2[0], ind2[1]])
                if len(nesz) > 0:
                    nesz_min[i, j] = np.min(nesz)
                    nesz_max[i, j] = np.max(nesz)
                    aa_min[i, j] = np.min(aa)
                    aa_max[i, j] = np.max(aa)
                    ra_min[i, j] = np.min(ra)
                    ra_max[i, j] = np.max(ra)
                if len(nesz_B) > 0:
                    nesz_min_B[i, j] = np.min(nesz_B)
                    nesz_max_B[i, j] = np.max(nesz_B)
                    aa_min_B[i, j] = np.min(aa_B)
                    aa_max_B[i, j] = np.max(aa_B)
                    ra_min_B[i, j] = np.min(ra_B)
                    ra_max_B[i, j] = np.max(ra_B)

    # Load the Sigma0 in [dB]
    # Warning: in the sigma0map: lat= (90,-90), lon= (-180,180)
    sigma0_map = load_sigma0(file_backscatt=file_backscatt, file_inc=file_inc,
                             lat=lat_arr[-1], lon=lon_arr[0],
                             lat_ext=lat_arr[-1]-lat_arr[0],
                             lon_ext=lon_arr[-1]-lon_arr[0])
    #  Interpolation over the lat lon map
    sigma0_map = zoom(sigma0_map, (lat_arr.size/sigma0_map.shape[0],
                      lon_arr.size/sigma0_map.shape[1]), order=1)

    # SNR computation
    SNR_max = db2lin(sigma0_map - np.flipud(nesz_min))
    SNR_min = db2lin(sigma0_map - np.flipud(nesz_max))

    SNR_max_B = db2lin(sigma0_map - np.flipud(nesz_min_B))
    SNR_min_B = db2lin(sigma0_map - np.flipud(nesz_max_B))
    # gamma_SNR computation
    gammaSnr_min = SNR_min/(1. + SNR_min)
    gammaSnr_max = SNR_max/(1. + SNR_max)
    gammaSnr_min_B = SNR_min_B/(1. + SNR_min_B)
    gammaSnr_max_B = SNR_max_B/(1. + SNR_max_B)
    # gamma_Combined (SNR, RASR and AASR) computation
    ra_min = np.flipud(ra_min)
    ra_max = np.flipud(ra_max)
    aa_min = np.flipud(aa_min)
    aa_max = np.flipud(aa_max)
    ra_min_B = np.flipud(ra_min_B)
    ra_max_B = np.flipud(ra_max_B)
    aa_min_B = np.flipud(aa_min_B)
    aa_max_B = np.flipud(aa_max_B)

    den1_m = np.sqrt(1 + SNR_min**(-1) + ra_min + aa_min)
    den2_m = np.sqrt(1 + SNR_min_B**(-1) + ra_min_B + aa_min_B)
    den1_M = np.sqrt(1 + SNR_max**(-1) + ra_max + aa_max)
    den2_M = np.sqrt(1 + SNR_max_B**(-1) + ra_max_B + aa_max_B)

    gammaComb_max = 1./(den1_m*den2_m)
    gammaComb_min = 1./(den1_M*den2_M)

    # save the data
    np.save(path+'/gammaSnr_min', (gammaSnr_min))
    np.save(path+'/gammaSnr_max', (gammaSnr_max))
    np.save(path+'/gammaSnr_min_B', (gammaSnr_min_B))
    np.save(path+'/gammaSnr_max_B', (gammaSnr_max_B))
    np.save(path+'/gammaComb_min', (gammaComb_min))
    np.save(path+'/gammaComb_max', (gammaComb_max))
    rat.srat(path+'/gammaSnr_min.rat', (gammaSnr_min))
    rat.srat(path+'/gammaSnr_max.rat', (gammaSnr_max))
    rat.srat(path+'/gammaSnr_min_B.rat', (gammaSnr_min_B))
    rat.srat(path+'/gammaSnr_max_B.rat', (gammaSnr_max_B))
    rat.srat(path+'/gammaComb.rat', (gammaComb_min))
    rat.srat(path+'/gammaComb.rat', (gammaComb_max))
    rat.srat(path+'/lat_array.rat', lat_arr)
    rat.srat(path+'/lon_array.rat', lon_arr)

    # do the plots
    # gamma snr
    # system1
    do_plots(path, lat_arr, lon_arr, gammaSnr_min,
             title='Minimum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_min', vmin=0.5, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_max,
             title='Maximum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_max', vmin=0.5, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_min,
             title='Minimum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_min_Fullscale', vmin=0.0, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_max,
             title='Maximum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_max_Fullscale', vmin=0.0, vmax=1)

    # system2
    do_plots(path, lat_arr, lon_arr, gammaSnr_min_B,
             title='Minimum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_min_B', vmin=0.5, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_max_B,
             title='Maximum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_max_B', vmin=0.5, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_min_B,
             title='Minimum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_min_B_Fullscale', vmin=0.0, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaSnr_max_B,
             title='Maximum Coherence related to Signal-to-Noise Ratio',
             name='gammaSnr_max_B_Fullscale', vmin=0.0, vmax=1)

    # snr and ambiguities (of the two systems)
    do_plots(path, lat_arr, lon_arr, gammaComb_max,
             title='Coherence related to SNR and ambiguities',
             name='gammaComb_max', vmin=0.0, vmax=1)
    do_plots(path, lat_arr, lon_arr, gammaComb_min,
             title='Maximum Coherence related to SNR and ambiguities',
             name='gammaComb_min', vmin=0.0, vmax=1)


def get_gamma_vol_map(path, system, param_File, asc_tl, desc_tl, lat_arr,
                      lon_arr):
    """ Function to retrieve the gamma_SNR
        :param system: name of the system (is saocom, only ascending)
        :type system: string
        :param file_backscatt: name of the file of the backscattering map
        :type file_backscatt: string
        :param file_inc: name of the file of the local incidence angle
        :type file_inc: float
        :param asc_tl: array of ascending acquisition information (angles, ...)
        :type asc_tl: numpy.ndarray
        :param desc_tl: array of descending acquisition information
        :type desc_tl:  numpy.ndarray
        :param lat_arr: array of the latitude values
        :type lat_arr: array
        :param lon_arr: array of the longitude values
        :type lon_arr: array
        :param SARPerf_asc: sar performance in ascending mode
        :type SARPerf_asc: named tuple
        :param SARPerf_desc: sar performance in descending mode
        :type SARPerf_desc: named tuple
        :param SARPerf_asc_B: sar performance in ascending mode (Bistatic)
        :type SARPerf_asc_B: named tuple
        :param SARPerf_desc_B: sar performance in descending mode (Bistatic)
        :type SARPerf_desc_B: named tuple
        :param path: path to save the results
        :type path: string
        :returns:  gamma_snr and gamma_snr+ambiguities maps
    """

    lat_0 = lat_arr[0]
    lat_1 = lat_arr[-1]
    lon_0 = lon_arr[0]
    lon_1 = lon_arr[-1]

    # load forest height map
    text = 'Open Forest Height Map '
    if lat_arr[1]-lat_arr[0] == 1:
        Tk().withdraw()
        forest_file = filedial.askopenfilename(title=text + '1 deg')
        forest_file = '/home/zonn_ma/Data/forest_height_1deg.p'
        forest_h = (pickle.load(open(forest_file, 'rb')))
        for_lats = np.arange(-90, 90)
        for_lons = np.arange(-180, 180)
    else:
        Tk().withdraw()
        forest_file = filedial.askopenfilename(title=text + '0.5 deg')
        forest_file = '/home/zonn_ma/Data/forest_height_0_5deg.p'
        forest_h = (pickle.load(open(forest_file, 'rb')))
        for_lats = np.arange(-90, 90, 0.5)
        for_lons = np.arange(-180, 180, 0.5)

    # define for the forest map the same area of the region of interest
    lat_ind = np.array(np.where(np.logical_and(for_lats >= lat_0,
                                               for_lats <= lat_1)))
    lon_ind = np.array(np.where(np.logical_and(for_lons >= lon_0,
                                               for_lons <= lon_1)))

    forest_h = forest_h[lat_ind.flatten()[0]:lat_ind.flatten()[-1]+1,
                        lon_ind.flatten()[0]:lon_ind.flatten()[-1]+1]

    # interpolation on the finer lat lon grid
    forest_h = zoom(forest_h, (lat_arr.size/forest_h.shape[0],
                    lon_arr.size/forest_h.shape[1]), order=1)

    # generate the orbit
    f = tl.FormationTimeline(param_File)
    repeat = int(f.track.repeat_cycle)
    Tot_time = 81
    cycles = np.arange(0, Tot_time, repeat)

    # Extinsion coefficient
    height_val = np.array([0, 20, 40])
    alpha_val = np.array([0, 0.1, 1.])  # [dB]
    interp = interp1d(height_val, alpha_val, kind='linear')

    # the lat_interv of the returned kz_map is fixed and is:
    lat_interv = np.arange(-90, 91, 1)
    # index for the lat interval in the region of interest
    lat_ind = (np.array(np.where(np.logical_and(lat_interv >= lat_0,
                                                lat_interv <= lat_1)))).flatten()

    gamma_vol = np.zeros((lat_arr.size, lon_arr.size, cycles.size))+np.nan
    kz_map = np.zeros((lat_arr.size, lon_arr.size, cycles.size))
    for i in range(lat_arr.size):
        print(i)
        for j in range(lon_arr.size):
            inc_angle_asc = asc_tl[i][j].theta_i
            inc_angle_desc = desc_tl[i][j].theta_i
            # Takes only the number of different geometries
            inc_angle_asc = np.unique(inc_angle_asc)
            inc_angle_desc = np.unique(inc_angle_desc)
            if system == 'saocom':
                angle_tmp = inc_angle_asc
            else:
                angle_tmp = np.hstack((inc_angle_asc, inc_angle_desc))
            # get the kz
            if len(angle_tmp) > 0:
                kz_ = f.get_kz(angle_tmp[0], ascending=True)
                # take the lats range of interest
                kz_ = kz_[lat_ind[0]:lat_ind[-1]+1, :]
                # interpolation over the same grid of lat_array
                kz_ = zoom(kz_, (lat_arr.size/kz_.shape[0], 1), order=1)

                # coherence model
                z = np.arange(0, forest_h[i, j]+0.1, 0.5)
                # extinsion coefficient
                alpha = interp(forest_h[i, j])/8.68   # from dB to Nepers
                # volume backscattering profile
                vb = np.exp((-2*alpha*z)/(np.cos(angle_tmp[0])))
                for k in range(cycles.size):
                    kz = kz_[i, cycles[k]]
                    gamma_vol[i, j, k] = np.abs(np.sum(vb*np.exp(1j*kz*z)) /
                                                np.sum(vb))
                    kz_map[i, j, k] = kz

    for k in range(cycles.size):
        do_plots(path, lat_arr, lon_arr, np.flipud(gamma_vol[:, :, k]),
                 title='Volumetric coherence', name=('gammaVol_cyc' + str(k)),
                 vmin=0, vmax=1)
        np.save(path+'/gammaVol_cyc'+str(k), np.flipud(gamma_vol[:, :, k]))
        np.save(path+'/kz_map_cyc'+str(k), kz_map[:, :, k])
        rat.srat(path + '/gammaVol_cyc' + str(k) + 'rat',
                 np.flipud(gamma_vol[:, :, k]))
        rat.srat(path+'/kz_map_cyc'+str(k)+'.rat', kz_map[:, :, k])


def do_plots(path, lat_arr, lon_arr, gamma_map, title, name, vmin=0, vmax=1):

    # Read latitudes and longitudes
    lat_min = np.min(lat_arr)
    lat_max = np.max(lat_arr)
    lon_min = np.min(lon_arr)
    lon_max = np.max(lon_arr)

    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)

    yticks = np.arange(lat_min, lat_max+1, 20)
    xticks = np.arange(lon_min, lon_max+1, 40)

    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    Map = np.flipud(gamma_map)
    Masked_Map = np.ma.array(Map, mask=np.isnan(Map))
    gamma_map_new = maskoceans(lon, lat, Masked_Map)
    cmap = plt.cm.Greys
    cmap.set_bad(color='w', alpha=1.)
    imag1 = m.pcolormesh(lon, lat, gamma_map_new, cmap=cmap, vmin=vmin,
                         vmax=vmax, latlon=True)
    m.drawmapboundary(fill_color='white')
#    m.drawparallels(np.arange(-90., 91., 10.))
#    m.drawmeridians(np.arange(-180., 181., 10.))
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    # add colorbar
    plt.colorbar(shrink=1, aspect=15, fraction=.12, pad=.02)
    plt.title(title)
    plt.show()
    plt.savefig(path + name + '.png')
