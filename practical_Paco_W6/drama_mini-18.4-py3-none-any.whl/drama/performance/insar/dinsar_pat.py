import os
import pickle
import sys
import time
from collections import namedtuple
from tkinter import Tk
from tkinter import filedialog as filedial

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.basemap import Basemap, maskoceans
from scipy.interpolate import griddata
from scipy.io import readsav
from scipy.ndimage.interpolation import zoom

import drama.mission.timeline as tl
from drama import constants as const
from drama.geo.sar.geometry import inc_to_look
from drama.io import cfg
from drama.io.cli import ProgressBar
from drama.performance.insar.coh_maps import get_coher_maps
from drama.performance.sar.system import load_mod_perf
from drama.utils.misc import db2lin
from drama.utils.read_backscattering import load_sigma0

font = {'family': 'normal',
        'weight': 'bold',
        'size'  : 16}


def atmosph_std(zpd_image_file, look_near, look_far, lat_max, lon_max,
                orbit_alt):

    """ Function to retrieve the total atmosphere (troposphere):
        fixed contribution plus a regional dependent contribution

        :param look_near: Minimum look angle
        :type look_near: float
        :param look_far: Maximum look angle
        :type look_far: float
        :param lat_max: Maximum (absolute) value of the considered latitude
        :type lat_max: float
        :param lon_max: Maximum (absolute) value of the considered longitude
        :type lon_max: float
        :param orbit_alt:Orbit altitude
        :type orbit_alt: float
        :returns: troposphere total standard deviation

    """

    # Load the ZPD map
    zpd_image = np.load(zpd_image_file)

    latstart = 90-lat_max
    lonstart = 180-lon_max
    zpd = zpd_image[latstart:181-latstart, lonstart:361-lonstart]  # [cm]

    # Transformation from the zenith path delay into the Slant path delay
    atm_alt = 6e3
    theta_near = np.arcsin(np.sin(look_near) * (const.r_earth + orbit_alt) /
                           (const.r_earth + atm_alt))
    theta_far = np.arcsin(np.sin(look_far) * (const.r_earth + orbit_alt) /
                          (const.r_earth + atm_alt))

    project = 8*((np.cos(theta_near) - np.cos(theta_far)) /
                 (np.cos(theta_near) * np.cos(theta_far)))**2
    # term related to the turbolence
    turb = (zpd**2*project)  # [cm**2]

    # fixed contribution
    fix = 4.  # [cm**2]
    tot = (fix + turb) / 2. # cm**2
    tot = (np.sqrt(tot)) / 100.   # [meters]
    return tot


def hcrb(acqTime, nLooks, lambdaa, sigmaAtm, SNR, tau=40., gamma0=0.95,
         gammaInf=0.15):

    """ Function for calculating the performance of DINSAR with a stack of
        images using the hybrid Cramer-Rao bound.

        :param acqTime: Acquistion time vector.
        :type acqTime:  1-D float array
        :param nLooks: Number of looks.
        :type nLooks: float
        :param lambdaa: Wavelenght (m).
        :type lambdaa: float
        :param sigmaAtm: Different standard deviations of the APS (rad).
        :type sigmaAtm: 1-D float array
        :param SNR: Signal-to-noise ratio (linear).
        :type SNR: float
        :param tau: Decorrelation time (days). Optional.
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: float
        :returns: standard deviation

    """
    rTemp = np.exp(-1./tau)     # Default: tau = 40 days

    # Some variables
    nAcq = np.size(acqTime)
    nAtm = np.size(sigmaAtm)

    gammaSnr = SNR/(1. + SNR)

    # Hybrid Cramer-Rao bound
    m1 = np.outer(acqTime, np.ones(nAcq))

#    gamma = (gammaSnr*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))
#             + gammaInf) + (1.-gammaSnr*gamma0)*np.eye(nAcq))
    gamma = (gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))+gammaInf
    theta = 4.*np.pi/lambdaa*np.transpose(m1[:, 0])
    X = 2.*nLooks*(gamma*np.linalg.inv(gamma)-np.eye(nAcq))
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])

    sigma = np.zeros(nAtm)

    for mm in range(nAtm):
        Vww = sigmaAtm[mm]**2.*np.eye(nAcq)
        kk4 = X + np.linalg.inv(Vww)
        tmp1 = np.hstack((kk1, kk2))
        tmp2 = np.hstack((kk3, kk4))
        kk = np.vstack((tmp1, tmp2))
        kk = np.linalg.inv(kk)
        sigma[mm] = np.sqrt(kk[0, 0])*365.*1000.   # mm/year

    return sigma


def hcrb_az(acqTime, nLooks, lambdaa, SNR, sigmaAz, azRes, tau=40.,
            gamma0=0.95, gammaInf=0.15):

    """ Function for calculating the performance of DINSAR with a stack of
        images using the hybrid Cramer-Rao bound (in azimuth direction).
        :param acqTime: Acquistion time vector.
        :type acqTime:  1-D float array
        :param nLooks: Number of looks.
        :type nLooks: float
        :param lambdaa: Wavelenght (m).
        :type lambdaa: float
        :param SNR: Signal-to-noise ratio (linear).
        :type SNR: float
        :param azRes: Azimuth resolution (m).
        :type azRes: float
        :param tau: Decorrelation time (days). Optional.
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: float

        :returns: standard deviation

    """
    rTemp = np.exp(-1./tau)     # Default: tau = 40 days

    # Some variables
    nAcq = np.size(acqTime)

    gammaSnr = SNR/(1. + SNR)

    # Hybrid Cramer-Rao bound
    m1 = np.outer(acqTime, np.ones(nAcq))

#    gamma = (gammaSnr*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))
#             + gammaInf)+(1.-gammaSnr*gamma0)*np.eye(nAcq))
    gamma = (gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1)))+gammaInf

    cte = nLooks*2./3.*np.pi**2.
    FIM_az = cte*(acqTime.dot(gamma*np.linalg.inv(gamma) -
                  np.eye(nAcq)).dot(np.transpose(acqTime)))

    sigmaAz = np.sqrt(1./FIM_az)
    sigma = azRes*sigmaAz*365.*1000.   # mm/year

    return sigma


def get_3d_accuracy(elos, stddev, option):
    """ Function for calculating the accuracy of the 3D vector.

        :param elos: Line-of-sight vectors, where (x,y,z)=(East,North,Up).
        :type elos: 2-D float array
        :param theta_nearstddev: Standard deviations of the LoS measurements.
        :type stddev: 1-D float array
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer
    """

    nTracks = np.size(stddev)

    # Building covariance matrix
    weights = np.zeros([nTracks, nTracks])
    for mm in range(np.size(stddev)):
        weights[mm, mm] = 1./(stddev[mm]**2.)

    # Options
    if option == 1:
        # Constraining motion only in the up-down direction
        # x is East, y is North, z is Up
        elos_ = elos[:, 2]
        variance3d = 1./(elos_.dot(weights).dot(elos_[:, np.newaxis]))

        aux = np.ones((3, 3))*1.e6
        aux[2, 2] = variance3d

        variance3d = np.copy(aux)

    elif option == 2:
        # Constrining motion only in the east-west, up-down plane
        # x is East, y is North, z is Up
        aux = np.copy(elos)
        aux[:, 1] = aux[:, 2]
        elos_ = aux[:, 0:2]
        variance3d = np.linalg.inv(np.transpose(elos_).dot(weights).dot(elos_))

        aux = np.ones((3, 3))*1.e6
        aux[0, 0] = variance3d[0, 0]
        aux[2, 0] = variance3d[1, 0]
        aux[2, 2] = variance3d[1, 1]
        aux[0, 2] = variance3d[0, 1]

        variance3d = np.copy(aux)

    elif option == 3:
        matrix = np.transpose(elos).dot(weights).dot(elos)
        if np.linalg.cond(matrix) < 1/sys.float_info.epsilon:
            # No constrains: obtaining full 3D vector
            # x is East, y is North, z is Up
            variance3d = np.linalg.inv(matrix)
        else:
            print('Singular matrix, SVD inversion ')
            variance3d = np.zeros((3, 3))+np.nan
            # SVD inversion of observation matrix
            # x is East, y is North, z is Up
            A = np.transpose(elos).dot(weights).dot(elos)
            U, s, V = np.linalg.svd(A)
            poszero = np.where(s < 0.002)
            diag = np.zeros((3, 3))
            for ix in range(3):
                if s[ix] != 0.0:
                    diag[ix, ix] = 1./s[ix]
            if np.size(poszero) > 0:
                diag[poszero, poszero] = 0.0

            variance3d = V.dot(diag).dot(np.transpose(U))

            if np.size(poszero) > 0:
                variance3d[1, 1] = 1.e6

    return variance3d


def dinsar_perf_tool(system, Atm, nImages,  SARPerf_asc, SARPerf_desc,
                     acqArray, option, SARPerf_2=None, inc_angle_B=None,
                     azCorr=1, deltax=100., deltagr=100., sigma0=-15., tau=60.,
                     gamma0=0.95, gammaInf=0.15):

    """ Function for calculating the D-InSAR performance analysis.

        :param system: name of the system
        :type system: string
        :param Atm: Atmosphere standard deviation
        :type Atm:  float
        :param SARPerf: SAR performance parameters.
        :type SARPerf: named tuple
        :param acqArray: Array containing information about the acquisitions.
        :type acqArray: named tuple
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer
        :param azCorr: If azCorr=1, azimuth correction is performed.
        :type azCorr: integer
        :param deltax: Posting requirement in along-track.
        :type deltax: float
        :param deltagr: Posting requirement in ground-range.
        :type deltagr: float
        :param sigma0: Normalized sigma zero of distributed scatterer
                       (or equivalent RCS of point-like targets) (dB).
        :type sigma0 : float
        :param tau: Decorrelation time (days). Optional.
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: floatdeform_EW

        :returns: named tuple with information the standard deviation of the
                  LoS measurements (mm/year) and the covariance matrix of the
                  3D vector (mm**2/year**2).
    """

    # Some constants
#    hsar = SARPerf_asc.h
    freq = SARPerf_asc.f0
    c0 = const.c
    lambdaa = c0/freq

    # Number of subswaths
    subswaths = len(SARPerf_asc.theta)

    # Number of different geometries
    nTracks = (acqArray.inc_angle).size

    # Obtaining the HCRB for every track configuartion

    # APS stddev [rad]
    sigmaAtm = np.array([4.*np.pi/lambdaa*Atm])
    nAtm = np.size(sigmaAtm)

    # Initializing output values
    stddev = np.zeros([nAtm, nTracks*(azCorr+1)])  # LOS stddev
    variance3d = np.zeros([3, 3, nAtm])+np.nan     # Cov matrix of the 3D vect
    elos = np.zeros([nTracks*(azCorr+1), 3])       # LOS vectors
    looks = np.zeros([nTracks])                    # Number of looks

    # for the bistatic case
    if inc_angle_B:
        nTracks_mono = acqArray.Nasc + acqArray.Ndesc
        nTracks_mono_B = acqArray.Nasc_B + acqArray.Ndesc_B
    else:
        nTracks_mono = nTracks

    for mm in range(nTracks_mono):
        # Obtaining LOS vector
        inc_angle = acqArray.inc_angle[mm]  # rad
        northing = acqArray.northing[mm]    # rad

        # x is east, y is north and z is up
        los = np.array([np.sin(inc_angle)*np.sin(northing),
                        -np.sin(inc_angle)*np.cos(northing),
                        np.cos(inc_angle)])
        los = -los/np.sqrt(np.sum(los**2.))     # Normalizing
        elos[mm, :] = los                       # From satellite to ground
        if azCorr == 1:
            los_az_corr = np.array([los[1], -los[0], 0.0])
            los_az_corr = los_az_corr/np.sqrt(np.sum(los_az_corr**2.))
            elos[mm+nTracks, :] = los_az_corr  # The orthogonal versor

        if acqArray.Mode[mm] == 'B1': # deformation ascending
            SARPerf = SARPerf_asc
        elif acqArray.Mode[mm] == 'A1': # mode A1 deformation descending
            SARPerf = SARPerf_desc
        else:
            SARPerf = SARPerf_2  # mode B4: global basemap
        # Computing number of looks
        if subswaths > 1:
            positions = np.argwhere(SARPerf.theta <= inc_angle)
            ind = positions[-1]
            bw = SARPerf.Brg[ind[0]]
            azRes = 7.  # np.mean(SARPerf.az_res[ind[0]])  # saocom = 5
            nesz = SARPerf.sigma_ne[ind[0], ind[1]]
        else:
            positions = np.argwhere(SARPerf.theta <= inc_angle)
            ind = positions[-1]
            bw = SARPerf.Brg
            azRes = np.mean(SARPerf.az_res)
            nesz = SARPerf.sigma_ne[ind[0]]
        rgRes = c0/2./bw
        grRes = rgRes / np.cos(inc_angle)
        looks[mm] = (deltax/azRes)*(deltagr/grRes)
        # Time vector
        tAcq = list(acqArray.acqtime)
        # if empty it must be defined
        # otherwise it has been extracted from the timeline information
        if len(tAcq) == 0:
            tAcq = np.arange(nImages)*SARPerf.repeat
        else:
            tAcq = np.array(tAcq)
        # Computing SNR
        SNR = db2lin(sigma0-nesz)

        # Obtaining the hybrid Cramer-Rao bound
        stddev[:, mm] = hcrb(tAcq, looks[mm], lambdaa, sigmaAtm, SNR,
                             tau, gamma0, gammaInf)
        sigmaAz = 0
        if azCorr == 1:
            stddev[:, mm+nTracks] = hcrb_az(tAcq, looks[mm], lambdaa,
                                            SNR, sigmaAz, azRes, tau, gamma0,
                                            gammaInf)
    if inc_angle_B:
        for mm in range(nTracks_mono_B):
            # Obtaining LOS vector
            inc_angle = acqArray.inc_angle[mm+nTracks_mono]  # rad
            northing = acqArray.northing[mm+nTracks_mono]    # rad

            # x is east, y is north and z is up
            los = np.array([np.sin(inc_angle)*np.sin(northing),
                            -np.sin(inc_angle)*np.cos(northing),
                            np.cos(inc_angle)])
            los = -los/np.sqrt(np.sum(los**2.))  # Normalizing
            elos[mm+nTracks_mono, :] = los       # From satellite to ground
            if azCorr == 1:
                los_az_corr = np.array([los[1], -los[0], 0.0])
                los_az_corr = los_az_corr/np.sqrt(np.sum(los_az_corr**2.))
                elos[mm+nTracks_mono+nTracks, :] = los_az_corr  # orthog versor

            # Computing number of looks
            if subswaths > 1:
                if mm <= nTracks_mono:
                    positions = np.argwhere(SARPerf_asc.theta <=
                                            acqArray.inc_angle[mm])
                    ind = positions[-1]
                    bw = SARPerf_asc.Brg[ind[0]]
                    rgRes = c0/2./bw
                    grRes = rgRes / np.cos(acqArray.inc_angle[mm])
                    azRes = 5.  # saocom
                else:
                    if inc_angle < np.radians(inc_angle_B[0]+(inc_angle_B[1] -
                                                              inc_angle_B[0])/2):
                        bw = SARPerf_asc.Brg[0]
                    else:
                        bw = SARPerf_asc.Brg[1]
                    rgRes = c0/2./bw
                    grRes = rgRes / np.cos(np.max(SARPerf_asc.theta))
            else:
                positions = np.argwhere(SARPerf_asc.theta <= inc_angle)
                ind = positions[-1]
                bw = SARPerf_asc.Brg
                azRes = np.mean(SARPerf_asc.az_res)
                nesz = SARPerf_asc.sigma_ne[ind[0]]

            looks[mm+nTracks_mono] = (deltax/azRes)*(deltagr/grRes)
            # azRes = np.mean(SARPerf_asc.az_res[ind[0]])
            nesz = SARPerf_asc.sigma_ne[ind[0], ind[1]]
            # Time vector
            tAcq = list(acqArray.acqtime)
            # if empty it must be defined
            # otherwise it has been extracted from the timeline information
            if len(tAcq) == 0:
                tAcq = np.arange(nImages)*SARPerf_asc.repeat
            else:
                tAcq = np.array(tAcq)
            # Computing SNR
            SNR = db2lin(sigma0-nesz)

            # Obtaining the hybrid Cramer-Rao bound
            stddev[:, mm+nTracks_mono] = hcrb(tAcq, looks[mm+nTracks_mono],
                                              lambdaa, sigmaAtm, SNR, tau,
                                              gamma0, gammaInf)
            sigmaAz = 0
            if azCorr == 1:
                stddev[:, mm+nTracks_mono+nTracks] = hcrb_az(tAcq,
                                                             looks[mm+nTracks_mono],
                                                             lambdaa, SNR,
                                                             sigmaAz, azRes,
                                                             tau, gamma0,
                                                             gammaInf)
    # Obtaining 3D deformation accuracy
    for nn in range(nAtm):
        variance3d[:, :, nn] = get_3d_accuracy(elos, stddev[nn, :], option)

    # Creating returned tuple
    tuple_res = namedtuple('DINSAR_PAT_OUT', ['stddev', 'var3d'])
    result = tuple_res(stddev, variance3d)

    return result


def dinsar_pat_main(MainPath, system, option=2, Coh_Map_Flag=True,
                    bistatic=False, tomo=False, plot_check=False):

    """ Main program of the D-InSAR performance analysis tool.

        :param system: Name of the system. Available: 'HRWS' and 'Sentinel'.
        :type system: string
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer
        :param Coh_Map_Flag: Flag to generate and save coherence maps
        :type Coh_Map_Flag: boolean
        :param bistatic: Flag for selecting the bistatic mode
        :type bistatic: boolean
        :param tomo: Flag for selecting the tomo mode
        :type tomo: boolean
        :param plot_check: Flag for checking the coverage plots
        :type plot_check: boolean

        :returns: deformation information in a 2-D matrix

    """

    # Open parameter file to derive user inputs
    main_dir = os.path.abspath('../..')
    if system == 'TandemL':
        more_modes = True
        # Parameter File
        Tk().withdraw()
        param_File = filedial.askopenfilename(title='Select parameter file')
        # TAP File
        Tk().withdraw()
        tap_File = filedial.askopenfilename(title='Select TAP file')
        # SAR performance
        perf_fileName = 'Tandem-L.sav'
        param_File2 = main_dir+'/performance/sar/sensors/'+system+'.cfg'
        perf_File = main_dir+'/coverage/params/'+perf_fileName
        modeId = ['A1', 'B1',  'B4']
        out_asc = load_mod_perf(systemName=system, par_fileName=param_File2,
                                perf_fileName=perf_File, mode=modeId[1])

        if more_modes:
            out_desc = out_asc
        out_desc = load_mod_perf(systemName=system, par_fileName=param_File2,
                                 perf_fileName=perf_File, mode=modeId[1])
        out_mode2 = load_mod_perf(systemName=system, par_fileName=param_File2,
                                 perf_fileName=perf_File, mode=modeId[2])

        # ! it's modeId[0] for descending but now use this because the
        # sar_performance file is complete only for B1 mode
        # some flags
        ext_orbit = True
        timeline = False
        bistatic = False
        # Atmosphere image
        Tk().withdraw()
        zpd_image_file = filedial.askopenfilename(title='Open the zpd image')
        Tk().withdraw()
        text = 'Open the deformation image'
        deform_map_file = filedial.askopenfilename(title=text)
    elif system == 'saocom':
        perf_fileName = 'SAOCOM_Mono_v1.sav'
        # Monostatic
        # Parameter File
        Tk().withdraw()
        param_File = filedial.askopenfilename(title='Select parameter file')
        # SAR performance
        modeId = np.array([1, 2])
        perf_File = main_dir+'/coverage/params/saocom/'+perf_fileName
        out_asc = load_mod_perf(systemName=system, par_fileName=param_File,
                                perf_fileName=perf_File, polarization='VV',
                                mode=modeId[1])
        out_desc = out_asc
        # Bistatic performance
        if tomo:
            # Performance filename
            perf_fileName2 = 'SAOCOM_CS_Tomo2_v2.sav'
            modeId = np.array([4, 14])    # 4: quadpo, 14: dualpol
        if bistatic:
            text = 'Select Bistatic parameter fiarrayle'
            Tk().withdraw()
            param_File_Bist = filedial.askopenfilename(title=text)
            # Performance filename
            perf_fileName2 = 'SAOCOM_CS_BiStatic_v1.sav'
            modeId = np.array([5, 15])    # 5: quadpo, 15: dualpol

        perf_File2 = main_dir+'/coverage/params/saocom/'+perf_fileName2
        out_asc_B = load_mod_perf(systemName=system, par_fileName=param_File,
                                  perf_fileName=perf_File2, polarization='VV',
                                  mode=modeId[1])
        out_desc_B = out_asc_B
        ext_orbit = False
        timeline = False

    else:
        Tk().withdraw()
        param_File = filedial.askopenfilename()
        # Read SAR performance
        # they are the same for ascending and descending
        out_asc = load_mod_perf(main_dir, fileName=perfFile, system=system,
                                mode=modeId, polarization='VV')
        out_desc = out_asc

    # Read the parameters from the input file
    inData = cfg.ConfigFile(param_File)

    # backscattering map patharray
    file_backscatt = inData.path.file_backscatt
    file_inc = inData.path.file_inc

    deltax = inData.misc.deltax    # Posting requirement in along-track [m]
    deltagr = inData.misc.deltagr  # Posting requirement in ground-range [m]
#    sigma0 = inData.misc.sigma0   # Normalized sigma0 of distributed scatterer
    totalTime = inData.orbit.timeduration  # Total time of acquisitions (days)

    # Inputs to the decorrelation model:
    tau = inData.misc.tau            # Decorrelation time (days)
    gamma0 = inData.misc.gamma0      # Coherence at time = 0
    gammaInf = inData.misc.gammaInf  # Coherence at time = inf

    # Lat - lon grid of the points of which the deformation has to be computed
    lat_min = inData.misc.lat_min    # Minimum latitude (deg)
    lat_max = inData.misc.lat_max    # Maximum latitude (deg)
    lat_res = inData.misc.lat_res    # Latitude resolution (deg)
    lon_min = inData.misc.lon_min    # Minimum longitude (deg)
    lon_max = inData.misc.lon_max    # Maximum longitude (deg)
    lon_res = inData.misc.lon_res    # Longitude resolution (deg)

    lat_arr = np.arange(lat_min, lat_max+lat_res, lat_res)
    lon_arr = np.arange(lon_min, lon_max+lon_res, lon_res)

    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)

    # Ratio of valid incidence angles (according to swath)
    min_ = np.rad2deg(np.min(out_asc.theta))
    max_ = np.rad2deg(np.max(out_asc.theta))
    inc_range = [np.abs(min_), np.abs(max_)]
    # For TANDEM-L two acquisition modes (in asc and desc) for the deformation
    # (A1 and B1), the angles are the same. But if different, it is necessary
    # to take this into account later
    if more_modes:
        min__ = 27     # np.rad2deg(np.min(out_mode2.theta))
        max__ = 38.26  # np.rad2deg(np.max(out_mode2.theta))
        inc_range2 = [np.abs(min__), np.abs(max__)]  # mode B4 tandem L

    # acquisition timeline
    if bistatic:
        f = tl.FormationTimeline(param_File_Bist)
        tl1 = tl.LatLonTimeline(par_file=param_File,
                                lats=lat, lons=lon, inc_angle_range=inc_range,
                                ext_orbit=ext_orbit, bistatic=bistatic,
                                form=f)
        min_ang = np.degrees(np.min(tl1.track2.swathData.incident))
        max_ang = np.degrees(np.max(tl1.track2.swathData.incident))
        inc_angle_B = np.array([(min_ang)-1, (max_ang)+1])
    elif more_modes:
        tl1 = tl.LatLonTimeline(par_file=param_File, lats=lat, lons=lon,
                                inc_angle_range=inc_range, ext_orbit=ext_orbit)
        tl2 = tl.LatLonTimeline(par_file=param_File, lats=lat, lons=lon,
                                inc_angle_range=inc_range2,
                                ext_orbit=ext_orbit)
    else:
        tl1 = tl.LatLonTimeline(par_file=param_File, lats=lat, lons=lon,
                                inc_angle_range=inc_range, ext_orbit=ext_orbit)

    # if it's available the TAP then it merge the information
    if timeline:
        # consider the bistatic case also here
        tl1.load_TAP(filename=tap_File, application='Deformation')
        tl1.TAP_merge()
        asc_tl = tl1.asc_TAP_timeline
        desc_tl = tl1.desc_TAP_timeline
        if more_modes:
            tl2.load_TAP(filename=tap_File, application='Global')
            tl2.TAP_merge()
            asc_tl2 = tl2.asc_TAP_timeline
            desc_tl2 = tl2.desc_TAP_timeline
    else:
        if bistatic:
            asc_tl = tl1.asc_acqs
            desc_tl = tl1.desc_acqs
            asc_tl_2 = tl1.asc_acqs2
            desc_tl_2 = tl1.desc_acqs2
        else:
            asc_tl = tl1.asc_acqs
            desc_tl = tl1.desc_acqs

    if plot_check:
        plot_ch(lon, lat, lat_arr, lon_arr, tl1, timeline)

    if Coh_Map_Flag:
        # IF lat and lon are passed as argument of the function keep in mind:
        # long = [-180:180] (from left to right)
        # lat = [90:-90] (from top to bottom)
        get_coher_maps(system, param_File, file_backscatt, file_inc, lat_arr,
                       lon_arr, out_asc, out_desc, out_asc_B, out_desc_B,
                       asc_tl, desc_tl, MainPath)

    # Load the Sigma0 in [dB]
    # Warning: in the sigma0map: lat= (90,-90), lon= (-180,180)
    sigma0_map = load_sigma0(file_backscatt=file_backscatt, file_inc=file_inc,
                             lat=lat_arr[-1], lon=lon_arr[0],
                             lat_ext=lat_arr[-1]-lat_arr[0],
                             lon_ext=lon_arr[-1]-lon_arr[0])
    sigma0_map = zoom(sigma0_map, (lat_arr.size/sigma0_map.shape[0],
                      lon_arr.size/sigma0_map.shape[1]), order=1)

    # Load Atmosphere map
    look_min = inc_to_look(np.deg2rad(min_), out_asc.h_sar)
    look_max = inc_to_look(np.deg2rad(max_), out_asc.h_sar)
    TotAtmStd = atmosph_std(zpd_image_file, look_min, look_max, lat_max,
                            lon_max, out_asc.h_sar)
    TotAtmStd = zoom(TotAtmStd, (lat_arr.size/TotAtmStd.shape[0],
                                 lon_arr.size/TotAtmStd.shape[1]), order=1)

    # Load deformation Map
    deformation_all = readsav(deform_map_file)
    def_mask = deformation_all.mask
    def_mask = np.where(def_mask > 0.0, 1.0, np.nan)
    def_mask = zoom(def_mask, (lat_arr.size/def_mask.shape[0],
                               lon_arr.size/def_mask.shape[1]), order=1)

    # inizialization
    # Easth - West deformattAcqion
    deform_EW = np.zeros((lat_arr.size, lon_arr.size))
    # Up - Down deformation
    deform_UD = np.zeros((lat_arr.size, lon_arr.size))
    # North -South deformation
    deform_NS = np.zeros((lat_arr.size, lon_arr.size))
    AcqArray_B = namedtuple('Acq_Info', ['inc_angle', 'northing', 'acqtime',
                                         'Nasc', 'Ndesc', 'Nasc_B', 'Ndesc_B'])
    AcqArray = namedtuple('Acq_Info', ['inc_angle', 'northing', 'acqtime',
                                       'Mode', 'Nasc', 'Ndesc'])
    count = 0
    bar = ProgressBar("Processing", lat_arr.size*lon_arr.size)
    nImages = np.floor(totalTime/out_asc.repeat)

    for i in range(lat_arr.size):
        for j in range(lon_arr.size):
            if def_mask[i, j] == 1:
                inc_angle_asc = asc_tl[i][j].theta_i
                northing_asc = asc_tl[i][j].northing
                inc_angle_desc = desc_tl[i][j].theta_i
                northing_desc = desc_tl[i][j].northing
                N_asc = inc_angle_asc.size
                N_desc = inc_angle_desc.size
                if bistatic:
                    inc_angle_asc_2 = asc_tl_2[i][j].theta_i
                    northing_asc_2 = asc_tl_2[i][j].northing
                    inc_angle_desc_2 = desc_tl_2[i][j].theta_i
                    northing_desc_2 = desc_tl_2[i][j].northing
                    N_asc_B = inc_angle_asc_2.size
                    N_desc_B = inc_angle_desc_2.size
                    inc_angle = np.hstack((inc_angle_asc, inc_angle_desc,
                                           inc_angle_asc_2, inc_angle_desc_2))
                    northing = np.hstack((northing_asc, northing_desc,
                                          northing_asc_2, northing_desc_2))
                elif more_modes:
                    inc_angle_asc2 = asc_tl2[i][j].theta_i
                    northing_asc2 = asc_tl2[i][j].northing
                    inc_angle_desc2 = desc_tl2[i][j].theta_i
                    northing_desc2 = desc_tl2[i][j].northing

                    inc_angle = np.hstack((inc_angle_asc, inc_angle_desc,
                                           inc_angle_asc2, inc_angle_desc2))
                    northing = np.hstack((northing_asc, northing_desc,
                                          northing_asc2, northing_desc2))
                    Mode = (modeId[1] * len(inc_angle_asc) +
                            modeId[0] * len(inc_angle_desc) +
                            modeId[2] * len(inc_angle_asc2) +
                            modeId[2] * len(inc_angle_desc2))
                else:
                    inc_angle = np.hstack((inc_angle_asc, inc_angle_desc))
                    northing = np.hstack((northing_asc, northing_desc))
                    Mode = (modeId[1] * len(inc_angle_asc) +
                            modeId[0]*len(inc_angle_desc))
                Mode = [Mode[i:i+2] for i in range(0, len(Mode), 2)]
                if timeline:
                    # Acquisition times ( in days (anyway float number) )
                    acqtime_asc = (asc_tl[i][j].acqtime)/(3600*24.)
                    acqtime_desc = (desc_tl[i][j].acqtime)/(3600*24.)
                    acqtime = np.hstack((acqtime_asc, acqtime_desc))
                    if more_modes:
                        acqtime_asc2 = (asc_tl2[i][j].acqtime) / (3600*24.)
                        acqtime_desc2 = (desc_tl2[i][j].acqtime) / (3600*24.)
                        acqtime = np.hstack((acqtime_asc, acqtime_desc,
                                              acqtime_asc2, acqtime_desc2))
                else:
                    acqtime = []

                if len(inc_angle) < option:
                    # Not enough geometries to calculate deformations errors
                    deform_EW[i, j] = np.nan
                    deform_UD[i, j] = np.nan
                    deform_NS[i, j] = np.nan
                else:
                    sigma0 = sigma0_map[i, j]
                    SigmaAtm = TotAtmStd[i, j]
                    if bistatic:
                        acqArray_B = AcqArray_B(inc_angle, northing, acqtime,
                                                N_asc, N_desc, N_asc_B, N_desc_B)
                        output = dinsar_perf_tool(system, SigmaAtm, nImages,
                                                  SARPerf_asc=out_asc,
                                                  SARPerf_desc=out_desc,
                                                  acqArray=acqArray_B,
                                                  option=option,
                                                  inc_angle_B=inc_angle_B,
                                                  azCorr=1, deltax=deltax,
                                                  deltagr=deltagr, sigma0=sigma0,
                                                  tau=tau, gamma0=gamma0,
                                                  gammaInf=gammaInf)
                    else:
                        acqArray = AcqArray(inc_angle, northing, acqtime, Mode,
                                            N_asc, N_desc)
                        output = dinsar_perf_tool(system, SigmaAtm, nImages,
                                                  SARPerf_asc=out_asc,
                                                  SARPerf_desc=out_desc,
                                                  SARPerf_2=out_mode2,
                                                  acqArray=acqArray,
                                                  option=option,
                                                  azCorr=1, deltax=deltax,
                                                  deltagr=deltagr,
                                                  sigma0=sigma0,
                                                  tau=tau, gamma0=gamma0,
                                                  gammaInf=gammaInf)
                    # the last zero is because I'm considering only one atmosph
                    # otherwise would be output.var3d[0, 0, 0:SigmaAtm.size]
                    deform_EW[i, j] = output.var3d[0, 0, 0]
                    deform_UD[i, j] = output.var3d[2, 2, 0]
                    deform_NS[i, j] = output.var3d[1, 1, 0]

                count = count + 1
                bar.update(count)
            print()

    Deformation = namedtuple('Deformation', ['deform_EW', 'deform_UD',
                                             'deform_NS', 'lat_arr',
                                             'lon_arr'])
    Deform = Deformation(deform_EW, deform_UD, deform_NS, lat_arr, lon_arr)

    filename = '/dinsar_performance_'+system+'_'+str(option)+'D.p'

    pickle.dump(Deform, open(MainPath+filename, 'wb'))

    return Deform


def get_dinsar_perf_map(system='saocom', option=3, Coh_Map_Flag=False,
                        bistatic=True, tomo=False, fill_gaps=True,
                        plot_check=False):

    """ Function for plotting the D-InSAR performance analysis.
        :param system: Name of the system. Available: 'HRWS' and 'Sentinel'.
        :type system: string
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer
        :param Coh_Map_Flag: Flag to generate and save coherence maps
        :type Coh_Map_Flag: boolean
        :param bistatic: Flag for selecting the bistatic mode
        :type bistatic: boolean
        :param tomo: Flag for selecting the tomo mode
        :type tomo: boolean
        :param fill_gaps: Flag for filling gaps in the coverage in the plots
        :type fill_gaps: boolean
        :param plot_check: Flag for checking the coverage plots
        :type plot_check: boolean
        :returns: plots
    """

    # Initial time
    start_time = time.time()
    MainPath = filedial.askdirectory(title='Open the main directory')
    Deform = dinsar_pat_main(MainPath, system='TandemL', option=2,
                             Coh_Map_Flag=False, bistatic=False, tomo=False,
                             plot_check=True)

    # Read latitudes and longitudes
    lat_arr = Deform.lat_arr
    lon_arr = Deform.lon_arr
    lat_min = np.min(lat_arr)
    lat_max = np.max(lat_arr)
    lon_min = np.min(lon_arr)
    lon_max = np.max(lon_arr)
    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)
    yticks = np.arange(lat_min, lat_max+1, 20)
    xticks = np.arange(lon_min, lon_max+1, 40)

    if fill_gaps:
        # East - West accuracy [mm/year]
        # select the point not NaN
        good_points = np.where(np.isfinite(Deform.deform_EW))
        # Do an interpolartion for the missing values
        lat_flat = lat[good_points].flatten()
        lat_flat = (lat_flat.reshape([1, lat_flat.size])).T
        lon_flat = lon[good_points].flatten()
        lon_flat = (lon_flat.reshape([1, lon_flat.size])).T
        grid_points = (np.hstack((lat_flat, lon_flat)))
        deform_flat = Deform.deform_EW[good_points].flatten()
        deform_flat = (deform_flat.reshape([1, deform_flat.size])).T
        deform = griddata(grid_points, deform_flat, (lat, lon),
                          method='linear')
        deform_EW = deform[:, :, 0]
    else:
        deform_EW = Deform.deform_EW

    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    Masked_deform_EW = np.ma.array(deform_EW, mask=np.isnan(deform_EW))
    deform1_im = maskoceans(lon, lat, Masked_deform_EW)
    cmap = plt.cm.OrRd
    cmap.set_bad(color='w', alpha=1.)
    imag1 = m.pcolormesh(lon, lat, deform1_im, shading='gouraud', cmap=cmap,
                         latlon=True, vmin=0., vmax=20)   # shading='flat'
    m.drawmapboundary(fill_color='white')
#    m.drawparallels(np.arange(-90., 91., 10.))
#    m.drawmeridians(np.arange(-180., 181., 10.))
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    # add colorbar
    cb = m.colorbar(imag1, "right", size="5%", pad="2%")
    plt.title('East-West accuracy [mm/year]')
    plt.show()

    # Up - Down accuracy [mm/year]
    if fill_gaps:
        # East - West accuracy [mm/year]
        # select the point not NaN
        good_points = np.where(np.isfinite(Deform.deform_UD))
        # Do an interpolartion for the missing values
        lat_flat = lat[good_points].flatten()
        lat_flat = (lat_flat.reshape([1, lat_flat.size])).T
        lon_flat = lon[good_points].flatten()
        lon_flat = (lon_flat.reshape([1, lon_flat.size])).T
        grid_points = (np.hstack((lat_flat, lon_flat)))
        deform_flat = Deform.deform_UD[good_points].flatten()
        deform_flat = (deform_flat.reshape([1, deform_flat.size])).T
        deform = griddata(grid_points, deform_flat, (lat, lon),
                          method='linear')
        deform_UD = deform[:, :, 0]
    else:
        deform_UD = Deform.deform_UD

    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    # setup Lambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    Masked_deform_UD = np.ma.array(deform_UD, mask=np.isnan(deform_UD))
    deform2_im = maskoceans(lon, lat, Masked_deform_UD)
    cmap = plt.cm.OrRd
    cmap.set_bad(color='w', alpha=1.)
    imag2 = m.pcolormesh(lon, lat, deform2_im, shading='gouraud', cmap=cmap,
                         latlon=True, vmin=0., vmax=10)
    m.drawmapboundary(fill_color='white')
#    m.drawparallels(np.arange(-90., 91., 10.))
#    m.drawmeridians(np.arange(-180., 181., 10.))
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    # add colorbar
    cb = m.colorbar(imag2, "right", size="5%", pad="2%")
    plt.title('Up-Down accuracy [mm/year]')
    plt.show()

    # North - South accuracy [mm/year]
    if fill_gaps:
        # East - West accuracy [mm/year]
        # select the point not NaN
        good_points = np.where(np.isfinite(Deform.deform_NS))
        # Do an interpolartion for the missing values
        lat_flat = lat[good_points].flatten()
        lat_flat = (lat_flat.reshape([1, lat_flat.size])).T
        lon_flat = lon[good_points].flatten()
        lon_flat = (lon_flat.reshape([1, lon_flat.size])).T
        grid_points = np.hstack((lat_flat, lon_flat))
        deform_flat = Deform.deform_NS[good_points].flatten()
        deform_flat = (deform_flat.reshape([1, deform_flat.size])).T
        deform = griddata(grid_points, deform_flat, (lat, lon),
                          method='linear')
        deform_NS = deform[:, :, 0]
    else:
        deform_NS = Deform.deform_NS

    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    # setup plot_chLambert Conformal basemap.
    m = Basemap(projection='cyl', llcrnrlat=lat_min, urcrnrlat=lat_max,
                llcrnrlon=lon_min, urcrnrlon=lon_max, resolution='c')
    # draw coastlines.
    m.drawcoastlines()
    Masked_deform_NS = np.ma.array(deform_NS, mask=np.isnan(deform_NS))
    deform3_im = maskoceans(lon, lat, Masked_deform_NS)
    cmap = plt.cm.OrRd
    cmap.set_bad(color='w', alpha=1.)
    imag3 = m.pcolormesh(lon, lat, deform3_im, shading='gouraud', cmap=cmap,
                         latlon=True, vmin=0., vmax=100)
    m.drawmapboundary(fill_color='white')
#    m.drawparallels(np.arange(-90., 91., 10.))
#    m.drawmeridians(np.arange(-180., 181., 10.))
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.xticks(xticks)
    plt.yticks(yticks)
    # add colorbar
    cb = m.colorbar(imag3, "right", size="5%", pad="2%")
    plt.title('North-South accuracy [mm/year]')
    plt.show()

    # Final time
    end_time = time.time()
    total_time = (end_time - start_time)/60.

    print('==================================================')
    print('Total time ', total_time, ' minutes')
    print('==================================================')
#    dinsar_pat_main(system = 'saocom', option=3, Coh_Map_Flag=True,
#                    bistatic=False, tomo=True)
    return Deform


def plot_ch(lon, lat, lat_arr, lon_arr, tl1, timeline):

    # Number of acquisitions
    Nasc = np.zeros([lon.shape[0], lon.shape[1]], dtype=np.int)
    Ndesc = np.zeros([lon.shape[0], lon.shape[1]], dtype=np.int)
    Nfinal_asc = np.zeros([lon.shape[0], lon.shape[1]], dtype=np.int)
    Nfinal_desc = np.zeros([lon.shape[0], lon.shape[1]], dtype=np.int)

    for ii in range(lon.shape[0]):
        for jj in range(lon.shape[1]):
            Nasc[ii, jj] = len(tl1.asc_acqs[ii][jj].theta_i)
            Ndesc[ii, jj] = len(tl1.desc_acqs[ii][jj].theta_i)
            if timeline:
                Nfinal_asc[ii, jj] = len(tl1.asc_TAP_timeline[ii][jj].theta_i)
                Nfinal_desc[ii, jj] = len(tl1.desc_TAP_timeline[ii][jj].
                                          theta_i)

    # set the colorbar
    cmap = plt.get_cmap('jet', np.max(Nasc)-np.min(Nasc)+1)
    cmaplist = [cmap(i) for i in range(cmap.N)]
    cmaplist[0] = (0, 0, 0, 0)
#    cmaplist[1] = (0, 0, 0, 0)
    cmap1 = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    cmap = plt.get_cmap('jet', np.max(Ndesc)-np.min(Ndesc)+1)
    cmaplist = [cmap(i) for i in range(cmap.N)]
    cmaplist[0] = (0, 0, 0, 0)
#    cmaplist[1] = (0, 0, 0, 0)
    cmap2 = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    cmap = plt.get_cmap('jet', np.max(Nfinal_asc)-np.min(Nfinal_asc)+1)
    cmaplist = [cmap(i) for i in range(cmap.N)]
    cmaplist[0] = (0, 0, 0, 0)
    cmap3 = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    cmap = plt.get_cmap('jet', np.max(Nfinal_desc)-np.min(Nfinal_desc)+1)
    cmaplist = [cmap(i) for i in range(cmap.N)]
    cmaplist[0] = (0, 0, 0, 0)
    cmap4 = cmap.from_list('Custom cmap', cmaplist, cmap.N)

    # plots
    v = [np.min(lon_arr), np.max(lon_arr), np.min(lat_arr), np.max(lat_arr)]
    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    plt.imshow(Nasc, origin='lower', extent=v,cmap=cmap1)
    ticks = np.arange(np.min(Nasc),np.max(Nasc)+1)
    tickpos = np.linspace(ticks[0] + .5, ticks[-1] - .5, len(ticks));
    tickpos = ticks[0:-1]+0.5
    cax = plt.colorbar(ticks=tickpos)
    cax.set_ticklabels(ticks)
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.title('Ascending acquisitions')
    plt.show()



    plt.figure(figsize=(14, 6))
    plt.rc('font', **font)
    plt.imshow(Ndesc, origin='lower', extent=v, cmap=cmap2)
    ticks = np.arange(np.min(Ndesc),np.max(Ndesc)+1)
    tickpos = np.linspace(ticks[0] + .5, ticks[-1] - .5, len(ticks));
    tickpos = ticks[0:-1]+0.5
    cax = plt.colorbar(ticks=tickpos)
    cax.set_ticklabels(ticks)
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.title('Merged ascending acquisitions')
    plt.show()
    plt.xlabel('Longitude [deg]')
    plt.ylabel('Latitude [deg]')
    plt.title('Descending acquisitions')
    plt.show()
    if timeline:
        plt.figure(figsize=(14, 6))
        plt.rc('font', **font)
        plt.imshow(Nfinal_asc, origin='lower', extent=v, cmap=cmap3)
        tickpos = ticks[0:-1]+0.5
        cax = plt.colorbar(ticks=tickpos)
        cax.set_ticklabels(ticks)
#        plt.colorbar()
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.title('Merged ascending acquisitions')
        plt.show()

        plt.figure(figsize=(14, 6))
        plt.rc('font', **font)
        plt.imshow(Nfinal_desc, origin='lower', extent=v, cmap=cmap4)
        ticks = np.arange(np.min(Nfinal_desc),np.max(Nfinal_desc)+1)
#        plt.colorbar()
        tickpos = ticks[0:-1]+0.5
        cax = plt.colorbar(ticks=tickpos)
        cax.set_ticklabels(ticks)
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.title('Merged descending acquisitions')
        plt.show()