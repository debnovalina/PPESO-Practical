import numpy as np


def gauss_hypergeo_function(a, b, c, z_):
    """ Gauss hypergeometric function 2F1(a,b,c,z).

        This function::

            - Converges for |z|<1.
            - Converges for |z|=1 only for Re{c-a-b}>0.

        :author: Maria Sanjuan-Ferrer.
        
        :param a: Function parameter.
        :type a: float
        :param b: Function parameter.
        :type b: float
        :param c: Function parameter.
        :type c: float
        :param z: Function variable.
        :type z: float or 1-D float array

        :returns: Function result.
    """
    shp = z_.shape
    z = z_.flatten()

    if isinstance(z.flatten()[0], complex):
        f_res = np.zeros([np.size(z)], complex)
    else:
        f_res = np.zeros([np.size(z)], float)

    n_max = 1.e5
    f_n_1_min = 1.e-12
    for index in range(np.size(z)):
        d_n = 1.
        f = 1.
        n = 0.
        condition = False
        while condition is False:
            d_n_1 = (n+a)*(n+b)/((n+1.)*(n+c))*d_n
            f = f+d_n_1*z[index]**(n+1.)
            d_n = d_n_1
            n = n+1.
            condition = (np.abs(d_n_1*z[index]**(n+1.)) < f_n_1_min) or (n == n_max)
        f_res[index] = f

    return f_res.reshape(shp)
