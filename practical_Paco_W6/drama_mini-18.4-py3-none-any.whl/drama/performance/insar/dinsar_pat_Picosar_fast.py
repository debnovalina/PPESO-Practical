from collections import namedtuple
from tkinter import Tk
from tkinter import filedialog as filedial

import numpy as np
from scipy.interpolate import interp1d

import drama.atmosphere.APSCorrelation as APS
import drama.geo.sar as geosar
import drama.mission.timeline as tl
from drama import constants as const
from drama.io import cfg
from drama.performance.sar.system import load_mod_perf
from drama.utils.misc import db2lin
from drama.utils.read_backscattering import load_Cband_sigma0


def atm_power(at_atmo, sigmaAtm, max_dist=3000):

    """ Function for retrieving the APS at the height of the atmosphere from
        the ground and at a fixed alon track distance assuming a linear trend
        for the autocorrelation function (First approximation)

        :author: Mariantonietta Zonno

        :param at_atmo: along track separation at the height of atmosphere from
                        ground
        :type at_atmo: float
        :param sigmaAtm: Standard deviations of the APS (meters).
        :type sigmaAtm: float
        :param max_dist: Distance at which the APS autocorrelation becomes zero
        :type max_dist: float

        :returns: APS standard deviation
    """

    distance = np.arange(0, max_dist)
    atm_pow = np.linspace(sigmaAtm**2, 0, max_dist)

    interp = interp1d(distance, atm_pow)

    if at_atmo > max_dist:
        atm_ = 0
    else:
        atm_ = interp(at_atmo)

    az_sigmaAtm = np.sqrt((sigmaAtm**2 - atm_))

    return az_sigmaAtm


def Bistatic_hcrb(aps1, at_atmo, acqTime, nLooks_M, nLooks_S, lambdaa, SNR_M,
                  SNR_S, theta_squint, tau=40., gamma0=0.95, gammaInf=0.15):

    """ Function for calculating the performance in the along and across track
        direction for of DINSAR using the hybrid Cramer-Rao bound.

        :author: Mariantonietta Zonno

        :param aps1: instance of the class for the APS delay variance
        :type aps1: class instance
        :param at_atmo: along track separation at the height of atmosphere from
                        ground
        :type at_atmo:  float
        :param acqTime: Acquistion time vector.
        :type acqTime:  1-D float array
        :param nLooks_M: Number of looks of the master
        :type nLooks_M: float
        :param nLooks_S: Number of looks of the slave
        :type nLooks_S: float
        :param lambdaa: Wavelenght (m).
        :type lambdaa: float
        :param SNR_M: Signal-to-noise ratio for the master system (linear).
        :type SNR_M: float
        :param SNR_S: Signal-to-noise ratio  for the slave system (linear).
        :type SNR_S: float
        :param theta_squint: Squint angle between master and slave (rad)
        :type theta_squint: float
        :param tau: Decorrelation time (days).
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: float

        :returns: standard deviation in Los and azimuth
    """

    # Some variables
    rTemp = np.exp(-1./tau)
    nAcq = np.size(acqTime)
    m1 = np.outer(acqTime, np.ones(nAcq))

    # Across Track Hybrid Cramer-Rao bound

    # GammaSNR for master and slave and resulting matrix X
    gamSnr_M = SNR_M/(1. + SNR_M)
    gamSnr_S = SNR_S/(1. + SNR_S)
    gam_M = (gamSnr_M*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_M*gamma0)*np.eye(nAcq))
    gam_S = (gamSnr_S*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf) + (1.-gamSnr_S*gamma0)*np.eye(nAcq))
    X = (2.*nLooks_M*(gam_M*np.linalg.inv(gam_M)-np.eye(nAcq)) +
         2.*nLooks_M*(gam_S*np.linalg.inv(gam_S)-np.eye(nAcq)))
    theta = 4.*np.pi / lambdaa * np.transpose(m1[:, 0])
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    sigmaAtm = 4 * np.pi * aps1.sigma_atm_m / lambdaa
    Vww = (sigmaAtm)**2.*np.eye(nAcq)
    kk4 = X + np.linalg.inv(Vww)
    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    sigma_LOS = np.sqrt(kk[0, 0])*365.*1000.   # mm/year

    # Along Track Hybrid Cramer-Rao bound

    # Equivalent phase variance resulting from the combination of the variance
    # for the two different acquisitions:
    var = ((1-gamSnr_M**2)/(2*nLooks_M*gamSnr_M**2) +
           (1-gamSnr_S**2)/(2*nLooks_M*gamSnr_S**2))
    # Equivalent gamma corresponding to the equivalent phase variance
    gammaSnr = np.sqrt(1./(2*nLooks_M*var+1))
    gamma = (gammaSnr*((gamma0-gammaInf)*rTemp**(np.abs(m1-np.transpose(m1))) +
             gammaInf)+(1.-gammaSnr*gamma0)*np.eye(nAcq))
    # retrieve the APS power at the given along track separation at 1km height
#    az_sigmaAtm = atm_power(at_atmo, aps1.sigma_atm_m)
    az_sigmaAtm = aps1.get_auto_at_delta_x(at_atmo) # meters
    az_sigmaAtm = 2*np.pi*az_sigmaAtm/lambdaa  # one way
    theta = 4.*np.pi / lambdaa * np.sin(theta_squint/2)*np.transpose(m1[:, 0])
    X = (nLooks_M*(gamma*np.linalg.inv(gamma) - np.eye(nAcq)))
    kk1 = theta.dot(X).dot(theta[:, np.newaxis])
    kk2 = theta.dot(X)
    kk3 = X.dot(theta[:, np.newaxis])
    Vww = (np.sqrt(2)*az_sigmaAtm)**2.*np.eye(nAcq)
    kk4 = X + np.linalg.inv(Vww)
    tmp1 = np.hstack((kk1, kk2))
    tmp2 = np.hstack((kk3, kk4))
    kk = np.vstack((tmp1, tmp2))
    kk = np.linalg.inv(kk)
    sigmaAz = np.sqrt(kk[0, 0])*365.*1000.   # mm/year

    return sigma_LOS, sigmaAz


def get_3d_accuracy(elos, stddev, option):

    """ Function for calculating the accuracy of the 3D vector.

        :param elos: Line-of-sight vectors, where (x,y,z)=(East,North,Up).
        :type elos: 2-D float array
        :param stddev: Standard deviations of the LoS measurements.
        :type stddev: 1-D float array
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer

        :returns: 3d motion covariance matrix

    """

    nTracks = np.size(stddev)

    # Building covariance matrix
    weights = np.zeros([nTracks, nTracks])
    for mm in range(np.size(stddev)):
        weights[mm, mm] = 1./(stddev[mm]**2.)

    # Options
    if option == 1:
        # Constraining motion only in the up-down direction
        # x is East, y is North, z is Up
        elos_ = elos[:, 2]
        variance3d = 1./(elos_.dot(weights).dot(elos_[:, np.newaxis]))

        aux = np.ones((3, 3))*1.e6
        aux[2, 2] = variance3d

        variance3d = np.copy(aux)

    elif option == 2:
        # Constrining motion only in the east-west, up-down plane
        # x is East, y is North, z is Up
        aux = np.copy(elos)
        aux[:, 1] = aux[:, 2]
        elos_ = aux[:, 0:2]
        variance3d = np.linalg.inv(np.transpose(elos_).dot(weights).dot(elos_))

        aux = np.ones((3, 3))*1.e6
        aux[0, 0] = variance3d[0, 0]
        aux[2, 0] = variance3d[1, 0]
        aux[2, 2] = variance3d[1, 1]
        aux[0, 2] = variance3d[0, 1]

        variance3d = np.copy(aux)

    elif option == 3:
        matrix = np.transpose(elos).dot(weights).dot(elos)
        variance3d = np.linalg.inv(matrix)
    else:
        print('Singular matrix, SVD inversion ')
        variance3d = np.zeros((3, 3))+np.nan
        # SVD inversion of observation matrix
        # x is East, y is North, z is Up
        A = np.transpose(elos).dot(weights).dot(elos)
        U, s, V = np.linalg.svd(A)
        poszero = np.where(s < 0.002)
        diag = np.zeros((3, 3))
        for ix in range(3):
            if s[ix] != 0.0:
                diag[ix, ix] = 1./s[ix]
        if np.size(poszero) > 0:
            diag[poszero, poszero] = 0.0

        variance3d = V.dot(diag).dot(np.transpose(U))

        if np.size(poszero) > 0:
            variance3d[1, 1] = 1.e6

    return variance3d


def dinsar_perf_tool(aps1, nImages,  SARPerf_M, SARPerf_S,
                     acqArray, option, Horb, Delta_track,  lat_dist=0,
                     lon_dist=0, SARPerf_2=None, inc_angle_B=None, azCorr=1,
                     deltax=100., deltagr=100., sigma0=-15., tau=60.,
                     gamma0=0.95, gammaInf=0.15, fixedheight=1000):

    """ Function for calculating the D-InSAR performance analysis.
        :param aps1: instance of the class for the APS delay variance
        :type aps1: class instance
        :param SARPerf: SAR performance parameters.
        :type SARPerf: named tuple
        :param acqArray: Array containing information about the acquisitions.
        :type acqArray: named tuple
        :param option: Option=1 for motion only in Up-Down;
                       option=2 for motion in East-West and Up-Down;
                       option=3 for true 3D motion (East-West, North-South,
                                                    Up-Down);
                       option=another for true 3D motion through SVD inversion.
        :type option: integer
        :param azCorr: If azCorr=1, azimuth correction is performed.
        :type azCorr: integer
        :param deltax: Posting requirement in along-track.
        :type deltax: float
        :param deltagr: Posting requirement in ground-range.
        :type deltagr: float
        :param sigma0: Normalized sigma zero of distributed scatterer
                       (or equivalent RCS of point-like targets) (dB).
        :type sigma0 : float
        :param tau: Decorrelation time (days). Optional.
        :type tau: float
        :param gamma0: Coherence at time = 0.
        :type gamma0: float
        :param gammaInf: Coherence at time = inf.
        :type gammaInf: floatd
        :param fixedheight: Height of the atmosphere from the ground
        :type fixedheight: float
        :returns: named tuple with information the standard deviation of the
                  LoS measurements (mm/year) and the covariance matrix of the
                  3D vector (mm**2/year**2).
    """

    tuple_res = namedtuple('DINSAR_PAT_OUT', ['stddev', 'var3d'])

    # Some constants
    freq = SARPerf_M.f0
    c0 = const.c
    lambdaa = c0/freq

    acqtime = acqArray.acqtime

    # Number of subswaths
    subswaths = len(SARPerf_M.theta)

    # Number of different geometries
    Nasc = acqArray.Nasc
    Ndesc = acqArray.Ndesc

    # monostatic and bistatic
    nTracks_asc = Nasc*2
    nTracks_desc = Ndesc*2

    # Initializing output values
    elos_asc = np.zeros([Nasc, 3])            # LOS vectors in ascending
    elos_desc = np.zeros([Ndesc, 3])          # and descending
    elos_az_asc = np.zeros([Nasc, 3])         # Azimuth vectors in ascending
    elos_az_desc = np.zeros([Ndesc, 3])       # and descending
    looks_asc = np.zeros([nTracks_asc])       # Number of looks
    looks_desc = np.zeros([nTracks_desc])
    SNR_asc = np.zeros([nTracks_asc])         # SNR
    SNR_desc = np.zeros([nTracks_desc])
    theta_squint_a = np.zeros([Nasc, 1])      # Real squint angle
    theta_squint_d = np.zeros([Ndesc, 1])

    #                               Ascending                                #

    for mm in range(Nasc):

        # Mono

        inc_angle = acqArray.inc_angle_asc[mm]    # rad
        northing = acqArray.northing_asc[mm]      # rad
        los = np.array([np.sin(inc_angle)*np.sin(northing),
                        -np.sin(inc_angle)*np.cos(northing),
                        np.cos(inc_angle)])
        los_mono = -los/np.sqrt(np.sum(los**2.))  # Normalizing

        # Bist

        inc_angle_2 = acqArray.inc_angle_asc_2[mm]  # rad
        northing_2 = acqArray.northing_asc_2[mm]    # rad
        los_bist = np.array([np.sin(inc_angle_2)*np.sin(northing_2),
                             -np.sin(inc_angle_2)*np.cos(northing_2),
                             np.cos(inc_angle_2)])
        los_bist = -los_bist/np.sqrt(np.sum(los_bist**2.))

        # Equivalent Bist

        los_bist_eq = (los_bist+los_mono)/2.
        los_bist_eq = los_bist_eq/np.sqrt(np.sum(los_bist_eq**2.))
        los_az_eq = np.array([los_bist_eq[1], -los_bist_eq[0], 0.0])
        # los_az_eq =  los_bist - los_mono
        los_az_eq = los_az_eq/np.sqrt(np.sum(los_az_eq**2.))

        elos_asc[mm, :] = los_bist
        elos_az_asc[mm, :] = los_az_eq
        theta_squint_a[mm] = np.arccos(np.sum(los_mono*los_bist))

        # System Performance
        # Monostatic
        if subswaths > 1:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle)
            ind = positions[-1]
            bw = SARPerf_M.Brg[ind[0]]
            azRes = 20  # tandem l = 7 # np.mean(SARPerf.az_res[ind[0]])
            nesz = SARPerf_M.sigma_ne[ind[0], 3, ind[1]]
        else:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle_2)
            ind = positions[-1]
            bw = SARPerf_M.Brgs_S,
            azRes = np.mean(SARPerf_M.az_res)
            nesz = SARPerf_M.sigma_ne[ind[0]]
        rgRes = c0/2./bw
        grRes = rgRes / np.cos(inc_angle)
        looks_asc[mm] = (deltax/azRes)*(deltagr/grRes)
        # Computing SNR
        if np.atleast_1d(sigma0) is sigma0:
            sigma0_ = load_Cband_sigma0(sigma0, acqArray.lat, acqArray.lon,
                                        inc_angle)
            SNR_asc[mm] = db2lin(sigma0_-nesz)
        else:
            SNR_asc[mm] = db2lin(sigma0-nesz)
        # Bistatic
        if subswaths > 1:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle_2)
            ind = positions[-1]
            bw = SARPerf_M.Brg[ind[0]]
            azRes = 20  # np.mean(SARPerf.az_res[ind[0]])
#            nesz = SARPerf_S.sigma_ne[ind[0],ind[1]]
            nesz = SARPerf_M.sigma_ne[ind[0], 3, ind[1]] + 6
        else:
            positions = np.argwhere(SARPerf_S.theta <= inc_angle_2)
            ind = positions[-1]
            bw = SARPerf_S.Brg
            azRes = np.mean(SARPerf_S.az_res)
            nesz = SARPerf_S.sigma_ne[ind[0]]
        rgRes = c0/2./bw
        grRes = rgRes / np.cos(inc_angle)
        looks_asc[mm+Nasc] = (deltax/azRes)*(deltagr/grRes)
        if np.atleast_1d(sigma0) is sigma0:
            sigma0_ = load_Cband_sigma0(sigma0, acqArray.lat, acqArray.lon,
                                        inc_angle_2)
            SNR_asc[mm+Nasc] = db2lin(sigma0_-nesz)
        else:
            SNR_asc[mm+Nasc] = db2lin(sigma0-nesz)

    #                               Descending                                #

    for mm in range(Ndesc):

        # Mono

        inc_angle = acqArray.inc_angle_desc[mm]  # rad
        northing = acqArray.northing_desc[mm]    # rad
        los = np.array([np.sin(inc_angle)*np.sin(northing),
                        -np.sin(inc_angle)*np.cos(northing),
                        np.cos(inc_angle)])
        los_mono = -los/np.sqrt(np.sum(los**2.))   # Normalizing

        # Bist

        inc_angle_2 = acqArray.inc_angle_desc_2[mm]  # rad
        northing_2 = acqArray.northing_desc_2[mm]    # rad
        los_bist = np.array([np.sin(inc_angle_2)*np.sin(northing_2),
                             -np.sin(inc_angle_2)*np.cos(northing_2),
                             np.cos(inc_angle_2)])
        los_bist = -los_bist/np.sqrt(np.sum(los_bist**2.))

        # Equivalent Bist

        los_bist_eq = (los_bist+los_mono)/2.
        los_bist_eq = los_bist_eq/np.sqrt(np.sum(los_bist_eq**2.))
        los_az_eq = np.array([los_bist_eq[1], -los_bist_eq[0], 0.0])
        # los_az_eq =  los_bist - los_mono
        los_az_eq = los_az_eq / np.sqrt(np.sum(los_az_eq**2.))

        elos_desc[mm, :] = los_bist
        elos_az_desc[mm, :] = los_az_eq
        theta_squint_d[mm] = np.arccos(np.sum(los_mono*los_bist))

        # System Performance
        #  Monostatic
        if subswaths > 1:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle)
            ind = positions[-1]
            bw = SARPerf_M.Brg[ind[0]]
            azRes = 20.  # tandem l = 7 # np.mean(SARPerf.az_res[ind[0]])
            nesz = SARPerf_M.sigma_ne[ind[0], 3, ind[1]]
        else:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle)
            ind = positions[-1]
            bw = SARPerf_M.Brg
            azRes = np.mean(SARPerf_M.az_res)
            nesz = SARPerf_M.sigma_ne[ind[0]]
        if np.atleast_1d(sigma0) is sigma0:
            sigma0_ = load_Cband_sigma0(sigma0, acqArray.lat, acqArray.lon,
                                        inc_angle)
            SNR_desc[mm] = db2lin(sigma0_-nesz)
        else:
            SNR_desc[mm] = db2lin(sigma0-nesz)
        rgRes = c0/2./bw
        grRes = rgRes / np.cos(inc_angle)
        looks_desc[mm] = (deltax/azRes)*(deltagr/grRes)
        #  Bistatic
        if subswaths > 1:
            positions = np.argwhere(SARPerf_M.theta <= inc_angle_2)
            ind = positions[-1]
            bw = SARPerf_M.Brg[ind[0]]
            azRes = 20.  # tandem l = 7 # np.mean(SARPerf.az_res[ind[0]])
            nesz = SARPerf_M.sigma_ne[ind[0], 3, ind[1]] + 6
        else:
            positions = np.argwhere(SARPerf_S.theta <= inc_angle_2)
            ind = positions[-1]
            bw = SARPerf_S.Brg
            azRes = np.mean(SARPerf_S.az_res)
            nesz = SARPerf_S.sigma_ne[ind[0]]
        if np.atleast_1d(sigma0) is sigma0:
            sigma0_ = load_Cband_sigma0(sigma0, acqArray.lat, acqArray.lon,
                                        inc_angle_2)
            SNR_desc[mm+Ndesc] = db2lin(sigma0_-nesz)
        else:
            SNR_desc[mm+Ndesc] = db2lin(sigma0-nesz)
        rgRes = c0/2./bw
        grRes = rgRes / np.cos(inc_angle)
        looks_desc[mm+Ndesc] = (deltax/azRes)*(deltagr/grRes)

    # Output vectors for the Finalerformance
    std_los_a = np.zeros(Nasc)
    std_az_a = np.zeros(Nasc)
    std_los_d = np.zeros(Ndesc)
    std_az_d = np.zeros(Ndesc)

    for mm in range(Nasc):
        inc_angle = acqArray.inc_angle_asc[mm]
        theta_squint = theta_squint_a[mm]
        print('Delta_track and squint', Delta_track, np.degrees(theta_squint))
        R_ = geosar.inc_to_sr(inc_angle, fixedheight)
        at_atmo = R_*np.sin(theta_squint)
        print('at_atmo', at_atmo)
        sigma_los_a, sigma_az_a = Bistatic_hcrb(aps1, at_atmo, acqtime,
                                                looks_asc[mm],
                                                looks_asc[mm+Nasc], lambdaa,
                                                SNR_asc[mm], SNR_asc[mm+Nasc],
                                                tau=20., gamma0=0.5,
                                                gammaInf=0.5,
                                                theta_squint=theta_squint)
        std_los_a[mm] = sigma_los_a
        std_az_a[mm] = sigma_az_a

    for mm in range(Ndesc):
        inc_angle = acqArray.inc_angle_desc[mm]
        theta_squint = theta_squint_d[mm]
        print('Delta_track and squint', Delta_track, np.degrees(theta_squint))
        R_ = geosar.inc_to_sr(inc_angle, fixedheight)
        at_atmo = R_*np.sin(theta_squint)
        print('at_atmo', at_atmo)
        sigma_los_d, sigma_az_d = Bistatic_hcrb(aps1, at_atmo, acqtime,
                                                looks_desc[mm],
                                                looks_desc[mm+Nasc], lambdaa,
                                                SNR_desc[mm],
                                                SNR_desc[mm+Ndesc],
                                                tau=20., gamma0=0.5,
                                                gammaInf=0.5,
                                                theta_squint=theta_squint)
        std_los_d[mm] = sigma_los_d
        std_az_d[mm] = sigma_az_d

    elos = np.vstack((elos_asc, elos_desc, elos_az_asc, elos_az_desc))
    stddev = np.hstack((std_los_a, std_los_d, std_az_a, std_az_d))
    variance3d = get_3d_accuracy(elos, stddev, option)
    result = tuple_res(stddev, variance3d)

    return result


def dinsar_pat_main(param_File=None, option=3, ext_orbit=False):
    """ Function for calculating the D-InSAR performance analysis.

        :returns: named tuple with information the standard deviation of the
                  LoS measurements (mm/year) and the covariance matrix of the
                  3D vector (mm**2/year**2).
    """

    # Open parameter file to derive user inputs
    if param_File is None:
        # Parameter File
        Tk().withdraw()
        param_File = filedial.askopenfilename(title='Select parameter file')

    # load the paths from the parameter file
    inData = cfg.ConfigFile(param_File)
    MainPath = inData.path.MainPath
    system = inData.path.system
    perf_File = inData.path.perf_File
    # Load SAR performance
    modeId = ['PicoSAR_SysID001_MonoScan', 'PicoSAR_SysID011_BiScan',
              'PicoSAR_SysID012_BiStrip']
    # Master
    SARPerf_M = load_mod_perf(systemName=system, par_fileName=param_File,
                              perf_fileName=perf_File, polarization='HH',
                              mode=modeId[0])
    # Picosar
    SARPerf_S = load_mod_perf(systemName=system, par_fileName=param_File,
                              perf_fileName=perf_File, polarization='HH',
                              mode=modeId[2])

    # Along track separation between master and slave
    Delta_track = inData.formation_primary.dau[0]

    deltax = inData.misc.deltax           # along-track [m]
    deltagr = inData.misc.deltagr         # ground-range [m]
    totalTime = inData.misc.totalTime     # Total time of acquisitions (days)
    days_cycle = inData.orbit.days_cycle
    # Inputs to the decorrelation model:
    tau = inData.misc.tau            # Decorrelation time (days)
    gamma0 = inData.misc.gamma0      # Coherence at time = 0
    gammaInf = inData.misc.gammaInf  # Coherence at time = inf

    # Lat - lon grid of the points of which the deformation has to be computed
    lat_min = inData.misc.lat_min   # Minimum latitude (deg)
    lat_max = inData.misc.lat_max   # Maximum latitude (deg)
    lat_res = inData.misc.lat_res   # Latitude resolution (deg)
    lon_min = inData.misc.lon_min   # Minimum longitude (deg)
    lon_max = inData.misc.lon_max   # Maximum longitude (deg)
    lon_res = inData.misc.lon_res

    lat_arr = np.arange(lat_min, lat_max+lat_res, lat_res)
    lon_arr = np.arange(lon_min, lon_max+lon_res, lon_res)
    lon = lon_arr.reshape([1, lon_arr.size]) + np.zeros([lat_arr.size,
                                                         lon_arr.size])
    lat = lat_arr.reshape([lat_arr.size, 1]) + np.zeros(lon_arr.shape)

    lat = inData.misc.lat_fix
    lon = inData.misc.lon_fix

    # acquisition timeline
    f1 = tl.FormationTimeline(param_File, secondary=True)

    # Ratio of valid incidence angles (according to swath)
    min_ = np.rad2deg(np.min(SARPerf_M.theta))
    max_ = np.rad2deg(np.max(SARPerf_M.theta))
    inc_range = [np.abs(min_), np.abs(max_)]
    Horb = f1.track.Horb
#    min_ = geosar.look_to_inc(np.deg2rad(inData.sar.near_1), Horb)
#    max_ = geosar.look_to_inc(np.deg2rad(inData.sar.far_1), Horb)
#    inc_range = np.degrees([np.abs(min_), np.abs(max_)])

    tl1 = tl.LatLonTimeline(par_file=param_File, lats=lat, lons=lon,
                            inc_angle_range=inc_range, ext_orbit=ext_orbit,
                            bistatic=True, SystemName=system, form=f1)

    asc_tl = tl1.asc_acqs
    desc_tl = tl1.desc_acqs
    asc_tl_2 = tl1.asc_acqs2
    desc_tl_2 = tl1.desc_acqs2

    AcqArray_B = namedtuple('Acq_Info', ['inc_angle_asc', 'inc_angle_desc',
                                         'northing_asc', 'northing_desc',
                                         'inc_angle_asc_2', 'inc_angle_desc_2',
                                         'northing_asc_2', 'northing_desc_2',
                                         'acqtime', 'Nasc', 'Ndesc', 'lat',
                                         'lon'])

    # Compute the autocorrelation function of the atmosphere
    aps1 = APS.aps_msquint(param_File)
    aps1.calculate_autocorrelation()

    # Monostatic
    inc_angle_asc = asc_tl[0].theta_i
    northing_asc = asc_tl[0].northing
    inc_angle_desc = desc_tl[0].theta_i
    northing_desc = desc_tl[0].northing
    N_asc = inc_angle_asc.size
    N_desc = inc_angle_desc.size

    # Bistatic
    inc_angle_asc_2 = asc_tl_2[0].theta_i
    northing_asc_2 = asc_tl_2[0].northing
    inc_angle_desc_2 = desc_tl_2[0].theta_i
    northing_desc_2 = desc_tl_2[0].northing

    # Time vector
    nImages = totalTime/days_cycle
    tAcq = np.arange(nImages)*days_cycle

    acqArray_B = AcqArray_B(inc_angle_asc, inc_angle_desc, northing_asc,
                            northing_desc, inc_angle_asc_2, inc_angle_desc_2,
                            northing_asc_2, northing_desc_2, tAcq, N_asc,
                            N_desc, lat, lon)
    output = dinsar_perf_tool(aps1, nImages, SARPerf_M=SARPerf_M,
                              SARPerf_S=SARPerf_S, acqArray=acqArray_B,
                              option=option, Horb=Horb,
                              Delta_track=Delta_track, lat_dist=0, lon_dist=0,
                              azCorr=1, deltax=deltax, deltagr=deltagr,
                              sigma0=-15, tau=tau, gamma0=gamma0,
                              gammaInf=gammaInf)

    deform_EW = np.sqrt(output.var3d[0, 0])
    deform_UD = np.sqrt(output.var3d[2, 2])
    deform_NS = np.sqrt(output.var3d[1, 1])
    print('deform_EW', deform_EW)
    print('deform_UD', deform_UD)
    print('deform_NS', deform_NS)

    np.save(MainPath+'/deform_EW', deform_EW)
    np.save(MainPath+'/deform_UD', deform_UD)
    np.save(MainPath+'/deform_NS', deform_NS)

if __name__ == '__main__':

    Filename = 'PICOSAR_CRYO_Drift_new.par'
    Dir = '/home/zonn_ma/Codes/Python/drama/drama/coverage/params/Picosar/'
    dinsar_pat_main(Dir+Filename, option=3)
