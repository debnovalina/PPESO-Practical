from scipy.special import gamma, hyp2f1
import numpy as np
# from drama.performance.insar import gauss_hypergeo_function


def p_Delta_Phi(Delta_Phi, N_l, rho):
    """ PDF of the interferometric phase error.

        :author: Maria Sanjuan-Ferrer.
        
        :param Delta_Phi: Interfreometric phase error (rad).
        :type Delta_Phi: float or 1-D float array
        :param N_l: Number of looks.
        :type N_l: float
        :param rho: Correlation coefficient.
        :type rho: float

        :returns: Function result.
    """
    z = rho*np.cos(Delta_Phi)
    result = ((gamma(N_l+0.5)*((1.-rho**2.)**N_l)*z)/(2.*np.sqrt(np.pi)*gamma(N_l)*((1.-z**2.)**(N_l+0.5)))+
             ((1.-rho**2.)**N_l)/(2.*np.pi)*hyp2f1(N_l, 1., 0.5, z**2.))

    return result
