
"""
===============================================
Performance Package (:mod:`drama.performance`)
===============================================

.. currentmodule:: drama.performance

Subpackages
===========

.. toctree::
   :maxdepth: 1

   drama.performance.sar
   drama.performance.insar

"""
